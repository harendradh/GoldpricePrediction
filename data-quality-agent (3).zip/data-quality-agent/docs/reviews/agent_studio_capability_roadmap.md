# Fiserv DCS Agent Studio — Capability Gap Analysis

Based on the 5 screens exercised while building the DQ Agent (Sandbox/Chat, New Tool, New
Agent, New RAG Collection, Workflow Builder), plus the friction points we actually hit writing
`agent_studio/BUILD_GUIDE.md`. This is a capability wishlist, not a UX critique — see
`agent_studio_additional_findings.md` for more screen-level findings, and the "Design Review"
deck for the original 7.

**Caveat:** the left nav also showed **Dashboard**, **Library**, **Batch**, and **Schedules**
items we didn't open. Some gaps below may already be covered there — treat this as "not
visible from the 5 screens we used," not "confirmed absent," until someone checks those four.

---

## Must-have (blocks enterprise/regulated adoption at Fiserv scale)

### 1. Config-as-code export/import for Agents, Tools, RAG, Workflows
**Evidence:** `BUILD_GUIDE.md` is, in effect, a manually-written spec of what the Agent Studio
UI should hold — because there's no way to export what we click into a YAML/JSON file. Every
environment (dev/stg/prod) means re-clicking through the same forms by hand, with no diff, no
code review, and no way to reproduce a build if a workspace is lost.
**Ask:** an "Export config" / "Import config" action per Agent/Tool/RAG Collection/Workflow,
so definitions can live in git alongside the rest of this repo and go through normal PR review.

### 2. Environment promotion with an approval gate (dev → staging → prod)
**Evidence:** the DQ engine itself has change control for rules (`rule_catalog` proposals land
**disabled** until a human approves — see `docs/ARCHITECTURE.md` §6). Agent Studio has no
equivalent concept for promoting an Agent/Tool change into production; a bad system-instruction
edit or a wrong Genie Space ID goes live the moment someone clicks Save.
**Ask:** a promote-with-approval flow, mirroring the HITL pattern the DQ Agent already uses.

### 3. Built-in eval/regression test sets per Agent
**Evidence:** `BUILD_GUIDE.md` Step 5 is a hand-invented "run these 5 prompts in Sandbox and
eyeball the output" checklist, because there's no way to save that checklist *in the platform*
and have it re-run automatically. Every future edit to a Tool, the RAG doc, or the system
instruction requires someone to remember to re-run all 5 prompts by hand.
**Ask:** a saved "test set" of prompts + pass/fail assertions per Agent, runnable on demand and
(ideally) required before promotion (ties to #2).

### 4. Secrets vault with per-tool scoping and rotation
**Evidence:** `GENIE_CLIENT_ID`/`GENIE_CLIENT_SECRET` live as one shared pair in `backend/.env`,
edited directly by a platform admin, with no rotation workflow and no way to scope a second
Genie space to a different credential without renaming the env vars by hand (see Deep Dive #3
in the Design Review deck).
**Ask:** a secrets UI scoped per tool/team, with rotation support — the credential-guidance
callout already shown on the Genie tool form is a good start; it needs a backing store, not a
`.env` file.

### 5. Role-based access control (view / edit / clone / delete) per Tool, Agent, RAG, Workflow
**Evidence:** the README's stated design goal is "a shared product across teams and BUs" — but
every screen we saw (Tools, Agents, RAG) is a flat, ungated list. Nothing stops one BU's
builder from editing another BU's cloned `DQ Agent` or a shared tool like `dq_run_checks`.
**Ask:** ownership + permission scoping, at minimum team-level view/edit separation.

---

## Should-have (meaningful safety or productivity gain)

### 6. Observability/analytics dashboard (tokens, cost, latency, tool error rate)
No usage metrics were visible on any screen we exercised. Without this, a silently-failing or
slow tool (e.g. `dq_run_checks` timing out against a busy job queue) is invisible until a user
complains in chat.

### 7. A native "pause for human approval" node in Workflows
The DQ Agent's own HITL pattern (`dq_propose_rule` creates a disabled rule; a human enables it)
happens entirely *outside* Agent Studio, in Delta tables. A staged workflow like
`dq_profiler → dq_runner → dq_analyst` (see `agent_studio/agents/workflow_subagents.md`) has no
way to pause mid-chain for a human sign-off inside the platform itself.

### 8. Bulk operations across Agents/Tools
Rolling the DQ Agent out per-BU means cloning `DQ Agent` and attaching the same 10 tools to each
clone (`BUILD_GUIDE.md` → "Rollout across BUs"). Today that's one Agent at a time; adding a 9th
tool later means reopening every BU clone individually.

### 9. Tool impact analysis ("used by N agents") before editing shared code
A Python Function tool like `dq_run_checks` is shared code pasted into one place but consumed
by every BU's cloned agent. Editing it today has no visible blast-radius warning.

### 10. Standalone tool test/invoke screen
To verify a Tool works, we have to attach it to an Agent and get the LLM to decide to call it
in chat. A direct "invoke with sample args, see raw JSON" screen would isolate tool bugs from
agent-reasoning bugs — useful during `BUILD_GUIDE.md` Step 1 especially for the 9 Python
Function tools.

---

## Nice-to-have (polish)

### 11. Side-by-side agent/model comparison
Run the same prompt through two Agent versions (or two models) and diff responses — useful
before swapping `databricks-claude-sonnet-4-6` for a future model.

### 12. Conversation pinning/labeling in Sandbox
"Recents" today is an unlabeled list (see the Design Review deck's Sandbox finding). Pinning a
transcript as "onboarding smoke test — payments BU" would make it reusable as a regression
fixture, and ties directly into capability #3 once eval sets exist.

### 13. Starter templates per Tool Type
A skeleton Python Function (with the docstring-as-description convention we relied on in
`BUILD_GUIDE.md`) pre-filled in the Code box would reduce first-tool friction for teams newer
to the platform than the DQ team.
