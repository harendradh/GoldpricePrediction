# DQA — Enterprise Architecture (scale + coverage)

This document explains how the DQ Agent scales to **thousands of Delta tables and billions of
rows across BUs**, and maps **every data-quality aspect to a native Databricks capability**
(no third-party DQ engine). It supersedes the "single job + poll loop" view for production.

---

## 1. Why the naive design breaks at scale — and the fix

| Naive (v1) | Problem at scale | Native fix (v2) |
|-----------|------------------|-----------------|
| One job run per dataset, agent polls | Thousands of tables ⇒ serial, slow, costly | **Workflows `for_each` task** fans out N datasets in parallel on **serverless** compute |
| Full-table scan every run | Billion-row tables re-scanned nightly | **Incremental / partition-pruned** checks via Delta **CDF** + watermark; only new data scanned |
| Hand-rolled row-count anomaly | Weak, no seasonality, no drift | **Lakehouse Monitoring** (native profiling, drift, freshness, custom metrics) |
| `DESCRIBE` per table for metadata | N round-trips | **`system.information_schema`** bulk metadata + UC lineage/tags |
| Results table grows unbounded | Query + storage blowup | **Liquid clustering + partitioning + Predictive Optimization + retention** |
| Monitor-only | Bad data still lands downstream | **DLT/Lakeflow expectations** with `expect_or_drop`/`fail` + **quarantine tables** |
| Rules only static SQL | Can't cover distribution/PII/schema | Monitoring metrics + **UC data classification** + schema-history checks |

## 2. Component map (all native Databricks)

```
                       ┌────────────────────────── Agent Studio (ACA) ──────────────────────────┐
   User / Schedule ──► │  DQ Agent (Single or Custom Workflow) + Python-Function Tools + RAG      │
                       └───────────────┬─────────────────────────────────────────────────────────┘
                                       │ Databricks REST (Jobs 2.1, SQL Exec 2.0, Monitoring)
   ┌───────────────────────────────────┼────────────────────────────────────────────────────────┐
   │ DATABRICKS LAKEHOUSE               │                                                          │
   │                                    ▼                                                          │
   │  Control plane (Delta, UC)   ┌──────────────┐   Execution plane (serverless)                 │
   │  • dataset_registry          │  DQ Sweep    │   ┌───────────────────────────────┐            │
   │  • rule_catalog (versioned)  │  Workflow    │──►│ for_each dataset (parallel):  │            │
   │  • results / run_summary     │  (driver +   │   │   native rule engine (Photon) │──► results │
   │  • execution_log / audit     │  for_each)   │   └───────────────────────────────┘            │
   │                              └──────────────┘                                                 │
   │  Native quality services                                                                      │
   │  • Lakehouse Monitoring  → profile/drift/freshness metric tables                               │
   │  • DLT/Lakeflow expectations → inline enforce + quarantine                                     │
   │  • Delta CHECK / NOT NULL constraints → write-time enforcement                                 │
   │  • Unity Catalog → lineage, tags, PII classification, grants (multi-tenant)                    │
   │  • system.information_schema / system.access → metadata + audit at scale                       │
   │                                                                                                │
   │  Serving  • DQ Enterprise Scorecard (Lakeview dashboard) • SQL Alerts → Teams/ServiceNow        │
   └────────────────────────────────────────────────────────────────────────────────────────────┘
```

## 3. Execution model at scale — three tiers

1. **Inline (write-time)** — DLT/Lakeflow **expectations** + Delta **constraints**. Catches
   bad data *before it lands*. Quarantine to `<table>_quarantine`. Zero extra scan.
2. **Batch sweep (scheduled)** — `for_each` Workflow over `dataset_registry`, **serverless +
   Photon**, **incremental** (only new Delta versions). Runs the rule engine + refreshes
   Lakehouse Monitors. Scales horizontally by dataset; job queue caps concurrency.
3. **On-demand (agent/interactive)** — the agent triggers a single-dataset run or reads the
   latest scorecard / monitor metrics. Sub-minute for cached results.

## 4. Coverage matrix — every DQ aspect → native capability

| Aspect | Dimension | Native capability used |
|--------|-----------|------------------------|
| Nulls / blanks / missing | Completeness | rule engine `not_null` + Monitoring null-rate metric |
| Duplicates | Uniqueness | rule engine `unique` (GROUP BY/HAVING) + PK constraint |
| Type/format/range/domain | Validity | rule engine `range/regex/accepted_values` + DLT expectations |
| Cross-field logic | Consistency | rule engine `expression` + DLT `expect` |
| Reference match / golden | Accuracy | rule engine `custom_sql` join to reference/golden table |
| Foreign-key orphans | Integrity | rule engine `referential` (anti-join) + FK constraint |
| Freshness / SLA | Timeliness | Lakehouse Monitoring freshness + rule engine `freshness` |
| Volume anomaly | Volume | Lakehouse Monitoring drift on row-count + `row_count_anomaly` |
| Distribution / drift | Distribution | **Lakehouse Monitoring** profile + drift metrics (native) |
| Schema change | Schema | Delta history / `information_schema` diff + schema-evolution alert |
| PII / classification | Governance | **Unity Catalog** data classification + tags |
| Lineage / impact | Governance | **Unity Catalog lineage** (system tables) |
| Enforcement (block/quarantine) | All | **DLT expectations** `expect_or_drop`/`fail` + quarantine tables |
| Audit / who-ran-what | Compliance | `system.access.audit`, immutable `results`, `execution_log` |
| Access / multi-tenant | Governance | **UC grants + row filters/column masks** per BU |

## 5. Performance & cost controls

- **Serverless + Photon** for all check compute; autoscaling per dataset.
- **Incremental scanning**: store `last_checked_version`; scan only `_change_type` deltas
  via **Change Data Feed**, or prune by `freshness_ts_column` watermark.
- **Single aggregate scan** per table batches all column-level predicates (kept from v1).
- **Approx functions** (`approx_count_distinct`, `approx_percentile`) for profiling huge tables.
- **Sampling** for tier-3 datasets (configurable `sample_fraction`).
- **Liquid clustering** on `results`/`run_summary` by `dataset_id, run_ts`; **Predictive
  Optimization** for auto OPTIMIZE/VACUUM; retention policy on raw results.
- **Job queue + max concurrent runs** to bound cluster cost during the nightly sweep.

## 6. Governance, security, compliance (Fiserv-grade)

- **Unity Catalog** is the control boundary: agent reads aggregates only; raw rows never
  leave Databricks. Per-BU **grants**, **row filters**, **column masks**.
- **PII/PCI**: UC **data classification** tags drive masking + which columns get DQ rules.
- **Immutable audit**: `results` is append-only; `system.access.audit` records every job/SQL.
- **Change control**: `rule_catalog` is versioned (CDF); rule changes go through
  propose (disabled) → approve (enable) with the approver recorded.
- **Secrets**: service principal via OAuth; **Databricks secret scopes** / Azure Key Vault.

## 7. Reliability & observability of the platform itself

- DQ jobs emit metrics to `execution_log` (duration, rows scanned, cost tags).
- **SQL Alerts** on: RED datasets, missed freshness SLA, sweep failures, drift breaches.
- **Lakeview dashboard** (`deploy/dashboards/dq_enterprise_scorecard.lvdash.json`): enterprise scorecard (score by BU/criticality/dimension over time), deployed as an Asset Bundle resource alongside the jobs; the agent's `dq_get_dashboard_link` tool hands back its URL.
- Dead-letter: a rule that errors is recorded per-run and never fails the whole sweep.

## 8. CI/CD

- **Databricks Asset Bundles** deploy engine wheel, jobs, DLT pipelines, monitors, dashboards
  across dev/stg/prod. Rules seeded via versioned SQL. Unit tests gate the wheel build.
