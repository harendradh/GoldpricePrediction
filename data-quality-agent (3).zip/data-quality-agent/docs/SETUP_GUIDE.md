# Data Quality Agent — Complete End-to-End Setup Guide

One document, start to finish: from an empty Databricks workspace to a working `DQ Agent` in
Fiserv Agent Studio that a pilot BU can chat with. Follow the phases in order — each one
depends on the previous.

**Companion docs**, if you want more depth on a specific phase:
- `agent_studio/BUILD_GUIDE.md` — exhaustive field-by-field detail for Phases 5-9 below.
- `docs/ARCHITECTURE.md` — why the platform is built this way, at scale.
- `docs/RUNBOOK.md` — day-2 operations (rollout, guardrails, roadmap hooks).
- `docs/reviews/` — Agent Studio platform findings, if you hit friction building this.

**Time estimate:** ~2-3 hours the first time (mostly waiting on Databricks approvals for
service principals / workspace access); ~45 minutes for the Agent Studio portion alone.

---

## Phase 0 — Prerequisites checklist

Before starting, confirm you have:

- [ ] A Databricks workspace with **Unity Catalog** enabled, and permission to create a
      catalog/schema (or an admin who can run Phase 1 for you).
- [ ] Permission to create a **SQL Warehouse** (or an existing one to point at).
- [ ] Permission to create **service principals** / OAuth app registrations in the workspace.
- [ ] Access to **Fiserv DCS Agent Studio** (the ACA-hosted UI) with permission to create
      Tools, Agents, and RAG Collections.
- [ ] Whoever manages Agent Studio's `backend/.env` — you'll need them for Phase 4.
- [ ] Python 3.10+ locally, with the `databricks` CLI configured (`databricks auth login`)
      against your workspace. (`pip install build` is only needed later, if/when you switch
      Phase 2 from POC mode to a production wheel.)
- [ ] One pilot dataset in mind (a real Delta table you can register first), e.g.
      `payments.txn_master`.

---

## Phase 1 — Create the Databricks control tables

These four Delta tables under `governance.dq` are the entire metadata backbone — nothing
else in this system holds state outside them.

Run on a SQL Warehouse, **in this order**:

```bash
databricks sql -f sql/01_control_tables.sql        # dataset_registry, rule_catalog, results, run_summary
databricks sql -f sql/03_scale_optimizations.sql    # liquid clustering, retention, incremental-scan support
databricks sql -f sql/04_dashboard_and_alerts.sql   # exec dashboard views + SQL alert definitions
databricks sql -f sql/05_dashboard_extensions.sql   # dimension breakdown + RAG distribution views (dashboard)
databricks sql -f sql/02_seed_golden_rules.sql      # seeds baseline golden rules (run last, after the schema exists)
```

Verify:
```sql
SHOW TABLES IN governance.dq;
-- expect: dataset_registry, rule_catalog, results, run_summary (+ v_latest_scorecard view)
```

---

## Phase 2 — Deploy the DQ engine job

The engine (`src/dq_agent/engine/`) runs inside Databricks as a Job, not inside Agent Studio.

**For a POC, skip the wheel entirely.** `deploy/databricks.job.yml` is already set up this
way by default: `databricks bundle deploy` syncs this whole repo to the workspace, each job
entrypoint (`jobs/dq_check_job.py`, `jobs/dq_refresh_monitors.py`) adds `../src` to `sys.path`
at the top of the file, and the only non-pyspark dependency (`pydantic`) is declared as a
`pypi` cluster library in the job YAML. So:

```bash
cd deploy
databricks bundle deploy -t prod --var="warehouse_id=<your SQL warehouse id>"
```

That's it — no `pip install build` / `python -m build` step needed for the POC path. This
same command also deploys the `DQ Enterprise Scorecard` Lakeview dashboard (see Phase 13) —
`warehouse_id` is required specifically for that; the jobs themselves don't need it as a bundle
variable (they read `SQL_WAREHOUSE_ID` from tool/job config instead).

**When you move past POC**, switch to a real versioned artifact instead of live source sync:
1. `pip install build && python -m build` → `dist/fiserv_dq_agent-1.0.0-py3-none-any.whl`
2. In `deploy/databricks.job.yml`, on each task, comment out the `pypi: { package: "pydantic>=2.5" }`
   line and uncomment the `whl: ../dist/fiserv_dq_agent-1.0.0-py3-none-any.whl` line beneath it
   (already present, just commented).
3. Re-run `databricks bundle deploy -t prod`.

This gets you a pinned, testable, CI-buildable artifact instead of whatever happens to be on
disk at deploy time — worth doing before this goes past a handful of pilot BUs.

**Write down the IDs you'll need for Phase 5:**
```bash
databricks jobs list --output json | grep -A2 '"DQA] Data Quality Check'   # → dq_check job_id
databricks warehouses list                                                   # → your SQL warehouse_id
databricks lakeview list --output json | grep -B2 "DQ Enterprise Scorecard"  # → dashboard id
```

---

## Phase 3 — Create the DQ service principal (Databricks REST + SQL access)

This identity backs the 9 Python Function tools (they call the Jobs API + SQL Statement
Execution API over REST).

1. Create a service principal (or reuse an existing platform one) in the workspace admin
   console, or via CLI:
   ```bash
   databricks service-principals create --display-name "dqa-agent-sp"
   ```
2. Generate a token/OAuth secret for it.
3. Grant it:
   - `CAN_MANAGE_RUN` (or equivalent) on the `dq_check` and `dq_sweep` jobs from Phase 2.
   - `CAN_USE` on the SQL warehouse from Phase 2.
   - `SELECT` on every target data schema you plan to register (**read-only** — the agent
     never writes to source data).
   - `SELECT, MODIFY` on `governance.dq.*` (to write results and HITL-proposed rules).
   - If you'll use Lakehouse Monitoring: `USE`/manage-monitor grants on the monitored schemas.

Note the resulting host + token — these become `DATABRICKS_HOST` / `DATABRICKS_TOKEN` in
Phase 4.

---

## Phase 4 — Create the Genie Space + its OAuth service principal

This backs the native `dq_scorecard_genie` tool (ad-hoc NL questions over DQ history).

1. In Databricks, create a **Genie Space** scoped to **`governance.dq.*` tables only**
   (`results`, `run_summary`, `dataset_registry`, `rule_catalog`) — deliberately never the
   raw source tables. This is what keeps "the agent never reads raw rows" true even for
   free-form questions.
2. Grab the **Genie Space ID** from its URL: `.../genie/spaces/<space-id>`.
3. Create (or reuse) an **OAuth service principal** for Genie access, scoped to that space.
4. Give whoever manages Agent Studio's backend the resulting credentials to set as
   `GENIE_CLIENT_ID` / `GENIE_CLIENT_SECRET` in `backend/.env` (a platform-level secret,
   shared by every Genie tool unless a tool overrides the env var names).

---

## Phase 5 — Make credentials available to Agent Studio tools

Two separate credential paths converge here:

| Used by | Vars | Set where |
|---|---|---|
| 9 Python Function tools (REST calls) | `DATABRICKS_HOST`, `DATABRICKS_TOKEN` (Phase 3), `DQ_JOB_ID`, `SQL_WAREHOUSE_ID`, `DQ_DASHBOARD_ID` (Phase 2), `DQ_CONTROL_SCHEMA=governance.dq` | Tool-sandbox env vars — confirm the mechanism with your Agent Studio platform admin (Container App env vars or a secrets store) |
| 1 native Genie tool (OAuth2) | `GENIE_CLIENT_ID`, `GENIE_CLIENT_SECRET` (Phase 4) | `backend/.env` |

Do not proceed to Phase 6 until these are confirmed set — the tools will silently fail their
first real call otherwise (see `docs/reviews/agent_studio_design_review.md` Deep Dive #1 — the
platform doesn't yet offer pre-flight validation).

---

## Phase 6 — Create the 9 Python Function tools

In Agent Studio: left nav → **Tools → New Tool**. For each file in `agent_studio/tools/`:
- **Type**: `Python Function`
- **Name** / **Function Name**: the function name (e.g. `dq_run_checks`)
- **Description**: copy the first line of its docstring
- **Code**: paste the entire file contents

| Tool | Description to paste |
|---|---|
| `dq_list_datasets` | List registered datasets, optionally filtered by business unit. |
| `dq_get_summary` | Return the latest data-quality scorecard for a dataset without re-running checks. |
| `dq_run_checks` | Trigger the Databricks DQ job for a dataset, wait for completion, return the scorecard. |
| `dq_get_failures` | Return failing rules and remediation guidance for a dataset's latest run. |
| `dq_get_rules` | List configured data-quality rules for a dataset. |
| `dq_profile_dataset` | Return schema, null%, and distinct-value profile for a dataset. |
| `dq_propose_rule` | Create a DISABLED candidate rule for a dataset (human-in-the-loop). |
| `dq_get_drift` | Return native Lakehouse Monitoring drift/distribution signals for a dataset. |
| `dq_get_dashboard_link` | Return the URL of the enterprise Data Quality dashboard. |

## Phase 7 — Create the native Genie tool

Still **Tools → New Tool**:
- **Name**: `dq_scorecard_genie`
- **Description**: `Ask ad-hoc natural-language questions over DQ control/result tables (governance.dq.* only — never raw source data).`
- **Type**: `Databricks Genie`
- **Genie Space ID**: from Phase 4
- **Databricks Host**: `https://<your-workspace>.azuredatabricks.net`
- **Token URL**: leave blank
- **Client ID / secret env var**: leave as defaults `GENIE_CLIENT_ID` / `GENIE_CLIENT_SECRET`
- **OAuth2 scope**: `all-apis`
- Click **Create Tool**. No code needed.

## Phase 8 — Create the RAG collection

Left nav → **RAG → New Collection**:
- **Name**: `DQ Knowledge`
- **Description**: `Data quality dimensions, rule types, scoring, and remediation playbook`
- **Embedding Model**: `BGE Model · 1024d` (leave the ★ recommended default)
- **Chunk Size**: `512`   **Chunk Overlap**: `50`
- Create, then upload `agent_studio/rag/dq_knowledge.md`.

## Phase 9 — Create the Agent

Left nav → **Agents → New Agent**:
- **Name**: `DQ Agent`
- **Description**: `Assesses, monitors, and explains data quality for Delta tables across BUs.`
- **Agent Type**: `Single`
- **Provider**: `Databricks`   **Model**: `databricks-claude-sonnet-4-6`
- **System Instruction**: paste `agent_studio/agents/single_agent_system_instruction.txt` verbatim
- **Output Key**: `dq_result`
- **Tools**: check all 10 (from Phases 6-7)
- **RAG Collections**: check `DQ Knowledge`
- **Callbacks**: enable **Log Requests** + **Rate Limit**; enable **Content Filter** if your
  BU policy requires it
- Click **Create Agent**.

---

## Phase 10 — Onboard your pilot dataset

Register it before testing — the agent can't check a dataset that isn't in the registry:

```sql
INSERT INTO governance.dq.dataset_registry
  (dataset_id, target_catalog, target_schema, target_table, owner_bu, owner_email,
   criticality, freshness_sla_minutes, freshness_ts_column, primary_keys, active)
VALUES
  ('payments.txn_master', 'prod', 'payments', 'txn_master', 'Payments', 'owner@fiserv.com',
   'tier1', 60, 'load_ts', ARRAY('txn_id'), true);
```

Add at least the golden rules (PK not_null/unique, freshness, referential integrity on FKs) to
`rule_catalog` — or skip this and let the agent do it in Phase 11, step 4.

---

## Phase 11 — Smoke test in Sandbox

Left nav → **Sandbox** → select `DQ Agent` → **New Chat**. Run in order:

1. `What datasets are registered for the payments BU?` — exercises `dq_list_datasets`.
2. `What's the data quality of payments.txn_master?` — exercises `dq_run_checks`; verdict
   should lead with score + RAG status.
3. `Why did it fail?` — exercises `dq_get_failures`, explained in business terms.
4. `Profile payments.txn_master and suggest any missing rules.` — exercises
   `dq_profile_dataset` + `dq_propose_rule`; confirm the agent states the new rule is
   **disabled pending owner approval**.
5. `Which BU has the most RED datasets this week?` — exercises `dq_scorecard_genie`.
6. `Show me the dashboard.` — exercises `dq_get_dashboard_link`; the returned URL should open
   the `DQ Enterprise Scorecard` dashboard.

If step 5 fails, re-check the Genie Space ID/host and that `GENIE_CLIENT_ID`/`SECRET` are set
(Phase 4-5). If step 6 fails, re-check `DQ_DASHBOARD_ID`. If steps 1-4 fail, re-check Phase 3/5
credentials and the `job_id`/`warehouse_id` from Phase 2.

**Definition of done:** all 6 prompts return correct, sensibly-worded answers with no tool
errors surfaced in chat.

---

## Phase 12 (optional) — Workflow for staged/audited execution

Only if you want separation of duties (profile → run → analyze as distinct audited steps).
Create `dq_profiler`, `dq_runner`, `dq_analyst` as three more Single agents following
`agent_studio/agents/workflow_subagents.md`, then:

- left nav → **Workflows → New Workflow**
- **Name**: `DQ Workflow`, **Type**: `Custom`
- Drag `dq_profiler → dq_runner → dq_analyst` onto the canvas between Start and End
- Test the same 5 prompts via Sandbox, selecting `DQ Workflow` instead of the agent

---

## Phase 13 — Go live

- **Schedule the nightly sweep**: the `dq_sweep` job (Phase 2) already has a cron
  (`0 0 2 * * ?` — 2am ET) — confirm it's enabled, or trigger it via Agent Studio **Schedules**
  instead if you prefer to manage cadence there.
- **Confirm alerts**: `sql/04_dashboard_and_alerts.sql` created SQL Alerts for RED datasets,
  missed freshness SLAs, and sweep failures — confirm they're wired to a real Teams/email
  channel, not just created.
- **Confirm the dashboard**: `databricks bundle deploy` (Phase 2) already deployed the
  `DQ Enterprise Scorecard` Lakeview dashboard from `deploy/dashboards/dq_enterprise_scorecard.lvdash.json`
  — open it once and confirm every tile renders (it reads `v_bu_scorecard`, `v_score_trend`,
  `v_rag_distribution`, `v_dimension_breakdown`, `v_top_failures`). If a tile shows a schema
  error, the Lakeview JSON schema may have drifted from this Databricks release — rebuild that
  one tile in the UI using the same backing view; see `docs/reviews/` if you want to log the
  friction as platform feedback.

## Phase 14 — Roll out to additional BUs

- **New dataset** = one `INSERT` into `dataset_registry` + `rule_catalog` (Phase 10 pattern) —
  no agent change, no redeploy. Or ask the agent to profile + propose rules, then approve.
- **New BU-specific agent** = clone `DQ Agent` in Agent Studio and attach the same 10 tools +
  `DQ Knowledge` RAG collection to the clone. The dashboard is shared across BUs — use its BU
  filter rather than deploying one dashboard per BU.
- Repeat Phase 11's smoke test against the new BU's dataset before calling it onboarded.

---

## Troubleshooting quick reference

| Symptom | Likely cause | Check |
|---|---|---|
| Tool errors with 401/403 | Credentials from Phase 3/4 not set or expired | Env vars in tool sandbox / `backend/.env` |
| `dq_run_checks` times out or never returns | `DQ_JOB_ID` wrong, or job queue backed up | `databricks jobs list`; check the job's run history directly |
| "dataset not registered" | Phase 10 skipped | `SELECT * FROM governance.dq.dataset_registry WHERE dataset_id = '...'` |
| `dq_scorecard_genie` errors | Genie Space ID/host wrong, or OAuth creds missing | Phase 4/7 fields; confirm `GENIE_CLIENT_ID/SECRET` in `backend/.env` |
| `dq_get_dashboard_link` returns a bad URL | `DQ_DASHBOARD_ID` unset or stale | Re-check the id from Phase 2's `databricks lakeview list` output |
| Dashboard tile shows a schema/query error | Lakeview JSON field drifted from this Databricks release, or `sql/05_dashboard_extensions.sql` wasn't run | Re-run Phase 1's SQL; rebuild the one broken tile manually against the same view |
| Proposed rule never takes effect | It's created **disabled** by design | A human must `UPDATE rule_catalog SET enabled = true WHERE rule_id = '...'` |
| Score looks wrong for a "few failures" | Severity-weighted, not count-weighted | See `agent_studio/rag/dq_knowledge.md` FAQ |
