# Data Quality Agent (DQA)

A production-grade, **metadata-driven Data Quality Agent** built on the Fiserv Agent Studio
framework. The agent orchestrates data-quality checks; **all compute stays on Databricks**
(Spark SQL, Delta, Lakehouse Monitoring). No third-party check engines (no Great Expectations).

It is designed as a **shared product** across teams and BUs: a team onboards a dataset by
inserting rows into control tables — no code changes, no redeploy.

> **Integration path:** Agent Studio is already deployed on Azure Container Apps. You build
> the agent **in the Agent Studio UI** — 9 Tools as **Python Functions** + 1 native
> **Databricks Genie** tool (NL Q&A over `governance.dq.*` only, no code), plus an Agent, a
> RAG collection, and (optionally) a Workflow. A native **Lakeview dashboard** rounds it out
> for the enterprise/cross-BU view.
> **Start with [`docs/SETUP_GUIDE.md`](docs/SETUP_GUIDE.md)** for the full path, or
> [`agent_studio/BUILD_GUIDE.md`](agent_studio/BUILD_GUIDE.md) for the Agent Studio steps alone.
> The `src/dq_agent/api/` + `deploy/Dockerfile` are an **optional** standalone service and are
> NOT required when using Agent Studio.

---

## What it does

1. **Discover & profile** any Delta table via Unity Catalog.
2. **Generate / fetch** data-quality rules from a Delta-backed rule catalog.
3. **Execute checks** as a Databricks Job (native Spark SQL engine — `src/dq_agent/engine`).
4. **Detect drift / anomalies / freshness** via Databricks Lakehouse Monitoring.
5. **Score** each dataset (0–100 + RAG) and persist results to Delta.
6. **Explain & remediate** — root-cause narrative + suggested actions (quarantine, backfill, notify).
7. **Alert** owners (Teams / email / ServiceNow).

## Architecture

```
User / Scheduler
      │
      ▼
Agent Studio (Azure Container Apps)
  DQ Agent (LLM on a Databricks model) ── orchestrates 9 Python Function tools + 1 native Genie tool
      │
      ▼ (Databricks REST: Jobs API + SQL Statement Execution API + Genie Conversation API)
Databricks Workspace
      ├── DQ Check / DQ Sweep Jobs  ──►  native rule engine (PySpark)  ──►  Delta: dq results
      ├── Lakehouse Monitoring (drift / freshness / anomaly)
      ├── Genie Space (governance.dq.* only)
      ├── Lakeview dashboard (DQ Enterprise Scorecard)
      └── Unity Catalog (metadata, lineage, governance)
```

The agent runtime **never reads data rows**. It triggers jobs and reads aggregated results.
This keeps PII/PCI inside the Databricks governance boundary — important for Fiserv.

## Components

| Path | Purpose |
|------|---------|
| `sql/` | Delta control-table DDL + golden-rule seeds + dashboard/alert views (the metadata backbone) |
| `agent_studio/tools/` | The 9 Python Function tools pasted into Agent Studio |
| `src/dq_agent/engine/` | Native Spark SQL DQ engine (rule compilation, scoring, profiler) |
| `src/dq_agent/databricks/` | Databricks REST clients (Jobs API, SQL Execution, Monitoring) — used by the *optional* standalone API only |
| `src/dq_agent/models/` | Pydantic schemas = the data contracts |
| `src/dq_agent/api/` | *Optional* standalone FastAPI service — not required for the Agent Studio path |
| `jobs/` | Databricks Job entrypoints: `dq_check_job.py`, `dq_sweep_driver.py`, `dq_refresh_monitors.py` |
| `deploy/databricks.job.yml` | Asset Bundle: the 2 jobs + the `DQ Enterprise Scorecard` Lakeview dashboard |
| `deploy/dashboards/` | Lakeview dashboard-as-code definition |
| `deploy/Dockerfile` | Only needed if you deploy the optional standalone API |
| `tests/` | Unit tests for the engine + scoring |

## Control tables (metadata backbone)

| Table | Role |
|-------|------|
| `dq.dataset_registry` | Datasets onboarded (owner BU, criticality, freshness SLA, PKs) |
| `dq.rule_catalog` | Every rule (dimension, type, target, threshold, severity) |
| `dq.results` | Row-level check outcomes per run |
| `dq.run_summary` | Per-run rollup: score + RAG + dimension breakdown |

Onboarding a new BU = `INSERT` into `dataset_registry` + `rule_catalog`. That's it.

## DQ dimensions covered

Completeness · Uniqueness · Validity/Conformity · Accuracy · Consistency ·
Integrity (referential) · Timeliness/Freshness · Volume/Anomaly · Distribution/Drift · Schema.

## Quick start

```bash
# 1. Create control tables + dashboard views + seed golden rules (Databricks SQL warehouse)
databricks sql -f sql/01_control_tables.sql
databricks sql -f sql/03_scale_optimizations.sql
databricks sql -f sql/04_dashboard_and_alerts.sql
databricks sql -f sql/05_dashboard_extensions.sql
databricks sql -f sql/02_seed_golden_rules.sql

# 2. Deploy the DQ jobs + Lakeview dashboard — POC mode by default: no wheel, runs from src/
cd deploy && databricks bundle deploy --var="warehouse_id=<your warehouse id>"
# (switch to a wheel for production — see docs/SETUP_GUIDE.md Phase 2)

# 3. Build the 10 tools + RAG collection + Agent in Agent Studio — no separate service to run
```

Full walkthrough: **[`docs/SETUP_GUIDE.md`](docs/SETUP_GUIDE.md)** (start to finish) or
**[`agent_studio/BUILD_GUIDE.md`](agent_studio/BUILD_GUIDE.md)** (Agent Studio steps only).
See `docs/RUNBOOK.md` for day-2 operations.

## Design principles

- **Metadata-driven**: rules are data, not code → reuse across BUs.
- **Compute stays in Databricks**: agent orchestrates, never processes rows.
- **Deterministic tools, reasoning LLM**: the model decides *when*; tools decide *what*.
- **Human-in-the-loop** for rule creation and remediation until trusted.
- **Everything auditable**: every run + LLM rationale is logged.
