-- =====================================================================
-- Extends 04_dashboard_and_alerts.sql with the two views the enterprise
-- Lakeview dashboard needs that didn't exist yet: a per-dimension rollup
-- and a RAG-status distribution. Run after 01/02/03/04.
-- =====================================================================

-- ---- Score by dimension, across every dataset's latest run -----------
-- dimension_scores is a MAP<STRING,DOUBLE> on run_summary; explode it so a bar/column
-- tile can group by dimension. Only the 9 rule-engine dimensions appear here --
-- distribution/drift is a native Lakehouse Monitoring signal, not part of this map.
CREATE OR REPLACE VIEW governance.dq.v_dimension_breakdown AS
SELECT dim.key AS dimension,
       ROUND(AVG(dim.value), 1) AS avg_score,
       COUNT(DISTINCT s.dataset_id) AS datasets
FROM governance.dq.v_latest_scorecard s
LATERAL VIEW explode(s.dimension_scores) dim AS key, value
GROUP BY dim.key;

-- ---- RAG distribution across the latest run of every dataset ---------
CREATE OR REPLACE VIEW governance.dq.v_rag_distribution AS
SELECT rag_status, COUNT(*) AS datasets
FROM governance.dq.v_latest_scorecard
GROUP BY rag_status;
