# Triggered Incident Investigation

Closes the gap between a rule/job failing and someone starting root-cause
investigation — instead of a human noticing a red row in `dq_stats`
tomorrow, the agent investigates within minutes of the failure and posts a
first-pass hypothesis to the incident channel.

## Trigger — two options, pick based on what's available

**Option A — job-failure webhook (preferred where possible).** If the
pipeline that populates a monitored table already runs as a Databricks
Workflow Job, attach a webhook notification on job failure
(`Job settings → Notifications → Webhook`) that calls a small handler
function instead of polling. Lowest latency, no wasted queries.

**Option B — `dq_stats` poller.** Where the failing pipeline isn't a
Databricks Job the DQ team owns/can attach a webhook to (common — most
teams' pipelines are outside the DQ team's control), run a lightweight
Databricks Job every 5-15 minutes that queries for new failures since the
last check:

```sql
SELECT team_name, catalog_name, schema_name, table_name, failed_rule_ids, execution_timestamp
FROM dq_stats
WHERE status = 'FAILED'
  AND execution_timestamp > :last_checked_ts
  -- Scope to CRITICAL to avoid noise -- join team_rule on failed_rule_ids
  -- and filter severity = 'CRITICAL'. Do not trigger an investigation for
  -- every LOW-severity blip; that defeats the point of automating this.
```

Either way, the trigger only fires the agent for **CRITICAL** (and
optionally HIGH) severity rule failures, per each rule's `team_rule.severity`
— filter this at the trigger, not by asking the agent to self-censor.

## Dedupe — required, not optional

Track "already investigated" state (a simple
`dq_catalog.dq_reports.incident_investigations` table keyed on
`team_name`/`catalog_name`/`schema_name`/`table_name`/`failed_rule_ids`/
`execution_date`) so a poller running every 10 minutes doesn't re-investigate
the same still-failing rule on every cycle. Re-investigate only if the
failure signature changes (a different rule, a materially different
`failed_pct`) or a configurable cooldown has elapsed (e.g. re-investigate a
still-open CRITICAL failure once every 4 hours, not every 10 minutes).

## Prompt template

```text
A CRITICAL rule failed: {rule_name} on {catalog}.{schema}.{table}, first
detected {execution_timestamp}. Investigate root cause: check execution
history for a step-change vs. gradual pattern, check Schema Intelligence
for a recent schema change on this table or its immediate upstream sources,
check Lineage & Impact Analysis for downstream tables/dashboards that
consume this table, and check whether this table has team_rule coverage
for adjacent dimensions that might explain the failure. State a confidence
level and a concrete, human-reviewable recommendation.
```

## Output routing

Post to the DQ team's **incident Slack channel**, formatted so severity and
next action are visible without opening a thread:

```text
🔴 CRITICAL — corebanking.transactions.daily_summary
Rule: total_amount_reconciliation_check (failing since 2026-07-16 03:14 UTC)

Root cause (confidence: High): Schema Intelligence confirms a TYPE_CHANGED
event on raw_transactions.currency_code 40 minutes before the first failure.
Downstream impact (Lineage & Impact Analysis): finance.daily_revenue,
reporting.exec_dashboard_summary — both confirmed affected.

Recommendation: escalate to the upstream schema owner; this is not a
threshold/rule problem. Candidate team_rule adjustment attached below for
review (not applied).
```

If the responsible team has an on-call rotation, `@`-mention it in the
message for CRITICAL findings — do this in the Slack-posting step, not by
asking the agent to know who's on call (it doesn't have that context).

## Guardrails specific to this pattern

- **Investigation only, never remediation.** The message always frames the
  SQL/recommendation as "attached for review," never "applied" — this
  pattern does not get an exception to AI-assisted-not-autonomous just
  because it's automated end-to-end up to the Slack post.
- **State the coverage gap if it exists.** If the failing table has thin
  `team_rule` coverage (e.g. this is the only rule defined for it), say so —
  a one-rule table failing isn't the same confidence picture as a
  well-covered table failing, and the investigation should reflect that
  rather than presenting both as equally well-understood.
- **A trigger that can't identify severity should not trigger.** If the
  poller can't confidently determine a failure is CRITICAL (e.g.
  `failed_rule_ids` references a rule that's since been deleted from
  `team_rule`), skip automated investigation and log it for manual triage
  instead of guessing.
