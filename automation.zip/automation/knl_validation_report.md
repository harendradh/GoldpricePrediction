# KNL Validation Report — Spec

A per-pipeline validation report covering all KNL product pipelines (10+
today, designed to scale beyond that without spec changes). One detailed
section per pipeline, not a single aggregate — each section is generated
independently, in the same pass, scoped to that pipeline's **last run**
(most recent `dq_stats` execution), so the report always reflects current
state rather than a historical trend.

This reuses the same invocation mechanics as every other pattern in
`agent_studio/automation/` (see that folder's `README.md`) — no new agent,
no new Genie space. It's a report *shape*, not new capability.

## 1. Scope — identifying "the KNL pipelines"

`team_rule`/`dq_stats`/`data_profile` are shared, multi-tenant tables
filtered by `team_name`/`catalog_name`/`schema_name`/`table_name` (per
`CONTEXT_BRIEF.md` §2) — KNL is not a separate table or schema, it's a
**filter value** on those shared tables. Confirm the exact filter against
your real data before building this (`team_name = 'KNL'` is the most likely
shape given the existing schema, but it could equally be a `catalog_name`
or a `table_name` prefix if KNL products span multiple owning teams):

```sql
-- Confirm this resolves to your actual 10+ KNL pipelines before building --
SELECT DISTINCT team_name, catalog_name, schema_name, table_name
FROM dq_stats
WHERE team_name = 'KNL'  -- <- adjust to the real scoping column/value
ORDER BY table_name;
```

The report generator loops over this pipeline list and produces one section
per row — adding an 11th KNL pipeline later requires no spec change, it
just appears in this query's result set on the next run.

## 2. Data grain — "last run," not history

For each pipeline, resolve exactly one `dq_stats` row: the most recent
execution.

```sql
SELECT *
FROM dq_stats
WHERE team_name = 'KNL' AND table_name = :pipeline_table
QUALIFY ROW_NUMBER() OVER (PARTITION BY table_name ORDER BY execution_timestamp DESC) = 1;
```

If that row's `status = 'NOT_RUN'` or there is no row at all for a pipeline,
the report says so explicitly for that pipeline — per the anti-fabrication
non-negotiable, a missing/NOT_RUN last run is never presented as a passing
or healthy pipeline, and it is never silently skipped from the report either
(a pipeline that hasn't run is itself a finding).

## 3. Per-pipeline report section — the repeating unit

Every pipeline's section carries the same fixed structure, so the report
reads consistently across all 10+:

| Field | Source | Notes |
|---|---|---|
| **Pipeline / Product** | `dq_stats.table_name` (+ `pipeline_name`, `job_name`) | Section header |
| **Last run** | `dq_stats.execution_timestamp`, `execution_id` | Always stated — a report without a timestamp isn't trustworthy |
| **Run status** | `dq_stats.status` | SUCCESS / FAILED / PARTIAL / NOT_RUN, verbatim — never softened |
| **Score** | `dq_stats.pass_rate_pct` | The run's own computed pass rate — not re-derived, cited directly from the source row |
| **Rules evaluated / passed / failed** | `dq_stats.rules_evaluated_count` / `rules_passed_count` / `rules_failed_count` | Raw counts alongside the score |
| **Rules failed (detail)** | `dq_stats.failed_rule_ids` joined to `team_rule` | Rule name, severity, `action_if_failed`, and (if Profiling Intelligence has it) the specific `failed_pct` driving each one |
| **Rules passed (detail)** | active `team_rule` rows for this table minus `failed_rule_ids` | Named, not just counted — leadership/engineers reviewing this want to see *which* rules are green, not just a number |
| **Failure rate** | `1 - pass_rate_pct` (or `rules_failed_count / rules_evaluated_count`) | Stated as a percentage, matching the Score field's basis so the two numbers are never computed two different ways in the same report |
| **Recommendation(s)** | agent synthesis, per failed rule | Concrete and human-reviewable — a `team_rule` SQL adjustment or an escalation note, per `docs/06_AGENT_CAPABILITIES.md`'s SQL-Based Recommendations capability. Never auto-applied. |
| **Other factors** | Schema Intelligence, Freshness Intelligence, Volume Intelligence (cross-referenced, not queried by default for every pipeline — see §5) | Only pulled in when a failure's pattern suggests it's worth checking (e.g. a step-change failure → check for a same-day schema event) |
| **Coverage note** | — | If this pipeline has no active `team_rule` rows at all, state that plainly: "no coverage today," not a fabricated pass |

## 4. Report assembly — order and rollup

1. **Summary index at the top** (not instead of, in addition to, the
   per-pipeline detail): one line per pipeline — name, status, score — so a
   reader can see at a glance which of the 10+ need attention before reading
   every section in full.
2. **One full section per pipeline**, in the order returned by the scope
   query (or sorted worst-score-first if this is meant to triage, not just
   report — confirm which framing fits the audience before building).
3. **No cross-pipeline aggregation math** (no "average score across all
   KNL pipelines") unless specifically requested — averaging masks which
   individual pipeline is the actual problem, and this report's whole point
   is per-pipeline detail.

## 5. Prompt template

```text
Generate the KNL Validation Report. For each pipeline where team_name = 'KNL'
in dq_stats (confirm exact scoping filter before running), using each
pipeline's single most recent execution: report status, score (pass_rate_pct),
rules evaluated/passed/failed as counts, every failed rule by name with its
severity and action_if_failed (joined from team_rule), every passed rule by
name, the failure rate, and a concrete recommendation per failed rule. If a
pipeline's last run status is NOT_RUN or no row exists, state that explicitly
as its own finding -- do not omit the pipeline or imply it passed. If a
failed rule's pattern looks like a step-change (not a chronic/gradual
failure), cross-reference Schema Intelligence for a same-window schema event
before asserting root cause in the recommendation. State plainly if a
pipeline has no active team_rule coverage. Start with a one-line-per-pipeline
summary index, then one full section per pipeline.
```

## 6. Output format and cadence

Two independent choices — pick based on how this report will actually be
used:

- **On-demand (chat)**: run the prompt above directly whenever someone asks
  for it — zero new infrastructure, good for validating the report shape
  before automating it.
- **Scheduled**: same mechanism as
  [`scheduled_daily_health_summary.md`](scheduled_daily_health_summary.md) —
  a cron-triggered Databricks Job posting to Slack/email and/or writing to a
  `dq_catalog.dq_reports.knl_validation_report` Delta table
  (`pipeline_name, run_date, status, score, rules_failed_detail_json,
  recommendations_json, generated_at`) for history and dashboarding.

For a document leadership will actually read end-to-end (10+ full sections
is long for a Slack message), consider generating this as a Word doc via the
same `python-docx` house style already used for
`docs/presentations/DQ_Agent_Enterprise_Leadership_Architecture.docx` —
title page, a one-page summary index, then one heading per pipeline — rather
than a single giant Slack post. Say the word and I'll spec/build that
generator the same way.

## 7. Sample output — one pipeline section (illustrative)

> **KNL — corebanking_transactions**
> Last run: 2026-07-17 03:12 UTC (execution_id `a1b2c3...`) · Status: FAILED
> **Score: 91.2%** (41 rules evaluated, 37 passed, 4 failed) · Failure rate: 8.8%
>
> **Failed rules:**
> - `txn_amount_not_null` (CRITICAL, action: REJECT) — failing since this run only; no prior-day pattern.
> - `merchant_code_valid_format` (HIGH, action: FLAG) — chronic, ~2% for 11 consecutive days.
> - `settlement_date_not_future` (MEDIUM, action: FLAG)
> - `currency_code_in_reference_list` (HIGH, action: QUARANTINE) — new today; Schema Intelligence shows a TYPE_CHANGED event on the source `currency_code` column 40 minutes before this run.
>
> **Passed rules (37):** `account_id_not_null`, `txn_id_unique`, ... *(full list, not truncated, in the actual generated report)*
>
> **Recommendations:**
> - `currency_code_in_reference_list`: escalate to the upstream schema owner — this is a schema event, not a rule/threshold problem. (Confidence: High)
> - `merchant_code_valid_format`: chronic low-grade failure; candidate `team_rule` tightening attached for review, not applied. (Confidence: Medium)
>
> **Coverage:** full `team_rule` coverage exists for this pipeline (41/41 active rules evaluated).

## 8. Guardrails specific to this report

- **Every pipeline gets a section, including ones with nothing wrong.** A
  clean pipeline's section can be short (status, score, "no failures"), but
  it must appear — a report that only shows problem pipelines makes it
  impossible to tell "all good" from "we forgot to check."
- **A failed rule is always named, never just counted.** "4 rules failed"
  without naming them is not actionable for the engineer reading this
  report — every field in §3 marked "(detail)" must be literal rule names,
  not just counts.
- **Recommendations stay recommendations.** Same non-negotiable as every
  other pattern in this project — the report proposes, a human applies;
  nothing gets auto-executed off the back of this report.
