# Pre-Change Impact Check

Moves Lineage & Impact Analysis from something an engineer asks *after* a
downstream team complains, to a check they run *before* a schema or pipeline
change ships. Same underlying capability as `docs/06_AGENT_CAPABILITIES.md`'s
Lineage & Impact Analysis — this doc is about *when* it's invoked, not a new
capability.

## When to use it

Any change to a table's shape or a pipeline's logic that could alter what
downstream consumers receive: column rename/drop/retype, a changed join key,
a changed filter/aggregation upstream of a shared table, a partition-scheme
change. Not every code change needs this — scope it to changes that touch a
table's schema or its row-level semantics, not e.g. a pure performance
refactor with no output change.

## How to invoke — two maturity levels, start with the first

**Level 1 — advisory, manual (start here).** Add a line to the team's PR
template: *"If this PR changes a table's schema or semantics, paste the
agent's Lineage & Impact answer below before requesting review."* The
engineer asks the agent directly (chat, same as any other question) and
pastes the response into the PR description. Zero new infrastructure,
immediately usable, relies on the engineer remembering to do it.

**Level 2 — automated CI comment (once Level 1 is trusted).** A CI step
(e.g. a GitHub Actions job) that runs on PRs touching known schema/pipeline
files, extracts the changed table name(s) from the diff (this extraction
logic is repo-specific — e.g. a `CREATE OR REPLACE TABLE` statement, a DLT
pipeline definition, or a config file naming the target table), calls the
agent's endpoint with the prompt below, and posts the response as a PR
comment automatically. Do not make this a merge-blocking check initially —
run it as an advisory comment for a probation period so the team can judge
false-positive/false-negative rate before it can block anyone's merge.

```yaml
# Illustrative CI step (GitHub Actions) — adapt table-name extraction to
# your repo's actual schema-change file patterns.
- name: DQ impact check
  run: |
    python ci/ask_dq_agent.py \
      --table "$(python ci/extract_changed_table.py --diff ${{ github.event.pull_request.diff_url }})" \
      --post-comment-to "${{ github.event.pull_request.number }}"
```

## Prompt template

```text
{catalog}.{schema}.{table} is about to have a schema/logic change: {short
description of the change, e.g. "column customer_id changing from STRING to
BIGINT"}. Before this ships: what are the confirmed downstream tables,
dashboards, or jobs that consume this table or column (per Lineage & Impact
Analysis)? State the lineage depth traversed (direct vs. multi-hop) — do not
imply full transitive closure unless actually traversed. Flag any downstream
consumer that has no team_rule/dq_stats coverage of its own, since a break
there won't self-report. If lineage coverage looks incomplete for this
table, say so explicitly rather than reporting "no downstream impact."
```

## Sample output

> **Lineage & Impact check — `crm.silver.customer_profile.customer_id`**
> Confirmed downstream (direct, 1-hop, per `system.access.column_lineage`):
> `billing.gold.customer_master`, `marketing.gold.campaign_targets`.
> Confirmed downstream (2-hop): `reporting.exec_dashboard_summary` (via
> `customer_master`).
> ⚠️ `marketing.gold.campaign_targets` has no `team_rule`/`dq_stats`
> coverage of its own — a break there from this change would not
> self-report; recommend the marketing team review before this merges.
> Lineage traversal stopped at 2 hops; deeper transitive consumers were not
> checked.

## Guardrails specific to this pattern

- **"No lineage edge found" ≠ "safe to change."** The agent must distinguish
  *confirmed no downstream impact* (a lineage query ran and returned
  nothing) from *lineage coverage is incomplete for this table* (the query
  couldn't establish confidence either way — e.g. consumers that query via a
  path Unity Catalog doesn't automatically capture, like an external BI tool
  hitting a JDBC connection outside UC-tracked compute). Never let the CI
  comment read as a green light when it's actually a coverage gap.
- **Advisory before blocking, always.** Even at Level 2, a false positive
  that blocks an unrelated team's merge does more damage than an occasional
  missed check — earn the right to gate merges with a visible track record
  first.
- **This does not replace a real migration/deprecation process** for
  genuinely breaking changes with many confirmed consumers — it's a fast
  first-pass check, not a substitute for coordinating with downstream teams
  once real impact is confirmed.
