# Automation Patterns — Moving the Agent Beyond Chat

Everything in `docs/` and the rest of `agent_studio/` assumes a human types a
question and reads an answer. That's necessary but not sufficient — an
investigative agent that only ever responds to a typed question has the same
blind spot as a dashboard: nobody looks until something is already visibly
broken. The three patterns here wire the same agent (`dq-investigation-agent`,
no new agent, no new Genie space) into things that already happen on their
own, so it surfaces findings before a human goes looking:

| Pattern | Trigger | Closes the gap between... |
|---|---|---|
| [`scheduled_daily_health_summary.md`](scheduled_daily_health_summary.md) | Time (cron) | ...a problem existing and someone thinking to ask about it |
| [`triggered_incident_investigation.md`](triggered_incident_investigation.md) | A `dq_stats`/job failure event | ...a failure happening and root-cause investigation starting |
| [`pre_change_impact_check.md`](pre_change_impact_check.md) | A PR/schema change | ...shipping a breaking change and finding out from an angry downstream team |
| [`knl_validation_report.md`](knl_validation_report.md) | On-demand or scheduled | ...10+ pipelines' health and one consistent, per-pipeline report instead of ad hoc spot-checks |

## Shared invocation mechanics

All three patterns call the same deployed agent (`dq-investigation-agent`,
per `agent_studio/agent_config.md`) the same way: a POST to its Databricks
Model Serving endpoint (DCS Agent Studio deploys every agent behind one),
with a fixed or templated prompt in the request body, exactly as if a user
had typed that prompt into the chat UI. There is no separate "automation
API" — automation here means *what calls the endpoint and what happens to
the response*, not a different agent capability.

```python
# Illustrative — adapt endpoint name/auth to your actual DCS Agent Studio
# deployment. This shape (Databricks Model Serving invocations API) is the
# same across all three patterns below; only the prompt and the destination
# of the response differ.
import requests

def ask_agent(prompt: str, databricks_host: str, endpoint_name: str, token: str) -> str:
    resp = requests.post(
        f"https://{databricks_host}/serving-endpoints/{endpoint_name}/invocations",
        headers={"Authorization": f"Bearer {token}"},
        json={"messages": [{"role": "user", "content": prompt}]},
        timeout=180,  # matches the agent's own overall turn timeout, agent_config.md
    )
    resp.raise_for_status()
    return resp.json()["choices"][0]["message"]["content"]
```

Non-negotiables that carry over from the agent's own design into every
automated caller (do not relax these just because a human isn't watching in
real time):

- **Never feed the response into anything that writes to a production
  table.** The agent still only recommends — a script that reads its output
  and auto-applies a `team_rule` INSERT would violate the AI-assisted-not-
  autonomous guarantee just as much as a human doing it blindly would.
- **Never suppress or rewrite a "no coverage today" / "did not run" finding**
  to make an automated report look cleaner. Post it as-is, including the
  gaps.
- **Rate-limit and dedupe.** A poller or webhook that fires the agent
  repeatedly for the same already-reported condition is noise, not
  automation — each pattern below specifies its own dedupe approach.
