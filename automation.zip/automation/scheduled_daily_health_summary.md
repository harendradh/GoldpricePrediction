# Scheduled Daily Health Summary / Scorecard

Runs the agent's existing **Daily Health Summary** and **Data Quality
Scorecard** capabilities (`docs/06_AGENT_CAPABILITIES.md`) on a fixed
schedule and pushes the result to Slack/email — nobody has to remember to
ask.

## Trigger

A **Databricks Workflow Job** with a single task (Python script or
notebook), scheduled via cron — e.g. `0 7 * * 1-5` (07:00 local, weekdays,
before the business day starts so leadership/on-call sees it before standup).
No dependency on the agent's own infrastructure beyond the endpoint it's
already deployed on; this is just another scheduled job in the workspace,
same as any other Databricks Job.

## Prompt template

Fixed, not templated per-run — the agent pulls "today" from the data itself
(via `dq_stats.execution_date`, `data_profile.profile_date`, etc.), so the
prompt doesn't need a date substituted in:

```text
Generate today's Daily Health Summary across all onboarded tables, followed
by the org-wide Data Quality Scorecard. For the summary: state new CRITICAL/
HIGH failures, resolved issues since yesterday, freshness delays, and volume
anomalies, each citing whether team_rule/dq_stats/data_profile or native UC
metadata answered it. List every table with no team_rule/dq_stats/
data_profile coverage as an explicit coverage gap — do not omit them or
imply they're healthy. For the scorecard: break down by quality dimension
and by team, with the as_of_date stated.
```

## Output routing

Two destinations, not mutually exclusive:

1. **Slack**, via an Incoming Webhook posted from the same job task right
   after the agent call — this is the "someone actually reads it" surface.
   Post the summary as-is; do not truncate the coverage-gap list to make the
   message shorter.
2. **A Delta table**, `dq_catalog.dq_reports.daily_health_summary`
   (`run_date DATE, generated_at TIMESTAMP, summary_text STRING,
   scorecard_json STRING`) — gives a queryable history for a dashboard or
   for "what did the scorecard say last Tuesday" questions, and is a durable
   record even if the Slack post fails.

```python
# Illustrative job task — see agent_studio/automation/README.md for the
# shared ask_agent() helper and non-negotiables (never auto-apply anything
# from the response; post coverage gaps as-is, don't suppress them).
summary = ask_agent(DAILY_HEALTH_SUMMARY_PROMPT, DATABRICKS_HOST, ENDPOINT_NAME, TOKEN)

requests.post(SLACK_WEBHOOK_URL, json={"text": summary})

spark.createDataFrame(
    [(today, datetime.now(timezone.utc), summary, None)],
    ["run_date", "generated_at", "summary_text", "scorecard_json"],
).write.mode("append").saveAsTable("dq_catalog.dq_reports.daily_health_summary")
```

## Sample output

(Matches the worked example already in `docs/06_AGENT_CAPABILITIES.md`'s
Daily Health Summary section — reproduced here for the Slack-message shape
specifically.)

> **Daily Health Summary — 2026-07-16**
> 214 tables in scope: 189 with active `team_rule`/`dq_stats` coverage, 25
> with none (no coverage today for those 25 on Completeness/Validity/
> Consistency/Uniqueness/Volume/Governance).
> 3 new CRITICAL failures · 1 freshness delay (native `lakeflow` job-run
> signal) · 0 unresolved volume anomalies among covered tables.
> *Coverage gap:* 25 tables listed below have zero `team_rule`/`dq_stats`/
> `data_profile` rows — onboarding, not an incident.

## Guardrails specific to this pattern

- **Idempotent on retry.** If the Databricks Job retries after a transient
  failure, it must not post the same summary to Slack twice — either check
  the `daily_health_summary` table for today's `run_date` before posting, or
  rely on the job's own "don't retry after partial success" semantics; pick
  one and document it in the actual job config.
- **Governance Intelligence is the primary space for the scorecard half** —
  per `agent_config.md`'s 3-tool-call-per-turn cap, this prompt intentionally
  asks for both the summary and the scorecard in one turn rather than two
  separate scheduled jobs, since they share most of the same underlying
  queries. If the combined response starts hitting the timeout/token budget
  as the table count grows, split into two jobs before raising the cap.
- **Low temperature stays low.** This is a reporting job, not a creative
  one — do not override `agent_config.md`'s temperature setting for this
  invocation.
