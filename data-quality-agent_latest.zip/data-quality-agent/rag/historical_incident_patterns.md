# RAG Collection: DQ Historical Incident Patterns

> Ingest into the `DQ Historical Incident Patterns` RAG collection. These are
> illustrative narrative patterns (not verified past incidents) meant to give the
> agent few-shot grounding for HOW a well-formed root-cause narrative reads, and
> to seed pattern-matching for common recurring incident shapes. Replace with real
> anonymized incident write-ups as they accumulate post-launch — see
> `docs/05_ONBOARDING_RUNBOOK.md` for the process to append new entries.

## Pattern: Upstream schema change cascading into completeness failures

**Shape.** A COLUMN_DROPPED or renamed-column event on a source table precedes,
by hours, a spike in COMPLETENESS rule failures on the dependent `dq_rules` for
the same product_id — the two events share the same date and the completeness
failure rate jumps from near-zero to double digits in one run.

**Good root-cause narrative example.** "Completeness rule `merchant_name is not
null` failed for 12.4% of records in today's corebanking_tran_ct run (up from a
7-day baseline of 0.1%). Schema Intelligence shows a COLUMN_DROPPED event on the
same source table 3 hours before this run — `merchant_name` was removed from the
upstream feed. This is very likely the root cause (High confidence: dated schema
event + dated rule failure spike on the same table, same day). Recommend
escalating to the upstream owner (per lineage) rather than adjusting the rule."

## Pattern: Volume drop that is actually seasonality

**Shape.** A volume-anomaly alert fires for a day-of-week that historically also
shows low volume (e.g. every Sunday). `error_count` is flat, not elevated.

**Good root-cause narrative example.** "Today's input_count for TELETRACK is 38%
below the 30-day average, but the last 4 Sundays show the same ~35–40% dip — this
matches a recurring weekly pattern, not a new anomaly. error_count is flat versus
baseline, ruling out a rejection-rate cause. Confidence: Medium — recommend
baselining a day-of-week-aware volume band in the registry so this stops
triggering false alerts, rather than treating today as an incident."

## Pattern: Reprocessing/replay producing false uniqueness failures

**Shape.** A uniqueness rule fails immediately after `input_count` for the run is
unusually close to (or exceeds) the prior run's `input_count`, with a short gap
between runs — consistent with the same batch being re-ingested.

**Good root-cause narrative example.** "Uniqueness rule failures today correspond
to a run with input_count nearly identical to yesterday's run, executed only 40
minutes after the prior run completed — consistent with a batch replay rather
than genuinely new duplicate source data. Recommend checking the ingestion
trigger for a double-fire before pursuing a data-side fix. Confidence: Medium —
recommend confirming with the pipeline owner since replay detection here is
inferential, not directly observed."

## Pattern: NO_RESULT masquerading as a "clean" day

**Shape.** A previously consistently-failing rule shows zero FAIL rows today —
but also zero rows of any status, i.e. it did not execute at all.

**Good root-cause narrative example.** "address_should_be_valid shows no FAIL
results today, but v_rules_not_run_7d confirms this rule has not executed in the
last 7 days for this product_id — this is NOT_RUN, not a quality improvement. Do
not interpret the absence of failures as resolution. Recommend checking whether
the rule was disabled or the task that evaluates it stopped running. Confidence:
High — this is a direct NOT_RUN signal, not an inference."
