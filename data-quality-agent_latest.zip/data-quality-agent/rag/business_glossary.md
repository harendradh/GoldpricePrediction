# RAG Collection: DQ Business Glossary

> Ingest into the `DQ Business Glossary` RAG collection. Gives the agent stable
> definitions for terms/identifiers that recur across `dq_rules`/`dq_stats`/
> `data_profile.*` but aren't self-explanatory from column names alone.

## Identifiers

- **product_id** — the primary tenant/feed identifier shared across `dq_rules`
  and `dq_stats`; joins profiling via `dq_profile_table_registry.owning_product_id`.
  Treat as the canonical "team/feed" key when a question says "team X" or "feed X."
- **domain / sub_domain** — a further partition within a product_id (e.g.
  `bp` / `bill_payment_tm`). Not every product_id has a sub_domain.
- **job_type / load_type / batch** — pipeline execution metadata on `dq_rules`/
  `dq_stats`; `load_type` distinguishes full vs incremental loads, relevant when
  explaining a volume anomaly (a full reload legitimately looks like a spike).
- **task_name** — the specific pipeline task a rule/run is scoped to; multiple
  task_names can exist under one product_id/domain.

## Rule vocabulary

- **rule_type** — the quality-dimension tag: COMPLETENESS, VALIDITY, CONSISTENCY,
  UNIQUENESS, TIMELINESS, VOLUME, SCHEMA_DRIFT. Drives `fn_dq_scorecard` grouping.
- **action_if_failed** — what the pipeline does when a rule fails: typically
  REJECT (drop/quarantine the record), WARN (log only, record passes through), or
  a similar pipeline-specific action. Always state this when explaining a failure's
  real-world consequence.
- **ignore_if_field_missing** — if true, the rule is skipped (not failed) when its
  target field is absent, rather than counted as a failure. Important for
  distinguishing a legitimate skip from a real failure.
- **OVERLAP** — an observed rule name representing a cross-field/cross-source
  consistency check (e.g. standardized vs raw address agreement); treat as a
  CONSISTENCY-dimension signal even if `rule_type` isn't explicitly tagged that way
  in a given row.
- **distribution_by** — the column `dq_rules` uses to partition/distribute rule
  evaluation for scale; operationally relevant, not usually business-relevant.

## Execution vocabulary

- **PASS / FAIL / NO_RESULT** — the three possible states for a rule check on a
  given run (defined in `v_rule_execution_detail.rule_status`). NO_RESULT means
  the rule produced no evaluable outcome for that run (e.g. upstream data missing
  before the check could even run) — it is NOT evidence of quality, good or bad.
- **NOT_RUN** — a rule that is `is_active = true` in `dq_rules` but has zero
  executions in the lookback window (`v_rules_not_run_7d`). Distinct from
  NO_RESULT (which implies an attempted run).
- **result_level: ROW vs AGGREGATE** — ROW-level checks evaluate per-record;
  AGGREGATE-level checks evaluate a summary condition over the whole batch (e.g.
  "merchant_drop_threshold_check"). A single rule name can appear at either level
  depending on how it's implemented.
- **failed_pct** — failed_row_count as a percentage of `input_count` for that run;
  the primary severity signal (see HIGH/MEDIUM/LOW bands in `fn_root_cause_summary`).

## Profiling vocabulary

- **metric_values** — a stringified map (e.g. `{'total_count': '4257409',
  'threshold': 90}`); always read via `v_profile_metrics_parsed`'s typed columns,
  never parse the raw string yourself.
- **status (profiling)** — SUCCESS or FAILURE for a given column/date's profiling
  check; FAILURE means the metric breached its threshold, not that the pipeline
  crashed.
- **pipeline_id / task_id / parent_job_id / child_job_id / schedule_id** — job
  orchestration identifiers on `data_profile.dp_*` rows; useful for tying a
  profiling anomaly back to a specific job run via `system.lakeflow.*`.
