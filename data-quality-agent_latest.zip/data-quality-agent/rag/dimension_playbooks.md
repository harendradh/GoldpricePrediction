# RAG Collection: DQ Dimension Playbooks

> Ingest this file into the `DQ Dimension Playbooks` RAG collection (chunk per
> `##` section). Content is remediation-oriented — "what to actually do" —
> complementing `docs/02_QUALITY_DIMENSIONS.md`'s investigation logic (which stays
> in SQL/Genie, not RAG, since it's structured and queryable).

## Completeness remediation playbook

When a completeness rule fails and is corroborated by profiling:
1. Identify whether the null/missing pattern is uniform (every record) or partial
   (a subset) — uniform points to a schema/mapping break, partial points to
   legitimate source variance.
2. If schema/mapping break: escalate to the source-owning team identified via
   lineage, referencing the specific `dq_schema_snapshot` diff.
3. If legitimate variance: consider whether the rule's `action_if_failed` should
   move from a hard reject to a WARN, and whether a default-value strategy is
   appropriate downstream — do not silently drop records.
4. Never recommend simply lowering a completeness threshold to make failures
   disappear without confirming the underlying cause first.

## Validity remediation playbook

For `*_should_be_valid`/`*_should_be_standardized` rule failures:
1. Pull 5–10 sample failing values (via the DQ Execution Analytics workspace) to
   see the actual failure pattern before proposing a fix — regex/format rules are
   easy to over-fit to one bad batch.
2. If the failure is a new, systemic pattern (e.g. a source system changed date
   format), fix at the mapping/transform layer, not by loosening the validation
   rule.
3. If the failure is a small tail of genuinely malformed source records, a WARN
   action with a dead-letter/quarantine pattern is usually more appropriate than
   a hard reject that blocks the whole batch.

## Consistency remediation playbook

For OVERLAP/cross-field consistency failures:
1. Identify both sides of the disagreement (e.g. raw vs standardized address) and
   check which one is "correct" per the system of record before recommending a fix.
2. If a reference/standardization dataset version changed, coordinate the fix with
   whichever team owns that reference data — this is rarely fixable by the
   consuming team alone.
3. Timing/join-order issues (comparing a record against a stale copy of a joined
   table) require a pipeline ordering fix, not a rule change.

## Uniqueness remediation playbook

For duplicate-key failures:
1. Confirm the actual duplicate key with a sample query before recommending a
   uniqueness rule — a wrong key choice produces false positives forever.
2. Distinguish replay/reprocessing duplicates (same batch re-ingested) from
   genuinely new duplicate source records — the fix is a pipeline idempotency
   change in the first case, a source-side fix in the second.
3. Recommend `MERGE`-based upsert patterns over `INSERT`-only patterns for
   pipelines with a real risk of reprocessing.

## Timeliness / Freshness remediation playbook

For SLA breaches:
1. Check whether the owning job failed, is still running, or was never triggered
   — these have completely different remediation owners (on-call engineer vs
   scheduler config vs upstream dependency).
2. If a breach is a repeated pattern on a specific day of week, consider whether
   the SLA itself (registry `expected_runs_per_day`) needs adjustment rather than
   treating every recurrence as a fresh incident.
3. Always loop in the job owner with the specific run evidence (run ID, status,
   duration) rather than a generic "data is late" message.

## Volume remediation playbook

For volume anomalies:
1. Rule out seasonality first (day-of-week, month boundary, known business
   calendar events) before treating a shift as an incident.
2. A volume drop with a rising `error_count` is a rejection-rate problem (check
   which rule started rejecting more), not a source outage — these need different
   playbooks.
3. A volume spike right after a "0 rows" or partial day often indicates a
   catch-up/backfill run — verify against job run history before flagging.

## Schema Drift remediation playbook

For detected drift:
1. Immediately enumerate downstream consumers via lineage before any other
   action — the fix priority should be driven by blast radius.
2. For COLUMN_DROPPED: check whether any active `dq_rules.condition` references
   the dropped column (it will start failing/erroring) and flag those specifically.
3. For TYPE_CHANGED: check whether existing rules' `condition` casts assume the
   old type — recommend a rule update alongside the schema fix, not after.
