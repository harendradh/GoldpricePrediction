# Onboarding Runbook — Standing This Up in DCS Agent Studio

Follow in order. Steps 1–2 are one-time platform setup; step 7 ("Onboard a new
team") is the repeatable steady-state process.

## 1. Deploy the SQL layer

Run in order against a SQL Warehouse with access to `prod_dcs_catalog`:
```
sql/01_profile_table_registry.sql
sql/02_unified_profile_view.sql
sql/03_flatten_dq_results.sql
sql/04_investigation_functions.sql
sql/05_lakehouse_monitoring_dropin.sql   -- documentation only; no DDL executes today
```
Then create the two scheduled Jobs referenced throughout:
- `dq_refresh_profile_unified_view` — runs the Python generator in
  `sql/02_unified_profile_view.sql`'s header comment; schedule every 15 min, or
  trigger off a Delta CDF listener on `dq_profile_table_registry`.
- `dq_snapshot_schema` — nightly job that inserts one day's `information_schema.columns`
  rows into `dq_schema_snapshot` for every table in `dq_profile_table_registry`
  plus `dq_rules`/`dq_stats` themselves.

Verify: run the sanity-check `SELECT` at the bottom of `sql/01_profile_table_registry.sql`
— every active registry row should show `table_exists = true`.

## 2. Create the 8 Genie spaces

In the Databricks Genie workspace UI, create one space per workspace in
`docs/03_GENIE_WORKSPACES.md`. For each:
1. Name it to match `tools_manifest.md` (e.g. "Rule Intelligence").
2. Add only the tables listed under that workspace's "Data sources / Tables."
3. Paste the "Instructions" text into the space's instructions field.
4. Add 3–5 certified queries seeded from that section's "Sample questions" —
   pre-authoring certified queries materially improves Genie's SQL accuracy for
   the exact question shapes leadership will ask first.
5. Note the Genie Space ID from the space's URL (`/genie/spaces/<space-id>`).

## 3. Register each Genie space as an Agent Studio tool

For each of the 8 spaces, go to **Tools → Create New Tool**:
- **Type**: `Databricks Genie`
- **Name / Description**: from `agent_studio/tools_manifest.md`
- **Genie Space ID**: the ID captured in step 2
- **Databricks Host**: your workspace URL
- **Token URL**: leave blank
- **Client ID / secret env var**: `GENIE_CLIENT_ID` / `GENIE_CLIENT_SECRET` (or
  per-tool overrides — see the note in `tools_manifest.md`)
- **OAuth2 scope**: `all-apis`

Confirm `GENIE_CLIENT_ID`/`GENIE_CLIENT_SECRET` are set in `backend/.env` for the
service principal(s) with read access to the relevant Unity Catalog objects.

## 4. Register the Python function tools

Create 4 more tools (**Type**: `Python Function`) per `tools_manifest.md`:
`lineage_lookup`, `delta_history_lookup`, `system_table_lookup`, `scorecard_calc`.
These reuse the agent's existing SQL Warehouse connection — no new credentials.

## 5. Create the RAG collections

Create 3 collections and ingest:
- `DQ Dimension Playbooks` ← `rag/dimension_playbooks.md`
- `DQ Business Glossary` ← `rag/business_glossary.md`
- `DQ Historical Incident Patterns` ← `rag/historical_incident_patterns.md`

Chunk on `##` headers (each is a self-contained playbook/pattern entry).

## 6. Create the agent

**Agents → Create New Agent**, using the exact values in
`agent_studio/agent_config.md`: Name, Description, Agent Type = `Sequential`,
Provider = `Databricks`, Model = `databricks-claude-sonnet-4-5`, paste
`agent_studio/system_instruction.md`'s fenced block into System Instruction,
Output Key = `dq_agent_result`, check all 12 tools, check all 3 RAG collections,
enable all 3 callbacks (Content Filter, Rate Limit, Log Requests).

## 7. Verify with evals before go-live

Run every case in `evals/eval_cases.md` against the deployed agent in the Sandbox
/ Chat tab. E1–E6 (anti-fabrication) are release-blocking — do not promote to
production consumers (scheduled digest, scorecard API) until all six pass.

## 8. Onboard a new team (steady-state process, repeat per team)

A new team needs:
1. Their pipeline already writing to `dq_rules`/`dq_stats` (standard platform
   pattern — no DQ-agent-specific change).
2. One `MERGE` into `dq_profile_table_registry` pointing at their
   `dp_<domain>_<sub_domain>_status` table (template in `sql/01_profile_table_registry.sql`).
3. Nothing else. The generated view, all 8 Genie workspaces, the investigation
   functions, and the agent instruction all key off `product_id`/`domain`/
   `sub_domain`, not hardcoded table names — the new team's data is queryable
   immediately after the next `dq_refresh_profile_unified_view` run.

## 9. Schedule the Daily Health Summary consumer

Create a Job that calls the agent (Output Key `dq_agent_result`) once per morning
per active `product_id` with a fixed prompt ("Give today's health summary and any
new root-cause findings"), posting the result to the team's usual channel. This
is the "Daily Health Summary" capability from `docs/01_ARCHITECTURE.md` §4 — a
scheduled consumer of the same agent, not a separate system.

For the three Phase 1 dimensions specifically, use the detailed, structured
prompts in `agent_studio/scheduled_dimension_reports.md` instead of the generic
one-liner above — one Databricks Job (`dq_phase1_daily_reports`) with three
parallel tasks (Completeness, Validity, Uniqueness), each producing a full
report (executive summary, findings table, root cause detail, recommendations,
data gaps) rather than a short chat-style summary.
