"""
Builds DQ_Agent_Leadership_Architecture.docx from the diagrams in this folder
plus narrative content summarizing the project docs. Run after build_diagrams.py.
Requires: python-docx.
"""
import os
from docx import Document
from docx.shared import Inches, Pt, RGBColor, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "DQ_Agent_Leadership_Architecture.docx")

NAVY = RGBColor(0x1F, 0x35, 0x57)
ORANGE = RGBColor(0xE8, 0x79, 0x2B)
GRAY = RGBColor(0x4B, 0x55, 0x63)
DARK = RGBColor(0x11, 0x18, 0x27)


def set_cell_shading(cell, hex_color):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hex_color)
    tcPr.append(shd)


def add_title_page(doc):
    doc.add_paragraph().paragraph_format.space_before = Pt(60)

    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(14)
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r0 = p.add_run("Data Quality ")
    r0.font.size = Pt(34)
    r0.font.bold = True
    r0.font.color.rgb = NAVY
    r1 = p.add_run("AI Agent")
    r1.font.size = Pt(34)
    r1.font.bold = True
    r1.font.color.rgb = ORANGE
    r2 = p.add_run(" \U0001F916")
    r2.font.size = Pt(30)

    p2 = doc.add_paragraph()
    p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r2 = p2.add_run("DCS Agent Studio")
    r2.font.size = Pt(18)
    r2.font.color.rgb = ORANGE

    p3 = doc.add_paragraph()
    p3.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p3.paragraph_format.space_before = Pt(20)
    r3 = p3.add_run("An investigative data quality engineer for the Lakehouse")
    r3.font.size = Pt(13)
    r3.font.italic = True
    r3.font.color.rgb = GRAY
    doc.add_page_break()


def add_heading(doc, text, level=1):
    h = doc.add_heading(text, level=level)
    for run in h.runs:
        run.font.color.rgb = NAVY
    return h


def add_body(doc, text, size=11, italic=False, bold=False, color=DARK):
    p = doc.add_paragraph()
    r = p.add_run(text)
    r.font.size = Pt(size)
    r.italic = italic
    r.bold = bold
    r.font.color.rgb = color
    return p


def add_bullets(doc, items):
    for item in items:
        p = doc.add_paragraph(style="List Bullet")
        r = p.add_run(item)
        r.font.size = Pt(11)


def add_image(doc, filename, width_in=6.4, caption=None):
    doc.add_picture(os.path.join(HERE, filename), width=Inches(width_in))
    doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
    if caption:
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = p.add_run(caption)
        r.font.size = Pt(9.5)
        r.italic = True
        r.font.color.rgb = GRAY


def add_table(doc, headers, rows, col_widths=None, header_fill="1F3557"):
    table = doc.add_table(rows=1, cols=len(headers))
    table.style = "Table Grid"
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    hdr_cells = table.rows[0].cells
    for i, h in enumerate(headers):
        hdr_cells[i].text = ""
        p = hdr_cells[i].paragraphs[0]
        r = p.add_run(h)
        r.bold = True
        r.font.size = Pt(10.5)
        r.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
        set_cell_shading(hdr_cells[i], header_fill)
    for row_i, row in enumerate(rows):
        cells = table.add_row().cells
        for i, val in enumerate(row):
            cells[i].text = ""
            p = cells[i].paragraphs[0]
            r = p.add_run(str(val))
            r.font.size = Pt(9.8)
            if row_i % 2 == 0:
                set_cell_shading(cells[i], "DCE8F5")
    if col_widths:
        for row in table.rows:
            for i, w in enumerate(col_widths):
                row.cells[i].width = Inches(w)
    doc.add_paragraph()
    return table


def _set_cell_borders(cell, **edges):
    """edges: e.g. left='E8792B' to draw a colored border on that edge only."""
    tcPr = cell._tc.get_or_add_tcPr()
    borders = OxmlElement("w:tcBorders")
    for edge, color in edges.items():
        el = OxmlElement(f"w:{edge}")
        el.set(qn("w:val"), "single")
        el.set(qn("w:sz"), "20")
        el.set(qn("w:color"), color)
        borders.append(el)
    tcPr.append(borders)


def add_toc_table(doc, items):
    """items: list of (number_str, title, description) tuples."""
    table = doc.add_table(rows=0, cols=2)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    badge_w, text_w = 0.62, 5.98
    for i, (num, title, desc) in enumerate(items):
        row = table.add_row()
        row.height = Inches(0.56)
        badge, text = row.cells
        badge.width = Inches(badge_w)
        text.width = Inches(text_w)

        row_fill = "F4F6FA" if i % 2 == 0 else "FFFFFF"
        set_cell_shading(badge, "1F3557")
        set_cell_shading(text, row_fill)
        _set_cell_borders(text, left="E8792B")

        badge.vertical_alignment = 1  # center
        bp = badge.paragraphs[0]
        bp.alignment = WD_ALIGN_PARAGRAPH.CENTER
        br = bp.add_run(num)
        br.bold = True
        br.font.size = Pt(12)
        br.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)

        text.vertical_alignment = 1  # center
        tp = text.paragraphs[0]
        tp.paragraph_format.space_before = Pt(3)
        tp.paragraph_format.space_after = Pt(0)
        tp.paragraph_format.left_indent = Pt(10)
        tr = tp.add_run(title)
        tr.bold = True
        tr.font.size = Pt(11.5)
        tr.font.color.rgb = NAVY
        dp = text.add_paragraph()
        dp.paragraph_format.space_after = Pt(4)
        dp.paragraph_format.left_indent = Pt(10)
        dr = dp.add_run(desc)
        dr.italic = True
        dr.font.size = Pt(9.3)
        dr.font.color.rgb = GRAY
    doc.add_paragraph()
    return table


def add_labeled_line(doc, label, text, label_color=NAVY):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(4)
    r1 = p.add_run(label + "  ")
    r1.bold = True
    r1.font.size = Pt(10.5)
    r1.font.color.rgb = label_color
    r2 = p.add_run(text)
    r2.font.size = Pt(10.5)
    r2.font.color.rgb = DARK
    return p


def add_callout_box(doc, label, text, fill="FBE6D4", accent="E8792B", label_color=None, text_color=None):
    label_color = label_color or RGBColor(0xE8, 0x79, 0x2B)
    text_color = text_color or RGBColor(0x4A, 0x3A, 0x20)
    table = doc.add_table(rows=1, cols=1)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = table.rows[0].cells[0]
    set_cell_shading(cell, fill)
    tcPr = cell._tc.get_or_add_tcPr()
    borders = OxmlElement("w:tcBorders")
    for edge in ("left",):
        el = OxmlElement(f"w:{edge}")
        el.set(qn("w:val"), "single")
        el.set(qn("w:sz"), "24")
        el.set(qn("w:color"), accent)
        borders.append(el)
    tcPr.append(borders)
    cell.text = ""
    p = cell.paragraphs[0]
    p.paragraph_format.space_before = Pt(6)
    p.paragraph_format.space_after = Pt(6)
    r = p.add_run(label + "  ")
    r.bold = True
    r.italic = True
    r.font.size = Pt(9.5)
    r.font.color.rgb = label_color
    r2 = p.add_run(text)
    r2.italic = True
    r2.font.size = Pt(9.5)
    r2.font.color.rgb = text_color
    doc.add_paragraph().paragraph_format.space_after = Pt(2)
    return table


def add_instruction_box(doc, text):
    return add_callout_box(doc, "Genie space instructions:", text)


GENIE_WORKSPACES = [
    {
        "name": "Rule Intelligence",
        "purpose": "Explain what a business rule does, why it exists, its current status, and its ownership — the \"rule encyclopedia\" surface.",
        "sources": "prod_dcs_catalog.df_app_configs.dq_rules only.",
        "instructions": "You answer questions about data quality rule definitions — what a rule checks, its condition, its action_if_failed, whether it's active, and who owns it. You do NOT answer questions about whether a rule passed or failed on a specific run (that's DQ Execution Analytics). If asked about pass/fail history, say so explicitly and name the correct workspace. Always filter to is_active = true unless the user asks about historical/retired rules.",
        "context": "rule_type is the quality-dimension tag (COMPLETENESS/VALIDITY/CONSISTENCY/UNIQUENESS/TIMELINESS/VOLUME/SCHEMA_DRIFT). product_id/domain/sub_domain identify the owning team/feed. ignore_if_field_missing and action_if_failed govern runtime behavior and are frequently asked about.",
        "guardrails": "Never fabricate a rule that isn't in the table. Never suggest this workspace can tell you if a rule passed — redirect to DQ Execution Analytics. Do not expose created_by/updated_by as if they were data owners unless asked specifically.",
        "questions": [
            "What does the merchant_action_check rule do?",
            "Which rules are active for corebanking_tran_ct?",
            "What happens when address_should_be_valid fails — is it rejected or just flagged?",
            "Who last updated the name_should_be_standardized rule?",
        ],
        "outputs": "A direct answer citing rule, description, condition, action_if_failed, rule_type, is_active, plus the certified SQL used.",
    },
    {
        "name": "Profiling Intelligence",
        "purpose": "Answer \"what does the data actually look like\" — null rates, distinct counts, cardinality, distribution, per-column status — sourced from the unified profiling layer.",
        "sources": "v_profile_unified, v_profile_metrics_parsed, v_profile_latest, dq_profile_table_registry (for scope/ownership context).",
        "instructions": "You answer questions about column-level profiling metrics (nulls, counts, thresholds, status) across every onboarded domain via the unified profiling views. Always state the formatted_date/loaddt of the data you're citing — profiling answers without a date are not trustworthy. If a domain/sub_domain isn't in dq_profile_table_registry, say it hasn't been onboarded to profiling yet rather than guessing.",
        "context": "metric_values is a stringified map — always use v_profile_metrics_parsed (typed total_count/threshold_pct) rather than parsing metric_values yourself. status values include SUCCESS/FAILURE; failed_metrics names which specific metric breached threshold.",
        "guardrails": "Do not average/aggregate across domains unless explicitly asked — profiling thresholds are domain-specific. Do not treat a missing profiling row as \"passed\" — say profiling data is unavailable for that scope/date.",
        "questions": [
            "What's the null rate trend for merchant_name this month?",
            "Which columns failed profiling today for bp/bill_payment_tm?",
            "What's the distinct count for column X as of last week?",
        ],
        "outputs": "Column-level metric table with date, status, and the specific failed_metrics/threshold breached; trend answers include a short time series, not just the latest point.",
    },
    {
        "name": "DQ Execution Analytics",
        "purpose": "The primary \"why did quality degrade / what failed and how badly\" surface — execution-level rule outcomes, pass rates, and run summaries.",
        "sources": "dq_stats, v_rule_execution_detail, v_rule_execution_subdetail, v_dq_run_summary, v_rules_not_run_7d.",
        "instructions": "You answer questions about DQ execution results — which rules passed/failed/had no result, on which run, with what magnitude. ALWAYS use v_rule_execution_detail/v_dq_run_summary rather than dq_stats.agg_dq_results/row_dq_results directly — those columns are semi-structured and already flattened for you. rule_status = 'NO_RESULT' is NOT the same as PASS — never report a NO_RESULT rule as passing. If a rule the user asks about doesn't appear in the last 7 days, check v_rules_not_run_7d and say it did not run rather than saying it passed.",
        "context": "result_level distinguishes ROW-level vs AGGREGATE-level checks. failed_pct is pre-computed against input_count. job_run_id, task_name, dataset_name scope a specific execution.",
        "guardrails": "Never conflate NOT_RUN/NO_RESULT with PASS (zero tolerance). Cite job_run_id for any specific-run claim. Do not editorialize severity beyond what failed_pct supports — use the HIGH/MEDIUM/LOW bands defined in fn_root_cause_summary.",
        "questions": [
            "Which rules failed today for zeta?",
            "What's the pass rate trend for OVERLAP checks this month?",
            "Did the name_should_be_valid rule even run for TELETRACK this week?",
            "Give me today's execution summary for corebanking_tran_ct.",
        ],
        "outputs": "Rule-level pass/fail/no-result breakdown with counts and percentages, always dated and run-scoped; explicit callouts when NO_RESULT is present.",
    },
    {
        "name": "Schema Intelligence",
        "purpose": "Detect and explain schema drift — added/dropped/retyped columns — and its likely downstream effect.",
        "sources": "dq_schema_snapshot, system.information_schema.columns, system.information_schema.tables, fn_schema_drift_check.",
        "instructions": "You answer questions about schema changes over time. Always use fn_schema_drift_check/dq_schema_snapshot for historical comparisons — information_schema.columns alone only shows the CURRENT schema and cannot answer \"did it change.\" If no snapshot history exists for a table yet, say so rather than inferring drift from indirect evidence.",
        "context": "Snapshots are captured nightly by the dq_snapshot_schema job; drift detection compares the two most recent snapshots (or latest vs a specified lookback window).",
        "guardrails": "Never infer a schema change purely from a rule-failure spike — require snapshot evidence. Flag when snapshot coverage is missing for a requested table rather than answering \"no drift detected.\"",
        "questions": [
            "Did the corebanking_tran_ct source table change schema this week?",
            "When was a column last added to the TELETRACK table?",
            "Has any column's data type changed on the bill_payment_tm source in the last 30 days?",
        ],
        "outputs": "A dated list of COLUMN_ADDED/COLUMN_DROPPED/TYPE_CHANGED events with old/new values, and — when asked — a pointer to correlated rule/profiling failures on the same date.",
    },
    {
        "name": "Freshness Intelligence",
        "purpose": "Answer \"is the data late\" and quantify SLA breaches against each feed's expected cadence.",
        "sources": "v_profile_unified (loaddt/dcs_etl_dt), dq_profile_table_registry (expected_runs_per_day), system.lakeflow.jobs / system.lakeflow.job_run_timeline, fn_freshness_gap.",
        "instructions": "You answer questions about data recency/SLA breaches using fn_freshness_gap, which compares the last load timestamp to the expected cadence from the registry. If you need to know whether the owning job actually ran, cross-reference system.lakeflow.job_run_timeline rather than guessing from the data timestamp alone.",
        "context": "expected_runs_per_day defaults to 1 if not yet baselined for a domain — say explicitly when a domain has no baselined SLA rather than treating the default as a real target.",
        "guardrails": "Do not conflate \"no data loaded yet today\" with \"breach\" if the domain's expected run window hasn't elapsed yet — compute against sla_hours, not calendar-day boundaries. Escalation language should name the specific job/run.",
        "questions": [
            "Is TELETRACK data late today?",
            "How many hours since the last load for zeta?",
            "Which feeds are currently breaching their freshness SLA?",
        ],
        "outputs": "Table of source_table, last_loaddt, hours_since_last_load, sla_hours, is_breach — plus, when asked, the underlying job's most recent run status.",
    },
    {
        "name": "Volume Intelligence",
        "purpose": "Detect and explain row-count anomalies — spikes, collapses, and baseline-band breaches.",
        "sources": "dq_stats (input_count/output_count/error_count), dq_profile_table_registry (expected_daily_rows_min/max), fn_volume_anomaly, v_profile_unified (day_of_week for seasonality checks).",
        "instructions": "You answer questions about volume trends and anomalies via fn_volume_anomaly. Before calling a change an \"anomaly,\" check day_of_week/day_of_month seasonality in v_profile_unified for the same domain — known low-volume days are not incidents. If no baseline band exists yet for a domain, say the domain hasn't been volume-baselined rather than declaring pass/fail.",
        "context": "pct_change_vs_prior_day is the primary trend signal; is_below_band/is_above_band are the primary threshold signals — report both when available.",
        "guardrails": "Never call a volume change an \"anomaly\" without checking seasonality first. Distinguish a volume drop from a rejection-rate increase (error_count up) — these have different root causes and different owners to escalate to.",
        "questions": [
            "Why did volume drop for TELETRACK today?",
            "Is today's volume for corebanking_tran_ct within the expected band?",
            "Show me the 30-day volume trend for zeta.",
        ],
        "outputs": "Day-by-day input_count/prior-day comparison, band-breach flags, and — when asked — the seasonality check that was performed before any anomaly claim.",
    },
    {
        "name": "Lineage & Impact Analysis",
        "purpose": "Answer \"what upstream caused this\" and \"what downstream is affected\" — the blast-radius surface.",
        "sources": "UC lineage system tables (system.access.table_lineage, system.access.column_lineage), system.lakeflow.job_run_timeline, joined against dq_rules/dq_stats for impact scoping.",
        "instructions": "You answer questions about data lineage — upstream sources and downstream consumers of a table/column, and whether an upstream job's run status could explain a downstream quality issue. Always state the lineage depth you traversed. Cross-reference dq_rules/dq_stats on downstream tables to flag any downstream consumer that does NOT have DQ coverage as a governance gap.",
        "context": "Lineage tables track table- and column-level dependencies as captured by Unity Catalog automatically from executed queries/jobs — coverage depends on those jobs having actually run through UC-tracked compute.",
        "guardrails": "Never assert a downstream impact without a lineage edge to support it. Flag when lineage coverage looks incomplete rather than asserting \"no downstream impact.\"",
        "questions": [
            "What's upstream of the corebanking_tran_ct dq_stats feed?",
            "If TELETRACK's source table breaks, what downstream tables/dashboards are affected?",
            "Which downstream consumers of this table have no active DQ rules?",
        ],
        "outputs": "A traversal path (parent -> child chain with hop count), the set of impacted downstream assets, and an explicit DQ-coverage gap callout where relevant.",
    },
    {
        "name": "Governance Intelligence",
        "purpose": "Answer ownership, compliance, and program-health questions — who owns what, is DQ coverage adequate, what's the overall scorecard.",
        "sources": "dq_rules (ownership/is_active), dq_profile_table_registry (owner_team), fn_dq_scorecard, system.access.audit (who changed a rule and when).",
        "instructions": "You answer governance questions: rule/data ownership, DQ coverage completeness, scorecards, and audit trail of rule changes. Use fn_dq_scorecard for any \"how healthy is X\" question rather than computing your own ad hoc score. When asked about coverage gaps, check both dq_rules and dq_profile_table_registry — a domain can have one without the other.",
        "context": "created_by/updated_by/created_at/updated_at on dq_rules, joined with system.access.audit where deeper change history is needed.",
        "guardrails": "Do not present a scorecard number without naming which rule_type dimensions contributed and the as_of_date. Do not imply 100% coverage without checking both rule and profiling registries.",
        "questions": [
            "What's the current DQ scorecard for corebanking_tran_ct?",
            "Which domains have rules but no profiling coverage yet?",
            "Who owns the zeta data quality rules?",
            "Show me the rule changes made in the last 7 days.",
        ],
        "outputs": "Scorecard table by dimension, ownership listing, and coverage-gap callouts (rules-without-profiling or profiling-without-rules).",
    },
]


doc = Document()

# Page size / margins
section = doc.sections[0]
section.page_width = Inches(8.5)
section.page_height = Inches(11)
section.left_margin = Inches(0.9)
section.right_margin = Inches(0.9)
section.top_margin = Inches(0.8)
section.bottom_margin = Inches(0.8)

# Footer watermark on every page (title page included)
footer_p = section.footer.paragraphs[0] if section.footer.paragraphs else section.footer.add_paragraph()
footer_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
footer_r = footer_p.add_run("Fiserv – Internal Use Only")
footer_r.font.size = Pt(7)
footer_r.font.italic = True
footer_r.font.color.rgb = RGBColor(0xA8, 0xAD, 0xB5)

# -------------------------------------------------------------------------
add_title_page(doc)

# -------------------------------------------------------------------------
add_heading(doc, "Contents", level=1)
add_toc_table(doc, [
    ("1", "Executive Summary", "What the agent does and the core guarantees, in one page"),
    ("2", "The Problem: Why Dashboards Aren't Enough", "Why more dashboards won't close the gap"),
    ("3", "Solution Overview", "The reasoning framework behind every answer"),
    ("4", "Quality Dimension Coverage", "What ships in Phase 1 vs. Phase 2, with worked examples"),
    ("5", "Eight Specialized Genie Workspaces", "5.1-5.8: full configuration detail per workspace"),
    ("6", "Root-Cause Investigation, Illustrated", "A worked example of the agent's multi-hop reasoning"),
    ("7", "Governance, Trust & Anti-Fabrication Guarantees", "How the agent earns and keeps trust"),
    ("8", "Lakehouse Monitoring Roadmap", "Today's workaround and the future migration path"),
    ("A", "Sample Scheduled Reports (Illustrative)", "Demo output for the three Phase 1 daily reports"),
])
doc.add_page_break()

# -------------------------------------------------------------------------
add_heading(doc, "1. Executive Summary", level=1)
add_body(doc,
    "The Data Quality AI Agent is a metadata-driven, multi-team investigative engineer "
    "built on DCS Agent Studio. It answers the questions a dashboard cannot: why did quality "
    "degrade, what is the root cause, who and what is impacted downstream, and what should we "
    "do about it — grounded in real query results from Unity Catalog, never fabricated.")
add_body(doc,
    "It reuses the platform's existing rule (dq_rules) and execution (dq_stats) tables directly, "
    "and introduces one focused piece of net-new engineering — a registry-driven unification layer "
    "for today's fragmented per-team profiling tables. Eight scoped Genie workspaces keep natural-"
    "language querying accurate; a Sequential agent classifies, routes, cross-references, and "
    "synthesizes a confidence-scored answer.")
add_bullets(doc, [
    "Onboarding a new team = one registry MERGE, zero code changes.",
    "Zero-tolerance anti-fabrication rule: a rule that didn't run is never reported as passing.",
    "AI-assisted rule recommendations only — the agent never writes to dq_rules itself.",
    "100% native Databricks: Unity Catalog, system tables, lineage, Genie, AI Functions, Vector Search.",
    "Lakehouse Monitoring is architected for a drop-in swap once serverless compute is available.",
])
doc.add_page_break()

# -------------------------------------------------------------------------
add_heading(doc, "2. The Problem: Why Dashboards Aren't Enough", level=1)
add_body(doc,
    "DCS already captures rich data quality signal: business rules in dq_rules, execution results "
    "in dq_stats, and column-level profiling per team. What's missing is not more data — it's "
    "reasoning. Today, when quality degrades, an analyst manually stitches together rule failures, "
    "profiling anomalies, schema changes, and upstream job status to find a root cause. That's slow, "
    "inconsistent across teams, and doesn't scale to hundreds of data products and thousands of "
    "pipelines.")
add_image(doc, "diagram_6_problem_statement.png", width_in=6.8,
          caption="Figure 1 — Six core investigation gaps a dashboard structurally can't close.")
doc.add_page_break()

# -------------------------------------------------------------------------
add_heading(doc, "3. Solution Overview", level=1)
add_body(doc,
    "An investigative AI agent, not a chatbot wrapper around SQL. It follows a fixed reasoning "
    "framework for every substantive question: classify the quality dimension and scope, route to "
    "the right specialized Genie workspace(s), cross-reference at least one corroborating signal "
    "before asserting a root cause, synthesize a plain-language answer with evidence, and tag a "
    "confidence level. Every claim traces to a real table, view, or function — nothing is invented.")
add_image(doc, "diagram_1_architecture.png", width_in=6.6,
          caption="Figure 2 — End-to-end architecture: data sources → SQL/metadata layer → tools → agent → Genie workspaces → consumers.")
doc.add_page_break()

# -------------------------------------------------------------------------
add_heading(doc, "4. Quality Dimension Coverage", level=1)
add_body(doc,
    "Every dimension is designed as a full investigation loop — detection, investigation workflow, "
    "and root-cause strategy — not a single static check. The agent's reasoning explicitly checks for "
    "corroborating evidence (e.g. ruling out seasonality before calling a volume change an anomaly) "
    "before it will assert a root cause. The right-most column below is a real-world example of the "
    "kind of finding the agent surfaces for each dimension — not a hypothetical.")
add_body(doc,
    "Rollout is phased by build complexity, not by business importance. Completeness, Validity, and "
    "Uniqueness (green, Phase 1) are pure rule-execution checks answerable directly from the existing "
    "dq_rules/dq_stats data with no new infrastructure — these ship first. Consistency, Timeliness, "
    "Volume, and Schema Drift (amber, Phase 2) each require new supporting infrastructure — a "
    "cross-source join, a registry-driven SLA/volume baseline, or the nightly schema-snapshot job — "
    "and follow once Phase 1 is live and validated. The same Phase 1 / Phase 2 color coding is carried "
    "through the Genie workspace map in Section 5.", bold=False)
add_image(doc, "diagram_3_dimension_matrix.png", width_in=6.8,
          caption="Figure 3 — Coverage across all 7 quality dimensions, grouped by rollout phase, with a representative example finding for each.")
doc.add_page_break()

# -------------------------------------------------------------------------
add_heading(doc, "5. Eight Specialized Genie Workspaces", level=1)
add_body(doc,
    "One large, do-everything Genie space degrades in accuracy as its table scope and instruction "
    "complexity grow. Instead, each investigative surface gets its own narrowly-scoped workspace with "
    "a small table set and explicit guardrails — including instructions on when to defer to a sibling "
    "workspace rather than guess. Workspace color follows the same Phase 1 / Phase 2 rollout as "
    "Section 4: the three Phase 1 workspaces (Rule, Profiling, DQ Execution Analytics) run entirely "
    "off data already in production; the five Phase 2 workspaces depend on infrastructure introduced "
    "alongside their dimensions.")
add_image(doc, "diagram_2_genie_map.png", width_in=6.4,
          caption="Figure 4 — The 8 Genie workspaces, color-coded by rollout phase, with their primary table/view scope.")
add_table(doc,
    ["Workspace", "Answers"],
    [
        ["Rule Intelligence", "What a rule does, its status, its owner"],
        ["Profiling Intelligence", "Column-level nulls, counts, cardinality, distribution"],
        ["DQ Execution Analytics", "Pass/fail/no-result history, run summaries"],
        ["Schema Intelligence", "Schema drift — added/dropped/retyped columns"],
        ["Freshness Intelligence", "Is data late, SLA-breach detection"],
        ["Volume Intelligence", "Row-count anomalies vs. baseline and seasonality"],
        ["Lineage & Impact", "Upstream cause, downstream blast radius"],
        ["Governance Intelligence", "Ownership, coverage gaps, DQ scorecards"],
    ],
    col_widths=[2.1, 4.3])
add_body(doc, "Full detail for each workspace — instructions, context, guardrails, and sample "
              "questions exactly as they should be configured in Agent Studio — follows below.",
         italic=True, color=GRAY)
doc.add_page_break()

for i, ws in enumerate(GENIE_WORKSPACES, start=1):
    add_heading(doc, f"5.{i}. {ws['name']} Genie", level=2)
    add_body(doc, ws["purpose"])
    add_labeled_line(doc, "Data sources / Tables:", ws["sources"])
    add_instruction_box(doc, ws["instructions"])
    add_labeled_line(doc, "Context:", ws["context"])
    add_labeled_line(doc, "Guardrails:", ws["guardrails"])
    add_body(doc, "Sample questions:", bold=True, size=10.5)
    add_bullets(doc, ws["questions"])
    add_labeled_line(doc, "Expected outputs:", ws["outputs"])
    if i < len(GENIE_WORKSPACES):
        doc.add_page_break()
doc.add_page_break()

# -------------------------------------------------------------------------
add_heading(doc, "6. Root-Cause Investigation, Illustrated", level=1)
add_body(doc,
    "A concrete example of the agent's multi-hop reasoning for a validity-failure question — deliberately "
    "a Phase 1 dimension, since that's what ships first. The same corroborate-before-concluding pattern "
    "applies across every dimension, Phase 1 or Phase 2.")
add_image(doc, "diagram_4_root_cause_sequence.png", width_in=6.8,
          caption="Figure 5 — Example investigation sequence for a validity failure.")
add_body(doc,
    "Sample synthesized answer: \"address_should_be_valid failures jumped from 0.3% to 9.1% today for "
    "corebanking_tran_ct — fn_rule_pass_rate_trend shows a sharp step-change, not gradual drift, and "
    "Schema Intelligence confirms a TYPE_CHANGED event on the source table's phone_number column 2 hours "
    "before this run. Confidence: High — recommend escalating to the upstream owner rather than adjusting "
    "the rule threshold.\"", italic=True, color=GRAY)
doc.add_page_break()

# -------------------------------------------------------------------------
add_heading(doc, "7. Governance, Trust & Anti-Fabrication Guarantees", level=1)
add_body(doc,
    "Trust is the product. Three guarantees are enforced at multiple layers — the SQL view logic, the "
    "agent's system instruction, and a dedicated eval suite — so they hold even as the system evolves:")
add_bullets(doc, [
    "NOT_RUN and NO_RESULT are never reported as PASS. A rule with no execution result is reported "
    "as exactly that, never as evidence of health.",
    "No fabricated tables, columns, rules, or lineage edges. If a workspace returns nothing, the "
    "agent says so rather than inventing a plausible answer.",
    "Every recommendation is AI-assisted, not AI-deployed. The agent proposes rule/threshold changes "
    "with SQL and rationale attached; it has no write access to dq_rules and never claims to have "
    "deployed anything.",
])
add_body(doc,
    "Every substantive answer is tagged with a confidence level (High / Medium / Low) tied to how much "
    "corroborating evidence was found — a single uncorroborated signal is reported as Medium/Low "
    "confidence, not stated as fact.")
doc.add_page_break()

# -------------------------------------------------------------------------
add_heading(doc, "8. Lakehouse Monitoring Roadmap", level=1)
add_body(doc,
    "Serverless compute — required for Lakehouse Monitoring's managed refresh — is not yet available "
    "in this workspace. Rather than wait, the interim profiling-unification layer is deliberately "
    "shaped to match Lakehouse Monitoring's own output schema, so migrating later is a targeted view "
    "swap, not a redesign.")
add_image(doc, "diagram_5_lhm_current_vs_future.png", width_in=6.8,
          caption="Figure 6 — Current-state workaround vs. future Lakehouse Monitoring state.")
add_body(doc, "Migration approach: pilot on one domain, validate metric parity for one week, cut over "
              "the view (not the callers), then roll forward domain-by-domain — retiring the interim "
              "registry and snapshot jobs as each domain migrates.")
add_body(doc, "Operational benefits once migrated: no custom registry/generator job to maintain, native "
              "statistical distribution drift detection (beyond schema-only today), zero onboarding step "
              "for profiling, and Databricks' own built-in monitor dashboards alongside the agent's "
              "investigative workspaces.")
doc.add_page_break()

# -------------------------------------------------------------------------
# Appendix A: Sample Scheduled Reports (Illustrative)
# -------------------------------------------------------------------------
add_heading(doc, "Appendix A: Sample Scheduled Reports (Illustrative)", level=1)
add_body(doc,
    "Illustrative sample output for each of the three Phase 1 scheduled reports defined in "
    "agent_studio/scheduled_dimension_reports.md — shown here for demo purposes only. The data "
    "below is representative (consistent with the examples used earlier in this document), not a "
    "live production run, but the structure, section headings, and level of detail are exactly "
    "what the scheduled agent job produces in production.", italic=True, color=GRAY)

SAMPLE_REPORTS = [
    {
        "name": "Completeness Daily Report",
        "subtitle": "as_of_date = 2026-07-15",
        "exec_summary": (
            "Portfolio-wide completeness held steady for 6 of 7 monitored rules today. One "
            "HIGH-severity NEW finding: merchant_name completeness for corebanking_tran_ct dropped "
            "from a sub-0.1% baseline to 12.4%, independently corroborated by profiling and traced "
            "to a COLUMN_DROPPED schema event 3 hours before this run. No rules are in a NOT_RUN "
            "state today; one rule (TELETRACK / name is not null) returned NO_RESULT and is called "
            "out below rather than treated as healthy."),
        "table_headers": ["product_id", "rule", "status", "failed_pct", "severity", "new_or_chronic"],
        "table_rows": [
            ["corebanking_tran_ct", "merchant_name is not null", "FAIL", "12.4%", "HIGH", "NEW"],
            ["bp / bill_payment_tm", "loaddt is not null", "PASS", "0.0%", "—", "—"],
            ["zeta", "address is not null", "PASS", "0.2%", "LOW", "CHRONIC"],
            ["TELETRACK", "name is not null", "NO_RESULT", "—", "—", "—"],
        ],
        "extra_section": None,
        "root_cause": [
            "corebanking_tran_ct / merchant_name is not null (HIGH, NEW): v_profile_metrics_parsed "
            "independently confirms the gap — total_count for merchant_name dropped in lockstep "
            "with the rule failure on the same date. fn_schema_drift_check shows a COLUMN_DROPPED "
            "event on the source table 3 hours before this run. Confidence: High — two independent "
            "signals plus a dated schema event on the same table.",
            "zeta / address is not null (LOW, CHRONIC): steady ~0.2% failure rate for 11 consecutive "
            "days — consistent with known source variance, not a new incident. Confidence: Medium.",
        ],
        "recommendations": [
            "corebanking_tran_ct: escalate to the source-owning team per lineage — the column was "
            "dropped, not degraded; a rule or threshold change will not fix this.",
            "zeta: no action needed today — the chronic rate is within the team's accepted variance; "
            "revisit only if it trends upward.",
        ],
        "data_gaps": [
            "TELETRACK / name is not null: NO_RESULT today — recommend checking whether the "
            "upstream task that evaluates this rule ran successfully.",
        ],
    },
    {
        "name": "Validity Daily Report",
        "subtitle": "as_of_date = 2026-07-15",
        "exec_summary": (
            "address_should_be_valid failures jumped from a 0.3% 7-day baseline to 9.1% today for "
            "corebanking_tran_ct — fn_rule_pass_rate_trend confirms a step-change, not gradual "
            "drift. One HIGH-severity STEP-CHANGE finding; one LOW-severity GRADUAL-DRIFT finding "
            "for TELETRACK that does not warrant incident response today."),
        "table_headers": ["product_id", "rule", "status", "failed_pct", "severity", "pattern"],
        "table_rows": [
            ["corebanking_tran_ct", "address_should_be_valid", "FAIL", "9.1%", "HIGH", "step_change"],
            ["zeta", "phone_should_be_valid", "PASS", "0.4%", "—", "—"],
            ["TELETRACK", "name_should_be_valid", "FAIL", "1.8%", "LOW", "gradual_drift"],
        ],
        "extra_section": ("Sub-Rule Breakdown",
            "corebanking_tran_ct / address_should_be_valid — top contributors: "
            "address_should_be_standardized (61% of failures), phone_number_format (24%), "
            "postal_code_range (15%)."),
        "root_cause": [
            "corebanking_tran_ct / address_should_be_valid (HIGH, step_change): Schema Intelligence "
            "confirms a TYPE_CHANGED event on the source table's phone_number column 2 hours before "
            "this run. Confidence: High.",
            "TELETRACK / name_should_be_valid (LOW, gradual_drift): failure rate has crept from 0.6% "
            "to 1.8% over 14 days with no single triggering event — consistent with slowly "
            "increasing bad-source volume, not an incident. Confidence: Medium.",
        ],
        "recommendations": [
            "corebanking_tran_ct: escalate to the upstream owner rather than adjusting the rule "
            "threshold — the schema event is the root cause.",
            "TELETRACK: no incident action; recommend the team review source-side data entry "
            "quality during the next planning cycle.",
        ],
        "data_gaps": [
            "bp / bill_payment_tm: no active VALIDITY rules configured yet — out of scope for this "
            "report, not a missing result. See Section 5.1 (Rule Intelligence) for onboarding "
            "guidance.",
        ],
    },
    {
        "name": "Uniqueness Daily Report",
        "subtitle": "as_of_date = 2026-07-15",
        "exec_summary": (
            "Duplicate-key failures detected for corebanking_tran_ct (txn_id) at 3.2% today. "
            "input_count is within 1% of yesterday's run, and the gap between the two runs "
            "(42 minutes) is well below this pipeline's normal 24-hour cadence — consistent with "
            "REPLAY-LIKELY rather than new source duplicates. Confidence: Medium (this "
            "classification is inferential, not directly observed)."),
        "table_headers": ["product_id", "rule", "status", "failed_pct", "severity", "replay_or_new"],
        "table_rows": [
            ["corebanking_tran_ct", "txn_id uniqueness check", "FAIL", "3.2%", "MEDIUM", "replay_likely"],
            ["zeta", "customer_id uniqueness check", "PASS", "0.0%", "—", "—"],
        ],
        "extra_section": None,
        "root_cause": [
            "corebanking_tran_ct / txn_id (MEDIUM, replay_likely): input_count 2,231,406 vs. "
            "yesterday's 2,209,880 (+0.97%); the two runs are 42 minutes apart against a normal "
            "~24h cadence. unique_pii_count is flat, which further supports a replay rather than "
            "new duplicate source records. Confidence: Medium — inference, not a direct "
            "observation.",
        ],
        "recommendations": [
            "corebanking_tran_ct: check the ingestion trigger for a double-fire and confirm the "
            "pipeline uses a MERGE-based idempotent upsert.",
        ],
        "data_gaps": [
            "TELETRACK: no active UNIQUENESS rules configured yet — out of scope for this report.",
        ],
    },
]

for i, rep in enumerate(SAMPLE_REPORTS, start=1):
    add_heading(doc, f"A.{i}. {rep['name']} — Sample Output", level=2)
    add_body(doc, rep["subtitle"], italic=True, color=GRAY, size=9.5)
    add_body(doc, "Executive Summary", bold=True, size=10.5)
    add_callout_box(doc, "Executive Summary:", rep["exec_summary"],
                     fill="DCE8F5", accent="2E6FB5", label_color=RGBColor(0x2E, 0x6F, 0xB5),
                     text_color=DARK)
    add_body(doc, "Findings Table", bold=True, size=10.5)
    add_table(doc, rep["table_headers"], rep["table_rows"], col_widths=None)
    if rep["extra_section"]:
        title, text = rep["extra_section"]
        add_body(doc, title, bold=True, size=10.5)
        add_body(doc, text, size=10)
    add_body(doc, "Root Cause Detail", bold=True, size=10.5)
    add_bullets(doc, rep["root_cause"])
    add_body(doc, "Recommendations", bold=True, size=10.5)
    add_bullets(doc, rep["recommendations"])
    add_body(doc, "Data Gaps", bold=True, size=10.5)
    add_bullets(doc, rep["data_gaps"])
    if i < len(SAMPLE_REPORTS):
        doc.add_page_break()

doc.save(OUT)
print("Saved", OUT)
