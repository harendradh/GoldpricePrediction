"""
Generates the architecture diagram PNGs embedded in
DQ_Agent_Leadership_Architecture.docx. Run with: python build_diagrams.py
Requires: matplotlib (no other project dependency).
"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle, Ellipse, Rectangle, Polygon, RegularPolygon
import os
import math

OUT = os.path.dirname(os.path.abspath(__file__))

NAVY = "#1F3557"
BLUE = "#2E6FB5"
LIGHT_BLUE = "#DCE8F5"
ORANGE = "#E8792B"
LIGHT_ORANGE = "#FBE6D4"
GREEN = "#3E8E5A"
LIGHT_GREEN = "#DCEFE2"
GRAY = "#6B7280"
LIGHT_GRAY = "#F0F1F3"
WHITE = "#FFFFFF"
SHADOW = "#0F1E33"
RED = "#C0392B"
LIGHT_RED = "#FBE4E1"

plt.rcParams["font.family"] = "DejaVu Sans"


# ---------------------------------------------------------------------------
# Core helpers: shadowed rounded box + connectors
# ---------------------------------------------------------------------------
def shadow(ax, x, y, w, h, offset=0.045, layers=4):
    for i in range(layers, 0, -1):
        a = 0.05 * (layers - i + 1) / layers
        p = FancyBboxPatch((x + offset * i / layers, y - offset * i / layers), w, h,
                            boxstyle="round,pad=0.02,rounding_size=0.07",
                            linewidth=0, facecolor=SHADOW, alpha=a, zorder=0.5)
        ax.add_patch(p)


def box(ax, x, y, w, h, text, fc=LIGHT_BLUE, ec=BLUE, fontsize=10, fontweight="normal",
        textcolor="#111827", zorder=2, icon=None, icon_color=None, accent=True, dashed=False, alpha=1.0):
    if not dashed:
        shadow(ax, x, y, w, h)
    p = FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.07",
                        linewidth=1.8, edgecolor=ec, facecolor=fc, zorder=zorder,
                        linestyle="--" if dashed else "-", alpha=alpha)
    ax.add_patch(p)
    if accent and not dashed:
        bar = FancyBboxPatch((x, y), 0.09, h, boxstyle="round,pad=0.0,rounding_size=0.03",
                              linewidth=0, facecolor=ec, zorder=zorder + 0.5, alpha=0.85)
        ax.add_patch(bar)
    text_y = y + h / 2
    if icon is not None:
        icon(ax, x + w / 2, y + h - 0.3, 0.2, icon_color or ec)
        text_y = y + h / 2 - 0.14
    ax.text(x + w / 2, text_y, text, ha="center", va="center", fontsize=fontsize,
             fontweight=fontweight, color=textcolor, zorder=zorder + 1, wrap=True, alpha=alpha)
    return p


def arrow(ax, xy1, xy2, color=GRAY, style="-|>", lw=1.8, connectionstyle="arc3,rad=0.0", alpha=1.0):
    a = FancyArrowPatch(xy1, xy2, arrowstyle=style, mutation_scale=15, linewidth=lw,
                         color=color, connectionstyle=connectionstyle, zorder=1, alpha=alpha)
    ax.add_patch(a)


def new_fig(w=13, h=8):
    fig, ax = plt.subplots(figsize=(w, h))
    ax.set_xlim(0, w)
    ax.set_ylim(0, h)
    ax.axis("off")
    return fig, ax


def flow_dots(ax, x1, y1, x2, y2, color, n=3):
    """Small dots along a connector to suggest live data flow (static-image approximation)."""
    for i in range(1, n + 1):
        t = i / (n + 1)
        ax.add_patch(Circle((x1 + (x2 - x1) * t, y1 + (y2 - y1) * t), 0.035,
                             facecolor=color, edgecolor="none", zorder=1.2, alpha=0.85))


# ---------------------------------------------------------------------------
# Vector icon library — small, monochrome, stroke-based
# ---------------------------------------------------------------------------
def icon_database(ax, cx, cy, r, color):
    w, h = r * 2.1, r * 1.9
    ax.add_patch(Ellipse((cx, cy + h * 0.32), w, h * 0.34, facecolor=color, edgecolor="none", zorder=5))
    ax.add_patch(Rectangle((cx - w / 2, cy - h * 0.18), w, h * 0.5, facecolor=color, edgecolor="none", zorder=4.8))
    ax.add_patch(Ellipse((cx, cy - h * 0.18), w, h * 0.34, facecolor=color, edgecolor="none", alpha=0.75, zorder=4.9))
    ax.add_patch(Ellipse((cx, cy + h * 0.32), w, h * 0.34, facecolor="none", edgecolor="white", lw=0.8, alpha=0.5, zorder=5.1))


def icon_gear(ax, cx, cy, r, color):
    n = 8
    outer, inner = r * 0.95, r * 0.62
    pts = []
    for i in range(n * 2):
        ang = math.pi * i / n
        rad = outer if i % 2 == 0 else outer * 0.75
        pts.append((cx + rad * math.cos(ang), cy + rad * math.sin(ang)))
    ax.add_patch(Polygon(pts, closed=True, facecolor=color, edgecolor="none", zorder=5))
    ax.add_patch(Circle((cx, cy), inner * 0.55, facecolor="white", edgecolor="none", zorder=5.1))


def icon_robot(ax, cx, cy, r, color):
    ax.add_patch(FancyBboxPatch((cx - r * 0.85, cy - r * 0.7), r * 1.7, r * 1.3,
                                 boxstyle="round,pad=0.0,rounding_size=0.05",
                                 facecolor=color, edgecolor="none", zorder=5))
    ax.add_patch(Circle((cx - r * 0.32, cy - r * 0.05), r * 0.14, facecolor="white", zorder=5.2))
    ax.add_patch(Circle((cx + r * 0.32, cy - r * 0.05), r * 0.14, facecolor="white", zorder=5.2))
    ax.plot([cx, cx], [cy + r * 0.6, cy + r * 0.95], color=color, lw=1.6, zorder=5)
    ax.add_patch(Circle((cx, cy + r * 1.0), r * 0.1, facecolor=color, zorder=5))
    ax.plot([cx - r * 0.85, cx - r * 1.05], [cy - r * 0.2, cy - r * 0.2], color=color, lw=2, zorder=4.9)
    ax.plot([cx + r * 0.85, cx + r * 1.05], [cy - r * 0.2, cy - r * 0.2], color=color, lw=2, zorder=4.9)


def icon_chat(ax, cx, cy, r, color):
    ax.add_patch(FancyBboxPatch((cx - r, cy - r * 0.7), r * 2, r * 1.25,
                                 boxstyle="round,pad=0.0,rounding_size=0.06",
                                 facecolor=color, edgecolor="none", zorder=5))
    ax.add_patch(Polygon([(cx - r * 0.35, cy - r * 0.45), (cx - r * 0.05, cy - r * 0.45), (cx - r * 0.35, cy - r * 0.9)],
                          closed=True, facecolor=color, edgecolor="none", zorder=5))
    for dx in (-0.35, 0, 0.35):
        ax.add_patch(Circle((cx + dx * r, cy - r * 0.05), r * 0.09, facecolor="white", zorder=5.2))


def icon_magnifier(ax, cx, cy, r, color):
    ax.add_patch(Circle((cx - r * 0.15, cy + r * 0.15), r * 0.55, facecolor="none", edgecolor=color, lw=2.2, zorder=5))
    ax.plot([cx + r * 0.25, cx + r * 0.68], [cy - r * 0.25, cy - r * 0.68], color=color, lw=2.6, solid_capstyle="round", zorder=5)


def icon_shield(ax, cx, cy, r, color):
    pts = [(cx, cy + r), (cx + r * 0.75, cy + r * 0.55), (cx + r * 0.75, cy - r * 0.35),
           (cx, cy - r), (cx - r * 0.75, cy - r * 0.35), (cx - r * 0.75, cy + r * 0.55)]
    ax.add_patch(Polygon(pts, closed=True, facecolor=color, edgecolor="none", zorder=5))
    ax.plot([cx - r * 0.32, cx - r * 0.05, cx + r * 0.38], [cy - r * 0.05, cy - r * 0.28, cy + r * 0.28],
            color="white", lw=1.8, solid_capstyle="round", solid_joinstyle="round", zorder=5.2)


def icon_clock(ax, cx, cy, r, color):
    ax.add_patch(Circle((cx, cy), r * 0.85, facecolor="none", edgecolor=color, lw=2.0, zorder=5))
    ax.plot([cx, cx], [cy, cy + r * 0.5], color=color, lw=1.8, solid_capstyle="round", zorder=5.1)
    ax.plot([cx, cx + r * 0.4], [cy, cy], color=color, lw=1.8, solid_capstyle="round", zorder=5.1)


def icon_chart(ax, cx, cy, r, color):
    heights = [0.5, 0.85, 1.15]
    for i, hh in enumerate(heights):
        x = cx - r * 0.7 + i * r * 0.7
        ax.add_patch(Rectangle((x, cy - r * 0.7), r * 0.42, r * hh, facecolor=color, edgecolor="none", zorder=5))


def icon_link(ax, cx, cy, r, color):
    ax.add_patch(Ellipse((cx - r * 0.35, cy), r * 0.75, r * 0.5, angle=35, facecolor="none", edgecolor=color, lw=2.2, zorder=5))
    ax.add_patch(Ellipse((cx + r * 0.35, cy), r * 0.75, r * 0.5, angle=35, facecolor="none", edgecolor=color, lw=2.2, zorder=5.1))


def icon_layers(ax, cx, cy, r, color):
    for i, dy in enumerate([-0.35, 0, 0.35]):
        ax.add_patch(Polygon([(cx - r * 0.8, cy + dy * r), (cx, cy + dy * r - r * 0.28), (cx + r * 0.8, cy + dy * r),
                               (cx, cy + dy * r + r * 0.28)],
                              closed=True, facecolor=color, edgecolor="white", lw=0.5,
                              alpha=0.55 + 0.15 * i, zorder=5 + i * 0.05))


def icon_screen(ax, cx, cy, r, color):
    ax.add_patch(FancyBboxPatch((cx - r * 0.9, cy - r * 0.55), r * 1.8, r * 1.15,
                                 boxstyle="round,pad=0.0,rounding_size=0.05",
                                 facecolor="none", edgecolor=color, lw=2.0, zorder=5))
    ax.plot([cx - r * 0.35, cx + r * 0.35], [cy - r * 0.85, cy - r * 0.85], color=color, lw=2.0, zorder=5)
    ax.plot([cx, cx], [cy - r * 0.55, cy - r * 0.85], color=color, lw=2.0, zorder=5)


def icon_question(ax, cx, cy, r, color):
    ax.add_patch(Circle((cx, cy), r * 0.95, facecolor="none", edgecolor=color, lw=2.0, zorder=5))
    ax.text(cx, cy - r * 0.03, "?", ha="center", va="center", fontsize=r * 34, fontweight="bold",
            color=color, zorder=5.1)


def icon_flag(ax, cx, cy, r, color):
    ax.plot([cx - r * 0.55, cx - r * 0.55], [cy - r * 0.9, cy + r * 0.9], color=color, lw=2.4,
            solid_capstyle="round", zorder=5)
    ax.add_patch(Polygon([(cx - r * 0.55, cy + r * 0.9), (cx + r * 0.75, cy + r * 0.5),
                           (cx - r * 0.55, cy + r * 0.1)], closed=True, facecolor=color,
                          edgecolor="none", zorder=5))


def icon_grid(ax, cx, cy, r, color):
    for dx in (-1, 0, 1):
        for dy in (-1, 0, 1):
            ax.add_patch(Rectangle((cx + dx * r * 0.42 - r * 0.13, cy + dy * r * 0.42 - r * 0.13),
                                    r * 0.26, r * 0.26, facecolor=color, edgecolor="none", zorder=5))


ICON_SIZE = {"fontsize_offset": 0}


# ---------------------------------------------------------------------------
# Diagram 1: End-to-end architecture
# ---------------------------------------------------------------------------
def diagram_1():
    fig, ax = new_fig(14.2, 9.8)
    # subtle vertical wash to separate layers visually
    for i, (y0, y1, c) in enumerate([
        (7.35, 8.9, "#F7FAFD"), (5.6, 7.35, "#EFF5FC"), (3.9, 5.6, "#FDF1E7"),
        (2.2, 3.9, "#F4F6F8"), (0.25, 2.2, "#EFF7F1"),
    ]):
        ax.add_patch(Rectangle((0.1, y0), 14.0, y1 - y0, facecolor=c, edgecolor="none", zorder=0))

    ax.text(7.1, 9.4, "Data Quality AI Agent — End-to-End Architecture", ha="center",
            fontsize=21, fontweight="bold", color=NAVY)

    y1 = 7.6
    box(ax, 0.4, y1, 3.0, 1.1, "dq_rules\n(unified rule catalog)", fc=LIGHT_GRAY, ec=GRAY, fontsize=10.8, icon=icon_database)
    box(ax, 3.7, y1, 3.0, 1.1, "dq_stats\n(unified execution metadata)", fc=LIGHT_GRAY, ec=GRAY, fontsize=10.8, icon=icon_database)
    box(ax, 7.0, y1, 3.2, 1.1, "data_profile.dp_*\n(fragmented per-team tables)", fc=LIGHT_GRAY, ec=GRAY, fontsize=10.8, icon=icon_database)
    box(ax, 10.5, y1, 3.1, 1.1, "UC system tables · lineage\n· Delta history", fc=LIGHT_GRAY, ec=GRAY, fontsize=10.8, icon=icon_link)
    ax.text(0.4, y1 + 1.32, "DATA LAYER", fontsize=11.5, color=GRAY, fontweight="bold")

    y2 = 5.85
    box(ax, 3.0, y2, 8.0, 1.15,
        "SQL / Metadata Layer\nunified views + investigation functions",
        fc=LIGHT_BLUE, ec=BLUE, fontsize=12, icon=icon_gear)
    ax.text(0.4, y2 + 1.32, "SQL / METADATA LAYER", fontsize=11.5, color=BLUE, fontweight="bold")

    for x_src, x_dst in zip([1.9, 5.2, 8.6, 12.05], [4.0, 5.8, 8.2, 10.0]):
        arrow(ax, (x_src, y1), (x_dst, y2 + 1.15))
        flow_dots(ax, x_src, y1, x_dst, y2 + 1.15, BLUE, n=2)

    # Future-state overlay: Lakehouse Monitoring plugs into the SQL/Metadata layer
    # once serverless compute is available (dashed = not active today).
    ax.text(12.35, y2 + 1.32, "FUTURE STAGE", fontsize=10.5, color=GREEN, fontweight="bold", ha="center")
    box(ax, 11.1, y2, 2.5, 1.15, "Lakehouse\nMonitoring", fc="#EAF7EE", ec=GREEN, fontsize=11,
        fontweight="bold", textcolor="#1E5C38", icon=icon_chart, icon_color=GREEN, dashed=True, accent=False)
    arrow(ax, (11.1, y2 + 0.575), (11.0, y2 + 0.575), color=GREEN, lw=2.0, style="-|>")
    ax.text(12.35, y2 - 0.28, "swaps in once serverless\ncompute is available", ha="center",
            fontsize=8.3, color=GREEN, style="italic")

    y3 = 4.15
    box(ax, 0.4, y3, 13.2, 1.35,
        "Tool Layer -- 8 Genie Tools\nRule Intelligence . Profiling Intelligence . DQ Execution Analytics . Schema Intelligence\nFreshness Intelligence . Volume Intelligence . Lineage & Impact . Governance Intelligence",
        fc=LIGHT_ORANGE, ec=ORANGE, fontsize=10.3, icon=icon_gear)
    ax.text(0.4, y3 + 1.52, "TOOL LAYER", fontsize=11.5, color=ORANGE, fontweight="bold")
    arrow(ax, (7, y2), (7, y3 + 1.35))
    flow_dots(ax, 7, y2, 7, y3 + 1.35, ORANGE, n=2)

    y4 = 2.45
    box(ax, 3.2, y4, 7.6, 1.15,
        "Data Quality AI Agent",
        fc=NAVY, ec=NAVY, fontsize=15, fontweight="bold", textcolor=WHITE, icon=icon_robot, icon_color=ORANGE, accent=False)
    ax.text(0.4, y4 + 1.32, "AGENT LAYER", fontsize=11.5, color=NAVY, fontweight="bold")
    arrow(ax, (7, y3), (7, y4 + 1.15))
    flow_dots(ax, 7, y3, 7, y4 + 1.15, NAVY, n=2)

    box(ax, 11.2, y4, 2.4, 1.15, "RAG:\nplaybooks . glossary", fc=LIGHT_GREEN, ec=GREEN, fontsize=10.2, icon=icon_layers)
    arrow(ax, (11.2, y4 + 0.6), (10.8, y4 + 0.6))

    y5 = 0.5
    box(ax, 0.6, y5, 3.6, 1.1, "Chat (Agent Studio)", fc=LIGHT_GRAY, ec=GRAY, fontsize=11.2, icon=icon_chat)
    box(ax, 4.6, y5, 4.6, 1.1, "Scheduled Daily Health Summary", fc=LIGHT_GRAY, ec=GRAY, fontsize=11.2, icon=icon_clock)
    box(ax, 9.6, y5, 4.0, 1.1, "Scorecard API / dashboards", fc=LIGHT_GRAY, ec=GRAY, fontsize=11.2, icon=icon_screen)
    ax.text(0.4, y5 + 1.32, "CONSUMERS", fontsize=11.5, color=GRAY, fontweight="bold")
    for x in [2.4, 6.9, 11.6]:
        arrow(ax, (7, y4), (x, y5 + 1.1))

    fig.tight_layout()
    fig.savefig(os.path.join(OUT, "diagram_1_architecture.png"), dpi=175)
    plt.close(fig)


# ---------------------------------------------------------------------------
# Diagram 2: Genie workspace map
# ---------------------------------------------------------------------------
def diagram_2():
    fig, ax = new_fig(15.0, 13.0)
    cx, cy = 7.5, 6.4
    ax.add_patch(Circle((cx, cy), 5.55, facecolor="#F6F8FB", edgecolor="none", zorder=0))
    ax.text(cx, 12.55, "8 Specialized Genie Workspaces", ha="center", fontsize=22, fontweight="bold", color=NAVY)
    ax.text(cx, 12.05, "color-coded to the same Phase 1 / Phase 2 rollout as the Quality Dimension Coverage Matrix",
            ha="center", fontsize=11.5, color=GRAY, style="italic")

    box(ax, cx - 1.5, cy - 0.62, 3.0, 1.24, "Data Quality\nAI Agent", fc=NAVY, ec=NAVY, fontsize=13.5,
        fontweight="bold", textcolor=WHITE, zorder=3, icon=icon_robot, icon_color=ORANGE, accent=False)

    # phase 1 = supports Completeness/Validity/Uniqueness directly from dq_rules/dq_stats/
    # profiling with no new infrastructure; phase 2 = needs the registry SLA/volume baselines,
    # the schema-snapshot job, or UC lineage tracking.
    workspaces = [
        ("Rule\nIntelligence", "dq_rules", icon_gear, 1),
        ("Profiling\nIntelligence", "v_profile_unified", icon_chart, 1),
        ("DQ Execution\nAnalytics", "v_rule_execution_detail", icon_screen, 1),
        ("Schema\nIntelligence", "dq_schema_snapshot", icon_layers, 2),
        ("Freshness\nIntelligence", "fn_freshness_gap", icon_clock, 2),
        ("Volume\nIntelligence", "fn_volume_anomaly", icon_chart, 2),
        ("Lineage &\nImpact", "UC lineage", icon_link, 2),
        ("Governance\nIntelligence", "fn_dq_scorecard", icon_shield, 2),
    ]
    n = len(workspaces)
    r = 4.55
    w, h = 2.35, 1.15
    for i, (name, scope, ic, phase) in enumerate(workspaces):
        angle = math.pi / 2 + 2 * math.pi * i / n
        x = cx + r * math.cos(angle)
        y = cy + r * math.sin(angle) * 0.92
        dx, dy = cx - x, cy - y
        dist = (dx ** 2 + dy ** 2) ** 0.5
        ux, uy = dx / dist, dy / dist
        line_color = GREEN if phase == 1 else ORANGE
        fc, ec = (LIGHT_GREEN, GREEN) if phase == 1 else (LIGHT_ORANGE, ORANGE)
        arrow(ax, (x + ux * (w / 2), y + uy * (h / 2)), (cx - ux * 1.5, cy - uy * 0.62), color=GRAY, lw=1.3)
        flow_dots(ax, x + ux * (w / 2), y + uy * (h / 2), cx - ux * 1.5, cy - uy * 0.62, line_color, n=2)
        box(ax, x - w / 2, y - h / 2, w, h, name, fc=fc, ec=ec, fontsize=11, fontweight="bold", icon=ic)
        ax.text(x, y - h / 2 - 0.24, scope, ha="center", fontsize=9.2, color=GRAY, style="italic")
        badge = "PHASE 1" if phase == 1 else "PHASE 2"
        ax.text(x, y - h / 2 - 0.48, badge, ha="center", fontsize=8, color=line_color, fontweight="bold")

    # legend
    ly = 0.35
    box(ax, cx - 3.7, ly, 0.4, 0.32, "", fc=LIGHT_GREEN, ec=GREEN, accent=False)
    ax.text(cx - 3.15, ly + 0.16, "Phase 1 — start here (no new infra)", ha="left", va="center", fontsize=10, color="#1E5C38")
    box(ax, cx + 0.55, ly, 0.4, 0.32, "", fc=LIGHT_ORANGE, ec=ORANGE, accent=False)
    ax.text(cx + 1.1, ly + 0.16, "Phase 2 — next (needs new infra)", ha="left", va="center", fontsize=10, color="#7A3B0E")

    fig.tight_layout()
    fig.savefig(os.path.join(OUT, "diagram_2_genie_map.png"), dpi=175)
    plt.close(fig)


# ---------------------------------------------------------------------------
# Diagram 3: Quality dimension coverage matrix (+ real-world example column)
# ---------------------------------------------------------------------------
def diagram_3():
    # Ordered Phase 1 (simple, start-here — pure rule-execution, no new infra) first,
    # then Phase 2 (complex — needs new registry/baseline/snapshot infrastructure).
    rows = [
        ("Completeness", icon_layers,
         "Rule + profile\ncorroboration", "Lineage-attributed\nupstream owner",
         "merchant_name null rate\n0.1% -> 12% same day a\nCOLUMN_DROPPED event fires", 1),
        ("Validity", icon_shield,
         "*_should_be_valid\nrules", "Step-change vs\ngradual drift",
         "address_should_be_valid\nfailures triple after an\nupstream date-format change", 1),
        ("Uniqueness", icon_gear,
         "Duplicate-key\nrules", "Idempotency /\nsource fix",
         "Duplicate txn_id spike traced\nto a batch replay, not new\nsource duplicates", 1),
        ("Consistency", icon_link,
         "OVERLAP /\ncross-field rules", "Reference-data /\njoin-timing",
         "Standardized vs raw address\ndisagree for 8% of zeta\nrecords (OVERLAP)", 2),
        ("Timeliness", icon_clock,
         "fn_freshness_gap\nvs SLA", "NOT_RUN vs\nfailed-but-ran",
         "TELETRACK feed 14h late --\nfn_freshness_gap shows the\njob never triggered (NOT_RUN)", 2),
        ("Volume", icon_chart,
         "fn_volume_anomaly\nbaseline bands", "Rejection rate vs\nsource outage",
         "corebanking_tran_ct volume\n-40%, matches the recurring\nSunday low-volume pattern", 2),
        ("Schema Drift", icon_layers,
         "dq_schema_snapshot\ndiff", "Usually the\nroot cause itself",
         "New nullable column appears\nupstream; lineage flags 3\ndownstream dashboards at risk", 2),
    ]

    fig, ax = new_fig(13.4, 14.0)
    ax.text(6.7, 13.55, "Quality Dimension Coverage Matrix", ha="center", fontsize=23, fontweight="bold", color=NAVY)
    ax.text(6.7, 13.05, "Detection -> Root Cause -> a real-world example, grouped by rollout phase", ha="center",
            fontsize=13, color=GRAY, style="italic")

    left, top = 0.35, 11.8
    dim_w = 2.15
    col_w = [2.75, 2.95, 4.85]
    total_w = dim_w + sum(col_w)
    row_h = 1.35
    divider_h = 0.62
    gap = 0.06

    x = left
    box(ax, x, top, dim_w, 1.0, "Dimension", fc=NAVY, ec=NAVY, textcolor=WHITE, fontweight="bold", fontsize=13.5, accent=False)
    x += dim_w
    for c, w in zip(["Detection", "Root Cause", "Real-World Example"], col_w):
        box(ax, x, top, w, 1.0, c, fc=NAVY, ec=NAVY, textcolor=WHITE, fontweight="bold", fontsize=13.5, accent=False)
        x += w

    y_top = top - 0.15
    current_phase = None
    for name, ic, det, rc, ex, phase in rows:
        if phase != current_phase:
            d_bottom = y_top - divider_h
            if phase == 1:
                label = "PHASE 1 -- START HERE   (rule-based, no new infrastructure needed)"
                fc_div, ec_div, tc_div = "#DCEFE2", GREEN, "#1E5C38"
            else:
                label = "PHASE 2 -- NEXT   (needs new registry / baseline / snapshot infrastructure)"
                fc_div, ec_div, tc_div = LIGHT_ORANGE, ORANGE, "#7A3B0E"
            box(ax, left, d_bottom, total_w, divider_h, label, fc=fc_div, ec=ec_div, textcolor=tc_div,
                fontweight="bold", fontsize=12.5, accent=False)
            y_top = d_bottom - gap
            current_phase = phase

        row_bottom = y_top - row_h
        cell_fc = "#EEF6F0" if phase == 1 else "#FDF3E9"
        dim_fc, dim_ec = (LIGHT_GREEN, GREEN) if phase == 1 else (LIGHT_ORANGE, ORANGE)
        x = left
        box(ax, x, row_bottom, dim_w, row_h - 0.1, name, fc=dim_fc, ec=dim_ec, fontsize=12.5, fontweight="bold", icon=ic)
        x += dim_w
        box(ax, x, row_bottom, col_w[0], row_h - 0.1, det, fc=cell_fc, ec="#C7CDD6", fontsize=11, accent=False)
        x += col_w[0]
        box(ax, x, row_bottom, col_w[1], row_h - 0.1, rc, fc=cell_fc, ec="#C7CDD6", fontsize=11, accent=False)
        x += col_w[1]
        box(ax, x, row_bottom, col_w[2], row_h - 0.1, ex, fc="#FFFDF7", ec="#E8C79A", fontsize=11, accent=False)

        y_top = row_bottom - gap

    fig.tight_layout()
    fig.savefig(os.path.join(OUT, "diagram_3_dimension_matrix.png"), dpi=175)
    plt.close(fig)


# ---------------------------------------------------------------------------
# Diagram 4: Root-cause investigation sequence (example)
# ---------------------------------------------------------------------------
def diagram_4():
    fig, ax = new_fig(14.2, 7.0)
    ax.text(7.1, 6.55, "Root-Cause Investigation Sequence -- Example: Validity Failure (Phase 1)", ha="center",
            fontsize=19, fontweight="bold", color=NAVY)

    steps = [
        ("1. DQ Execution Analytics\ndetects a validity rule's\nfailure rate spike", LIGHT_ORANGE, ORANGE, icon_shield),
        ("2. Sub-rule drill-down\n(v_rule_execution_subdetail)\nisolates which check failed", LIGHT_GRAY, GRAY, icon_magnifier),
        ("3. fn_rule_pass_rate_trend\nshows a step-change,\nnot gradual drift", LIGHT_BLUE, BLUE, icon_chart),
        ("4. Schema Intelligence checks\nfor a TYPE_CHANGED event\non the source table", LIGHT_BLUE, BLUE, icon_layers),
        ("5. Rule Intelligence confirms\naction_if_failed and\nthreshold configuration", LIGHT_GREEN, GREEN, icon_gear),
        ("6. Agent synthesizes root\ncause + confidence +\nrecommendation", NAVY, NAVY, icon_robot),
    ]
    n = len(steps)
    w, h = 2.05, 1.85
    gap = (14.2 - n * w) / (n + 1)
    y = 3.55
    for i, (text, fc, ec, ic) in enumerate(steps):
        x = gap + i * (w + gap)
        textcolor = WHITE if fc == NAVY else "#111827"
        icon_color = ORANGE if fc == NAVY else ec
        box(ax, x, y - h / 2, w, h, text, fc=fc, ec=ec, fontsize=9.6, textcolor=textcolor, icon=ic, icon_color=icon_color)
        if i < n - 1:
            arrow(ax, (x + w, y), (x + w + gap, y), color=NAVY, lw=2.2)
            flow_dots(ax, x + w, y, x + w + gap, y, ORANGE, n=1)

    fig.tight_layout()
    fig.savefig(os.path.join(OUT, "diagram_4_root_cause_sequence.png"), dpi=175)
    plt.close(fig)


# ---------------------------------------------------------------------------
# Diagram 5: Current state vs future Lakehouse Monitoring state
# ---------------------------------------------------------------------------
def diagram_5():
    fig, ax = new_fig(13.8, 8.7)
    ax.add_patch(Rectangle((0.25, 0.3), 6.1, 6.85, facecolor="#F4F5F7", edgecolor="none", zorder=0))
    ax.add_patch(Rectangle((7.15, 0.3), 6.1, 6.85, facecolor="#F1F8F3", edgecolor="none", zorder=0))
    ax.text(6.9, 8.35, "Current State vs. Future Lakehouse Monitoring State", ha="center",
            fontsize=20, fontweight="bold", color=NAVY)
    ax.text(6.9, 7.95, "Migrate domain-by-domain — pilot one domain, validate for a week, then cut over (no big-bang cutover)",
            ha="center", fontsize=11, color=GRAY, style="italic")

    box(ax, 0.4, 6.9, 5.8, 0.8, "TODAY -- no serverless compute", fc=GRAY, ec=GRAY, textcolor=WHITE,
        fontweight="bold", fontsize=12.5, accent=False)
    cur = [("dq_profile_table_registry\n(manual onboarding MERGE)", icon_database),
           ("Generated UNION ALL\nv_profile_unified (Job: 15-min refresh)", icon_gear),
           ("Nightly dq_schema_snapshot\n+ fn_schema_drift_check diff", icon_layers),
           ("Classic SQL Warehouse +\nregular Databricks Jobs", icon_gear)]
    y = 6.3
    for c, ic in cur:
        box(ax, 0.4, y - 0.85, 5.8, 0.95, c, fc=LIGHT_GRAY, ec=GRAY, fontsize=10.4, icon=ic)
        y -= 1.15

    box(ax, 7.3, 6.9, 5.8, 0.8, "FUTURE -- serverless enabled", fc=GREEN, ec=GREEN, textcolor=WHITE,
        fontweight="bold", fontsize=12.5, accent=False)
    fut = [("CREATE MONITOR per table\n(no registry needed)", icon_database),
           ("Native *_profile_metrics /\n*_drift_metrics tables", icon_gear),
           ("Native distribution drift\n(beyond schema-only)", icon_shield),
           ("Managed refresh --\nno custom jobs to maintain", icon_clock)]
    y = 6.3
    for c, ic in fut:
        box(ax, 7.3, y - 0.85, 5.8, 0.95, c, fc=LIGHT_GREEN, ec=GREEN, fontsize=10.4, icon=ic)
        y -= 1.15

    box(ax, 3.9, 0.5, 5.7, 1.0, "Migration = view swap only.\nGenie workspaces, agent, tools unchanged.",
        fc=LIGHT_ORANGE, ec=ORANGE, fontsize=11.5, fontweight="bold", icon=icon_shield)
    arrow(ax, (6.2, 1.55), (6.2, 1.9), color=NAVY, lw=2.2)
    ax.annotate("", xy=(7.2, 3.575), xytext=(6.35, 3.575),
                arrowprops=dict(arrowstyle="-|>", color=NAVY, lw=2.2))
    flow_dots(ax, 6.35, 3.575, 7.2, 3.575, ORANGE, n=2)

    fig.tight_layout()
    fig.savefig(os.path.join(OUT, "diagram_5_lhm_current_vs_future.png"), dpi=175)
    plt.close(fig)


# ---------------------------------------------------------------------------
# Diagram 6: The problem — 6 core problems this agent solves
# ---------------------------------------------------------------------------
def problem_card(ax, x, y, w, h, title, desc, icon):
    shadow(ax, x, y, w, h)
    p = FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.09",
                        linewidth=1.8, edgecolor=RED, facecolor=WHITE, zorder=2)
    ax.add_patch(p)
    bar = FancyBboxPatch((x, y), 0.1, h, boxstyle="round,pad=0.0,rounding_size=0.03",
                          linewidth=0, facecolor=RED, zorder=2.5, alpha=0.9)
    ax.add_patch(bar)

    icon_cy = y + h - 0.62
    ax.add_patch(Circle((x + w / 2, icon_cy), 0.4, facecolor=LIGHT_RED, edgecolor=RED, lw=1.4, zorder=3))
    icon(ax, x + w / 2, icon_cy, 0.23, RED)

    ax.text(x + w / 2, y + h - 1.32, title, ha="center", va="center", fontsize=13.5,
            fontweight="bold", color=NAVY, zorder=3)
    ax.text(x + w / 2, y + 0.72, desc, ha="center", va="center", fontsize=9.6, color=GRAY, zorder=3)


def diagram_6():
    fig, ax = new_fig(14.2, 9.7)
    ax.text(7.1, 9.25, "The Problem: 6 Core Gaps This Agent Closes", ha="center",
            fontsize=21, fontweight="bold", color=NAVY)
    ax.text(7.1, 8.8, "Not just \"dashboards need another chart\" -- the underlying investigation "
                       "problems a dashboard structurally can't solve", ha="center",
            fontsize=11.2, color=GRAY, style="italic")

    cards = [
        ("No Root Cause,\nJust Alerts",
         "A rule fails and shows a\nred flag -- with no explanation\nof why.", icon_flag),
        ("Signals Live\nin Silos",
         "Rules, profiling, schema\nhistory, and lineage sit in\nseparate tables and tools.", icon_layers),
        ("Inconsistent\nInvestigation",
         "Every team debugs its own\nway -- answers vary by who\nhappens to look.", icon_question),
        ("Fragmented\nProfiling Data",
         "Profiling is scattered across\ndozens of per-team tables\nwith no unified view.", icon_database),
        ("No Confidence\nor Audit Trail",
         "\"Probably fine\" can't be\nchecked or trusted at scale\nwithout an evidence trail.", icon_shield),
        ("Doesn't Scale",
         "Manual triage collapses across\nhundreds of products and\nthousands of pipelines.", icon_grid),
    ]

    card_w, card_h, gap_x, gap_y = 4.2, 2.55, 0.35, 0.35
    left = 0.45
    row_y = [5.55, 2.65]
    for idx, (title, desc, ic) in enumerate(cards):
        col = idx % 3
        row = idx // 3
        x = left + col * (card_w + gap_x)
        y = row_y[row]
        problem_card(ax, x, y, card_w, card_h, title, desc, ic)

    box(ax, 0.45, 0.55, 13.3, 1.0,
        "The fix isn't another dashboard -- it's an agent that investigates, corroborates, and explains.",
        fc=LIGHT_RED, ec=RED, fontsize=12.5, fontweight="bold", textcolor=RED, accent=False)

    fig.tight_layout()
    fig.savefig(os.path.join(OUT, "diagram_6_problem_statement.png"), dpi=175)
    plt.close(fig)


if __name__ == "__main__":
    diagram_1()
    diagram_2()
    diagram_3()
    diagram_4()
    diagram_5()
    diagram_6()
    print("Diagrams written to", OUT)
