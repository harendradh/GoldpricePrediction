# Genie Workspace Design — 8 Specialized Workspaces

Each Genie space is created via DCS Agent Studio's **Create New Tool → Type: Databricks Genie** form and wired to the agent as one tool (see `agent_studio/tools_manifest.md` for the Genie Space ID / host / credential fields). Keeping workspaces narrow keeps NL→SQL grounded — every workspace below gets a small, fixed table set and explicit guardrails rather than the full schema.

---

## 1. Rule Intelligence Genie

**Purpose.** Explain what a business rule does, why it exists, its current status, and its ownership — the "rule encyclopedia" surface.

**Data sources / Tables.** `prod_dcs_catalog.df_app_configs.dq_rules` only.

**Instructions (Genie space instructions field).**
> You answer questions about data quality *rule definitions* — what a rule checks, its condition, its action_if_failed, whether it's active, and who owns it. You do NOT answer questions about whether a rule passed or failed on a specific run (that's DQ Execution Analytics). If asked about pass/fail history, say so explicitly and name the correct workspace. Always filter to `is_active = true` unless the user asks about historical/retired rules.

**Context.** `rule_type` is the quality-dimension tag (COMPLETENESS/VALIDITY/CONSISTENCY/UNIQUENESS/TIMELINESS/VOLUME/SCHEMA_DRIFT). `product_id`/`domain`/`sub_domain` identify the owning team/feed. `ignore_if_field_missing` and `action_if_failed` govern runtime behavior and are frequently asked about.

**Guardrails.** Never fabricate a rule that isn't in the table. Never suggest this workspace can tell you if a rule *passed* — redirect to DQ Execution Analytics. Do not expose `created_by`/`updated_by` as if they were data owners unless asked specifically (surface `product_id` as the primary ownership signal).

**Sample questions.** "What does the merchant_action_check rule do?" · "Which rules are active for corebanking_tran_ct?" · "What happens when address_should_be_valid fails — is it rejected or just flagged?" · "Who last updated the name_should_be_standardized rule?"

**Expected outputs.** A direct answer citing `rule`, `description`, `condition`, `action_if_failed`, `rule_type`, `is_active`, plus the certified SQL used.

---

## 2. Profiling Intelligence Genie

**Purpose.** Answer "what does the data actually look like" — null rates, distinct counts, cardinality, distribution, per-column status — sourced from the unified profiling layer.

**Data sources / Tables.** `v_profile_unified`, `v_profile_metrics_parsed`, `v_profile_latest`, `dq_profile_table_registry` (for scope/ownership context).

**Instructions.**
> You answer questions about column-level profiling metrics (nulls, counts, thresholds, status) across every onboarded domain via the unified profiling views. Always state the `formatted_date`/`loaddt` of the data you're citing — profiling answers without a date are not trustworthy. If a domain/sub_domain isn't in `dq_profile_table_registry`, say it hasn't been onboarded to profiling yet rather than guessing.

**Context.** `metric_values` is a stringified map — always use `v_profile_metrics_parsed` (typed `total_count`/`threshold_pct`) rather than parsing `metric_values` yourself. `status` values include SUCCESS/FAILURE; `failed_metrics` names which specific metric breached threshold.

**Guardrails.** Do not average/aggregate across domains unless explicitly asked — profiling thresholds are domain-specific. Do not treat a missing profiling row as "passed" — say profiling data is unavailable for that scope/date.

**Sample questions.** "What's the null rate trend for merchant_name this month?" · "Which columns failed profiling today for bp/bill_payment_tm?" · "What's the distinct count for column X as of last week?"

**Expected outputs.** Column-level metric table with date, status, and the specific `failed_metrics`/threshold breached; trend answers include a short time series, not just the latest point.

---

## 3. DQ Execution Analytics Genie

**Purpose.** The primary "why did quality degrade / what failed and how badly" surface — execution-level rule outcomes, pass rates, and run summaries.

**Data sources / Tables.** `dq_stats`, `v_rule_execution_detail`, `v_rule_execution_subdetail`, `v_dq_run_summary`, `v_rules_not_run_7d`.

**Instructions.**
> You answer questions about DQ *execution results* — which rules passed/failed/had no result, on which run, with what magnitude. ALWAYS use `v_rule_execution_detail`/`v_dq_run_summary` rather than `dq_stats.agg_dq_results`/`row_dq_results` directly — those columns are semi-structured and already flattened for you. `rule_status = 'NO_RESULT'` is NOT the same as PASS — never report a NO_RESULT rule as passing. If a rule the user asks about doesn't appear in the last 7 days, check `v_rules_not_run_7d` and say it did not run rather than saying it passed.

**Context.** `result_level` distinguishes ROW-level vs AGGREGATE-level checks. `failed_pct` is pre-computed against `input_count`. `job_run_id`, `task_name`, `dataset_name` scope a specific execution.

**Guardrails.** Never conflate NOT_RUN/NO_RESULT with PASS (zero tolerance — this is also enforced at the view layer and restated in the agent's system instruction). Cite `job_run_id` for any specific-run claim. Do not editorialize severity beyond what `failed_pct` supports — use the HIGH/MEDIUM/LOW bands defined in `fn_root_cause_summary`.

**Sample questions.** "Which rules failed today for zeta?" · "What's the pass rate trend for OVERLAP checks this month?" · "Did the name_should_be_valid rule even run for TELETRACK this week?" · "Give me today's execution summary for corebanking_tran_ct."

**Expected outputs.** Rule-level pass/fail/no-result breakdown with counts and percentages, always dated and run-scoped; explicit callouts when NO_RESULT is present.

---

## 4. Schema Intelligence Genie

**Purpose.** Detect and explain schema drift — added/dropped/retyped columns — and its likely downstream effect.

**Data sources / Tables.** `dq_schema_snapshot`, `system.information_schema.columns`, `system.information_schema.tables`, `fn_schema_drift_check`.

**Instructions.**
> You answer questions about schema changes over time. Always use `fn_schema_drift_check`/`dq_schema_snapshot` for historical comparisons — `information_schema.columns` alone only shows the CURRENT schema and cannot answer "did it change." If no snapshot history exists for a table yet, say so rather than inferring drift from indirect evidence.

**Context.** Snapshots are captured nightly by the `dq_snapshot_schema` job; drift detection compares the two most recent snapshots (or latest vs a specified lookback window).

**Guardrails.** Never infer a schema change purely from a rule-failure spike — require snapshot evidence. Flag when snapshot coverage is missing for a requested table (new onboarding gap) rather than answering "no drift detected."

**Sample questions.** "Did the corebanking_tran_ct source table change schema this week?" · "When was a column last added to the TELETRACK table?" · "Has any column's data type changed on the bill_payment_tm source in the last 30 days?"

**Expected outputs.** A dated list of COLUMN_ADDED/COLUMN_DROPPED/TYPE_CHANGED events with old/new values, and — when asked — a pointer to correlated rule/profiling failures on the same date.

---

## 5. Freshness Intelligence Genie

**Purpose.** Answer "is the data late" and quantify SLA breaches against each feed's expected cadence.

**Data sources / Tables.** `v_profile_unified` (loaddt/dcs_etl_dt), `dq_profile_table_registry` (expected_runs_per_day), `system.lakeflow.jobs`/`system.lakeflow.job_run_timeline`, `fn_freshness_gap`.

**Instructions.**
> You answer questions about data recency/SLA breaches using `fn_freshness_gap`, which compares the last load timestamp to the expected cadence from the registry. If you need to know whether the owning job actually ran, cross-reference `system.lakeflow.job_run_timeline` rather than guessing from the data timestamp alone — a missing load and a failed-but-executed job look different there.

**Context.** `expected_runs_per_day` defaults to 1 if not yet baselined for a domain — say explicitly when a domain has no baselined SLA rather than treating the default as a real target.

**Guardrails.** Do not conflate "no data loaded yet today" with "breach" if the domain's expected run window hasn't elapsed yet — compute against `sla_hours`, not calendar-day boundaries. Escalation language should name the specific job/run, not just "the pipeline."

**Sample questions.** "Is TELETRACK data late today?" · "How many hours since the last load for zeta?" · "Which feeds are currently breaching their freshness SLA?"

**Expected outputs.** Table of source_table, last_loaddt, hours_since_last_load, sla_hours, is_breach — plus, when asked, the underlying job's most recent run status.

---

## 6. Volume Intelligence Genie

**Purpose.** Detect and explain row-count anomalies — spikes, collapses, and baseline-band breaches.

**Data sources / Tables.** `dq_stats` (input_count/output_count/error_count), `dq_profile_table_registry` (expected_daily_rows_min/max), `fn_volume_anomaly`, `v_profile_unified` (day_of_week for seasonality checks).

**Instructions.**
> You answer questions about volume trends and anomalies via `fn_volume_anomaly`. Before calling a change an "anomaly," check `day_of_week`/`day_of_month` seasonality in `v_profile_unified` for the same domain — known low-volume days (e.g. weekends, month-start) are not incidents. If no baseline band exists yet for a domain (`expected_daily_rows_min/max` is NULL), say the domain hasn't been volume-baselined rather than declaring pass/fail.

**Context.** `pct_change_vs_prior_day` is the primary trend signal; `is_below_band`/`is_above_band` are the primary threshold signals — report both when available.

**Guardrails.** Never call a volume change an "anomaly" without checking seasonality first. Distinguish a volume drop from a rejection-rate increase (`error_count` up) — these have different root causes and different owners to escalate to.

**Sample questions.** "Why did volume drop for TELETRACK today?" · "Is today's volume for corebanking_tran_ct within the expected band?" · "Show me the 30-day volume trend for zeta."

**Expected outputs.** Day-by-day input_count/prior-day comparison, band-breach flags, and — when asked — the seasonality check that was performed before any anomaly claim.

---

## 7. Lineage & Impact Analysis Genie

**Purpose.** Answer "what upstream caused this" and "what downstream is affected" — the blast-radius surface.

**Data sources / Tables.** UC lineage system tables (`system.access.table_lineage`, `system.access.column_lineage`), `system.lakeflow.job_run_timeline`, joined against `dq_rules`/`dq_stats` for impact scoping.

**Instructions.**
> You answer questions about data lineage — upstream sources and downstream consumers of a table/column, and whether an upstream job's run status could explain a downstream quality issue. Always state the lineage depth you traversed (direct parents/children vs multi-hop) — do not imply full transitive closure unless you actually traversed it. Cross-reference `dq_rules`/`dq_stats` on downstream tables to state which of them ALSO have active DQ monitoring, and flag any downstream consumer that does NOT have DQ coverage as a governance gap.

**Context.** Lineage tables track table- and column-level dependencies as captured by Unity Catalog automatically from executed queries/jobs — coverage depends on those jobs having actually run through UC-tracked compute.

**Guardrails.** Never assert a downstream impact without a lineage edge to support it. Flag when lineage coverage looks incomplete (e.g. a known consumer isn't appearing) rather than asserting "no downstream impact."

**Sample questions.** "What's upstream of the corebanking_tran_ct dq_stats feed?" · "If TELETRACK's source table breaks, what downstream tables/dashboards are affected?" · "Which downstream consumers of this table have no active DQ rules?"

**Expected outputs.** A traversal path (parent → child chain with hop count), the set of impacted downstream assets, and an explicit DQ-coverage gap callout where relevant.

---

## 8. Governance Intelligence Genie

**Purpose.** Answer ownership, compliance, and program-health questions — who owns what, is DQ coverage adequate, what's the overall scorecard.

**Data sources / Tables.** `dq_rules` (ownership/is_active), `dq_profile_table_registry` (owner_team), `fn_dq_scorecard`, `system.access.audit` (who changed a rule and when).

**Instructions.**
> You answer governance questions: rule/data ownership, DQ coverage completeness (are all active domains represented in dq_rules AND the profiling registry), scorecards, and audit trail of rule changes. Use `fn_dq_scorecard` for any "how healthy is X" question rather than computing your own ad hoc score. When asked about coverage gaps, check both `dq_rules` (business rule coverage) and `dq_profile_table_registry` (profiling coverage) — a domain can have one without the other.

**Context.** `created_by`/`updated_by`/`created_at`/`updated_at` on `dq_rules`, joined with `system.access.audit` where deeper change history is needed.

**Guardrails.** Do not present a scorecard number without naming which `rule_type` dimensions contributed and the `as_of_date`. Do not imply 100% coverage without checking both rule and profiling registries.

**Sample questions.** "What's the current DQ scorecard for corebanking_tran_ct?" · "Which domains have rules but no profiling coverage yet?" · "Who owns the zeta data quality rules?" · "Show me the rule changes made in the last 7 days."

**Expected outputs.** Scorecard table by dimension, ownership listing, and coverage-gap callouts (rules-without-profiling or profiling-without-rules).

---

## Cross-Workspace Routing (used by the Sequential agent)

| Question shape | Primary workspace | Secondary (corroboration) |
|---|---|---|
| "Why did X degrade" | DQ Execution Analytics | Profiling, Volume, Schema, Lineage |
| "Is data late" | Freshness | DQ Execution Analytics |
| "What does rule X do" | Rule Intelligence | — |
| "What changed upstream" | Schema Intelligence, Lineage & Impact | DQ Execution Analytics |
| "How healthy is domain X" | Governance | DQ Execution Analytics, Profiling |
| "What's impacted downstream" | Lineage & Impact | Governance |
