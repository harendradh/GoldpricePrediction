# Quality Dimensions — Investigation Design

Each dimension below is designed as a full investigation loop, not a single check. `rule_type` in `dq_rules` is the tag that maps a business rule to its dimension (COMPLETENESS, VALIDITY, CONSISTENCY, UNIQUENESS, TIMELINESS, VOLUME, SCHEMA_DRIFT); `fn_dq_scorecard` aggregates by this tag.

## Rollout phasing

Phasing is driven by build complexity, not business importance:

- **Phase 1 — start here.** Completeness, Validity, Uniqueness. Each is a pure rule-execution check answerable directly from `v_rule_execution_detail` (built on the already-production `dq_rules`/`dq_stats` tables) — no new registry, baseline, or job is required.
- **Phase 2 — next.** Consistency, Timeliness, Volume, Schema Drift. Each needs one piece of new supporting infrastructure before it can run: Consistency needs cross-source/sub-rule correlation; Timeliness and Volume need the registry-driven SLA/baseline bands (`dq_profile_table_registry.expected_runs_per_day` / `expected_daily_rows_min/max`); Schema Drift needs the nightly `dq_schema_snapshot` job.

See `docs/03_GENIE_WORKSPACES.md` and the leadership deck's Quality Dimension Coverage Matrix (Figure 3) for the same grouping applied to the Genie workspaces and rollout plan.

---

## 1. Completeness

**Business problem.** Required fields or entire records are missing, silently degrading downstream reports and models (e.g. `merchant_name is not null` failures observed in production `dq_stats.row_dq_results`).

**Detection approach.** `rule_type = 'COMPLETENESS'` rules in `dq_rules` (e.g. null checks, mandatory-field checks) evaluated per run; cross-checked against `v_profile_metrics_parsed.total_count`/null-related `failed_metrics` from profiling.

**Investigation workflow.**
1. Query `v_rule_execution_detail` for `rule_status = 'FAIL'` and rule names matching completeness rules for the scope/date.
2. Pull the matching `v_profile_metrics_parsed` row for the same column/date to see if null% independently corroborates.
3. Check `v_dq_run_summary.input_count` — a completeness spike often coincides with a volume/schema change (upstream dropped a field or a join changed cardinality).
4. If corroborated, check `fn_schema_drift_check` for a recent `COLUMN_DROPPED`/`TYPE_CHANGED` event on the source table.

**Root cause strategy.** Chain: rule failure → profiling confirmation → schema drift or upstream job failure (via Lineage & Impact Genie) → attribute to the most recent qualifying upstream event.

**AI reasoning.** The agent should not report "completeness dropped" from a single rule failure alone — it must corroborate with profiling before asserting root cause, and explicitly say when profiling is unavailable (`NO_RESULT`) rather than assuming health.

**Recommendation.** Add/tighten a `not null`/`is not null` rule in `dq_rules` scoped to the affected `product_id`/`task_name`; suggested `condition` SQL is generated from the failing column.

**Example questions.** "Why is merchant_name null more often this week?" · "Which required fields are missing today for corebanking_tran_ct?" · "Is this a new completeness gap or a known issue?"

---

## 2. Validity

**Business problem.** Values exist but don't conform to expected format/domain (invalid address, phone, email, out-of-range values) — e.g. `address_should_be_valid`, `phone_should_be_valid`, `name_should_be_valid` rules seen in production `dq_rules`.

**Detection approach.** `rule_type = 'VALIDITY'` rules with `condition` expressing a regex/range/enum check; results land in `v_rule_execution_detail` with `rule_name` matching the `*_should_be_valid` naming convention already in use.

**Investigation workflow.**
1. Pull failing validity rules and their `failed_row_count`/`failed_pct` from `v_rule_execution_detail`.
2. Drill into `v_rule_execution_subdetail` for the nested sub-rule breakdown (e.g. which specific standardization sub-checks failed inside a composite `details_json`).
3. Compare `failed_pct` trend via `fn_rule_pass_rate_trend` — a step change (not gradual drift) points to an upstream format change; gradual drift points to increasing bad-source volume.
4. Cross-check `fn_schema_drift_check` for a `TYPE_CHANGED` event that could explain a sudden validity break.

**Root cause strategy.** Step-change detection on the trend line is the primary signal; correlate the exact date of the step change against `dq_schema_snapshot` and lineage upstream job run history.

**AI reasoning.** Distinguish "new failure pattern" (investigate upstream) from "known, chronically low pass rate" (candidate for rule threshold review, not incident).

**Recommendation.** Either a source-side fix (flag to upstream owner via lineage) or a rule threshold/action_if_failed change (e.g. from `REJECT` to `WARN`) if the rule is over-strict for legitimate data variance.

**Example questions.** "Why did address_should_be_valid fail rate jump today?" · "Which sub-rule is driving the OVERLAP failures?" · "Is this validity drop new or chronic?"

---

## 3. Consistency

**Business problem.** The same real-world entity or fact disagrees across datasets/columns/time (e.g. standardized vs raw address mismatch — `address_should_be_standardized` rules), or a value contradicts another field in the same record.

**Detection approach.** `rule_type = 'CONSISTENCY'` rules (cross-field or cross-table `condition` expressions) plus `OVERLAP`-style rules already observed in `dq_stats.row_dq_results` (`"rule":"OVERLAP"` with nested `details` listing the specific rule set in conflict).

**Investigation workflow.**
1. Query `v_rule_execution_detail` for `rule_name = 'OVERLAP'` or other consistency rules; expand `details_json` via `v_rule_execution_subdetail` to see which specific fields disagree.
2. Check whether both sides of the inconsistency come from the same source table (internal bug) or different upstream tables/pipelines (join/timing issue) via lineage.
3. Check for a recent standardization/reference-data update (e.g. address standardization library version) via Delta history on any lookup/reference tables involved.

**Root cause strategy.** Multi-source join timing and reference-data version changes are the two dominant causes; the agent should check both explicitly before concluding "data entry error."

**AI reasoning.** Consistency failures often implicate a *pair* of pipelines — the agent must identify both sides, not just the failing dataset, and check whether the discrepancy is symmetric (both changed) or one-sided (one pipeline lagged).

**Recommendation.** Reference-data refresh, join key/timing fix, or an explicit consistency rule scoped to the specific field pair.

**Example questions.** "Why are address and standardized_address disagreeing for zeta today?" · "Is the OVERLAP failure isolated to one pipeline or shared across teams?"

---

## 4. Uniqueness

**Business problem.** Duplicate records or duplicate keys inflate counts, break joins, and cause double-counted business metrics.

**Detection approach.** `rule_type = 'UNIQUENESS'` rules (`condition` expressing `COUNT(*) > 1` over a key) evaluated per run; `unique_pii_count` in `dq_stats` gives an independent PII-cardinality signal to cross-check against.

**Investigation workflow.**
1. Query `v_rule_execution_detail` for uniqueness rule failures and `failed_row_count`.
2. Compare `dq_stats.input_count` vs `output_count` for the same run — a widening gap alongside uniqueness failures suggests dedup logic changed or upstream started re-emitting records.
3. Check Delta history / CDF on the source table for late-arriving or reprocessed batches (a common duplicate-cause pattern in streaming/batch hybrid pipelines).

**Root cause strategy.** Distinguish "true new duplicates from source" vs "reprocessing/replay of the same batch" — the latter is visible as a spike in `input_count` with an unusually short interval since the prior run.

**AI reasoning.** Do not recommend a blanket dedup rule without identifying the actual duplicate key — pull sample duplicate keys via the certified query pattern so the recommendation is scoped correctly.

**Recommendation.** Add a uniqueness rule on the correct composite key, or fix the upstream replay/reprocessing trigger.

**Example questions.** "Are we seeing new duplicates in corebanking_tran_ct today?" · "Is this a replay or genuinely new duplicate data?"

---

## 5. Timeliness (Freshness)

**Business problem.** Data arrives late or not at all, breaking downstream SLAs even when the data itself would otherwise be correct.

**Detection approach.** `fn_freshness_gap` compares `MAX(loaddt)` in `v_profile_unified` (or `dcs_etl_dt`) against `dq_profile_table_registry.expected_runs_per_day`-derived SLA hours.

**Investigation workflow.**
1. Run `fn_freshness_gap` for the domain/sub_domain; identify `is_breach = true` rows.
2. Check `system.lakeflow.*` job-run tables for the owning job's most recent run status (did it fail, or hasn't it been scheduled yet).
3. Check upstream lineage — is the breach isolated to this feed or cascading from an upstream job failure.

**Root cause strategy.** Job failure/skip (visible in system tables) is the most common cause; a silent scheduler/trigger misconfiguration is the second most common and requires checking the job's schedule definition against `expected_runs_per_day`.

**AI reasoning.** A missed run is `NOT_RUN`, structurally different from a run that completed with bad data — the agent must say which one occurred, never blur them into a generic "quality issue."

**Recommendation.** Escalate to job owner with the specific run-history evidence; suggest an `expected_runs_per_day`/SLA adjustment only if the miss is a legitimate cadence change, not a failure.

**Example questions.** "Is bill_payment_tm data late today?" · "How many hours since the last successful load for zeta?" · "Did the job actually run and fail, or did it not run at all?"

---

## 6. Volume

**Business problem.** Row counts spike or collapse relative to normal patterns, indicating upstream outages, duplicate ingestion, or partial loads.

**Detection approach.** `fn_volume_anomaly` compares day-over-day `input_count` and baseline bands (`expected_daily_rows_min/max` in the registry).

**Investigation workflow.**
1. Run `fn_volume_anomaly` for the product/domain; flag `is_below_band`/`is_above_band` days.
2. Cross-check `error_count`/`output_count` in the same `dq_stats` rows — a volume drop with rising `error_count` points to filtering/rejection, not a source outage.
3. Check lineage for an upstream job status change and Delta history for a source table truncate/reload event.

**Root cause strategy.** Rank candidate causes: (1) upstream job failure/partial run, (2) new/changed filter or DQ rule increasing rejections, (3) genuine business seasonality — check day-of-week pattern in `v_profile_unified.day_of_week` before flagging an anomaly.

**AI reasoning.** Always check seasonality (day-of-week, month-end, known batch calendars) before declaring an anomaly — a "drop" on a known low-volume day is not an incident.

**Recommendation.** Baseline band adjustment if the shift is a legitimate new normal; otherwise escalate with the specific upstream job/run identified.

**Example questions.** "Why did volume drop 40% for TELETRACK today?" · "Is this volume spike expected for month-end?"

---

## 7. Schema Drift

**Business problem.** Upstream schema changes (added/dropped/retyped columns) silently break rules, joins, or downstream consumers.

**Detection approach.** `fn_schema_drift_check` diffs the two most recent `dq_schema_snapshot` captures (nightly job) for a table.

**Investigation workflow.**
1. Run `fn_schema_drift_check` for the table in question; list `COLUMN_ADDED`/`COLUMN_DROPPED`/`TYPE_CHANGED` events with dates.
2. Cross-reference the drift date against rule-failure and completeness/validity spikes on the same table.
3. Use Lineage & Impact Genie to enumerate downstream consumers of the changed table so the blast radius is quantified, not just the immediate failure.

**Root cause strategy.** Schema drift is usually the *cause*, not the symptom — when a drift event's date lines up with a spike in completeness/validity failures, lead with the drift as root cause rather than listing the failures as independent issues.

**AI reasoning.** Never infer schema drift without a snapshot diff or `information_schema` comparison — do not guess from rule failure patterns alone.

**Recommendation.** Update the dependent `dq_rules.condition`/downstream schema to match, and flag the source-owning team via the lineage-derived owner.

**Example questions.** "Did TELETRACK's source table schema change recently?" · "What downstream datasets are affected by this new column?"
