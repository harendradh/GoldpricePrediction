# Lakehouse Monitoring — Current-State Workaround & Future Migration Plan

## Why LHM isn't in use today

Databricks Lakehouse Monitoring's monitor-refresh jobs require **serverless
compute**, which is not available in this workspace today. Rather than block the
whole DQ agent effort on a compute-provisioning timeline, this project builds a
metadata-driven equivalent using classic compute (SQL Warehouses + regular Jobs)
that is **structurally compatible** with LHM, so the eventual migration is a
targeted swap, not a redesign.

## Current-state workaround, mapped to what LHM would otherwise provide

| LHM capability | Current-state equivalent | Where |
|---|---|---|
| Auto-generated profile metrics table | `dq_profile_table_registry` + generated `v_profile_unified` | `sql/01_profile_table_registry.sql`, `sql/02_unified_profile_view.sql` |
| Auto-generated drift metrics table | Nightly `dq_schema_snapshot` capture + `fn_schema_drift_check` diff | `sql/04_investigation_functions.sql` |
| Time-series/snapshot monitor scheduling | Databricks Jobs (`dq_refresh_profile_unified_view`, `dq_snapshot_schema`) on classic compute | Job definitions referenced in `docs/05_ONBOARDING_RUNBOOK.md` |
| Slicing by dimension (e.g. domain) | `product_id`/`domain`/`sub_domain` columns carried through every view | All `sql/*.sql` views |

This is intentionally the same shape a Databricks-native shop (per the
Databricks/Microsoft/AWS reference patterns this design follows) would build as
an interim measure — a registry-driven UNION ALL is the standard workaround
wherever native monitoring isn't yet available.

## Migration plan once serverless compute is enabled

1. **Pilot on one domain.** Enable `CREATE MONITOR` on the `bp`/`bill_payment_tm`
   source table (the one with a confirmed physical profiling table today) and run
   it alongside the existing `dp_bp_bill_payment_tm_status`-based path for one
   full week. Compare `v_profile_unified` output to the LHM-generated
   `*_profile_metrics` table for the same window to validate no material metric
   drift.
2. **Cut over the view, not the callers.** Swap `v_profile_unified`'s definition
   to source from `*_profile_metrics`/`*_drift_metrics` (concrete SQL in
   `sql/05_lakehouse_monitoring_dropin.sql`). Every Genie workspace, tool, and
   agent instruction that reads `v_profile_unified`/`v_profile_metrics_parsed`
   needs zero changes — this is the entire point of shaping the interim view to
   match LHM's output shape from day one.
3. **Retire the interim machinery.** Once the pilot validates, decommission the
   `dq_refresh_profile_unified_view` and `dq_snapshot_schema` jobs and the
   `dq_profile_table_registry`-driven UNION ALL generation for migrated domains.
   `fn_schema_drift_check` is superseded by LHM's native `*_drift_metrics` table
   for those domains (its SQL signature stays the same — only the underlying
   table changes, so no Genie/agent-facing change is needed here either).
4. **Roll forward domain-by-domain.** Repeat steps 1–3 per onboarded domain
   rather than a big-bang cutover — this matches the metadata-driven, incremental
   onboarding model already used for new teams.

## Operational benefits once fully migrated

- **No custom registry/generator job to maintain** — Databricks manages monitor
  refresh scheduling natively.
- **Native distribution drift detection**, not just schema drift — LHM tracks
  statistical drift (e.g. distribution shift on a numeric column) that the
  current-state workaround does not attempt to detect.
- **Zero onboarding step for profiling** — new tables get monitored by enabling
  `CREATE MONITOR`, no `dq_profile_table_registry` MERGE required.
- **Built-in Databricks dashboards** per monitor, complementing (not replacing)
  the agent's own investigative Genie workspaces — leadership gets both a
  standard dashboard view and the agent's narrative investigation.
- **Lower operational surface area** — two fewer scheduled jobs, one fewer
  custom table (registry) to keep in sync as teams onboard/offboard.

## What does NOT change in the migration

- `dq_rules` and `dq_stats` — already unified, untouched by this migration.
- The flattening layer (`v_rule_execution_detail` and friends) — LHM does not
  address execution-result flattening; that stays as designed.
- The 8 Genie workspaces, agent system instruction, and tool manifest — all
  reference views/functions by name, not by underlying table, so they are
  insulated from this migration by design.
