# Data Quality AI Agent — Architecture

## 1. Design Principles

1. **Metadata-driven, not hardcoded.** Every new team/domain onboards by adding rows to `dq_rules`, `dq_stats`, and `dq_profile_table_registry` — never by editing agent code, views, or Genie SQL by hand. See [`sql/01_profile_table_registry.sql`](../sql/01_profile_table_registry.sql).
2. **Investigate, don't dashboard.** The agent's job is to fan out across rules, profiling, execution history, lineage, and schema, then synthesize a reasoned narrative with a recommendation — never a single isolated query result presented as "the answer."
3. **Reuse what's already unified; unify only what isn't.** `dq_rules` and `dq_stats` are already shared, multi-tenant tables in `prod_dcs_catalog.df_app_configs` — the agent reads them directly. `data_profile.dp_*` is genuinely fragmented (one physical table per domain) — that's the one place real unification machinery (registry + generated view) is built.
4. **Narrow, well-instructed Genie workspaces beat one do-everything Genie.** Genie's NL→SQL quality degrades as table scope and instruction complexity grow. Eight scoped workspaces (§ [03_GENIE_WORKSPACES.md](03_GENIE_WORKSPACES.md)) each get a small table set and tight guardrails.
5. **Anti-fabrication is load-bearing, not a footnote.** `NOT_RUN` / `NO_RESULT` must never be reported as `PASS`. This is enforced at the view layer (`rule_status` in `v_rule_execution_detail`), restated in the agent's system instruction, and covered by dedicated eval cases.
6. **AI-assisted recommendations, human-approved deployment.** The agent proposes new rules, thresholds, and remediations with SQL and rationale attached — it never writes to `dq_rules` or triggers a job itself.
7. **Native Databricks first.** Unity Catalog `information_schema`, system tables, Delta `DESCRIBE HISTORY`, and UC lineage APIs cover investigation needs without external tooling. Lakehouse Monitoring is the intended long-term profiling/drift backbone once serverless compute is available (§ [04_LAKEHOUSE_MONITORING_MIGRATION.md](04_LAKEHOUSE_MONITORING_MIGRATION.md)).

## 2. Component Architecture

```
┌───────────────────────────────────────────────────────────────────────────────┐
│ DATA LAYER (existing + net-new)                                               │
│  dq_rules · dq_stats · data_profile.dp_* (fragmented, per team)               │
│  UC information_schema · system.lakeflow.* · system.access.audit · lineage    │
│  Delta history (DESCRIBE HISTORY)                                             │
└───────────────────────────────────────────────────────────────────────────────┘
                                     │
┌───────────────────────────────────────────────────────────────────────────────┐
│ SQL / METADATA LAYER  (sql/01–05)                                             │
│  dq_profile_table_registry → v_profile_unified → v_profile_metrics_parsed     │
│  v_rule_execution_detail / _subdetail → v_dq_run_summary → v_rules_not_run_7d │
│  fn_root_cause_summary · fn_volume_anomaly · fn_freshness_gap                 │
│  fn_schema_drift_check · fn_rule_pass_rate_trend · fn_dq_scorecard            │
└───────────────────────────────────────────────────────────────────────────────┘
                                     │
┌───────────────────────────────────────────────────────────────────────────────┐
│ TOOL LAYER  (agent_studio/tools_manifest.md)                                  │
│  8 Databricks-Genie tools (one per workspace) + Python function tools:        │
│  lineage_lookup · delta_history_lookup · system_table_lookup · scorecard_calc │
└───────────────────────────────────────────────────────────────────────────────┘
                                     │
┌───────────────────────────────────────────────────────────────────────────────┐
│ AGENT LAYER  (DCS Agent Studio — Sequential agent)                            │
│  classify question/dimension → route to Genie workspace(s) + tools →         │
│  cross-reference results → root-cause synthesis → confidence-scored answer   │
│  RAG collections: dimension playbooks · business glossary · incident patterns │
└───────────────────────────────────────────────────────────────────────────────┘
                                     │
┌───────────────────────────────────────────────────────────────────────────────┐
│ GENIE WORKSPACE LAYER  (docs/03_GENIE_WORKSPACES.md)                          │
│  Rule Intel · Profiling Intel · Execution Analytics · Schema Intel            │
│  Freshness Intel · Volume Intel · Lineage & Impact · Governance Intel         │
└───────────────────────────────────────────────────────────────────────────────┘
                                     │
                    Consumers: Chat (Agent Studio), Batch digest, Scorecard API
```

## 3. Why "Sequential" as the Agent Type

DCS Agent Studio offers Single / Sequential / Parallel agent types. This agent is **Sequential**: it must (1) classify the incoming question against a quality dimension and scope (product/domain/sub_domain/date), (2) route to the right Genie workspace(s) and/or SQL functions, (3) cross-reference the results (a rule failure alone is not a root cause — it needs a volume/profile/lineage/schema check to corroborate), then (4) synthesize a single explainable answer. That ordering is a pipeline, not independent branches — Parallel would lose the cross-referencing step; Single would force one oversized system prompt covering every table and dimension, defeating the scoped-Genie design.

## 4. Capability Catalog

| Capability | Primary component(s) | Notes |
|---|---|---|
| Root Cause Analysis | `fn_root_cause_summary`, DQ Execution Analytics + Volume + Profiling + Lineage Genies | Fans out signals, ranks by severity, cites each source |
| Intelligent Investigation | Sequential agent orchestration layer | Multi-hop: rule → profile → lineage → upstream job |
| Rule Discovery & Explanation | Rule Intelligence Genie, `dq_rules` | Explains what a rule does, when it fires, its history |
| Rule Recommendation (AI-assisted) | Rule Intelligence Genie + RAG dimension playbooks | Proposes new/adjusted rules with SQL + rationale; human deploys |
| Profiling Analysis | Profiling Intelligence Genie, `v_profile_metrics_parsed` | Null%, distinct count, cardinality, distribution shifts |
| Historical Trend Analysis | `fn_rule_pass_rate_trend`, DQ Execution Analytics Genie | Pass-rate and volume trend lines |
| Data Freshness Analysis | `fn_freshness_gap`, Freshness Intelligence Genie | Cadence-vs-SLA breach detection |
| Volume Anomaly Detection | `fn_volume_anomaly`, Volume Intelligence Genie | Baseline-band + day-over-day |
| Duplicate Detection | Governance Intelligence Genie, uniqueness rules in `dq_rules` (rule_type = 'UNIQUENESS') | Surfaced via `v_rule_execution_detail` |
| Missing Data Investigation | Profiling + DQ Execution Analytics Genies | Null% spikes correlated to rule failures |
| Schema Drift Detection | `fn_schema_drift_check`, `dq_schema_snapshot`, Schema Intelligence Genie | Snapshot-diff today; native LHM drift later |
| Lineage & Impact Analysis | Lineage & Impact Genie, UC lineage system tables | Upstream cause / downstream blast radius |
| SQL-Based Recommendations | Every Genie workspace | Every answer includes the certified query used |
| Daily Health Summary | DQ Execution Analytics + Governance Genies, scheduled batch consumer | Digest job, not ad hoc chat only |
| Data Quality Scorecard | `fn_dq_scorecard` | Per-dimension weighted score per product |
| Confidence Scoring | Agent synthesis layer | Every answer tags High/Medium/Low confidence + why |
| Explainability | System instruction citation discipline | Every claim traces to a table/view/function, never invented |

## 5. Multi-Team Onboarding Pattern

Onboarding a new team/domain requires exactly:
1. Their `dq_rules` rows (already the pattern in production — no change needed).
2. Their `dq_stats` rows (already the pattern in production — no change needed).
3. One `MERGE` into `dq_profile_table_registry` pointing at their `dp_<domain>_<sub_domain>_status` table (see `sql/01_profile_table_registry.sql`).
4. Nothing else — the generated view, the Genie workspaces, the agent instruction, and the investigation functions all pick the new domain up automatically because they query by `product_id`/`domain`/`sub_domain`, not by hardcoded table names.

## 6. Native Databricks Capabilities Used

| Capability | Used for |
|---|---|
| Unity Catalog + `information_schema` | Table discovery, `dq_schema_snapshot` diffing, registry validation |
| System tables (`system.lakeflow.*`, `system.access.audit`) | Job/pipeline run metadata for lineage and freshness cross-checks |
| UC Data Lineage | Upstream/downstream impact analysis (Lineage & Impact Genie) |
| Delta `DESCRIBE HISTORY` / CDF | Row-level "what changed" investigation, registry change tracking |
| SQL Warehouses | Serving layer for all views/functions and Genie query execution |
| Databricks Jobs/Workflows | `dq_refresh_profile_unified_view`, `dq_snapshot_schema` scheduled jobs |
| Genie | 8 scoped NL→SQL workspaces (§ 03_GENIE_WORKSPACES.md) |
| AI Functions (`ai_query`, `ai_classify`) | Optional: severity classification, free-text rule description generation |
| Vector Search | Backing the RAG collections (dimension playbooks, glossary, incident patterns) |

No external (non-Databricks) tooling is introduced.
