-- =============================================================================
-- 04_investigation_functions.sql
-- Unity Catalog SQL functions the agent's Python tools and the Genie workspaces
-- call for multi-hop investigation. Each is a TABLE function so it composes
-- cleanly inside Genie-authored SQL and inside the agent's own tool calls.
-- =============================================================================

-- -----------------------------------------------------------------------------
-- fn_root_cause_summary: single entry point for "why did quality degrade" —
-- pulls rule failures, volume delta, and profiling anomalies for one scope/date
-- and ranks them by severity so the agent can lead with the biggest signal.
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION prod_dcs_catalog.df_app_configs.fn_root_cause_summary(
    p_product_id STRING,
    p_domain STRING,
    p_sub_domain STRING,
    p_as_of_date DATE
)
RETURNS TABLE (
    signal_type STRING, detail STRING, severity STRING, metric_value DOUBLE
)
COMMENT 'Root-cause fan-out: rule failures + volume anomaly + profile anomaly for one (product, domain, sub_domain, date), ranked by severity.'
RETURN
    SELECT 'RULE_FAILURE' AS signal_type,
           rule_name || ' failed ' || failed_row_count || ' rows (' || ROUND(failed_pct,2) || '%) on task ' || task_name AS detail,
           CASE WHEN failed_pct > 10 THEN 'HIGH' WHEN failed_pct > 1 THEN 'MEDIUM' ELSE 'LOW' END AS severity,
           failed_pct AS metric_value
    FROM prod_dcs_catalog.df_app_configs.v_rule_execution_detail
    WHERE product_id = p_product_id AND domain = p_domain
      AND (p_sub_domain IS NULL OR sub_domain = p_sub_domain)
      AND rule_status = 'FAIL'
    UNION ALL
    SELECT 'VOLUME_ANOMALY' AS signal_type,
           'input_count=' || input_count || ' output_count=' || output_count AS detail,
           CASE WHEN error_count > input_count * 0.1 THEN 'HIGH' ELSE 'MEDIUM' END AS severity,
           CAST(error_count AS DOUBLE) AS metric_value
    FROM prod_dcs_catalog.df_app_configs.v_dq_run_summary
    WHERE product_id = p_product_id AND domain = p_domain
      AND (p_sub_domain IS NULL OR sub_domain = p_sub_domain)
      AND error_count > 0
    UNION ALL
    SELECT 'PROFILE_ANOMALY' AS signal_type,
           column_name || ' status=' || status || ' (' || failed_metrics || ')' AS detail,
           CASE WHEN status = 'FAILURE' THEN 'HIGH' ELSE 'LOW' END AS severity,
           COALESCE(total_count, 0) AS metric_value
    FROM prod_dcs_catalog.df_app_configs.v_profile_metrics_parsed
    WHERE product_id = p_product_id AND domain = p_domain
      AND (p_sub_domain IS NULL OR sub_domain = p_sub_domain)
      AND formatted_date = CAST(p_as_of_date AS STRING)
      AND status <> 'SUCCESS';

-- -----------------------------------------------------------------------------
-- fn_volume_anomaly: day-over-day and vs-baseline-band volume check.
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION prod_dcs_catalog.df_app_configs.fn_volume_anomaly(
    p_product_id STRING,
    p_domain STRING,
    p_lookback_days INT
)
RETURNS TABLE (
    run_date DATE, input_count BIGINT, prior_day_input_count BIGINT,
    pct_change_vs_prior_day DOUBLE, expected_min BIGINT, expected_max BIGINT,
    is_below_band BOOLEAN, is_above_band BOOLEAN
)
COMMENT 'Volume trend + baseline-band breach detector, joined to registry-defined expected_daily_rows_min/max.'
RETURN
    WITH daily AS (
        SELECT s.domain, s.product_id,
               to_date(s.job_run_id) AS run_date,   -- job_run_id assumed date-prefixed per platform convention; adjust extraction per real job_run_id format at onboarding
               SUM(s.input_count) AS input_count
        FROM prod_dcs_catalog.df_app_configs.dq_stats s
        WHERE s.product_id = p_product_id AND s.domain = p_domain
        GROUP BY s.domain, s.product_id, to_date(s.job_run_id)
    ),
    with_lag AS (
        SELECT *, LAG(input_count) OVER (ORDER BY run_date) AS prior_day_input_count
        FROM daily
    )
    SELECT w.run_date, w.input_count, w.prior_day_input_count,
           ROUND((w.input_count - w.prior_day_input_count) / NULLIF(w.prior_day_input_count, 0) * 100, 2) AS pct_change_vs_prior_day,
           r.expected_daily_rows_min, r.expected_daily_rows_max,
           (r.expected_daily_rows_min IS NOT NULL AND w.input_count < r.expected_daily_rows_min) AS is_below_band,
           (r.expected_daily_rows_max IS NOT NULL AND w.input_count > r.expected_daily_rows_max) AS is_above_band
    FROM with_lag w
    LEFT JOIN prod_dcs_catalog.df_app_configs.dq_profile_table_registry r
      ON r.owning_product_id = w.product_id AND r.domain = w.domain
    WHERE w.run_date >= date_sub(current_date(), p_lookback_days)
    ORDER BY w.run_date DESC;

-- -----------------------------------------------------------------------------
-- fn_freshness_gap: last-loaded timestamp vs expected cadence from the registry.
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION prod_dcs_catalog.df_app_configs.fn_freshness_gap(
    p_domain STRING,
    p_sub_domain STRING
)
RETURNS TABLE (
    source_table STRING, last_loaddt STRING, hours_since_last_load DOUBLE,
    expected_runs_per_day INT, sla_hours DOUBLE, is_breach BOOLEAN
)
COMMENT 'Compares max(loaddt) in v_profile_unified against registry cadence to flag stale feeds.'
RETURN
    SELECT p.source_table,
           MAX(p.loaddt) AS last_loaddt,
           (unix_timestamp(current_timestamp()) - unix_timestamp(MAX(p.loaddt))) / 3600.0 AS hours_since_last_load,
           r.expected_runs_per_day,
           24.0 / GREATEST(r.expected_runs_per_day, 1) AS sla_hours,
           ((unix_timestamp(current_timestamp()) - unix_timestamp(MAX(p.loaddt))) / 3600.0) > (24.0 / GREATEST(r.expected_runs_per_day, 1)) AS is_breach
    FROM prod_dcs_catalog.df_app_configs.v_profile_unified p
    JOIN prod_dcs_catalog.df_app_configs.dq_profile_table_registry r
      ON r.table_name = split(p.source_table, '\\.')[2] AND r.domain = p.domain
    WHERE p.domain = p_domain AND (p_sub_domain IS NULL OR p.sub_domain = p_sub_domain)
    GROUP BY p.source_table, r.expected_runs_per_day;

-- -----------------------------------------------------------------------------
-- dq_schema_snapshot: nightly capture table schema drift needs a history to
-- diff against, since information_schema.columns only reflects current state.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS prod_dcs_catalog.df_app_configs.dq_schema_snapshot (
    snapshot_date   DATE,
    table_catalog   STRING,
    table_schema    STRING,
    table_name      STRING,
    column_name     STRING,
    ordinal_position INT,
    data_type       STRING,
    is_nullable     STRING
)
USING DELTA
PARTITIONED BY (snapshot_date)
COMMENT 'Nightly snapshot of information_schema.columns for registered tables — job: dq_snapshot_schema. Basis for fn_schema_drift_check.';

CREATE OR REPLACE FUNCTION prod_dcs_catalog.df_app_configs.fn_schema_drift_check(
    p_table_catalog STRING,
    p_table_schema STRING,
    p_table_name STRING,
    p_lookback_days INT
)
RETURNS TABLE (
    change_type STRING, column_name STRING, old_value STRING, new_value STRING, detected_between STRING
)
COMMENT 'Diffs the two most recent schema snapshots (or the latest snapshot vs live information_schema.columns) for one table.'
RETURN
    WITH snaps AS (
        SELECT snapshot_date, column_name, ordinal_position, data_type, is_nullable,
               DENSE_RANK() OVER (ORDER BY snapshot_date DESC) AS recency_rank
        FROM prod_dcs_catalog.df_app_configs.dq_schema_snapshot
        WHERE table_catalog = p_table_catalog AND table_schema = p_table_schema AND table_name = p_table_name
          AND snapshot_date >= date_sub(current_date(), p_lookback_days)
    ),
    latest AS (SELECT * FROM snaps WHERE recency_rank = 1),
    prior  AS (SELECT * FROM snaps WHERE recency_rank = 2)
    SELECT 'COLUMN_ADDED' AS change_type, l.column_name, NULL AS old_value, l.data_type AS new_value,
           'latest_vs_prior_snapshot' AS detected_between
    FROM latest l LEFT JOIN prior p ON l.column_name = p.column_name WHERE p.column_name IS NULL
    UNION ALL
    SELECT 'COLUMN_DROPPED', p.column_name, p.data_type, NULL, 'latest_vs_prior_snapshot'
    FROM prior p LEFT JOIN latest l ON p.column_name = l.column_name WHERE l.column_name IS NULL
    UNION ALL
    SELECT 'TYPE_CHANGED', l.column_name, p.data_type, l.data_type, 'latest_vs_prior_snapshot'
    FROM latest l JOIN prior p ON l.column_name = p.column_name WHERE l.data_type <> p.data_type;

-- -----------------------------------------------------------------------------
-- fn_rule_pass_rate_trend: pass-rate history for one rule, for trend questions.
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION prod_dcs_catalog.df_app_configs.fn_rule_pass_rate_trend(
    p_product_id STRING,
    p_rule_name STRING,
    p_lookback_days INT
)
RETURNS TABLE (
    run_date DATE, rules_evaluated BIGINT, pass_rate_pct DOUBLE
)
COMMENT 'Daily pass-rate trend for a specific rule — root-cause chart data source.'
RETURN
    SELECT to_date(job_run_id) AS run_date,
           COUNT(*) AS rules_evaluated,
           ROUND(SUM(CASE WHEN rule_status = 'PASS' THEN 1 ELSE 0 END) / COUNT(*) * 100, 2) AS pass_rate_pct
    FROM prod_dcs_catalog.df_app_configs.v_rule_execution_detail
    WHERE product_id = p_product_id AND rule_name = p_rule_name
      AND to_date(job_run_id) >= date_sub(current_date(), p_lookback_days)
    GROUP BY to_date(job_run_id)
    ORDER BY run_date;

-- -----------------------------------------------------------------------------
-- fn_dq_scorecard: weighted composite score across dimensions for a product.
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION prod_dcs_catalog.df_app_configs.fn_dq_scorecard(
    p_product_id STRING,
    p_as_of_date DATE
)
RETURNS TABLE (
    dimension STRING, score_pct DOUBLE, contributing_rules BIGINT
)
COMMENT 'Per-dimension pass-rate score (rule_type acts as the dimension tag in dq_rules) for a product scorecard.'
RETURN
    SELECT r.rule_type AS dimension,
           ROUND(SUM(CASE WHEN d.rule_status = 'PASS' THEN 1 ELSE 0 END) / COUNT(*) * 100, 2) AS score_pct,
           COUNT(*) AS contributing_rules
    FROM prod_dcs_catalog.df_app_configs.v_rule_execution_detail d
    JOIN prod_dcs_catalog.df_app_configs.dq_rules r
      ON r.rule = d.rule_name AND r.product_id = d.product_id
    WHERE d.product_id = p_product_id AND to_date(d.job_run_id) = p_as_of_date
    GROUP BY r.rule_type;
