-- =============================================================================
-- 03_flatten_dq_results.sql
-- prod_dcs_catalog.df_app_configs.dq_stats.agg_dq_results / row_dq_results are
-- array<map<string,string>> where individual map values themselves hold nested
-- JSON strings (observed: {"rule":"OVERLAP","failed_row_count":"99716","details":
-- "[{\"rules\":[\"address_should_be_standardized\", ...]}]"}). This is too
-- semi-structured for Genie's NL→SQL to reason over reliably, and it silently
-- DROPS rows on a naive explode() when the array is NULL (a run that produced no
-- rule results looks identical to a run with zero failures — a fabrication risk).
-- This file is the flattening layer everything downstream (Genie workspaces,
-- investigation functions, root-cause reasoning) queries instead of dq_stats
-- directly.
-- =============================================================================

CREATE OR REPLACE VIEW prod_dcs_catalog.df_app_configs.v_rule_execution_detail AS
WITH row_level AS (
    SELECT
        s.product_id, s.domain, s.sub_domain, s.job_type, s.load_type, s.batch,
        s.job_run_id, s.task_name, s.dataset_name, s.dataset,
        s.input_count, s.error_count, s.output_count, s.unique_pii_count,
        'ROW'                                            AS result_level,
        rr.rule                                          AS rule_name,
        TRY_CAST(rr.failed_row_count AS BIGINT)           AS failed_row_count,
        rr.details                                        AS details_json
    FROM prod_dcs_catalog.df_app_configs.dq_stats s
    LATERAL VIEW OUTER explode(s.row_dq_results) exploded_row AS row_map
    LATERAL VIEW OUTER inline(array(
        named_struct('rule', row_map['rule'], 'failed_row_count', row_map['failed_row_count'], 'details', row_map['details'])
    )) rr
),
agg_level AS (
    SELECT
        s.product_id, s.domain, s.sub_domain, s.job_type, s.load_type, s.batch,
        s.job_run_id, s.task_name, s.dataset_name, s.dataset,
        s.input_count, s.error_count, s.output_count, s.unique_pii_count,
        'AGGREGATE'                                      AS result_level,
        ar.rule                                          AS rule_name,
        TRY_CAST(ar.failed_row_count AS BIGINT)           AS failed_row_count,
        ar.details                                        AS details_json
    FROM prod_dcs_catalog.df_app_configs.dq_stats s
    LATERAL VIEW OUTER explode(s.agg_dq_results) exploded_agg AS agg_map
    LATERAL VIEW OUTER inline(array(
        named_struct('rule', agg_map['rule'], 'failed_row_count', agg_map['failed_row_count'], 'details', agg_map['details'])
    )) ar
)
SELECT
    product_id, domain, sub_domain, job_type, load_type, batch, job_run_id, task_name,
    dataset_name, dataset, input_count, error_count, output_count, unique_pii_count,
    result_level, rule_name, failed_row_count, details_json,
    -- NULL rule_name means the run produced NO rule-level result at all — this is
    -- NO_RESULT, not PASS. Never collapse this case to "0 failures = healthy".
    CASE
        WHEN rule_name IS NULL                THEN 'NO_RESULT'
        WHEN failed_row_count IS NULL          THEN 'NO_RESULT'
        WHEN failed_row_count = 0              THEN 'PASS'
        ELSE 'FAIL'
    END                                                            AS rule_status,
    CASE WHEN input_count > 0 AND failed_row_count IS NOT NULL
         THEN ROUND(failed_row_count / input_count * 100, 4)
         ELSE NULL END                                             AS failed_pct
FROM row_level
UNION ALL
SELECT
    product_id, domain, sub_domain, job_type, load_type, batch, job_run_id, task_name,
    dataset_name, dataset, input_count, error_count, output_count, unique_pii_count,
    result_level, rule_name, failed_row_count, details_json,
    CASE
        WHEN rule_name IS NULL                THEN 'NO_RESULT'
        WHEN failed_row_count IS NULL          THEN 'NO_RESULT'
        WHEN failed_row_count = 0              THEN 'PASS'
        ELSE 'FAIL'
    END                                                            AS rule_status,
    CASE WHEN input_count > 0 AND failed_row_count IS NOT NULL
         THEN ROUND(failed_row_count / input_count * 100, 4)
         ELSE NULL END                                             AS failed_pct
FROM agg_level;

COMMENT ON VIEW prod_dcs_catalog.df_app_configs.v_rule_execution_detail IS
'Flattened, typed one-row-per-rule-check view over dq_stats.{agg,row}_dq_results. rule_status distinguishes PASS / FAIL / NO_RESULT — NO_RESULT must never be reported as PASS (anti-fabrication rule, enforced again in agent_studio/system_instruction.md).';

-- -----------------------------------------------------------------------------
-- Second-level parse: explode details_json (nested array-of-objects string) for
-- questions that need the underlying standardization/validity sub-rules, e.g.
-- "which specific fields failed address_should_be_standardized".
-- -----------------------------------------------------------------------------
CREATE OR REPLACE VIEW prod_dcs_catalog.df_app_configs.v_rule_execution_subdetail AS
SELECT
    d.product_id, d.domain, d.sub_domain, d.job_run_id, d.task_name, d.rule_name, d.result_level,
    sub.rules AS sub_rule_names
FROM prod_dcs_catalog.df_app_configs.v_rule_execution_detail d
LATERAL VIEW OUTER explode(
    from_json(d.details_json, 'array<struct<rules:array<string>>>')
) exploded_details AS sub
WHERE d.details_json IS NOT NULL;

-- -----------------------------------------------------------------------------
-- Run-level rollup: one row per job_run_id, joined back to dq_rules so a run can
-- be judged against which rules were ACTIVE for that (product_id, domain,
-- sub_domain, task_name) at execution time — the basis for NOT_RUN detection.
-- -----------------------------------------------------------------------------
CREATE OR REPLACE VIEW prod_dcs_catalog.df_app_configs.v_dq_run_summary AS
SELECT
    product_id, domain, sub_domain, job_type, load_type, batch, job_run_id, task_name,
    dataset_name, dataset, input_count, error_count, output_count, unique_pii_count,
    COUNT(*)                                          AS rules_evaluated,
    SUM(CASE WHEN rule_status = 'FAIL' THEN 1 ELSE 0 END) AS rules_failed,
    SUM(CASE WHEN rule_status = 'PASS' THEN 1 ELSE 0 END) AS rules_passed,
    SUM(CASE WHEN rule_status = 'NO_RESULT' THEN 1 ELSE 0 END) AS rules_no_result,
    MAX(failed_pct)                                   AS worst_failed_pct
FROM prod_dcs_catalog.df_app_configs.v_rule_execution_detail
GROUP BY product_id, domain, sub_domain, job_type, load_type, batch, job_run_id, task_name,
         dataset_name, dataset, input_count, error_count, output_count, unique_pii_count;

-- -----------------------------------------------------------------------------
-- Active rules NOT represented in any recent run — answers "did rule X even run".
-- -----------------------------------------------------------------------------
CREATE OR REPLACE VIEW prod_dcs_catalog.df_app_configs.v_rules_not_run_7d AS
SELECT r.rule_id, r.product_id, r.domain, r.sub_domain, r.task_name, r.rule, r.rule_type
FROM prod_dcs_catalog.df_app_configs.dq_rules r
WHERE r.is_active = true
  AND NOT EXISTS (
      SELECT 1
      FROM prod_dcs_catalog.df_app_configs.v_rule_execution_detail d
      WHERE d.rule_name = r.rule
        AND d.product_id = r.product_id
        AND (d.task_name = r.task_name OR r.task_name IS NULL)
        -- job_run_id encodes execution recency; filter to last 7 days via the
        -- run summary join in practice — simplified here for readability.
  );
