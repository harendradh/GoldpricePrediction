-- =============================================================================
-- 01_profile_table_registry.sql
-- Metadata-driven registry of the physical per-domain profiling tables under
-- prod_dcs_catalog.data_profile.*  (observed pattern: dp_<domain>_<sub_domain>_status,
-- e.g. prod_dcs_catalog.data_profile.dp_bp_bill_payment_tm_status).
--
-- WHY THIS EXISTS: Unity Catalog has no wildcard/dynamic table reference inside a
-- static view. Because every onboarding team gets its own physical dp_* table
-- (same shape: column_name, failed_metrics, metric_values, status, formatted_date,
-- year/month/day_of_month/day_of_year/week_of_year/day_of_week/hour_of_day,
-- pipeline_name, domain, subdomain, pipeline_id, task_id, parent_job_id,
-- child_job_id, schedule_id, dcs_etl_dt, loaddt), the only way to query "all
-- profiling data" generically is to (a) catalog every physical table here, then
-- (b) generate a UNION ALL view from this registry (see 02_unified_profile_view.sql).
-- This is the ONE piece of net-new unification machinery this project introduces;
-- dq_rules and dq_stats are already unified, multi-tenant tables and are read
-- directly (see 03_flatten_dq_results.sql).
-- =============================================================================

CREATE TABLE IF NOT EXISTS prod_dcs_catalog.df_app_configs.dq_profile_table_registry (
    registry_id             BIGINT GENERATED ALWAYS AS IDENTITY,
    domain                  STRING      NOT NULL COMMENT 'e.g. bp, zeta, TELETRACK, epoch, corebanking_tran_ct',
    sub_domain              STRING      COMMENT 'e.g. bill_payment_tm; NULL if the domain has no sub-domain split',
    catalog_name            STRING      NOT NULL DEFAULT 'prod_dcs_catalog',
    schema_name             STRING      NOT NULL DEFAULT 'data_profile',
    table_name              STRING      NOT NULL COMMENT 'physical dp_<domain>_<sub_domain>_status table name',
    owning_product_id       STRING      COMMENT 'joins to dq_rules.product_id / dq_stats.product_id for the same feed',
    owner_team              STRING,
    profiled_columns        STRING      COMMENT 'comma-separated list of columns this team profiles on the source table',
    expected_runs_per_day   INT         DEFAULT 1,
    expected_daily_rows_min BIGINT      COMMENT 'lower band for volume-anomaly detection; NULL = not yet baselined',
    expected_daily_rows_max BIGINT      COMMENT 'upper band for volume-anomaly detection; NULL = not yet baselined',
    is_active                BOOLEAN    NOT NULL DEFAULT TRUE,
    created_by               STRING,
    created_at                TIMESTAMP DEFAULT current_timestamp(),
    updated_by                STRING,
    updated_at                TIMESTAMP DEFAULT current_timestamp()
)
USING DELTA
COMMENT 'Registry of physical data_profile.dp_* tables — drives the generated v_profile_unified view. Onboarding a new team = one MERGE into this table, no code change.'
TBLPROPERTIES (delta.enableChangeDataFeed = true);

-- -----------------------------------------------------------------------------
-- Onboarding pattern: teams (or their onboarding PR) MERGE their table into the
-- registry instead of editing any view/notebook by hand.
-- -----------------------------------------------------------------------------
MERGE INTO prod_dcs_catalog.df_app_configs.dq_profile_table_registry AS tgt
USING (
    SELECT * FROM VALUES
        -- Confirmed from production screenshot: prod_dcs_catalog.data_profile.dp_bp_bill_payment_tm_status
        ('bp',              'bill_payment_tm',  'prod_dcs_catalog', 'data_profile', 'dp_bp_bill_payment_tm_status', 'bp',              'BillPay Data Platform', 'loaddt,status,column_name', 24,  NULL, NULL, true),
        -- Illustrative onboarding examples for domains already present in dq_rules —
        -- CONFIRM the exact physical table name with each team before activating;
        -- table_name here follows the observed dp_<domain>_<sub_domain>_status convention.
        ('zeta',             NULL,               'prod_dcs_catalog', 'data_profile', 'dp_zeta_status',              'zeta',            'Zeta Team',             'address,name,phone',       1,   NULL, NULL, false),
        ('TELETRACK',        NULL,               'prod_dcs_catalog', 'data_profile', 'dp_teletrack_status',         'TELETRACK',       'TeleTrack Team',       'address,name',             1,   NULL, NULL, false),
        ('corebanking_tran_ct', NULL,             'prod_dcs_catalog', 'data_profile', 'dp_corebanking_tran_ct_status','corebanking_tran_ct','Core Banking Team',  'address,name,merchant_name', 4, NULL, NULL, false)
    AS s(domain, sub_domain, catalog_name, schema_name, table_name, owning_product_id, owner_team, profiled_columns, expected_runs_per_day, expected_daily_rows_min, expected_daily_rows_max, is_active)
) AS src
ON tgt.catalog_name = src.catalog_name AND tgt.schema_name = src.schema_name AND tgt.table_name = src.table_name
WHEN NOT MATCHED THEN INSERT (
    domain, sub_domain, catalog_name, schema_name, table_name, owning_product_id, owner_team,
    profiled_columns, expected_runs_per_day, expected_daily_rows_min, expected_daily_rows_max,
    is_active, created_by, created_at, updated_by, updated_at
) VALUES (
    src.domain, src.sub_domain, src.catalog_name, src.schema_name, src.table_name, src.owning_product_id, src.owner_team,
    src.profiled_columns, src.expected_runs_per_day, src.expected_daily_rows_min, src.expected_daily_rows_max,
    src.is_active, current_user(), current_timestamp(), current_user(), current_timestamp()
);

-- Sanity check every ACTIVE registry row resolves to a real table before the
-- generator (02_unified_profile_view.sql) runs. Surfaces broken onboardings early.
SELECT r.domain, r.sub_domain, r.catalog_name, r.schema_name, r.table_name,
       (t.table_name IS NOT NULL) AS table_exists
FROM prod_dcs_catalog.df_app_configs.dq_profile_table_registry r
LEFT JOIN system.information_schema.tables t
  ON t.table_catalog = r.catalog_name AND t.table_schema = r.schema_name AND t.table_name = r.table_name
WHERE r.is_active = true;
