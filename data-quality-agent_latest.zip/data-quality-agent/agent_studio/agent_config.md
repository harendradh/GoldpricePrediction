# Agent Studio — Create New Agent Form Values

> Field names below match the actual **Create New Agent** form in DCS Agent Studio
> (`/agents/new`). Fill the form with these values when onboarding.

| Field | Value |
|---|---|
| **Name (identifier)** | `data_quality_agent` |
| **Description** | Investigative data quality engineer — explains why quality degraded, finds root cause across rules/profiling/execution/lineage/schema, and recommends remediation. Not a dashboard. |
| **Agent Type** | `Sequential` — classify → route to Genie workspace(s)/tools → cross-reference → synthesize (see `docs/01_ARCHITECTURE.md` §3 for why Sequential over Single/Parallel) |
| **Provider** | `Databricks` |
| **Model** | `databricks-claude-sonnet-4-5` |
| **System Instruction** | See `agent_studio/system_instruction.md` — paste the fenced block verbatim into this field |
| **Output Key** | `dq_agent_result` |
| **Tools** (checkboxes) | All 8 Genie tools (`genie_rule_intelligence`, `genie_profiling_intelligence`, `genie_dq_execution_analytics`, `genie_schema_intelligence`, `genie_freshness_intelligence`, `genie_volume_intelligence`, `genie_lineage_impact`, `genie_governance_intelligence`) + Python function tools (`lineage_lookup`, `delta_history_lookup`, `system_table_lookup`, `scorecard_calc`) — full definitions in `agent_studio/tools_manifest.md` |
| **RAG Collections** (checkboxes) | `DQ Dimension Playbooks`, `DQ Business Glossary`, `DQ Historical Incident Patterns` — source content in `rag/*.md`, ingestion steps in `docs/05_ONBOARDING_RUNBOOK.md` |
| **Callbacks** | `Content Filter` (block harmful keywords before LLM call) — enable; `Rate Limit` — enable, default cap acceptable (this agent is chat + scheduled digest, not high-QPS); `Log Requests` — enable, required for the audit trail Governance Intelligence Genie references |

## Notes for reviewers

- Do **not** enable write-capable tools. Every tool in this manifest is read-only
  (SELECT/Genie query execution) — the agent proposes changes to `dq_rules`, it
  never executes a MERGE/UPDATE itself. This is enforced by scoping each Genie
  Space's service principal to read-only grants on its table set.
- `Output Key` (`dq_agent_result`) is what downstream consumers (batch health-summary
  job, scorecard API) read from session state — keep it stable once other
  workflows depend on it.
