# Agent Studio — Tool Definitions

> Field names match the actual **Create New Tool** form (`/tools/new`) — Name,
> Description, Type, and the type-specific fields it reveals. Create one tool per
> row below, then attach all of them to the agent per `agent_config.md`.

## Genie tools (Type = Databricks Genie)

Common fields for all 8 rows: **Databricks Host** = `https://<workspace>.azuredatabricks.net`; **Token URL** = blank (defaults to `{host}/oidc/v1/token`); **Client ID env var** = `GENIE_CLIENT_ID`; **Client secret env var** = `GENIE_CLIENT_SECRET` (or a per-tool override — see note); **OAuth2 scope** = `all-apis`.

| Name | Description | Genie Space ID |
|---|---|---|
| `genie_rule_intelligence` | Explains DQ rule definitions, ownership, and status from `dq_rules`. | `<space-id-1>` — create the Genie space per `docs/03_GENIE_WORKSPACES.md` §1, paste its ID here |
| `genie_profiling_intelligence` | Column-level profiling metrics (nulls, counts, cardinality) across all onboarded domains. | `<space-id-2>` — §2 |
| `genie_dq_execution_analytics` | Rule pass/fail/no-result execution history and run summaries. | `<space-id-3>` — §3 |
| `genie_schema_intelligence` | Schema drift detection via snapshot diffing. | `<space-id-4>` — §4 |
| `genie_freshness_intelligence` | Data recency and SLA-breach detection. | `<space-id-5>` — §5 |
| `genie_volume_intelligence` | Row-count anomaly and baseline-band detection. | `<space-id-6>` — §6 |
| `genie_lineage_impact` | Upstream/downstream lineage and blast-radius analysis. | `<space-id-7>` — §7 |
| `genie_governance_intelligence` | Ownership, coverage gaps, and DQ scorecards. | `<space-id-8>` — §8 |

**Credentials from environment note.** If all 8 Genie spaces share one service
principal, leave the default `GENIE_CLIENT_ID`/`GENIE_CLIENT_SECRET` env vars as
shown in the Create Tool form's yellow hint box. If spaces are governed by
different owning teams with separate service principals (recommended once more
than ~3 teams are onboarded, for cleaner audit trails), set distinct env var
names per row, e.g. `GENIE_CLIENT_ID_RULE_INTEL` / `GENIE_CLIENT_SECRET_RULE_INTEL`,
and add them to `backend/.env`.

## Python function tools (Type = Python Function)

| Name | Description | Signature |
|---|---|---|
| `lineage_lookup` | Wraps `system.access.table_lineage`/`column_lineage` queries to return upstream/downstream assets for a table, with hop-count metadata, for cases where the Lineage & Impact Genie needs a precise programmatic traversal rather than NL→SQL. | `lineage_lookup(catalog: str, schema: str, table: str, direction: Literal["upstream","downstream"], max_hops: int = 3) -> list[dict]` |
| `delta_history_lookup` | Wraps `DESCRIBE HISTORY` for a table to surface recent write operations (MERGE/UPDATE/OVERWRITE) with operation metrics — used for "what changed and when" questions the SQL views can't answer directly. | `delta_history_lookup(catalog: str, schema: str, table: str, limit: int = 20) -> list[dict]` |
| `system_table_lookup` | Wraps `system.lakeflow.job_run_timeline` queries to return a job's recent run status/duration — used by Freshness Intelligence to distinguish NOT_RUN from failed-but-executed. | `system_table_lookup(job_name: str, lookback_days: int = 7) -> list[dict]` |
| `scorecard_calc` | Calls `fn_dq_scorecard` and formats a weighted composite score with dimension breakdown, used by the Daily Health Summary consumer as well as ad hoc chat. | `scorecard_calc(product_id: str, as_of_date: date) -> dict` |

Each Python tool is a thin wrapper (parameterized SQL via the SQL Warehouse
connection already configured for the agent) — no external services, no
credentials beyond the workspace's existing SQL Warehouse auth.

## Callbacks referenced by tools

`Log Requests` (enabled at the agent level per `agent_config.md`) captures every
tool call including these four, which is what lets Governance Intelligence answer
"what did the agent check" audit-style questions.
