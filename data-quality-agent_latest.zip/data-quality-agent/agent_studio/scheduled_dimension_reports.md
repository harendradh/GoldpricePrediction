# Scheduled Dimension Reports — Phase 1 (Completeness, Validity, Uniqueness)

Three production-ready, detailed prompts — one per Phase 1 dimension — designed to be sent to
the Data Quality AI Agent (`agent_studio/system_instruction.md`) on a schedule, producing a
structured report rather than a conversational answer. These extend the generic "Daily Health
Summary" consumer from `docs/05_ONBOARDING_RUNBOOK.md` §9 into three dimension-scoped, high-detail
reports that ship with Phase 1.

## How this runs

**One Databricks Job, three tasks — `dq_phase1_daily_reports`:**

| Task | Calls agent with | Output |
|---|---|---|
| `completeness_report` | Prompt §1 below | `dq_agent_result` → Completeness report |
| `validity_report` | Prompt §2 below | `dq_agent_result` → Validity report |
| `uniqueness_report` | Prompt §3 below | `dq_agent_result` → Uniqueness report |

- All three tasks run in parallel (no dependency between them), each invoking the agent's chat/
  completion endpoint with the fixed `user_question` text below (with `{{as_of_date}}`
  substituted by the job's scheduled date — do not let the agent infer "today" on its own, since
  a stale run should still report against its intended date).
- **Schedule**: daily, after the source pipelines' typical completion window (start at `07:00`
  local and adjust per each product's actual load SLA — running before upstream data lands
  produces a misleading "all clear" for feeds that legitimately haven't loaded yet).
- **Distribution**: each task's `dq_agent_result` is posted to the owning team's channel by a
  final notebook/task step (Slack/Teams webhook or email) — reuse whatever transport the
  existing "Daily Health Summary" consumer already uses; do not build a second distribution
  mechanism.
- **Scope parameter**: each prompt below defaults to "every active product_id/domain/sub_domain
  with at least one rule of that dimension" — i.e., one full-portfolio report per dimension, not
  one report per team. If a team wants their own filtered copy, parameterize `{{scope_filter}}`
  with a `WHERE product_id = '...'` clause instead of re-running the whole report.
- **Anti-fabrication carries through**: these prompts do not relax any rule from
  `agent_studio/system_instruction.md` — NOT_RUN/NO_RESULT is never PASS, every claim cites its
  source table/view/function, and every recommendation is marked AI-assisted, not deployed.

---

## 1. Completeness Daily Report

**Job task name**: `completeness_report`
**Primary workspace/tools**: DQ Execution Analytics, Profiling Intelligence, Schema Intelligence, `fn_schema_drift_check`, `fn_rule_pass_rate_trend`

### Prompt (`user_question`)

```
Generate the Daily Completeness Report for {{as_of_date}}. Scope: every (product_id, domain,
sub_domain) with at least one active rule where dq_rules.rule_type = 'COMPLETENESS'. {{scope_filter}}

Do the following for every rule in scope, not a sample:

1. Pull each COMPLETENESS rule's result for {{as_of_date}} from v_rule_execution_detail. Classify
   as PASS, FAIL, or NO_RESULT. Separately check v_rules_not_run_7d — if a rule appears there,
   report it as NOT_RUN, not as a pass. Never infer health from the absence of a FAIL row.

2. For every FAIL, corroborate against v_profile_metrics_parsed for the same column and date:
   pull total_count, threshold_pct, and status. State explicitly whether profiling independently
   confirms the completeness gap, contradicts it, or is unavailable (no row found) — do not guess
   in the unavailable case.

3. For every FAIL that IS corroborated by profiling, call fn_schema_drift_check against the
   rule's source table for the last 3 days. If a COLUMN_DROPPED or TYPE_CHANGED event is found on
   the failing column (or a column it depends on), treat that as the probable root cause and cite
   the exact event timestamp. If no snapshot history exists for that table yet, say so — do not
   conclude "no drift" from missing coverage.

4. For every FAIL, call fn_rule_pass_rate_trend over the last 7 days to classify it as NEW (first
   appearance or sharp jump from a near-zero baseline) or CHRONIC (recurring at a similar rate).

5. Rank all FAIL findings by severity using failed_pct: HIGH >10%, MEDIUM 1-10%, LOW <1%. Within
   the same severity, list NEW findings before CHRONIC ones.

Produce the report in exactly this structure:

## Executive Summary
3-5 sentences: overall completeness health across the portfolio, count of HIGH-severity NEW
findings, count of NOT_RUN rules, and one sentence on whether today looks better/worse/flat vs.
the 7-day trend.

## Findings Table
Columns: product_id | domain | sub_domain | rule | status | failed_pct | severity | new_or_chronic
One row per COMPLETENESS rule in scope, including PASS rows (compact) and all FAIL/NO_RESULT/
NOT_RUN rows (full detail).

## Root Cause Detail
One paragraph per HIGH or MEDIUM finding: the profiling corroboration result, the schema-drift
check result (event found / none found / no coverage), and a confidence tag (High/Medium/Low)
with the reasoning for that tag.

## Recommendations
One bullet per HIGH/MEDIUM finding: a specific proposed action (new/tightened completeness rule
with its SQL condition, a threshold change, or an escalation to the source-owning team per
lineage) — explicitly labeled as an AI-assisted recommendation for human review, not an action
taken.

## Data Gaps
Any (product_id, domain, sub_domain, rule) where profiling coverage, schema-snapshot coverage, or
execution history was insufficient to reach a conclusion. List these plainly rather than omitting
them.
```

---

## 2. Validity Daily Report

**Job task name**: `validity_report`
**Primary workspace/tools**: DQ Execution Analytics, `v_rule_execution_subdetail`, `fn_rule_pass_rate_trend`, Schema Intelligence

### Prompt (`user_question`)

```
Generate the Daily Validity Report for {{as_of_date}}. Scope: every (product_id, domain,
sub_domain) with at least one active rule where dq_rules.rule_type = 'VALIDITY' (typically named
*_should_be_valid or *_should_be_standardized). {{scope_filter}}

Do the following for every rule in scope, not a sample:

1. Pull each VALIDITY rule's result for {{as_of_date}} from v_rule_execution_detail — status,
   failed_row_count, failed_pct. Treat NO_RESULT and NOT_RUN (via v_rules_not_run_7d) as distinct
   from PASS, exactly as defined in the system instruction.

2. For every FAIL, drill into v_rule_execution_subdetail to break down the nested sub-rule detail
   (e.g. which specific standardization sub-checks failed inside a composite details_json). List
   the top 3 sub-rule contributors by volume.

3. Call fn_rule_pass_rate_trend over the last 14 days for every failing rule. Classify the pattern
   as STEP-CHANGE (a sudden jump from a stable baseline within the window) or GRADUAL-DRIFT (a
   slow, steady increase). This distinction drives the recommendation in step 5 — do not skip it.

4. For every STEP-CHANGE finding, call fn_schema_drift_check on the rule's source table for the
   window since the step occurred, looking specifically for a TYPE_CHANGED event (a format/type
   change is the most common validity step-change cause). Cite the exact event date if found.

5. For GRADUAL-DRIFT findings, do not search for a single triggering event — these reflect
   increasing bad-source volume over time, not a discrete break. Say so explicitly rather than
   forcing a root-cause event that doesn't exist.

6. Rank findings by severity (failed_pct: HIGH >10%, MEDIUM 1-10%, LOW <1%), then by pattern
   (STEP-CHANGE findings first within each severity, since they're actionable incidents).

Produce the report in exactly this structure:

## Executive Summary
3-5 sentences: overall validity health, count of HIGH-severity STEP-CHANGE findings (the ones
that look like real incidents), count of NOT_RUN rules, one sentence on GRADUAL-DRIFT rules that
may need a rule/threshold review rather than an incident response.

## Findings Table
Columns: product_id | domain | sub_domain | rule | status | failed_pct | severity | pattern
(step_change / gradual_drift / n/a)

## Sub-Rule Breakdown
For each FAIL: the top 3 sub-rule contributors from v_rule_execution_subdetail with their share of
the total failure volume.

## Root Cause Detail
One paragraph per HIGH or MEDIUM finding: the pattern classification, the schema-drift check
result for STEP-CHANGE findings (event found / none found / no coverage), and a confidence tag
(High/Medium/Low) with reasoning.

## Recommendations
One bullet per HIGH/MEDIUM finding. For STEP-CHANGE with a confirmed schema event: escalate to
the source-owning team, do not loosen the rule. For GRADUAL-DRIFT: propose either a source-side
data-quality conversation or a threshold/action_if_failed review, explicitly labeled AI-assisted.

## Data Gaps
Any rule/table where sub-rule detail, trend history, or schema-snapshot coverage was insufficient
to classify the pattern.
```

---

## 3. Uniqueness Daily Report

**Job task name**: `uniqueness_report`
**Primary workspace/tools**: DQ Execution Analytics, `dq_stats` (input_count/job_run_id), `v_dq_run_summary`

### Prompt (`user_question`)

```
Generate the Daily Uniqueness Report for {{as_of_date}}. Scope: every (product_id, domain,
sub_domain) with at least one active rule where dq_rules.rule_type = 'UNIQUENESS' (duplicate-key
checks). {{scope_filter}}

Do the following for every rule in scope, not a sample:

1. Pull each UNIQUENESS rule's result for {{as_of_date}} from v_rule_execution_detail — status,
   failed_row_count, failed_pct. Treat NO_RESULT and NOT_RUN (via v_rules_not_run_7d) as distinct
   from PASS.

2. For every FAIL, pull the run's input_count from dq_stats/v_dq_run_summary and compare it to the
   immediately prior run for the same (product_id, domain, sub_domain, task_name): compute the
   percentage difference in input_count and the elapsed time between the two runs (via
   job_run_id-derived timestamps).

3. Classify each FAIL as REPLAY-LIKELY if input_count is within 5% of the prior run AND the gap
   between runs is unusually short for that pipeline's normal cadence (consistent with the same
   batch being reprocessed), or NEW-DUPLICATES-LIKELY otherwise. State this is an inference, not a
   direct observation, and tag confidence accordingly (never High confidence for this
   classification alone).

4. Note unique_pii_count from dq_stats for the same run as a secondary corroborating signal where
   available — a flat or dropping unique_pii_count alongside rising failed_row_count further
   supports REPLAY-LIKELY; a rising unique_pii_count alongside rising failures further supports
   NEW-DUPLICATES-LIKELY.

5. Rank findings by severity (failed_pct: HIGH >10%, MEDIUM 1-10%, LOW <1%), then by
   classification (NEW-DUPLICATES-LIKELY first within each severity, since it typically indicates
   a source-side problem rather than a pipeline replay).

Produce the report in exactly this structure:

## Executive Summary
3-5 sentences: overall uniqueness health, count of HIGH-severity NEW-DUPLICATES-LIKELY findings,
count of NOT_RUN rules, one sentence flagging any REPLAY-LIKELY cluster (same pipeline recurring
across multiple days, which points to a systemic reprocessing-trigger bug rather than one-off
duplicate data).

## Findings Table
Columns: product_id | domain | sub_domain | rule | status | failed_pct | severity |
replay_or_new_duplicates | classification_confidence

## Root Cause Detail
One paragraph per HIGH or MEDIUM finding: the input_count comparison, elapsed time between runs,
unique_pii_count corroboration if available, and the confidence tag with reasoning.

## Recommendations
One bullet per HIGH/MEDIUM finding. For REPLAY-LIKELY: recommend checking the ingestion trigger
for a double-fire and adopting a MERGE-based idempotent upsert if not already in place. For
NEW-DUPLICATES-LIKELY: recommend confirming the actual duplicate key with a sample query before
proposing any new rule, and flag to the source-owning team. All recommendations explicitly
labeled AI-assisted, not deployed.

## Data Gaps
Any rule/run where the prior-run comparison, unique_pii_count, or job-run timing was unavailable
to support a confident replay/new-duplicates classification.
```
