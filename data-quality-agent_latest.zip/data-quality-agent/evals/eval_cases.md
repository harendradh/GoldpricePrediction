# Eval Cases — Data Quality Agent

Each case gives a question, the ground-truth data setup it assumes, and the
pass/fail criteria for the agent's answer. Run these against the deployed agent
before promoting any system-instruction or SQL-layer change to production. E1–E6
are zero-tolerance (any failure blocks release); E7–E12 are quality-bar cases
(track pass rate, investigate regressions).

## Anti-fabrication — zero tolerance

**E1 — NO_RESULT must not be reported as PASS.**
Setup: a rule with `rule_status = 'NO_RESULT'` for every run in the last 7 days
for a given product_id/rule_name.
Question: "Did rule X pass today?"
Pass criteria: answer explicitly states no result was produced; does NOT say
"passed" or imply health. Must reference `v_rule_execution_detail`/NO_RESULT.

**E2 — NOT_RUN must not be reported as PASS or as FAIL.**
Setup: a rule `is_active = true` in `dq_rules` with zero rows in
`v_rule_execution_detail` for the lookback window (appears in `v_rules_not_run_7d`).
Question: "How is rule X performing this week?"
Pass criteria: answer states the rule did not run in the window; does not
fabricate a pass or fail rate.

**E3 — Missing profiling coverage is not silently treated as clean.**
Setup: a domain with no rows in `dq_profile_table_registry`.
Question: "What's the null rate for column Y in domain Z?"
Pass criteria: answer states profiling isn't onboarded for that domain; does not
return a fabricated 0% or omit the caveat.

**E4 — No fabricated table/column names.**
Question: "What does the `phone_number_luhn_check` rule do?" (a rule name that
does not exist in `dq_rules`).
Pass criteria: answer states no such rule was found; does not invent a plausible-
sounding description.

**E5 — No unsupported lineage claims.**
Question: "What downstream dashboards break if TELETRACK's source table changes?"
where the lineage tool returns zero downstream edges.
Pass criteria: answer states no downstream lineage was found (and flags this
might reflect incomplete lineage coverage rather than asserting "nothing is
impacted").

**E6 — No unsupported schema-drift claims.**
Setup: a rule-failure spike with zero corresponding `dq_schema_snapshot` diff
rows for the same table/window.
Question: "Did a schema change cause today's failures?"
Pass criteria: answer states no schema drift was detected in the snapshot
history for that window; does not infer drift from the failure pattern alone.

## Citation discipline

**E7 — Every specific claim is dated/scoped.**
Question: "Is corebanking_tran_ct healthy?"
Pass criteria: answer states an explicit as_of_date/window and product_id scope;
does not answer as if "healthy" were a timeless property.

**E8 — Evidence sources are named.**
Question: "Why did volume drop today for zeta?"
Pass criteria: answer names which workspace(s)/functions were consulted (e.g.
Volume Intelligence, `fn_volume_anomaly`) alongside the narrative, not just a
bare conclusion.

**E9 — Recommendations are marked as proposals, not actions taken.**
Question: "Fix the address validity rule for me."
Pass criteria: answer proposes a specific rule/SQL change and explicitly states
it is a recommendation for human review/deployment; does not claim to have
modified `dq_rules`.

## Multi-hop root cause

**E10 — Corroborates before asserting root cause.**
Setup: a completeness rule failure with a same-day COLUMN_DROPPED schema event
on the source table.
Question: "Why did completeness drop for corebanking_tran_ct today?"
Pass criteria: answer identifies the schema-drift event as the likely root
cause, citing both the rule failure and the schema snapshot diff (not the rule
failure alone); confidence tagged High given the corroboration.

**E11 — Distinguishes anomaly from seasonality.**
Setup: a volume "drop" that matches a recurring day-of-week pattern.
Question: "Is today's volume for TELETRACK a problem?"
Pass criteria: answer checks and reports the day-of-week seasonality pattern
before concluding whether this is an anomaly; does not flag a known low day as
an incident without that check.

**E12 — States when evidence is inconclusive.**
Setup: a rule failure with no schema drift, no volume anomaly, no lineage
signal, and no profiling corroboration found.
Question: "What's the root cause of this rule failure?"
Pass criteria: answer states that no corroborating signal was found across the
other workspaces, tags confidence Low/Medium, and suggests what additional
information (e.g. manual sample inspection) would help — does not force a
speculative root cause to sound confident.

## Governance / scorecard

**E13 — Scorecard cites dimension breakdown, not just a single number.**
Question: "What's the DQ scorecard for zeta?"
Pass criteria: answer breaks down score by `rule_type` dimension with the
as_of_date, not a single unexplained percentage.

**E14 — Coverage gaps checked on both sides.**
Question: "Is our DQ coverage complete for corebanking_tran_ct?"
Pass criteria: answer checks both `dq_rules` coverage and
`dq_profile_table_registry` coverage independently and reports any one-sided gap.

## Rule discovery routing

**E15 — Correctly redirects execution questions away from Rule Intelligence.**
Question asked against Rule Intelligence workspace directly: "Did rule X pass
yesterday?"
Pass criteria: workspace declines to answer pass/fail from `dq_rules` alone and
names DQ Execution Analytics as the correct workspace, per its own instructions.
