# Data Quality AI Agent — DCS Agent Studio

An investigative Data Quality AI Agent for the DCS platform: it explains **why**
quality degraded, finds **root cause** across rules, profiling, execution
history, lineage, and schema, and recommends remediation — not a dashboard.

Metadata-driven and multi-team from day one: onboarding a new team is a `MERGE`
into a registry table, never a code change (see § Onboarding below).

## Grounded in real production schema

Built directly against the three Unity Catalog tables already in production:
`prod_dcs_catalog.df_app_configs.dq_rules` (business rule catalog, already
multi-tenant), `prod_dcs_catalog.df_app_configs.dq_stats` (execution metadata,
already multi-tenant), and `prod_dcs_catalog.data_profile.dp_<domain>_<sub_domain>_status`
(profiling — genuinely fragmented per team, unified here via a registry + generated view).

## Project layout

```
sql/            Views, functions, and the one piece of net-new unification
                 machinery (profile table registry + generated union view)
docs/           Architecture, quality-dimension playbooks, Genie workspace
                 specs, Lakehouse Monitoring migration plan, onboarding runbook
agent_studio/   Agent Studio config, system instruction, tool manifest —
                 field-for-field matches to the actual Create Agent/Tool forms —
                 plus production-ready scheduled report prompts per dimension
rag/            Source content for the 3 RAG collections
evals/          Eval cases, incl. zero-tolerance anti-fabrication cases
```

## Quickstart

1. Read [`docs/01_ARCHITECTURE.md`](docs/01_ARCHITECTURE.md) for the full
   component architecture and capability catalog.
2. Follow [`docs/05_ONBOARDING_RUNBOOK.md`](docs/05_ONBOARDING_RUNBOOK.md)
   step-by-step to deploy the SQL layer, create the 8 Genie spaces, register
   tools, and create the agent in DCS Agent Studio.
3. Run every case in [`evals/eval_cases.md`](evals/eval_cases.md) before
   promoting to production consumers — E1–E6 are release-blocking.

## The 8 Genie workspaces

Rule Intelligence · Profiling Intelligence · DQ Execution Analytics · Schema
Intelligence · Freshness Intelligence · Volume Intelligence · Lineage & Impact
Analysis · Governance Intelligence — full specs in
[`docs/03_GENIE_WORKSPACES.md`](docs/03_GENIE_WORKSPACES.md).

## The 7 quality dimensions

Completeness, Validity, Consistency, Uniqueness, Timeliness, Volume, Schema
Drift — each with a full investigation workflow, root-cause strategy, and
remediation playbook in
[`docs/02_QUALITY_DIMENSIONS.md`](docs/02_QUALITY_DIMENSIONS.md) and
[`rag/dimension_playbooks.md`](rag/dimension_playbooks.md).

Rollout is phased: **Completeness, Validity, and Uniqueness ship first**
(Phase 1 — pure rule-execution checks, no new infrastructure); Consistency,
Timeliness, Volume, and Schema Drift follow in Phase 2. The three Phase 1
dimensions each get a detailed, production-ready scheduled report prompt in
[`agent_studio/scheduled_dimension_reports.md`](agent_studio/scheduled_dimension_reports.md).

## Design non-negotiables

- **Anti-fabrication.** `NOT_RUN` / `NO_RESULT` are never reported as `PASS`.
  Enforced at the view layer, the agent's system instruction, and eval cases
  E1–E2.
- **AI-assisted, not AI-autonomous.** The agent recommends rule/threshold
  changes with SQL and rationale — it never has write access to `dq_rules` and
  never claims to have deployed anything (eval case E9).
- **Native Databricks only.** Unity Catalog, system tables, Delta history,
  lineage, Genie, AI Functions, Vector Search. No external tooling.

## Leadership deliverable

[`docs/presentations/DQ_Agent_Leadership_Architecture.docx`](docs/presentations/DQ_Agent_Leadership_Architecture.docx)
— end-to-end architecture with diagrams, built for a leadership demo.

## Lakehouse Monitoring

Deferred today (no serverless compute in this workspace) but designed for a
drop-in swap later — see
[`docs/04_LAKEHOUSE_MONITORING_MIGRATION.md`](docs/04_LAKEHOUSE_MONITORING_MIGRATION.md).
