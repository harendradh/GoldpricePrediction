# Databricks notebook source
# MAGIC %md
# MAGIC # Open Table Formats — Live Demo
# MAGIC **Presenters: Prakash · Harendra**
# MAGIC
# MAGIC > Delta Lake · Apache Iceberg (UniForm) · Delta Sharing · Unity Catalog
# MAGIC
# MAGIC **Requirements:** DBR 14.3 LTS+ · Unity Catalog enabled · CREATE TABLE permission on target catalog

# COMMAND ----------
# MAGIC %md
# MAGIC ## ⚙️ CMD 1 — Environment Setup
# MAGIC > **Edit the 3 variables below before running anything**

# COMMAND ----------

# ── EDIT THESE ───────────────────────────────────────────────────────────────
CATALOG = "demo"           # your Unity Catalog name
SCHEMA  = "otf_demo"      # schema / database to use
# ─────────────────────────────────────────────────────────────────────────────

spark.sql(f"CREATE CATALOG IF NOT EXISTS {CATALOG}")
spark.sql(f"CREATE SCHEMA  IF NOT EXISTS {CATALOG}.{SCHEMA}")
spark.sql(f"USE {CATALOG}.{SCHEMA}")

print(f"✅ Using: {CATALOG}.{SCHEMA}")
print(f"   Spark : {spark.version}")

# COMMAND ----------
# MAGIC %md
# MAGIC ## 📦 CMD 2 — Generate 2M Payment Transactions

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import IntegerType

df = spark.range(1, 2_000_001).select(
    F.col("id").alias("txn_id"),
    F.concat(F.lit("ACCT-"),
             F.lpad((F.col("id") % 10000).cast("string"), 8, "0")
    ).alias("account_id"),
    F.round(F.rand(seed=42) * 9999.99 + 0.01, 2).alias("amount"),
    F.element_at(
        F.array(F.lit("USD"), F.lit("EUR"), F.lit("GBP"), F.lit("SGD")),
        (F.col("id") % 4 + 1).cast(IntegerType())
    ).alias("currency"),
    F.element_at(
        F.array(F.lit("PAYMENT"), F.lit("REFUND"), F.lit("TRANSFER"), F.lit("FEE")),
        (F.col("id") % 4 + 1).cast(IntegerType())
    ).alias("txn_type"),
    F.element_at(
        F.array(F.lit("APAC"), F.lit("EMEA"), F.lit("US"), F.lit("LATAM")),
        (F.col("id") % 4 + 1).cast(IntegerType())
    ).alias("region"),
    F.date_add(
        F.lit("2024-01-01"),
        (F.col("id") % 365).cast(IntegerType())
    ).alias("txn_date"),
    F.element_at(
        F.array(F.lit("COMPLETED"), F.lit("PENDING"), F.lit("FAILED")),
        (F.col("id") % 3 + 1).cast(IntegerType())
    ).alias("status"),
)

# Write as Delta Lake (default on Databricks)
(df.write
   .format("delta")
   .mode("overwrite")
   .option("overwriteSchema", "true")
   .saveAsTable(f"{CATALOG}.{SCHEMA}.transactions"))

print(f"✅ Written {df.count():,} rows as Delta Lake")
df.show(5, truncate=False)

# COMMAND ----------
# MAGIC %md
# MAGIC ## ✨ CMD 3 — Enable UniForm (Iceberg) + Liquid Clustering
# MAGIC > **Do this first** — Databricks auto-generates Iceberg metadata alongside `_delta_log/`. Zero data rewrite.

# COMMAND ----------

# Enable UniForm: Iceberg metadata generated automatically on every Delta commit
spark.sql(f"""
  ALTER TABLE {CATALOG}.{SCHEMA}.transactions
  SET TBLPROPERTIES (
    'delta.universalFormat.enabledFormats' = 'iceberg'
  )
""")
print("✅ UniForm enabled — Iceberg metadata now generated on every commit")

# Enable Liquid Clustering: replaces PARTITIONED BY + ZORDER in one operation
spark.sql(f"""
  ALTER TABLE {CATALOG}.{SCHEMA}.transactions
  CLUSTER BY (txn_date, region)
""")
print("✅ Liquid Clustering enabled on (txn_date, region)")

# Verify both properties are active
print("\n── Table Properties ──────────────────────────────────────────────────────")
spark.sql(f"SHOW TBLPROPERTIES {CATALOG}.{SCHEMA}.transactions").show(truncate=False)

# COMMAND ----------
# MAGIC %md
# MAGIC ### 🔍 What UniForm enables (no extra steps needed)
# MAGIC ```sql
# MAGIC -- Trino / Presto reads same table as native Iceberg:
# MAGIC SELECT * FROM iceberg.demo.otf_demo.transactions LIMIT 10;
# MAGIC
# MAGIC -- Snowflake external Iceberg table points to same metadata.json
# MAGIC -- Athena, Dremio, StarRocks — all read natively, no ETL
# MAGIC ```

# COMMAND ----------
# MAGIC %md
# MAGIC ## 🔍 CMD 4 — Inspect the Delta Transaction Log
# MAGIC > Every write = exactly 1 JSON commit appended atomically to `_delta_log/`

# COMMAND ----------

import json

# See full version history: operation, user, timestamp, row counts
print("── Table History ──────────────────────────────────────────────────────────")
spark.sql(f"DESCRIBE HISTORY {CATALOG}.{SCHEMA}.transactions").show(truncate=False)

# COMMAND ----------

# Get the physical storage path
detail = spark.sql(f"DESCRIBE DETAIL {CATALOG}.{SCHEMA}.transactions").collect()[0]
location = detail["location"]
print(f"Table location: {location}")

log_path = f"{location}/_delta_log"
print(f"\n── _delta_log/ contents ───────────────────────────────────────────────────")
for f in dbutils.fs.ls(log_path)[:8]:
    print(f"  {f.name:<55} {f.size:>10,} bytes")

# COMMAND ----------

# Parse the raw CREATE TABLE commit — see exactly what Delta records
print("── Commit 0 (CREATE TABLE) — raw JSON ────────────────────────────────────")
commit_0 = spark.read.text(f"{log_path}/00000000000000000000.json")
for row in commit_0.collect():
    parsed = json.loads(row.value)
    action = list(parsed.keys())[0]
    print(f"\nAction: {action}")
    print(json.dumps(parsed, indent=2)[:600])

# COMMAND ----------
# MAGIC %md
# MAGIC ## ⚡ CMD 5 — ACID MERGE — Atomic Upsert (CDC Pattern)
# MAGIC > Simulates incoming payment corrections from a Kafka CDC stream

# COMMAND ----------

# Simulate CDC updates arriving from upstream system
updates = spark.createDataFrame([
    (1001, "ACCT-00001001", 500.00,    "USD", "PAYMENT",  "APAC",  "2024-06-15", "COMPLETED"),
    (1002, "ACCT-00001002", 999.99,    "EUR", "REFUND",   "EMEA",  "2024-06-15", "FAILED"),
    (9_999_999, "ACCT-99999999", 1.00, "GBP", "FEE",     "US",    "2024-06-15", "PENDING"),  # new row
], "txn_id BIGINT, account_id STRING, amount DOUBLE, currency STRING, "
   "txn_type STRING, region STRING, txn_date DATE, status STRING")

updates.createOrReplaceTempView("updates")

before = spark.sql(f"SELECT COUNT(*) AS n FROM {CATALOG}.{SCHEMA}.transactions").first().n

spark.sql(f"""
  MERGE INTO {CATALOG}.{SCHEMA}.transactions  t
  USING updates                                u  ON t.txn_id = u.txn_id
  WHEN MATCHED     THEN UPDATE SET t.amount = u.amount,  t.status = u.status
  WHEN NOT MATCHED THEN INSERT *
""")

after = spark.sql(f"SELECT COUNT(*) AS n FROM {CATALOG}.{SCHEMA}.transactions").first().n

print(f"✅ MERGE complete")
print(f"   Before : {before:,} rows")
print(f"   After  : {after:,} rows  (+{after-before} inserted, 2 updated — 1 atomic commit)")

# Confirm what changed
spark.sql(f"""
  SELECT txn_id, account_id, amount, status
  FROM   {CATALOG}.{SCHEMA}.transactions
  WHERE  txn_id IN (1001, 1002, 9999999)
  ORDER BY txn_id
""").show()

# COMMAND ----------
# MAGIC %md
# MAGIC ## 📡 CMD 6 — Change Data Feed — Stream Row-Level Changes
# MAGIC > Read ONLY changed rows since a given version — no full table rescan

# COMMAND ----------

# Enable CDF — captures INSERT / UPDATE_PREIMAGE / UPDATE_POSTIMAGE / DELETE
spark.sql(f"""
  ALTER TABLE {CATALOG}.{SCHEMA}.transactions
  SET TBLPROPERTIES ('delta.enableChangeDataFeed' = true)
""")
print("✅ Change Data Feed enabled")

# Make additional changes to populate the feed
spark.sql(f"""
  UPDATE {CATALOG}.{SCHEMA}.transactions
  SET    status = 'COMPLETED'
  WHERE  region = 'APAC' AND status = 'PENDING'
""")
print("✅ UPDATE applied — APAC PENDING → COMPLETED")

spark.sql(f"""
  DELETE FROM {CATALOG}.{SCHEMA}.transactions
  WHERE  txn_id = 9999999
""")
print("✅ DELETE applied — txn_id 9999999 removed")

# COMMAND ----------

# Read only changed rows since version 3 — this is what downstream consumers get
changes = (
    spark.read
         .format("delta")
         .option("readChangeFeed",    "true")
         .option("startingVersion",   3)
         .table(f"{CATALOG}.{SCHEMA}.transactions")
)

print(f"Changed rows: {changes.count():,}")
changes.select(
    "_change_type", "_commit_version", "_commit_timestamp",
    "txn_id", "account_id", "region", "status"
).orderBy("_commit_version", "_change_type").show(20, truncate=False)

# _change_type values:
#   insert            — new row added
#   update_preimage   — row before update
#   update_postimage  — row after update
#   delete            — deleted row

# COMMAND ----------
# MAGIC %md
# MAGIC ## ⏳ CMD 7 — Time Travel — Query Any Historical Version
# MAGIC > Full audit trail built-in — no extra tooling needed

# COMMAND ----------

# See every version with user, timestamp, operation, row counts
print("── Full Version History ───────────────────────────────────────────────────")
spark.sql(f"""
  SELECT version, timestamp, userName, operation, operationMetrics
  FROM   (DESCRIBE HISTORY {CATALOG}.{SCHEMA}.transactions)
  ORDER  BY version
""").show(truncate=False)

# COMMAND ----------

# Query at any past version — reproduce exact state for audit reports
print("── Row counts across versions ─────────────────────────────────────────────")
for v in range(0, 5):
    try:
        cnt = spark.sql(
            f"SELECT COUNT(*) AS n FROM {CATALOG}.{SCHEMA}.transactions VERSION AS OF {v}"
        ).first().n
        print(f"  v{v}: {cnt:,} rows")
    except Exception:
        print(f"  v{v}: not available")

# COMMAND ----------

# Query by timestamp (useful for SOX/PCI audit: "show me the table as of market close")
# spark.sql(f"""
#   SELECT * FROM {CATALOG}.{SCHEMA}.transactions
#   TIMESTAMP AS OF '2024-06-01 17:00:00'
#   LIMIT 10
# """).show()

# Restore entire table to v1 — seconds, not hours (metadata-only if VACUUM hasn't run)
spark.sql(f"RESTORE TABLE {CATALOG}.{SCHEMA}.transactions TO VERSION AS OF 1")
print("✅ Table restored to VERSION 1 instantly")

# COMMAND ----------
# MAGIC %md
# MAGIC ## 📐 CMD 8 — Schema Evolution — Add Columns Without Rewrite

# COMMAND ----------

# Add new columns — existing Parquet files untouched, reads as NULL for old rows
spark.sql(f"ALTER TABLE {CATALOG}.{SCHEMA}.transactions ADD COLUMN risk_score  DOUBLE")
spark.sql(f"ALTER TABLE {CATALOG}.{SCHEMA}.transactions ADD COLUMN merchant_id STRING")
print("✅ Added risk_score and merchant_id columns — no data rewrite")

# Rename a column — metadata only, zero data movement
spark.sql(f"ALTER TABLE {CATALOG}.{SCHEMA}.transactions RENAME COLUMN txn_type TO transaction_type")
print("✅ Renamed txn_type → transaction_type — metadata only")

# Verify the evolved schema
print("\n── Current Schema ─────────────────────────────────────────────────────────")
spark.sql(f"DESCRIBE TABLE {CATALOG}.{SCHEMA}.transactions").show(truncate=False)

# COMMAND ----------
# MAGIC %md
# MAGIC ## 📊 CMD 9 — OPTIMIZE + Data Skipping Benchmark
# MAGIC > Show the real performance impact of compaction and column statistics

# COMMAND ----------

# Before OPTIMIZE: many small files from incremental writes
before_detail = spark.sql(f"DESCRIBE DETAIL {CATALOG}.{SCHEMA}.transactions").collect()[0]
print(f"Before OPTIMIZE:")
print(f"  Files : {before_detail['numFiles']:,}")
print(f"  Size  : {before_detail['sizeInBytes']/1024/1024:.1f} MB")

# COMMAND ----------

# OPTIMIZE: compact small files + apply Liquid Clustering layout
spark.sql(f"OPTIMIZE {CATALOG}.{SCHEMA}.transactions")

after_detail = spark.sql(f"DESCRIBE DETAIL {CATALOG}.{SCHEMA}.transactions").collect()[0]
print(f"After OPTIMIZE:")
print(f"  Files : {after_detail['numFiles']:,}  (was {before_detail['numFiles']:,})")
print(f"  Size  : {after_detail['sizeInBytes']/1024/1024:.1f} MB")

# COMMAND ----------

# Data skipping benchmark — selective query on clustered columns
import time

q = f"SELECT SUM(amount) AS total FROM {CATALOG}.{SCHEMA}.transactions WHERE region='APAC' AND txn_date='2024-06-15'"

spark.conf.set("spark.databricks.delta.stats.skipping", "false")
t0 = time.time()
spark.sql(q).collect()
t_no_skip = time.time() - t0
print(f"Without data skipping : {t_no_skip:.2f}s")

spark.conf.set("spark.databricks.delta.stats.skipping", "true")
t0 = time.time()
spark.sql(q).collect()
t_skip = time.time() - t0
print(f"With    data skipping : {t_skip:.2f}s")
print(f"Speedup               : {t_no_skip/t_skip:.1f}x  (typical: 10–100x on large tables)")

# COMMAND ----------
# MAGIC %md
# MAGIC ## 🔗 CMD 10 — Delta Sharing — Provider Side
# MAGIC > Share live data with any partner or cloud — no credentials, no data copy

# COMMAND ----------
# MAGIC %sql
# MAGIC -- Create a Share: logical container for what we expose
# MAGIC CREATE SHARE IF NOT EXISTS partner_share
# MAGIC   COMMENT 'APAC transaction data for partner access';
# MAGIC
# MAGIC -- Add table with partition filter — partner sees ONLY APAC rows
# MAGIC ALTER SHARE partner_share
# MAGIC   ADD TABLE demo.otf_demo.transactions
# MAGIC   PARTITION (region = 'APAC');
# MAGIC
# MAGIC -- Create recipient — generates a bearer token for the partner
# MAGIC CREATE RECIPIENT IF NOT EXISTS partner_org;
# MAGIC
# MAGIC -- Grant SELECT access
# MAGIC GRANT SELECT ON SHARE partner_share TO RECIPIENT partner_org;
# MAGIC
# MAGIC -- Get the activation link to send to partner (no storage credentials included)
# MAGIC DESCRIBE RECIPIENT partner_org;

# COMMAND ----------
# MAGIC %md
# MAGIC ## 🤝 CMD 11 — Delta Sharing — Recipient Side
# MAGIC > Partner runs this on **any** platform — AWS EMR, GCP Dataproc, local Spark — no Databricks needed

# COMMAND ----------

# pip install delta-sharing  (on recipient cluster, not needed here)
# Partner receives a .share profile file via secure channel containing:
#   endpoint, bearerToken, shareCredentialsVersion

try:
    import delta_sharing

    # Path to the .share profile file the partner received
    PROFILE = "/dbfs/tmp/partner_org.share"

    client = delta_sharing.SharingClient(PROFILE)

    print("── Available shared tables ────────────────────────────────────────────────")
    tables = client.list_all_tables()
    for t in tables:
        print(f"  {t.share}.{t.schema}.{t.name}")

    # Load as Pandas DataFrame
    pdf = delta_sharing.load_as_pandas(f"{PROFILE}#partner_share.otf_demo.transactions")
    print(f"\nLoaded {len(pdf):,} rows (APAC only — row filter applied server-side)")
    print(pdf.head())

    # Load as Spark DataFrame (for large-scale processing)
    sdf = (spark.read
                .format("deltaSharing")
                .load(f"{PROFILE}#partner_share.otf_demo.transactions"))
    sdf.groupBy("status").count().show()

except (ImportError, FileNotFoundError) as e:
    print(f"Note: {e}")
    print("This cell runs on the recipient's cluster with a real .share profile file.")
    print("The partner never sees storage credentials — only time-limited pre-signed URLs.")

# COMMAND ----------
# MAGIC %md
# MAGIC ## 🛡️ CMD 12 — Unity Catalog Governance
# MAGIC > Column masking, row-level security, and built-in audit — zero extra setup

# COMMAND ----------
# MAGIC %sql
# MAGIC -- Column masking: show raw account_id only to finance-admin group
# MAGIC CREATE OR REPLACE FUNCTION demo.otf_demo.mask_account(acct STRING)
# MAGIC   RETURNS STRING
# MAGIC   RETURN CASE
# MAGIC     WHEN is_account_group_member('finance-admin') THEN acct
# MAGIC     ELSE CONCAT(LEFT(acct, 9), '****')
# MAGIC   END;
# MAGIC
# MAGIC ALTER TABLE demo.otf_demo.transactions
# MAGIC   ALTER COLUMN account_id
# MAGIC   SET MASK demo.otf_demo.mask_account;
# MAGIC
# MAGIC -- Test: non-admin sees masked values
# MAGIC SELECT txn_id, account_id, amount, region
# MAGIC FROM   demo.otf_demo.transactions
# MAGIC LIMIT  5;

# COMMAND ----------
# MAGIC %sql
# MAGIC -- Row-level security: each user sees only rows matching their region attribute
# MAGIC CREATE OR REPLACE VIEW demo.otf_demo.secure_transactions AS
# MAGIC   SELECT * FROM demo.otf_demo.transactions
# MAGIC   WHERE region = (
# MAGIC     SELECT region_attribute
# MAGIC     FROM   system.access.user_attributes
# MAGIC     WHERE  user_name = current_user()
# MAGIC     LIMIT  1
# MAGIC   );
# MAGIC
# MAGIC -- APAC analyst → sees only APAC rows automatically
# MAGIC SELECT region, COUNT(*) AS rows
# MAGIC FROM   demo.otf_demo.secure_transactions
# MAGIC GROUP  BY region;

# COMMAND ----------
# MAGIC %sql
# MAGIC -- Built-in audit log — always on, no setup, queryable via SQL
# MAGIC SELECT
# MAGIC   user_identity.email      AS user_email,
# MAGIC   action_name,
# MAGIC   request_params.full_name AS table_name,
# MAGIC   event_time
# MAGIC FROM system.access.audit
# MAGIC WHERE service_name = 'unityCatalog'
# MAGIC   AND action_name  IN (
# MAGIC         'getTable',
# MAGIC         'generateTemporaryTableCredential',
# MAGIC         'createTable',
# MAGIC         'deleteTable'
# MAGIC       )
# MAGIC ORDER BY event_time DESC
# MAGIC LIMIT 25;

# COMMAND ----------
# MAGIC %md
# MAGIC ## 🧹 CMD 13 — Cleanup
# MAGIC > Run only to reset the demo environment

# COMMAND ----------

# Uncomment the lines below to clean up
# spark.sql(f"DROP TABLE    IF EXISTS {CATALOG}.{SCHEMA}.transactions")
# spark.sql(f"DROP VIEW     IF EXISTS {CATALOG}.{SCHEMA}.secure_transactions")
# spark.sql(f"DROP FUNCTION IF EXISTS {CATALOG}.{SCHEMA}.mask_account")
# spark.sql(f"DROP SCHEMA   IF EXISTS {CATALOG}.{SCHEMA}")
# spark.sql(f"DROP CATALOG  IF EXISTS {CATALOG}")
# print("✅ Cleanup complete")

print("Cleanup cells are commented out — uncomment to reset.")

# COMMAND ----------
# MAGIC %md
# MAGIC ---
# MAGIC ## Quick Reference
# MAGIC
# MAGIC | Capability | Command |
# MAGIC |---|---|
# MAGIC | Enable UniForm (Iceberg) | `ALTER TABLE t SET TBLPROPERTIES ('delta.universalFormat.enabledFormats'='iceberg')` |
# MAGIC | Liquid Clustering | `ALTER TABLE t CLUSTER BY (col1, col2)` |
# MAGIC | Atomic Upsert | `MERGE INTO t USING src ON ... WHEN MATCHED ... WHEN NOT MATCHED ...` |
# MAGIC | Enable CDF | `ALTER TABLE t SET TBLPROPERTIES ('delta.enableChangeDataFeed'=true)` |
# MAGIC | Read CDC stream | `spark.read.format('delta').option('readChangeFeed','true').option('startingVersion',N).table(t)` |
# MAGIC | Time Travel | `SELECT * FROM t VERSION AS OF N` |
# MAGIC | Restore | `RESTORE TABLE t TO VERSION AS OF N` |
# MAGIC | Compact files | `OPTIMIZE t` |
# MAGIC | Share data | `CREATE SHARE s; ALTER SHARE s ADD TABLE t PARTITION (...); CREATE RECIPIENT r` |
# MAGIC | Audit log | `SELECT * FROM system.access.audit WHERE service_name='unityCatalog'` |
# MAGIC
# MAGIC ---
# MAGIC **Prakash · Harendra | Open Table Formats**
