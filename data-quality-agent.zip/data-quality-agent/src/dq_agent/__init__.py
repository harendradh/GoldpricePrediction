"""Fiserv Data Quality Agent."""
from .models.schemas import ENGINE_VERSION

__version__ = ENGINE_VERSION
