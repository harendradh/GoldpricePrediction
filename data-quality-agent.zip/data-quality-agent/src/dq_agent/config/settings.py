"""Centralized configuration (12-factor: everything from env)."""
from __future__ import annotations

from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="DQA_", env_file=".env", extra="ignore")

    # Databricks workspace
    databricks_host: str = Field(..., description="https://adb-xxxx.azuredatabricks.net")
    databricks_token: str = Field(default="", description="PAT or empty when using OAuth SP")
    databricks_client_id: str = ""           # service principal (preferred in prod)
    databricks_client_secret: str = ""

    # Compute
    dq_job_id: str = Field(..., description="Job id of the DQ check job")
    sql_warehouse_id: str = Field(..., description="Warehouse for control-table reads")
    control_schema: str = "governance.dq"

    # Notifications
    teams_webhook_url: str = ""
    servicenow_url: str = ""

    # Agent / API
    api_key: str = Field(default="", description="Shared secret for tool endpoints")
    request_timeout_s: int = 60
    poll_interval_s: int = 10
    poll_timeout_s: int = 1800

    @property
    def use_oauth(self) -> bool:
        return bool(self.databricks_client_id and self.databricks_client_secret)


@lru_cache
def get_settings() -> Settings:
    return Settings()  # type: ignore[call-arg]
