"""Databricks REST client: Jobs API (2.1) + SQL Statement Execution API (2.0).

The agent runtime uses this to:
  - trigger the DQ check Job (which runs the Spark engine on a cluster),
  - poll the run to completion,
  - read control tables / results via a SQL Warehouse (no Spark in this process).

Auth: OAuth service principal (preferred) or PAT. Retries + timeouts baked in.
"""
from __future__ import annotations

import time
from typing import Any, Optional

import httpx

from ..config.settings import Settings, get_settings


class DatabricksClient:
    def __init__(self, settings: Optional[Settings] = None):
        self.s = settings or get_settings()
        self._token: Optional[str] = None
        self._token_exp: float = 0.0
        self._http = httpx.Client(
            base_url=self.s.databricks_host.rstrip("/"),
            timeout=self.s.request_timeout_s,
        )

    # ------------------------------------------------------------------ auth
    def _auth_header(self) -> dict[str, str]:
        if self.s.use_oauth:
            return {"Authorization": f"Bearer {self._oauth_token()}"}
        return {"Authorization": f"Bearer {self.s.databricks_token}"}

    def _oauth_token(self) -> str:
        now = time.time()
        if self._token and now < self._token_exp - 60:
            return self._token
        resp = httpx.post(
            f"{self.s.databricks_host.rstrip('/')}/oidc/v1/token",
            data={"grant_type": "client_credentials", "scope": "all-apis"},
            auth=(self.s.databricks_client_id, self.s.databricks_client_secret),
            timeout=self.s.request_timeout_s,
        )
        resp.raise_for_status()
        tok = resp.json()
        self._token = tok["access_token"]
        self._token_exp = now + int(tok.get("expires_in", 3600))
        return self._token

    def _request(self, method: str, path: str, **kw) -> dict[str, Any]:
        for attempt in range(4):
            resp = self._http.request(method, path, headers=self._auth_header(), **kw)
            if resp.status_code < 500 and resp.status_code != 429:
                resp.raise_for_status()
                return resp.json() if resp.content else {}
            time.sleep(2 ** attempt)
        resp.raise_for_status()
        return {}

    # ------------------------------------------------------------ Jobs API 2.1
    def trigger_dq_job(self, dataset_id: str, rule_ids: Optional[list[str]], triggered_by: str) -> str:
        params = {
            "dataset_id": dataset_id,
            "rule_ids": ",".join(rule_ids) if rule_ids else "",
            "triggered_by": triggered_by,
        }
        body = {"job_id": int(self.s.dq_job_id), "notebook_params": params}
        out = self._request("POST", "/api/2.1/jobs/run-now", json=body)
        return str(out["run_id"])

    def get_run(self, run_id: str) -> dict[str, Any]:
        return self._request("GET", "/api/2.1/jobs/runs/get", params={"run_id": run_id})

    def wait_for_run(self, run_id: str) -> dict[str, Any]:
        deadline = time.time() + self.s.poll_timeout_s
        while time.time() < deadline:
            run = self.get_run(run_id)
            state = run.get("state", {})
            if state.get("life_cycle_state") in {"TERMINATED", "SKIPPED", "INTERNAL_ERROR"}:
                return run
            time.sleep(self.s.poll_interval_s)
        raise TimeoutError(f"DQ job run {run_id} did not finish within {self.s.poll_timeout_s}s")

    # --------------------------------------------- SQL Statement Execution 2.0
    def sql(self, statement: str, params: Optional[list[dict]] = None) -> list[dict[str, Any]]:
        body = {
            "warehouse_id": self.s.sql_warehouse_id,
            "statement": statement,
            "wait_timeout": "30s",
            "on_wait_timeout": "CONTINUE",
        }
        if params:
            body["parameters"] = params
        out = self._request("POST", "/api/2.0/sql/statements", json=body)
        out = self._await_sql(out)
        return _rows_to_dicts(out)

    def _await_sql(self, out: dict) -> dict:
        state = out.get("status", {}).get("state")
        stmt_id = out.get("statement_id")
        deadline = time.time() + self.s.poll_timeout_s
        while state in {"PENDING", "RUNNING"} and time.time() < deadline:
            time.sleep(1.5)
            out = self._request("GET", f"/api/2.0/sql/statements/{stmt_id}")
            state = out.get("status", {}).get("state")
        if state != "SUCCEEDED":
            raise RuntimeError(f"SQL failed: {out.get('status')}")
        return out

    def close(self) -> None:
        self._http.close()


def _rows_to_dicts(out: dict) -> list[dict[str, Any]]:
    result = out.get("result", {})
    schema = out.get("manifest", {}).get("schema", {}).get("columns", [])
    names = [c["name"] for c in schema]
    return [dict(zip(names, row)) for row in result.get("data_array", [])]
