"""Agent Studio Tools — thin, deterministic functions the LLM can call.

Each tool has a stable JSON contract (args in, dict out). The FastAPI layer
(api/main.py) exposes them; register those endpoints in Agent Studio as Tools.

The LLM decides *when* to call; these decide *what* happens. No business logic
lives in the prompt.
"""
from __future__ import annotations

from typing import Optional

from ..config.settings import get_settings
from ..databricks.client import DatabricksClient


class DQTools:
    def __init__(self, client: Optional[DatabricksClient] = None):
        self.client = client or DatabricksClient()
        self.control = get_settings().control_schema

    # 1 -------------------------------------------------- discover / registry
    def list_datasets(self, owner_bu: Optional[str] = None) -> dict:
        """List datasets registered for DQ, optionally filtered by BU."""
        where = " WHERE active"
        if owner_bu:
            where += f" AND owner_bu = '{owner_bu}'"
        rows = self.client.sql(
            f"SELECT dataset_id, target_catalog, target_schema, target_table, "
            f"owner_bu, criticality FROM {self.control}.dataset_registry{where} "
            f"ORDER BY criticality, dataset_id"
        )
        return {"count": len(rows), "datasets": rows}

    # 2 ------------------------------------------------------------- profile
    def profile_dataset(self, dataset_id: str) -> dict:
        """Return schema + null%/distinct profile via a short-lived profiling query.

        Runs SELECTs through the SQL Warehouse. For very wide/large tables prefer the
        profiling task on the cluster; kept here as a fast interactive overview.
        """
        ds = self._dataset(dataset_id)
        fq = f"{ds['target_catalog']}.{ds['target_schema']}.{ds['target_table']}"
        cols = self.client.sql(f"DESCRIBE {fq}")
        total = self.client.sql(f"SELECT COUNT(*) AS c FROM {fq}")[0]["c"]
        return {"dataset_id": dataset_id, "fq_table": fq, "row_count": total,
                "columns": [c for c in cols if c.get("col_name") and not c["col_name"].startswith("#")]}

    # 3 --------------------------------------------------------- get rules
    def get_rules(self, dataset_id: str) -> dict:
        rows = self.client.sql(
            f"SELECT rule_id, rule_name, dimension, rule_type, target_column, "
            f"severity, threshold, enabled FROM {self.control}.rule_catalog "
            f"WHERE dataset_id = '{dataset_id}' ORDER BY severity, dimension"
        )
        return {"dataset_id": dataset_id, "count": len(rows), "rules": rows}

    # 4 ---------------------------------------------------- run checks (job)
    def run_checks(self, dataset_id: str, rule_ids: Optional[list[str]] = None,
                   triggered_by: str = "agent", wait: bool = True) -> dict:
        """Trigger the DQ Databricks job. Returns run info (+ summary if wait=True)."""
        job_run_id = self.client.trigger_dq_job(dataset_id, rule_ids, triggered_by)
        if not wait:
            return {"job_run_id": job_run_id, "status": "RUNNING"}
        run = self.client.wait_for_run(job_run_id)
        state = run.get("state", {})
        summary = self.get_latest_summary(dataset_id)
        return {
            "job_run_id": job_run_id,
            "result_state": state.get("result_state"),
            "summary": summary,
        }

    # 5 ------------------------------------------------------- read results
    def get_latest_summary(self, dataset_id: str) -> dict:
        rows = self.client.sql(
            f"SELECT * FROM {self.control}.v_latest_scorecard WHERE dataset_id = '{dataset_id}'"
        )
        return rows[0] if rows else {"dataset_id": dataset_id, "note": "no runs yet"}

    def get_failures(self, dataset_id: str, run_id: Optional[str] = None, limit: int = 50) -> dict:
        """Return failed rules for the given (or latest) run — feeds remediation."""
        run_clause = f"AND run_id = '{run_id}'" if run_id else (
            f"AND run_id = (SELECT run_id FROM {self.control}.run_summary "
            f"WHERE dataset_id='{dataset_id}' ORDER BY run_ts DESC LIMIT 1)")
        rows = self.client.sql(
            f"SELECT rule_id, dimension, rule_type, target_column, severity, "
            f"failed_rows, total_rows, violation_rate, message, sample_bad_keys "
            f"FROM {self.control}.results WHERE dataset_id='{dataset_id}' "
            f"AND passed = false {run_clause} ORDER BY severity LIMIT {limit}"
        )
        return {"dataset_id": dataset_id, "failures": rows}

    # 6 --------------------------------------------- propose rule (HITL write)
    def propose_rule(self, dataset_id: str, rule_name: str, dimension: str, rule_type: str,
                     target_column: Optional[str], params: dict, severity: str = "medium",
                     threshold: float = 0.0) -> dict:
        """Insert a *disabled* candidate rule for human approval (never auto-enabled)."""
        rule_id = f"{dataset_id}::{_slug(rule_name)}"
        kv = ", ".join(f"'{k}', '{v}'" for k, v in params.items())
        self.client.sql(
            f"INSERT INTO {self.control}.rule_catalog "
            f"(rule_id, rule_name, dataset_id, dimension, rule_type, target_column, "
            f"params, threshold, severity, enabled) VALUES "
            f"('{rule_id}', '{rule_name}', '{dataset_id}', '{dimension}', '{rule_type}', "
            f"{_q(target_column)}, map({kv}), {threshold}, '{severity}', false)"
        )
        return {"rule_id": rule_id, "status": "PENDING_APPROVAL",
                "note": "Rule created disabled. Enable after review."}

    # helpers
    def _dataset(self, dataset_id: str) -> dict:
        rows = self.client.sql(
            f"SELECT * FROM {self.control}.dataset_registry WHERE dataset_id='{dataset_id}'")
        if not rows:
            raise ValueError(f"dataset not registered: {dataset_id}")
        return rows[0]


def _slug(text: str) -> str:
    return "".join(ch.lower() if ch.isalnum() else "_" for ch in text).strip("_")


def _q(v: Optional[str]) -> str:
    return "NULL" if v is None else f"'{v}'"
