"""Notification + remediation advisory.

The agent SUGGESTS remediation; a human (or an approved automation) acts. We only
send alerts here — no data mutation. Extend `create_ticket` for ServiceNow.
"""
from __future__ import annotations

import httpx

from ..config.settings import get_settings


def notify_teams(title: str, summary: dict, failures: list[dict]) -> bool:
    """Post a scorecard + top failures to a Teams incoming webhook."""
    s = get_settings()
    if not s.teams_webhook_url:
        return False
    color = {"GREEN": "2ea44f", "AMBER": "d29922", "RED": "cf222e"}.get(
        summary.get("rag_status", ""), "8b949e")
    facts = [
        {"name": "Score", "value": f"{summary.get('overall_score')}"},
        {"name": "Status", "value": summary.get("rag_status", "?")},
        {"name": "Critical failures", "value": str(summary.get("critical_failures", 0))},
        {"name": "Passed", "value": f"{summary.get('passed_rules')}/{summary.get('total_rules')}"},
    ]
    top = "\n".join(
        f"- **{f.get('severity','')}** {f.get('rule_id','')}: {f.get('message','')}"
        for f in failures[:5]
    ) or "None"
    card = {
        "@type": "MessageCard", "@context": "http://schema.org/extensions",
        "themeColor": color, "summary": title,
        "sections": [{
            "activityTitle": title,
            "activitySubtitle": summary.get("fq_table", ""),
            "facts": facts, "text": f"**Top issues**\n{top}",
        }],
    }
    r = httpx.post(s.teams_webhook_url, json=card, timeout=s.request_timeout_s)
    return r.status_code < 300


def remediation_advice(failures: list[dict]) -> list[dict]:
    """Deterministic remediation suggestions per failure type (agent narrates these)."""
    advice = []
    playbook = {
        "not_null": "Backfill/reject nulls upstream; add NOT NULL constraint if stable.",
        "unique": "Deduplicate on the key; investigate double-load / missing MERGE key.",
        "referential": "Quarantine orphan rows; fix load order so parent lands first.",
        "freshness": "Check upstream job SLA / scheduler; alert data owner.",
        "range": "Validate source mapping / units; clamp or reject out-of-range values.",
        "accepted_values": "Reconcile domain/enum with source system reference data.",
        "regex": "Fix formatting at ingestion; standardize before load.",
        "expression": "Review business rule with owner; correct upstream logic.",
        "row_count_anomaly": "Check for partial load / duplicate load / source outage.",
        "custom_sql": "Review the custom rule with its author.",
    }
    for f in failures:
        advice.append({
            "rule_id": f.get("rule_id"),
            "severity": f.get("severity"),
            "action": playbook.get(f.get("rule_type"), "Investigate with data owner."),
        })
    return advice
