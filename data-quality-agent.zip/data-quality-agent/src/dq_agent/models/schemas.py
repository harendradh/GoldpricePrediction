"""Pydantic data contracts shared by the engine, tools, and API.

These are the *product's* interface. Keep them stable and versioned.
"""
from __future__ import annotations

from enum import Enum
from typing import Any, Optional

from pydantic import BaseModel, Field

ENGINE_VERSION = "1.0.0"


class Dimension(str, Enum):
    completeness = "completeness"
    uniqueness = "uniqueness"
    validity = "validity"
    accuracy = "accuracy"
    consistency = "consistency"
    integrity = "integrity"
    timeliness = "timeliness"
    volume = "volume"
    schema = "schema"


class RuleType(str, Enum):
    not_null = "not_null"
    unique = "unique"
    range = "range"
    regex = "regex"
    accepted_values = "accepted_values"
    expression = "expression"          # cross-column boolean expr that must be TRUE
    referential = "referential"        # FK exists in parent
    freshness = "freshness"
    row_count_anomaly = "row_count_anomaly"
    custom_sql = "custom_sql"          # user SQL returning failed rows


class Severity(str, Enum):
    critical = "critical"
    high = "high"
    medium = "medium"
    low = "low"


# Weights used by the scorer. Tunable per org policy.
SEVERITY_WEIGHT: dict[str, float] = {
    "critical": 10.0,
    "high": 5.0,
    "medium": 2.0,
    "low": 1.0,
}


class Rule(BaseModel):
    rule_id: str
    rule_name: str
    dataset_id: str
    dimension: Dimension
    rule_type: RuleType
    target_column: Optional[str] = None
    params: dict[str, str] = Field(default_factory=dict)
    threshold: float = 0.0
    severity: Severity = Severity.medium
    filter_condition: Optional[str] = None
    enabled: bool = True


class Dataset(BaseModel):
    dataset_id: str
    target_catalog: str
    target_schema: str
    target_table: str
    owner_bu: str
    owner_email: str
    criticality: str = "tier2"
    freshness_sla_minutes: Optional[int] = None
    freshness_ts_column: Optional[str] = None
    primary_keys: list[str] = Field(default_factory=list)
    filter_condition: Optional[str] = None
    # scale controls (see sql/03_scale_optimizations.sql)
    enforcement_mode: str = "monitor"          # monitor | quarantine | block
    incremental: bool = False                  # scan only new data since watermark
    sample_fraction: Optional[float] = None    # TABLESAMPLE fraction for tier-3
    enable_monitor: bool = False               # create a Lakehouse Monitor

    @property
    def fq_table(self) -> str:
        return f"{self.target_catalog}.{self.target_schema}.{self.target_table}"


class RuleResult(BaseModel):
    run_id: str
    rule_id: str
    dataset_id: str
    fq_table: str
    dimension: Dimension
    rule_type: RuleType
    target_column: Optional[str] = None
    severity: Severity
    total_rows: Optional[int] = None
    failed_rows: Optional[int] = None
    violation_rate: Optional[float] = None
    threshold: float = 0.0
    passed: bool
    message: str = ""
    sample_bad_keys: list[str] = Field(default_factory=list)
    engine_version: str = ENGINE_VERSION
    job_run_id: Optional[str] = None


class RunSummary(BaseModel):
    run_id: str
    dataset_id: str
    fq_table: str
    overall_score: float
    rag_status: str
    total_rules: int
    passed_rules: int
    failed_rules: int
    critical_failures: int
    dimension_scores: dict[str, float] = Field(default_factory=dict)
    triggered_by: str = "agent"
    engine_version: str = ENGINE_VERSION


class CheckRequest(BaseModel):
    """What the agent tool sends to trigger a run."""
    dataset_id: str
    rule_ids: Optional[list[str]] = None      # None => all enabled rules
    triggered_by: str = "agent"
    dry_run: bool = False
