"""FastAPI service deployed to the Azure Container App.

Exposes the DQ tools as HTTP endpoints for Agent Studio to register as Tools, plus
health/readiness probes. Auth via a shared API key header (swap for Entra ID / mTLS in
your environment).
"""
from __future__ import annotations

from typing import Optional

from fastapi import Depends, FastAPI, Header, HTTPException
from pydantic import BaseModel

from ..config.settings import get_settings
from ..remediation.notifier import notify_teams, remediation_advice
from ..tools.tools import DQTools

app = FastAPI(title="Fiserv Data Quality Agent", version="1.0.0")
_tools: Optional[DQTools] = None


def tools() -> DQTools:
    global _tools
    if _tools is None:
        _tools = DQTools()
    return _tools


def require_key(x_api_key: str = Header(default="")) -> None:
    expected = get_settings().api_key
    if expected and x_api_key != expected:
        raise HTTPException(status_code=401, detail="invalid api key")


# ---- probes ---------------------------------------------------------------
@app.get("/healthz")
def healthz() -> dict:
    return {"status": "ok"}


@app.get("/readyz")
def readyz() -> dict:
    # cheap dependency check
    get_settings()
    return {"status": "ready"}


# ---- tool request models --------------------------------------------------
class RunChecksBody(BaseModel):
    dataset_id: str
    rule_ids: Optional[list[str]] = None
    triggered_by: str = "agent"
    wait: bool = True
    notify: bool = False


class ProposeRuleBody(BaseModel):
    dataset_id: str
    rule_name: str
    dimension: str
    rule_type: str
    target_column: Optional[str] = None
    params: dict = {}
    severity: str = "medium"
    threshold: float = 0.0


# ---- tool endpoints (register these in Agent Studio) ----------------------
@app.get("/tools/list_datasets", dependencies=[Depends(require_key)])
def list_datasets(owner_bu: Optional[str] = None) -> dict:
    return tools().list_datasets(owner_bu)


@app.get("/tools/profile_dataset", dependencies=[Depends(require_key)])
def profile_dataset(dataset_id: str) -> dict:
    return tools().profile_dataset(dataset_id)


@app.get("/tools/get_rules", dependencies=[Depends(require_key)])
def get_rules(dataset_id: str) -> dict:
    return tools().get_rules(dataset_id)


@app.post("/tools/run_checks", dependencies=[Depends(require_key)])
def run_checks(body: RunChecksBody) -> dict:
    result = tools().run_checks(body.dataset_id, body.rule_ids, body.triggered_by, body.wait)
    if body.notify and result.get("summary"):
        failures = tools().get_failures(body.dataset_id).get("failures", [])
        notify_teams(f"DQ result: {body.dataset_id}", result["summary"], failures)
    return result


@app.get("/tools/get_latest_summary", dependencies=[Depends(require_key)])
def get_latest_summary(dataset_id: str) -> dict:
    return tools().get_latest_summary(dataset_id)


@app.get("/tools/get_failures", dependencies=[Depends(require_key)])
def get_failures(dataset_id: str, run_id: Optional[str] = None) -> dict:
    out = tools().get_failures(dataset_id, run_id)
    out["remediation"] = remediation_advice(out.get("failures", []))
    return out


@app.post("/tools/propose_rule", dependencies=[Depends(require_key)])
def propose_rule(body: ProposeRuleBody) -> dict:
    return tools().propose_rule(
        body.dataset_id, body.rule_name, body.dimension, body.rule_type,
        body.target_column, body.params, body.severity, body.threshold,
    )
