"""Native Spark SQL Data Quality engine.

Runs *inside a Databricks Job* (see jobs/dq_check_job.py). It:
  1. loads the dataset + its enabled rules from the control tables,
  2. batches column-level checks into one aggregate scan per table,
  3. runs set/relationship checks (unique, referential, freshness, volume, custom) individually,
  4. writes per-rule results + a scored run summary back to Delta.

No pandas collect of raw rows — only aggregates and a tiny sample of offending PKs.
"""
from __future__ import annotations

import time
import uuid
from typing import Optional

from pyspark.sql import SparkSession

from .dimensions import PREDICATE_TYPES, violation_predicate
from .scoping import Scope, advance_watermark, build_scope
from .scoring import score_run
from .sql_safe import quote_fq_table, quote_ident, quote_literal, validate_expression
from ..models.schemas import (
    ENGINE_VERSION,
    Dataset,
    Rule,
    RuleResult,
    RuleType,
    RunSummary,
)

CONTROL = "governance.dq"
SAMPLE_KEYS = 20  # max offending PKs captured for triage


class DQEngine:
    def __init__(self, spark: SparkSession, control_schema: str = CONTROL):
        self.spark = spark
        self.control = control_schema

    # ------------------------------------------------------------------ public
    def run(
        self,
        dataset_id: str,
        rule_ids: Optional[list[str]] = None,
        triggered_by: str = "agent",
        job_run_id: Optional[str] = None,
    ) -> RunSummary:
        run_id = uuid.uuid4().hex
        started = time.time()
        dataset = self._load_dataset(dataset_id)
        rules = self._load_rules(dataset_id, rule_ids)
        scope = build_scope(self.spark, dataset, self.control)

        results: list[RuleResult] = []
        rows_scanned = 0
        error: Optional[str] = None
        try:
            predicate_rules = [r for r in rules if r.rule_type in PREDICATE_TYPES]
            other_rules = [r for r in rules if r.rule_type not in PREDICATE_TYPES]

            if predicate_rules:
                batch, rows_scanned = self._run_predicate_batch(
                    run_id, dataset, predicate_rules, scope, job_run_id)
                results.extend(batch)
            for rule in other_rules:
                results.append(self._run_single(run_id, dataset, rule, scope, job_run_id))

            summary = score_run(run_id, dataset, results, triggered_by)
            self._persist(results, summary)
            advance_watermark(self.spark, self.control, dataset, scope, run_id)
        except Exception as exc:  # noqa: BLE001
            error = str(exc)
            raise
        finally:
            self._log_execution(run_id, dataset_id, job_run_id, len(rules),
                                 rows_scanned, scope.mode, started, error)
        return summary

    # ---------------------------------------------------- batched column checks
    def _run_predicate_batch(
        self, run_id: str, ds: Dataset, rules: list[Rule], scope: Scope, job_run_id: Optional[str]
    ) -> tuple[list[RuleResult], int]:
        """One scan computes total + failed count for every predicate rule.

        Scan is scoped (full / incremental / sample) via `scope`. Returns (results, rows_scanned).
        """
        where = _combine_filters(ds.filter_condition, scope.predicate)

        selects = ["COUNT(*) AS __total"]
        valid_rules: list[Rule] = []
        errored: list[RuleResult] = []

        for r in rules:
            try:
                pred = violation_predicate(r)
                alias = f"f_{len(valid_rules)}"
                selects.append(f"SUM(CASE WHEN {pred} THEN 1 ELSE 0 END) AS {alias}")
                valid_rules.append(r)
            except ValueError as exc:
                errored.append(self._errored(run_id, ds, r, str(exc), job_run_id))

        sql = f"SELECT {', '.join(selects)} FROM {scope.source}{where}"
        row = self.spark.sql(sql).first()
        total = int(row["__total"])

        out: list[RuleResult] = list(errored)
        for i, r in enumerate(valid_rules):
            failed = int(row[f"f_{i}"] or 0)
            out.append(self._make_result(run_id, ds, r, total, failed, job_run_id))
        return out, total

    # ------------------------------------------------- individual complex checks
    def _run_single(
        self, run_id: str, ds: Dataset, rule: Rule, scope: Scope, job_run_id: Optional[str]
    ) -> RuleResult:
        try:
            if rule.rule_type == RuleType.unique:
                return self._check_unique(run_id, ds, rule, job_run_id)
            if rule.rule_type == RuleType.referential:
                return self._check_referential(run_id, ds, rule, job_run_id)
            if rule.rule_type == RuleType.freshness:
                return self._check_freshness(run_id, ds, rule, job_run_id)
            if rule.rule_type == RuleType.row_count_anomaly:
                return self._check_row_count(run_id, ds, rule, job_run_id)
            if rule.rule_type == RuleType.custom_sql:
                return self._check_custom_sql(run_id, ds, rule, job_run_id)
            raise ValueError(f"unsupported rule_type {rule.rule_type}")
        except Exception as exc:  # noqa: BLE001 - never let one rule kill the run
            return self._errored(run_id, ds, rule, str(exc), job_run_id)

    def _check_unique(self, run_id, ds: Dataset, rule: Rule, job_run_id) -> RuleResult:
        cols = [rule.target_column] if rule.target_column else ds.primary_keys
        if not cols:
            raise ValueError("unique rule needs target_column or dataset primary_keys")
        qcols = ", ".join(quote_ident(c) for c in cols)
        fq = quote_fq_table(ds.fq_table)
        where = _combine_filters(ds.filter_condition, rule.filter_condition)
        # failed_rows = rows that participate in a duplicate key group
        sql = f"""
            SELECT COALESCE(SUM(cnt), 0) AS total,
                   COALESCE(SUM(CASE WHEN cnt > 1 THEN cnt ELSE 0 END), 0) AS dup_rows
            FROM (SELECT {qcols}, COUNT(*) AS cnt FROM {fq}{where} GROUP BY {qcols})
        """
        row = self.spark.sql(sql).first()
        total, failed = int(row["total"]), int(row["dup_rows"])
        samples = self._sample_keys(
            f"SELECT {qcols} FROM {fq}{where} GROUP BY {qcols} HAVING COUNT(*) > 1 LIMIT {SAMPLE_KEYS}"
        )
        return self._make_result(run_id, ds, rule, total, failed, job_run_id, samples)

    def _check_referential(self, run_id, ds: Dataset, rule: Rule, job_run_id) -> RuleResult:
        col = rule.target_column
        ref_table = rule.params.get("ref_table")
        ref_col = rule.params.get("ref_column")
        if not (col and ref_table and ref_col):
            raise ValueError("referential rule needs target_column, params.ref_table, params.ref_column")
        c = quote_ident(col)
        fq = quote_fq_table(ds.fq_table)
        rt = quote_fq_table(ref_table)
        rc = quote_ident(ref_col)
        where = _combine_filters(ds.filter_condition, rule.filter_condition)
        sql = f"""
            SELECT
              (SELECT COUNT(*) FROM {fq}{where}) AS total,
              (SELECT COUNT(*) FROM {fq} src{where}
                 WHERE src.{c} IS NOT NULL
                   AND NOT EXISTS (SELECT 1 FROM {rt} ref WHERE ref.{rc} = src.{c})) AS orphans
        """
        row = self.spark.sql(sql).first()
        return self._make_result(run_id, ds, rule, int(row["total"]), int(row["orphans"]), job_run_id)

    def _check_freshness(self, run_id, ds: Dataset, rule: Rule, job_run_id) -> RuleResult:
        ts_col = rule.target_column or ds.freshness_ts_column
        sla = int(rule.params.get("sla_minutes") or ds.freshness_sla_minutes or 0)
        if not ts_col or not sla:
            raise ValueError("freshness rule needs a ts column and sla_minutes")
        tc = quote_ident(ts_col)
        fq = quote_fq_table(ds.fq_table)
        sql = f"""
            SELECT
              CAST((unix_timestamp(current_timestamp()) - unix_timestamp(MAX({tc}))) / 60 AS DOUBLE) AS age_min
            FROM {fq}
        """
        age = self.spark.sql(sql).first()["age_min"]
        age = float(age) if age is not None else float("inf")
        failed = 1 if age > sla else 0
        r = self._make_result(run_id, ds, rule, 1, failed, job_run_id)
        r.message = f"data age {age:.1f} min vs SLA {sla} min"
        return r

    def _check_row_count(self, run_id, ds: Dataset, rule: Rule, job_run_id) -> RuleResult:
        fq = quote_fq_table(ds.fq_table)
        lookback = int(rule.params.get("lookback_runs", "7"))
        max_drop = float(rule.params.get("max_pct_drop", "30"))
        max_spike = float(rule.params.get("max_pct_spike", "300"))
        current = int(self.spark.sql(f"SELECT COUNT(*) AS c FROM {fq}").first()["c"])

        hist = self.spark.sql(f"""
            SELECT AVG(total_rows) AS baseline FROM (
              SELECT total_rows FROM {self.control}.results
              WHERE rule_id = {quote_literal(rule.rule_id)} AND total_rows IS NOT NULL
              ORDER BY run_ts DESC LIMIT {lookback})
        """).first()["baseline"]

        if hist is None or hist == 0:
            r = self._make_result(run_id, ds, rule, current, 0, job_run_id)
            r.message = f"baseline warming up; current={current}"
            return r
        pct = (current - hist) / hist * 100.0
        failed = 1 if (pct < -max_drop or pct > max_spike) else 0
        r = self._make_result(run_id, ds, rule, current, failed, job_run_id)
        r.message = f"current={current}, baseline={hist:.0f}, delta={pct:+.1f}%"
        return r

    def _check_custom_sql(self, run_id, ds: Dataset, rule: Rule, job_run_id) -> RuleResult:
        """params.sql must SELECT COUNT(*) AS failed_rows [, COUNT-like total]. Screened for DDL/DML."""
        raw = rule.params.get("sql")
        if not raw:
            raise ValueError("custom_sql rule needs params.sql")
        validate_expression(raw)  # reuse the breakout screen
        # allow {table} templating so authors don't hardcode fq names
        rendered = raw.replace("{table}", quote_fq_table(ds.fq_table))
        row = self.spark.sql(rendered).first()
        failed = int(row["failed_rows"])
        total = int(row["total_rows"]) if "total_rows" in row.asDict() else None
        return self._make_result(run_id, ds, rule, total, failed, job_run_id)

    # ----------------------------------------------------------------- helpers
    def _make_result(
        self, run_id, ds: Dataset, rule: Rule, total, failed, job_run_id, samples=None
    ) -> RuleResult:
        rate = (failed / total) if total else 0.0
        passed = rate <= rule.threshold
        return RuleResult(
            run_id=run_id, rule_id=rule.rule_id, dataset_id=ds.dataset_id,
            fq_table=ds.fq_table, dimension=rule.dimension, rule_type=rule.rule_type,
            target_column=rule.target_column, severity=rule.severity,
            total_rows=total, failed_rows=failed, violation_rate=rate,
            threshold=rule.threshold, passed=passed,
            message=("OK" if passed else f"{failed}/{total} rows violate ({rate:.4%})"),
            sample_bad_keys=samples or [], job_run_id=job_run_id,
        )

    def _errored(self, run_id, ds: Dataset, rule: Rule, msg, job_run_id) -> RuleResult:
        return RuleResult(
            run_id=run_id, rule_id=rule.rule_id, dataset_id=ds.dataset_id,
            fq_table=ds.fq_table, dimension=rule.dimension, rule_type=rule.rule_type,
            target_column=rule.target_column, severity=rule.severity,
            passed=False, message=f"RULE ERROR: {msg}", job_run_id=job_run_id,
        )

    def _sample_keys(self, sql: str) -> list[str]:
        try:
            rows = self.spark.sql(sql).limit(SAMPLE_KEYS).collect()
            return ["|".join(str(v) for v in r) for r in rows]
        except Exception:  # noqa: BLE001 - sampling is best-effort
            return []

    # ------------------------------------------------------- control-table I/O
    def _load_dataset(self, dataset_id: str) -> Dataset:
        row = self.spark.sql(
            f"SELECT * FROM {self.control}.dataset_registry "
            f"WHERE dataset_id = {quote_literal(dataset_id)} AND active"
        ).first()
        if not row:
            raise ValueError(f"dataset not registered or inactive: {dataset_id}")
        d = row.asDict()
        return Dataset(**{k: d.get(k) for k in Dataset.model_fields}, )

    def _load_rules(self, dataset_id: str, rule_ids: Optional[list[str]]) -> list[Rule]:
        clause = f"dataset_id = {quote_literal(dataset_id)} AND enabled"
        if rule_ids:
            ids = ", ".join(quote_literal(r) for r in rule_ids)
            clause += f" AND rule_id IN ({ids})"
        rows = self.spark.sql(f"SELECT * FROM {self.control}.rule_catalog WHERE {clause}").collect()
        rules = []
        for row in rows:
            d = row.asDict()
            d["params"] = dict(d.get("params") or {})
            rules.append(Rule(**{k: d.get(k) for k in Rule.model_fields}))
        if not rules:
            raise ValueError(f"no enabled rules for dataset {dataset_id}")
        return rules

    def _persist(self, results: list[RuleResult], summary: RunSummary) -> None:
        res_rows = [r.model_dump() for r in results]
        self.spark.createDataFrame(res_rows).write.mode("append").saveAsTable(
            f"{self.control}.results"
        )
        self.spark.createDataFrame([summary.model_dump()]).write.mode("append").saveAsTable(
            f"{self.control}.run_summary"
        )

    def _log_execution(self, run_id, dataset_id, job_run_id, n_rules, rows_scanned,
                       scan_mode, started, error) -> None:
        """Append a platform-observability record (best-effort; never masks the real error)."""
        try:
            rec = {
                "run_id": run_id, "dataset_id": dataset_id, "job_run_id": job_run_id,
                "status": "FAILED" if error else "SUCCEEDED", "rules_evaluated": n_rules,
                "rows_scanned": int(rows_scanned), "scan_mode": scan_mode,
                "duration_ms": int((time.time() - started) * 1000), "error": error,
            }
            self.spark.createDataFrame([rec]).write.mode("append").saveAsTable(
                f"{self.control}.execution_log")
        except Exception:  # noqa: BLE001
            pass


def _combine_filters(*filters: Optional[str]) -> str:
    active = [f for f in filters if f]
    for f in active:
        validate_expression(f)
    return f" WHERE {' AND '.join(f'({f})' for f in active)}" if active else ""
