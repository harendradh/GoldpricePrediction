"""Lightweight profiler used to (a) show a dataset overview to the agent and
(b) power rule *suggestion*. Native Spark only; returns aggregates, never raw rows.
"""
from __future__ import annotations

from pyspark.sql import SparkSession

from .sql_safe import quote_fq_table, quote_ident


def profile_table(spark: SparkSession, fq_table: str, sample_columns: int = 50) -> dict:
    fq = quote_fq_table(fq_table)
    schema = spark.sql(f"DESCRIBE {fq}").collect()
    cols = [(r["col_name"], r["data_type"]) for r in schema if r["col_name"] and not r["col_name"].startswith("#")]
    cols = cols[:sample_columns]

    total = int(spark.sql(f"SELECT COUNT(*) c FROM {fq}").first()["c"])
    profile = {"fq_table": fq_table, "row_count": total, "columns": []}

    # one aggregate scan for null counts + distinct approx across all columns
    exprs = []
    for name, _ in cols:
        c = quote_ident(name)
        exprs.append(f"SUM(CASE WHEN {c} IS NULL THEN 1 ELSE 0 END) AS n_{_safe(name)}")
        exprs.append(f"approx_count_distinct({c}) AS d_{_safe(name)}")
    if exprs:
        row = spark.sql(f"SELECT {', '.join(exprs)} FROM {fq}").first().asDict()
        for name, dtype in cols:
            key = _safe(name)
            nulls = int(row.get(f"n_{key}") or 0)
            distinct = int(row.get(f"d_{key}") or 0)
            profile["columns"].append({
                "name": name,
                "data_type": dtype,
                "null_count": nulls,
                "null_pct": round(nulls / total * 100, 3) if total else 0.0,
                "approx_distinct": distinct,
                "is_candidate_key": total > 0 and distinct >= total * 0.99,
            })
    return profile


def _safe(name: str) -> str:
    return "".join(ch if ch.isalnum() else "_" for ch in name)
