"""SQL safety helpers.

Rules come from a Delta catalog that humans (and an LLM) can write to. Even though the
catalog is access-controlled, we defend in depth: identifiers are validated, literals are
escaped, and free-form expressions are screened for statement breakout / DDL / DML.

This is a guardrail, not a full SQL parser. Combine with:
  - Unity Catalog grants (rule authors can only touch their team's rules)
  - the engine running under a service principal with read-only data access
"""
from __future__ import annotations

import re

_IDENT_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")

# Tokens that must never appear inside a rule expression / custom predicate.
_FORBIDDEN = re.compile(
    r"(;|--|/\*|\*/|\b(drop|delete|update|insert|merge|alter|create|truncate|"
    r"grant|revoke|call|copy|refresh|vacuum|optimize|set|use)\b)",
    re.IGNORECASE,
)


def quote_ident(name: str) -> str:
    """Backtick-quote a single identifier (column). Rejects anything non-identifier."""
    if not name or not _IDENT_RE.match(name):
        raise ValueError(f"unsafe identifier: {name!r}")
    return f"`{name}`"


def quote_fq_table(fq: str) -> str:
    """Validate and backtick-quote a catalog.schema.table name."""
    parts = fq.split(".")
    if len(parts) != 3:
        raise ValueError(f"expected catalog.schema.table, got {fq!r}")
    return ".".join(quote_ident(p) for p in parts)


def quote_literal(value: str) -> str:
    """Escape a string literal. Numbers pass through unquoted."""
    if re.fullmatch(r"-?\d+(\.\d+)?", value):
        return value
    escaped = value.replace("'", "''")
    return f"'{escaped}'"


def validate_expression(expr: str) -> None:
    """Screen a free-form boolean expression used inside a WHERE/CASE.

    Raises ValueError if it looks like an attempt to break out of the expression
    context (statement terminators, comments, DDL/DML keywords).
    """
    if _FORBIDDEN.search(expr):
        raise ValueError(f"expression rejected by safety filter: {expr!r}")
    if expr.count("(") != expr.count(")"):
        raise ValueError(f"unbalanced parentheses in expression: {expr!r}")
