"""Native Databricks Lakehouse Monitoring integration.

Instead of hand-rolling distribution/drift/freshness math, we let Databricks Lakehouse
Monitoring do it. For each dataset with `enable_monitor = true` we create (once) and refresh
a monitor. Databricks maintains `<table>_profile_metrics` and `<table>_drift_metrics` tables
(null rates, distinct counts, quantiles, drift vs baseline/previous window, per time granule).

The DQ Agent reads those metric tables via the `dq_get_drift` tool — so drift/anomaly get the
full native treatment (seasonality windows, statistical drift tests) that a SQL rule can't match.

Requires: `databricks-sdk` on the cluster and Unity Catalog. Runs from the refresh job.
"""
from __future__ import annotations

from typing import Optional

try:
    from databricks.sdk import WorkspaceClient
    from databricks.sdk.service.catalog import (
        MonitorInfoStatus,
        MonitorMetric,
        MonitorTimeSeries,
        MonitorSnapshot,
    )
except Exception:  # pragma: no cover - only on cluster
    WorkspaceClient = None  # type: ignore

from .sql_safe import quote_literal


def ensure_monitor(spark, control_schema: str, dataset_row: dict,
                   output_schema: str, w: Optional["WorkspaceClient"] = None) -> dict:
    """Create the monitor if missing, else refresh it, then register its metric tables."""
    w = w or WorkspaceClient()
    fq = f"{dataset_row['target_catalog']}.{dataset_row['target_schema']}.{dataset_row['target_table']}"
    ts_col = dataset_row.get("freshness_ts_column")

    try:
        info = w.quality_monitors.get(table_name=fq)
    except Exception:
        # First time: TimeSeries profile if we have a timestamp col, else Snapshot.
        if ts_col:
            profile = MonitorTimeSeries(timestamp_col=ts_col, granularities=["1 day"])
            info = w.quality_monitors.create(
                table_name=fq, assets_dir=f"/Shared/dqa_monitors/{fq}",
                output_schema_name=output_schema, time_series=profile)
        else:
            info = w.quality_monitors.create(
                table_name=fq, assets_dir=f"/Shared/dqa_monitors/{fq}",
                output_schema_name=output_schema, snapshot=MonitorSnapshot())

    # Kick a refresh so metrics reflect the latest data.
    try:
        w.quality_monitors.run_refresh(table_name=fq)
    except Exception:
        pass

    profile_tbl = getattr(info, "profile_metrics_table_name", None)
    drift_tbl = getattr(info, "drift_metrics_table_name", None)
    status = str(getattr(info, "status", "UNKNOWN"))

    spark.sql(f"""
        MERGE INTO {control_schema}.monitor_registry t
        USING (SELECT {quote_literal(dataset_row['dataset_id'])} AS dataset_id) s
        ON t.dataset_id = s.dataset_id
        WHEN MATCHED THEN UPDATE SET fq_table={quote_literal(fq)},
             profile_metrics_table={quote_literal(profile_tbl or '')},
             drift_metrics_table={quote_literal(drift_tbl or '')},
             monitor_status={quote_literal(status)}, updated_ts=current_timestamp()
        WHEN NOT MATCHED THEN INSERT (dataset_id, fq_table, timestamp_col, profile_metrics_table,
             drift_metrics_table, monitor_status)
             VALUES ({quote_literal(dataset_row['dataset_id'])}, {quote_literal(fq)},
                     {quote_literal(ts_col or '')}, {quote_literal(profile_tbl or '')},
                     {quote_literal(drift_tbl or '')}, {quote_literal(status)})
    """)
    return {"dataset_id": dataset_row["dataset_id"], "fq_table": fq,
            "profile_metrics_table": profile_tbl, "drift_metrics_table": drift_tbl,
            "status": status}


def refresh_all(spark, control_schema: str, output_schema: str) -> list[dict]:
    rows = spark.sql(
        f"SELECT * FROM {control_schema}.dataset_registry WHERE active AND enable_monitor"
    ).collect()
    w = WorkspaceClient()
    out = []
    for r in rows:
        try:
            out.append(ensure_monitor(spark, control_schema, r.asDict(), output_schema, w))
        except Exception as exc:  # noqa: BLE001 - one monitor failing must not stop the rest
            out.append({"dataset_id": r["dataset_id"], "error": str(exc)})
    return out
