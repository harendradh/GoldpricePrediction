"""Scan scoping — how much of a (possibly huge) table each run actually reads.

Three modes, chosen per dataset in the registry:
  - full        : scan everything (default; correct for small/medium tables).
  - incremental : scan only rows newer than the last watermark (freshness_ts_column).
                  Correct for append-mostly tables (events, transactions). Set-level rules
                  (unique / referential) still run full — they need whole-table context.
  - sample      : TABLESAMPLE a fraction (tier-3 tables where approximate quality is enough).

Watermarks live in <control>.dataset_state so successive runs advance automatically.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from .sql_safe import quote_fq_table, quote_ident, quote_literal
from ..models.schemas import Dataset


@dataclass
class Scope:
    source: str                 # FROM-source (fq table, optionally TABLESAMPLE'd)
    predicate: Optional[str]    # extra WHERE for incremental scoping (None if full)
    mode: str                   # full | incremental | sample
    new_watermark_sql: Optional[str]  # SQL expr to read the new watermark after the run


def build_scope(spark, dataset: Dataset, control_schema: str) -> Scope:
    fq = quote_fq_table(dataset.fq_table)

    # sample mode (tier-3): approximate but cheap
    if dataset.sample_fraction and 0 < dataset.sample_fraction < 1:
        pct = dataset.sample_fraction * 100.0
        return Scope(source=f"{fq} TABLESAMPLE ({pct} PERCENT)", predicate=None,
                     mode="sample", new_watermark_sql=None)

    # incremental mode: only rows past the last watermark
    if dataset.incremental and dataset.freshness_ts_column:
        ts_col = quote_ident(dataset.freshness_ts_column)
        last = _last_watermark(spark, control_schema, dataset.dataset_id)
        predicate = f"{ts_col} > {quote_literal(last)}" if last else None
        return Scope(source=fq, predicate=predicate, mode="incremental",
                     new_watermark_sql=f"SELECT MAX({ts_col}) AS wm FROM {fq}")

    return Scope(source=fq, predicate=None, mode="full", new_watermark_sql=None)


def _last_watermark(spark, control_schema: str, dataset_id: str) -> Optional[str]:
    row = spark.sql(
        f"SELECT last_watermark_ts FROM {control_schema}.dataset_state "
        f"WHERE dataset_id = {quote_literal(dataset_id)}"
    ).first()
    if row and row["last_watermark_ts"] is not None:
        return str(row["last_watermark_ts"])
    return None


def advance_watermark(spark, control_schema: str, dataset: Dataset, scope: Scope, run_id: str) -> None:
    if scope.mode != "incremental" or not scope.new_watermark_sql:
        return
    wm = spark.sql(scope.new_watermark_sql).first()["wm"]
    if wm is None:
        return
    spark.sql(f"""
        MERGE INTO {control_schema}.dataset_state t
        USING (SELECT {quote_literal(dataset.dataset_id)} AS dataset_id) s
        ON t.dataset_id = s.dataset_id
        WHEN MATCHED THEN UPDATE SET last_watermark_ts = TIMESTAMP {quote_literal(str(wm))},
                                     last_run_id = {quote_literal(run_id)},
                                     updated_ts = current_timestamp()
        WHEN NOT MATCHED THEN INSERT (dataset_id, last_watermark_ts, last_run_id)
             VALUES ({quote_literal(dataset.dataset_id)}, TIMESTAMP {quote_literal(str(wm))},
                     {quote_literal(run_id)})
    """)
