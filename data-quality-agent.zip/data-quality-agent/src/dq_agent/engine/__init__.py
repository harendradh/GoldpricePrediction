"""Engine package.

`DQEngine` pulls in PySpark, which only exists on a Databricks cluster. It is imported
lazily so the pure-logic modules (dimensions, scoring, sql_safe) stay importable off-cluster
for unit tests and the agent API layer.
"""
from .scoring import score_run

__all__ = ["DQEngine", "score_run"]


def __getattr__(name: str):
    if name == "DQEngine":
        from .rule_engine import DQEngine
        return DQEngine
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
