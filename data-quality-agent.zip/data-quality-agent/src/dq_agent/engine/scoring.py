"""Scoring: turn per-rule results into a comparable 0-100 score + RAG status.

The score is a severity-weighted pass rate, so a critical failure hurts far more than a
low one. Dimension sub-scores let a BU see *where* quality is weak. RAG thresholds are
policy — tune in one place.
"""
from __future__ import annotations

from collections import defaultdict

from ..models.schemas import (
    ENGINE_VERSION,
    SEVERITY_WEIGHT,
    Dataset,
    RuleResult,
    RunSummary,
)

# RAG policy. A single critical failure forces RED regardless of score.
GREEN_MIN = 95.0
AMBER_MIN = 80.0


def score_run(
    run_id: str, dataset: Dataset, results: list[RuleResult], triggered_by: str
) -> RunSummary:
    total_weight = 0.0
    earned_weight = 0.0
    dim_weight: dict[str, float] = defaultdict(float)
    dim_earned: dict[str, float] = defaultdict(float)

    passed = failed = critical_failures = 0
    for r in results:
        w = SEVERITY_WEIGHT.get(r.severity.value, 1.0)
        total_weight += w
        dim_weight[r.dimension.value] += w
        if r.passed:
            passed += 1
            earned_weight += w
            dim_earned[r.dimension.value] += w
        else:
            failed += 1
            if r.severity.value == "critical":
                critical_failures += 1

    score = (earned_weight / total_weight * 100.0) if total_weight else 100.0
    dimension_scores = {
        dim: round(dim_earned[dim] / dim_weight[dim] * 100.0, 2)
        for dim in dim_weight
    }

    rag = _rag(score, critical_failures)

    return RunSummary(
        run_id=run_id,
        dataset_id=dataset.dataset_id,
        fq_table=dataset.fq_table,
        overall_score=round(score, 2),
        rag_status=rag,
        total_rules=len(results),
        passed_rules=passed,
        failed_rules=failed,
        critical_failures=critical_failures,
        dimension_scores=dimension_scores,
        triggered_by=triggered_by,
        engine_version=ENGINE_VERSION,
    )


def _rag(score: float, critical_failures: int) -> str:
    if critical_failures > 0:
        return "RED"
    if score >= GREEN_MIN:
        return "GREEN"
    if score >= AMBER_MIN:
        return "AMBER"
    return "RED"
