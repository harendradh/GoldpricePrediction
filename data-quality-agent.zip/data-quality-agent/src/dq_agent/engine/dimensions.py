"""Compiles a Rule into a Spark SQL *violation predicate* or a standalone check.

Design:
- Column-level rules (not_null, range, regex, accepted_values, expression) compile to a
  boolean SQL predicate that is TRUE when the row VIOLATES the rule. These are batched
  into a single aggregate scan per table for efficiency.
- Set/relationship rules (unique, referential, freshness, row_count_anomaly, custom_sql)
  need their own query and are handled by the engine directly.

Everything is native Spark SQL — no external DQ library.
"""
from __future__ import annotations

from .sql_safe import quote_ident, quote_literal, validate_expression
from ..models.schemas import Rule, RuleType

# Rule types that reduce to a per-row violation predicate.
PREDICATE_TYPES = {
    RuleType.not_null,
    RuleType.range,
    RuleType.regex,
    RuleType.accepted_values,
    RuleType.expression,
}


def violation_predicate(rule: Rule) -> str:
    """Return SQL that is TRUE when a row violates `rule`.

    Raises ValueError on malformed rule params (caught by the engine and recorded
    as an errored check rather than crashing the whole run).
    """
    col = quote_ident(rule.target_column) if rule.target_column else None
    p = rule.params

    if rule.rule_type == RuleType.not_null:
        _require(col, rule, "target_column")
        return f"{col} IS NULL"

    if rule.rule_type == RuleType.range:
        _require(col, rule, "target_column")
        parts = []
        if "min" in p:
            parts.append(f"{col} < {quote_literal(p['min'])}")
        if "max" in p:
            parts.append(f"{col} > {quote_literal(p['max'])}")
        if not parts:
            raise ValueError("range rule needs min and/or max")
        # violation if out of range (nulls are NOT counted here — use not_null for that)
        return f"({col} IS NOT NULL AND ({' OR '.join(parts)}))"

    if rule.rule_type == RuleType.regex:
        _require(col, rule, "target_column")
        pattern = p.get("pattern")
        if not pattern:
            raise ValueError("regex rule needs params.pattern")
        return f"({col} IS NOT NULL AND {col} NOT RLIKE {quote_literal(pattern)})"

    if rule.rule_type == RuleType.accepted_values:
        _require(col, rule, "target_column")
        raw = p.get("values")
        if not raw:
            raise ValueError("accepted_values rule needs params.values (comma-separated)")
        values = [quote_literal(v.strip()) for v in raw.split(",") if v.strip()]
        in_list = ", ".join(values)
        return f"({col} IS NOT NULL AND {col} NOT IN ({in_list}))"

    if rule.rule_type == RuleType.expression:
        expr = p.get("expr")
        if not expr:
            raise ValueError("expression rule needs params.expr (must be TRUE for valid rows)")
        validate_expression(expr)          # blocks DML/DDL/statement breakout
        # violation when the assertion is not true (NULL treated as violation-safe: use COALESCE)
        return f"NOT ({expr})"

    raise ValueError(f"{rule.rule_type} is not a predicate rule")


def _require(value, rule: Rule, field: str) -> None:
    if not value:
        raise ValueError(f"rule {rule.rule_id} ({rule.rule_type}) requires {field}")
