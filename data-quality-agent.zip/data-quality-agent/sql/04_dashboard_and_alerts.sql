-- =====================================================================
-- Serving layer: queries for the AI/BI dashboard + Databricks SQL Alerts.
-- Native Databricks — no external BI tool needed.
-- =====================================================================

-- ---- Dashboard datasets (build an AI/BI dashboard on these) ----------

-- Enterprise scorecard by BU (tile: table / bar)
-- SELECT * FROM governance.dq.v_bu_scorecard ORDER BY avg_score;

-- Score trend over time (tile: line)
CREATE OR REPLACE VIEW governance.dq.v_score_trend AS
SELECT dataset_id, date_trunc('day', run_ts) AS day,
       AVG(overall_score) AS score, MAX(critical_failures) AS critical_failures
FROM governance.dq.run_summary
GROUP BY dataset_id, date_trunc('day', run_ts);

-- Top failing rules right now (tile: table)
CREATE OR REPLACE VIEW governance.dq.v_top_failures AS
SELECT r.dataset_id, r.dimension, r.rule_type, r.target_column, r.severity,
       r.failed_rows, r.total_rows, r.violation_rate, r.message
FROM governance.dq.results r
JOIN governance.dq.run_summary s
  ON r.run_id = s.run_id AND r.dataset_id = s.dataset_id
JOIN (SELECT dataset_id, MAX(run_ts) mx FROM governance.dq.run_summary GROUP BY dataset_id) l
  ON s.dataset_id = l.dataset_id AND s.run_ts = l.mx
WHERE r.passed = false
ORDER BY CASE r.severity WHEN 'critical' THEN 0 WHEN 'high' THEN 1
                         WHEN 'medium' THEN 2 ELSE 3 END, r.violation_rate DESC;

-- Platform health: sweep durations + failures (tile: table)
CREATE OR REPLACE VIEW governance.dq.v_platform_health AS
SELECT dataset_id, status, scan_mode, rows_scanned, duration_ms, error, run_ts
FROM governance.dq.execution_log
WHERE run_ts > current_timestamp() - INTERVAL 7 DAYS;

-- ---- Alert queries (attach a Databricks SQL Alert to each) -----------

-- ALERT 1: any RED / critical dataset in the latest run -> notify owners/Teams/ServiceNow
CREATE OR REPLACE VIEW governance.dq.alert_red_datasets AS
SELECT s.dataset_id, s.fq_table, r.owner_bu, r.owner_email,
       s.overall_score, s.critical_failures
FROM governance.dq.v_latest_scorecard s
JOIN governance.dq.dataset_registry r ON s.dataset_id = r.dataset_id
WHERE s.rag_status = 'RED';
-- Alert condition: row count > 0.

-- ALERT 2: freshness SLA breaches (from the freshness rule results)
CREATE OR REPLACE VIEW governance.dq.alert_freshness_breach AS
SELECT dataset_id, fq_table, target_column, message, run_ts
FROM governance.dq.results
WHERE rule_type = 'freshness' AND passed = false
  AND run_ts > current_timestamp() - INTERVAL 1 DAY;

-- ALERT 3: sweep task failures (platform reliability)
CREATE OR REPLACE VIEW governance.dq.alert_sweep_failures AS
SELECT dataset_id, error, run_ts FROM governance.dq.execution_log
WHERE status = 'FAILED' AND run_ts > current_timestamp() - INTERVAL 1 DAY;
