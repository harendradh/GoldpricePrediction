-- =====================================================================
-- Serving layer: queries for the AI/BI dashboard + Databricks SQL Alerts.
-- Everything here reads the unified views (sql/03) — nothing new to maintain.
-- =====================================================================

-- ---- Team scorecard (tile: table / bar) --------------------------------
CREATE OR REPLACE VIEW governance.dq.v_team_scorecard AS
SELECT dr.owner_team, dr.criticality,
       COUNT(DISTINCT s.dataset_id)                                   AS datasets,
       ROUND(AVG(s.overall_score), 1)                                 AS avg_score,
       SUM(CASE WHEN s.rag_status='RED'   THEN 1 ELSE 0 END)          AS red,
       SUM(CASE WHEN s.rag_status='AMBER' THEN 1 ELSE 0 END)          AS amber,
       SUM(CASE WHEN s.rag_status='GREEN' THEN 1 ELSE 0 END)          AS green
FROM governance.dq.v_latest_scorecard s
JOIN governance.dq.dataset_registry dr
  ON s.domain = dr.domain AND (s.sub_domain <=> dr.sub_domain)
GROUP BY dr.owner_team, dr.criticality;

-- ---- Score trend over time (tile: line) --------------------------------
CREATE OR REPLACE VIEW governance.dq.v_score_trend AS
SELECT dataset_id, date_trunc('day', run_ts) AS day,
       AVG(overall_score) AS score, MAX(has_critical_failure) AS critical_failures
FROM governance.dq.v_run_summary
GROUP BY dataset_id, date_trunc('day', run_ts);

-- ---- Top failing rules right now (tile: table) -------------------------
CREATE OR REPLACE VIEW governance.dq.v_top_failures AS
SELECT s.dataset_id, s.rule_name, r.severity, r.description,
       s.failed_row_count, s.input_count,
       ROUND(s.failed_row_count / NULLIF(s.input_count, 0), 4) AS violation_rate
FROM governance.dq.v_stats_unified s
LEFT JOIN governance.dq.v_rules_unified r
  ON s.rule_name = r.rule_name AND s.domain = r.domain AND (s.sub_domain <=> r.sub_domain)
WHERE s.result_level = 'row' AND s.failed_row_count > 0
ORDER BY CASE r.severity WHEN 'critical' THEN 0 WHEN 'high' THEN 1
                         WHEN 'medium' THEN 2 ELSE 3 END, violation_rate DESC;

-- ---- ALERT 1: any RED dataset in the latest run -------------------------
CREATE OR REPLACE VIEW governance.dq.alert_red_datasets AS
SELECT s.dataset_id, dr.owner_team, dr.owner_email, s.overall_score, s.has_critical_failure
FROM governance.dq.v_latest_scorecard s
JOIN governance.dq.dataset_registry dr
  ON s.domain = dr.domain AND (s.sub_domain <=> dr.sub_domain)
WHERE s.rag_status = 'RED';
-- Alert condition: row count > 0.

-- ---- ALERT 2: sweep/job failures (platform reliability) ------------------
-- Reads directly from dq_stats' own job_run_id/task_name — no separate audit
-- table needed, the Ingestion team's own job telemetry already carries this.
CREATE OR REPLACE VIEW governance.dq.alert_stats_gaps AS
SELECT domain, sub_domain, MAX(loaded_ts) AS last_seen
FROM governance.dq.v_stats_unified
GROUP BY domain, sub_domain
HAVING MAX(loaded_ts) < current_timestamp() - INTERVAL 1 DAY;
-- Fires when a domain that normally reports stats hasn't written any in 24h —
-- catches an upstream pipeline going silent, not just a rule failing.
