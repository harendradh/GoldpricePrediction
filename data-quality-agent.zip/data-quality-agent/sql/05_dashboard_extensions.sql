-- =====================================================================
-- Extends 04_dashboard_and_alerts.sql with two more dashboard tiles.
-- Note: there's no invented "dimension" taxonomy here — dq_rules doesn't have
-- one, so grouping uses what's actually there: rule_type and severity
-- (severity itself derived from action_if_failed, see sql/03).
-- =====================================================================

-- ---- Pass rate by rule_type, across every rule outcome -----------------
CREATE OR REPLACE VIEW governance.dq.v_rule_type_breakdown AS
SELECT r.rule_type,
       COUNT(*)                                                        AS outcomes,
       ROUND(100.0 * SUM(CASE WHEN s.failed_row_count IS NULL OR s.failed_row_count = 0
                               THEN 1 ELSE 0 END) / COUNT(*), 1)        AS pass_rate
FROM governance.dq.v_stats_unified s
JOIN governance.dq.v_rules_unified r
  ON s.rule_name = r.rule_name AND s.domain = r.domain AND (s.sub_domain <=> r.sub_domain)
WHERE s.result_level = 'row'
GROUP BY r.rule_type;

-- ---- RAG distribution across the latest run of every dataset -----------
CREATE OR REPLACE VIEW governance.dq.v_rag_distribution AS
SELECT rag_status, COUNT(*) AS datasets
FROM governance.dq.v_latest_scorecard
GROUP BY rag_status;
