-- =====================================================================
-- Data Quality Agent :: Control Tables (Delta / Unity Catalog)
-- The metadata backbone. Everything the agent does is driven by these.
-- Run on a Databricks SQL Warehouse. Adjust <catalog> to your UC catalog.
-- =====================================================================

CREATE CATALOG IF NOT EXISTS governance;
CREATE SCHEMA IF NOT EXISTS governance.dq
  COMMENT 'Data Quality Agent control + results tables';

-- ---------------------------------------------------------------------
-- 1. Dataset registry — a team onboards a dataset by inserting a row.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS governance.dq.dataset_registry (
  dataset_id            STRING    NOT NULL COMMENT 'Stable id, e.g. payments.txn_master',
  target_catalog        STRING    NOT NULL,
  target_schema         STRING    NOT NULL,
  target_table          STRING    NOT NULL,
  owner_bu              STRING    NOT NULL COMMENT 'Business unit that owns this dataset',
  owner_email           STRING    NOT NULL,
  criticality           STRING    NOT NULL COMMENT 'tier1 | tier2 | tier3',
  freshness_sla_minutes INT                COMMENT 'Max allowed staleness; NULL = no SLA',
  freshness_ts_column   STRING             COMMENT 'Column used for freshness (load ts)',
  primary_keys          ARRAY<STRING>      COMMENT 'PK columns for uniqueness/integrity',
  filter_condition      STRING             COMMENT 'Optional global WHERE for scoping',
  active                BOOLEAN   NOT NULL DEFAULT true,
  created_ts            TIMESTAMP NOT NULL DEFAULT current_timestamp(),
  updated_ts            TIMESTAMP NOT NULL DEFAULT current_timestamp(),
  CONSTRAINT pk_dataset_registry PRIMARY KEY (dataset_id)
) USING DELTA
TBLPROPERTIES (delta.enableChangeDataFeed = true);

-- ---------------------------------------------------------------------
-- 2. Rule catalog — every check the engine can run. Rules are DATA.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS governance.dq.rule_catalog (
  rule_id          STRING    NOT NULL,
  rule_name        STRING    NOT NULL,
  dataset_id       STRING    NOT NULL COMMENT 'FK -> dataset_registry.dataset_id',
  dimension        STRING    NOT NULL COMMENT 'completeness|uniqueness|validity|accuracy|'
                                            || 'consistency|integrity|timeliness|volume|schema',
  rule_type        STRING    NOT NULL COMMENT 'not_null|unique|range|regex|accepted_values|'
                                            || 'expression|referential|freshness|row_count_anomaly|custom_sql',
  target_column    STRING             COMMENT 'Column under test; NULL for table-level rules',
  params           MAP<STRING,STRING> COMMENT 'Rule params: min,max,pattern,values,ref_table,ref_column,sql,...',
  threshold        DOUBLE    NOT NULL DEFAULT 0.0 COMMENT 'Fail if violation_rate > threshold (0..1)',
  severity         STRING    NOT NULL DEFAULT 'medium' COMMENT 'critical|high|medium|low',
  filter_condition STRING             COMMENT 'Optional per-rule WHERE',
  enabled          BOOLEAN   NOT NULL DEFAULT true,
  owner_bu         STRING,
  created_ts       TIMESTAMP NOT NULL DEFAULT current_timestamp(),
  CONSTRAINT pk_rule_catalog PRIMARY KEY (rule_id)
) USING DELTA
TBLPROPERTIES (delta.enableChangeDataFeed = true);

-- ---------------------------------------------------------------------
-- 3. Results — one row per rule per run (written by the engine).
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS governance.dq.results (
  run_id           STRING    NOT NULL,
  rule_id          STRING    NOT NULL,
  dataset_id       STRING    NOT NULL,
  fq_table         STRING    NOT NULL COMMENT 'catalog.schema.table',
  dimension        STRING    NOT NULL,
  rule_type        STRING    NOT NULL,
  target_column    STRING,
  severity         STRING    NOT NULL,
  total_rows       BIGINT,
  failed_rows      BIGINT,
  violation_rate   DOUBLE,
  threshold        DOUBLE,
  passed           BOOLEAN   NOT NULL,
  message          STRING,
  sample_bad_keys  ARRAY<STRING> COMMENT 'Up to N offending PKs for triage (no raw PII)',
  engine_version   STRING,
  job_run_id       STRING,
  run_ts           TIMESTAMP NOT NULL DEFAULT current_timestamp()
) USING DELTA
PARTITIONED BY (dataset_id)
TBLPROPERTIES (delta.enableChangeDataFeed = true);

-- ---------------------------------------------------------------------
-- 4. Run summary — per dataset per run: score + RAG + dimension rollup.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS governance.dq.run_summary (
  run_id           STRING    NOT NULL,
  dataset_id       STRING    NOT NULL,
  fq_table         STRING    NOT NULL,
  overall_score    DOUBLE    NOT NULL COMMENT '0..100 weighted by severity + dimension',
  rag_status       STRING    NOT NULL COMMENT 'GREEN|AMBER|RED',
  total_rules      INT       NOT NULL,
  passed_rules     INT       NOT NULL,
  failed_rules     INT       NOT NULL,
  critical_failures INT      NOT NULL,
  dimension_scores MAP<STRING,DOUBLE>,
  triggered_by     STRING,
  engine_version   STRING,
  run_ts           TIMESTAMP NOT NULL DEFAULT current_timestamp(),
  CONSTRAINT pk_run_summary PRIMARY KEY (run_id, dataset_id)
) USING DELTA
PARTITIONED BY (dataset_id)
TBLPROPERTIES (delta.enableChangeDataFeed = true);

-- Convenience view: latest score per dataset (feeds exec dashboard).
CREATE OR REPLACE VIEW governance.dq.v_latest_scorecard AS
SELECT s.*
FROM governance.dq.run_summary s
JOIN (
  SELECT dataset_id, MAX(run_ts) AS max_ts
  FROM governance.dq.run_summary
  GROUP BY dataset_id
) l ON s.dataset_id = l.dataset_id AND s.run_ts = l.max_ts;
