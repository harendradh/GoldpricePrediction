-- =====================================================================
-- Data Quality Agent :: Control Tables — SIMPLIFIED DESIGN
--
-- Principle: don't copy anyone's data quality results into a new schema.
-- The Ingestion team already runs checks and writes results to:
--   prod_dcs_catalog.df_app_configs.dq_rules   (their rule definitions)
--   prod_dcs_catalog.df_app_configs.dq_stats   (their check results, per job run)
--   prod_dcs_catalog.data_profile.dp_*_status  (their column profiling, one table/pipeline)
-- Other teams (e.g. Data Panel) have their own equivalents in their own shape.
--
-- This system reads all of them through UNION ALL views (sql/03) built from the
-- registry below — it never copies rows, never runs a sync job, never goes stale.
-- Only TWO lightweight tables exist here:
--   1. source_registry   — which tables to union, and how to map their columns
--   2. dataset_registry  — the one thing genuinely missing upstream: who owns a
--                          dataset, how critical it is, its freshness SLA
--
-- This system has NO rule-proposal/staging mechanism. It never writes into any team's
-- own rule table — full stop. A new or changed rule is a conversation with the owning
-- team, not something this agent stages or tracks.
--
-- NOTE ON KEYS: Delta Lake does not enforce PRIMARY KEY / FOREIGN KEY constraints —
-- none are declared here. Uniqueness comes from write discipline (MERGE, not INSERT).
-- =====================================================================

CREATE CATALOG IF NOT EXISTS governance;
CREATE SCHEMA IF NOT EXISTS governance.dq
  COMMENT 'Data Quality Agent: source registry + thin views over each team''s own DQ tables';

-- ---------------------------------------------------------------------
-- 1. Source registry — one row per team table to fold into a unified view.
--    Adding a new team/table = one MERGE here, by the platform team (sql/02 is the worked
--    example), then re-run jobs/dq_view_refresh.py. No CDF, no sync state, no watermark —
--    views read the source table live.
--
--    This is a MANUAL, platform-team-only action by design — not something the agent can
--    do. A column_mapping value becomes SQL text embedded directly into a CREATE VIEW
--    statement run by the service principal, so it gets the same review a schema change
--    would, not a self-service form. `enabled` is the on/off switch: stage a row with
--    `enabled = false` while reviewing, flip it to `true` (and re-run dq_view_refresh) once
--    it's ready to go live.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS governance.dq.source_registry (
  source_id      STRING    NOT NULL COMMENT 'Stable id, e.g. ingestion_dq_rules',
  owner_team     STRING    NOT NULL,
  source_type    STRING    NOT NULL COMMENT 'rules | stats | profile  (profile tables named dp_*_status in data_profile are auto-discovered and do NOT need a row here — register profile explicitly only when a table does not follow that naming convention)',
  fq_table       STRING    NOT NULL COMMENT 'catalog.schema.table of the team''s OWN table — never copied',
  column_mapping MAP<STRING,STRING> NOT NULL COMMENT 'unified_column -> source SQL expression, see sql/02 for the worked example',
  enabled        BOOLEAN   NOT NULL DEFAULT true COMMENT 'false = staged but not yet live in the unified views',
  created_ts     TIMESTAMP NOT NULL DEFAULT current_timestamp(),
  updated_ts     TIMESTAMP NOT NULL DEFAULT current_timestamp()
) USING DELTA;

-- ---------------------------------------------------------------------
-- 2. Dataset registry — ownership/criticality/SLA. The one thing dq_rules and
--    dq_stats don't already carry. Keyed the same way dq_rules groups rules:
--    (domain, sub_domain) — NOT a new dataset-naming scheme.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS governance.dq.dataset_registry (
  domain                STRING    NOT NULL,
  sub_domain            STRING,
  owner_team            STRING    NOT NULL,
  owner_email           STRING    NOT NULL,
  criticality           STRING    NOT NULL DEFAULT 'tier2' COMMENT 'tier1 | tier2 | tier3',
  freshness_sla_minutes INT,
  active                BOOLEAN   NOT NULL DEFAULT true,
  created_ts            TIMESTAMP NOT NULL DEFAULT current_timestamp(),
  updated_ts            TIMESTAMP NOT NULL DEFAULT current_timestamp()
) USING DELTA;
