-- =====================================================================
-- Unity Catalog Functions — the governed, reusable "skill" layer.
--
-- Every read-only tool's logic lives here ONCE, not duplicated across Python
-- Function files. Benefits over hand-building SQL in each tool:
--   - Governed centrally: UC grants control who can call fn_get_summary, same
--     as any other UC object — not "whatever's pasted into this one agent."
--   - Reusable by anyone: a SQL analyst, a notebook, or a DIFFERENT agent can
--     run `SELECT * FROM governance.dq.fn_get_summary('TELETRACK')` directly —
--     not locked inside this Agent Studio tool's Python.
--   - One place to fix a bug or add a domain, not eight.
--   - Every tool in agent_studio/tools/ is a plain Python Function that calls these
--     functions over SQL — no other Agent Studio tool type is required or assumed.
-- =====================================================================

CREATE OR REPLACE FUNCTION governance.dq.fn_list_datasets(p_owner_team STRING DEFAULT NULL)
RETURNS TABLE (domain STRING, sub_domain STRING, owner_team STRING, criticality STRING,
               freshness_sla_minutes INT)
COMMENT 'Registered domains, optionally filtered by owning team.'
RETURN
  SELECT domain, sub_domain, owner_team, criticality, freshness_sla_minutes
  FROM governance.dq.dataset_registry
  WHERE active AND (p_owner_team IS NULL OR owner_team = p_owner_team)
  ORDER BY criticality, domain;

CREATE OR REPLACE FUNCTION governance.dq.fn_get_rules(p_domain STRING, p_sub_domain STRING DEFAULT NULL)
RETURNS TABLE (rule_id STRING, rule_name STRING, description STRING, rule_type STRING,
               condition STRING, action_if_failed STRING, severity STRING, is_active BOOLEAN,
               owner_team STRING, source_table STRING)
COMMENT 'A domain''s rules, from v_rules_unified — every registered team''s own table, live.'
RETURN
  SELECT rule_id, rule_name, description, rule_type, condition, action_if_failed, severity,
         is_active, owner_team, source_table
  FROM governance.dq.v_rules_unified
  WHERE domain = p_domain AND (p_sub_domain IS NULL OR sub_domain = p_sub_domain)
  ORDER BY is_active DESC, severity, rule_name;

CREATE OR REPLACE FUNCTION governance.dq.fn_get_summary(p_domain STRING, p_sub_domain STRING DEFAULT NULL)
RETURNS TABLE (domain STRING, sub_domain STRING, job_run_id STRING, input_count BIGINT,
               rules_checked BIGINT, rules_failed BIGINT, has_critical_failure INT,
               run_ts TIMESTAMP, overall_score DOUBLE, rag_status STRING)
COMMENT 'Latest DQ scorecard for a domain, straight from v_latest_scorecard — no job triggered.'
RETURN
  SELECT domain, sub_domain, job_run_id, input_count, rules_checked, rules_failed,
         has_critical_failure, run_ts, overall_score, rag_status
  FROM governance.dq.v_latest_scorecard
  WHERE domain = p_domain AND (p_sub_domain IS NULL OR sub_domain = p_sub_domain);

CREATE OR REPLACE FUNCTION governance.dq.fn_get_failures(p_domain STRING, p_sub_domain STRING DEFAULT NULL)
RETURNS TABLE (rule_name STRING, severity STRING, description STRING, action_if_failed STRING,
               failed_row_count BIGINT, input_count BIGINT, violation_rate DOUBLE, job_run_id STRING)
COMMENT 'Failing rules from the most recent job run for a domain, with severity + description.'
RETURN
  SELECT s.rule_name, r.severity, r.description, r.action_if_failed, s.failed_row_count,
         s.input_count, ROUND(s.failed_row_count / NULLIF(s.input_count, 0), 4) AS violation_rate,
         s.job_run_id
  FROM governance.dq.v_stats_unified s
  LEFT JOIN governance.dq.v_rules_unified r
    ON s.rule_name = r.rule_name AND s.domain = r.domain AND (s.sub_domain <=> r.sub_domain)
  WHERE s.domain = p_domain AND (p_sub_domain IS NULL OR s.sub_domain = p_sub_domain)
    AND s.result_level = 'row' AND s.failed_row_count > 0
    AND s.job_run_id = (
      SELECT job_run_id FROM governance.dq.v_stats_unified
      WHERE domain = p_domain AND (p_sub_domain IS NULL OR sub_domain = p_sub_domain)
      ORDER BY loaded_ts DESC LIMIT 1)
  ORDER BY CASE r.severity WHEN 'critical' THEN 0 WHEN 'high' THEN 1
                          WHEN 'medium' THEN 2 ELSE 3 END;

CREATE OR REPLACE FUNCTION governance.dq.fn_profile_dataset(p_domain STRING, p_sub_domain STRING DEFAULT NULL)
RETURNS TABLE (pipeline_name STRING, column_name STRING, failed_metrics STRING,
               metric_values STRING, status STRING, formatted_date STRING, loaddt STRING)
COMMENT 'Column profiling for a domain, from v_profile_unified (the existing profiler output).'
RETURN
  SELECT pipeline_name, column_name, failed_metrics, metric_values, status, formatted_date, loaddt
  FROM governance.dq.v_profile_unified
  WHERE domain = p_domain AND (p_sub_domain IS NULL OR sub_domain = p_sub_domain)
  ORDER BY formatted_date DESC LIMIT 100;

CREATE OR REPLACE FUNCTION governance.dq.fn_team_scorecard(p_owner_team STRING DEFAULT NULL)
RETURNS TABLE (owner_team STRING, criticality STRING, datasets BIGINT, avg_score DOUBLE,
               red BIGINT, amber BIGINT, green BIGINT)
COMMENT 'Per-team rollup — what the dashboard''s Score by Team tile and dq_scorecard_genie both read.'
RETURN
  SELECT owner_team, criticality, datasets, avg_score, red, amber, green
  FROM governance.dq.v_team_scorecard
  WHERE p_owner_team IS NULL OR owner_team = p_owner_team;

CREATE OR REPLACE FUNCTION governance.dq.fn_get_freshness(p_domain STRING, p_sub_domain STRING DEFAULT NULL)
RETURNS TABLE (domain STRING, sub_domain STRING, owner_team STRING, criticality STRING,
               freshness_sla_minutes INT, last_seen_ts TIMESTAMP, minutes_since_last_run BIGINT,
               is_stale BOOLEAN)
COMMENT 'Is a domain''s pipeline still reporting on schedule, from v_freshness_status (sql/07).'
RETURN
  SELECT domain, sub_domain, owner_team, criticality, freshness_sla_minutes, last_seen_ts,
         minutes_since_last_run, is_stale
  FROM governance.dq.v_freshness_status
  WHERE domain = p_domain AND (p_sub_domain IS NULL OR sub_domain = p_sub_domain);

CREATE OR REPLACE FUNCTION governance.dq.fn_get_volume_trend(p_domain STRING, p_sub_domain STRING DEFAULT NULL,
                                                              p_days INT DEFAULT 7)
RETURNS TABLE (domain STRING, sub_domain STRING, day DATE, input_count BIGINT, error_count BIGINT,
               output_count BIGINT, run_count BIGINT)
COMMENT 'Daily volume (input/error/output row counts) for a domain, last p_days -- from v_volume_trend (sql/07).'
RETURN
  SELECT domain, sub_domain, day, input_count, error_count, output_count, run_count
  FROM governance.dq.v_volume_trend
  WHERE domain = p_domain AND (p_sub_domain IS NULL OR sub_domain = p_sub_domain)
    AND day >= date_sub(current_date(), p_days)
  ORDER BY day DESC;

CREATE OR REPLACE FUNCTION governance.dq.fn_get_rule_outcomes(p_domain STRING, p_sub_domain STRING DEFAULT NULL)
RETURNS TABLE (rule_name STRING, rule_type STRING, severity STRING, description STRING,
               action_if_failed STRING, status STRING, failed_row_count BIGINT)
COMMENT 'Every active rule for a domain with PASS/FAIL/NOT_RUN for the latest run, not just failures -- from v_rule_outcomes_latest (sql/07).'
RETURN
  SELECT rule_name, rule_type, severity, description, action_if_failed, status, failed_row_count
  FROM governance.dq.v_rule_outcomes_latest
  WHERE domain = p_domain AND (p_sub_domain IS NULL OR sub_domain = p_sub_domain)
  ORDER BY CASE status WHEN 'FAIL' THEN 0 WHEN 'NOT_RUN' THEN 1 ELSE 2 END,
           CASE severity WHEN 'critical' THEN 0 WHEN 'high' THEN 1 WHEN 'medium' THEN 2 ELSE 3 END;

-- Grant example (adjust group/principal names to your workspace):
--   GRANT EXECUTE ON FUNCTION governance.dq.fn_get_summary TO `dq-agent-readers`;
-- Repeat per function, or GRANT EXECUTE ON SCHEMA governance.dq TO `dq-agent-readers`
-- once all functions here are stable — same governance model as any other UC object.
