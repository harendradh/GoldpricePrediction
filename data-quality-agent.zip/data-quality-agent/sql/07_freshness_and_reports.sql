-- =====================================================================
-- Freshness, volume, and full-rule-outcome views — closes 2 real gaps:
--   1. Nothing surfaced dataset/date-level FRESHNESS or VOLUME as a queryable
--      metric — only a binary 24h-silence alert existed (sql/04's alert_stats_gaps).
--   2. Nothing returned a domain's FULL rule outcome list (pass AND fail) — only
--      the failures (fn_get_failures) or the rule definitions with no outcome
--      (fn_get_rules) existed. dq_get_full_report (agent_studio/tools/) needs both.
--
-- All three views read v_rules_unified / v_stats_unified / dataset_registry —
-- nothing new to register, no new source tables.
-- =====================================================================

-- ---------------------------------------------------------------------
-- v_freshness_status — is a domain's pipeline still reporting on schedule?
-- Only as accurate as v_stats_unified.loaded_ts — see sql/03's comment on
-- v_stats_unified for the known gap (loaded_ts defaults to query-time unless a
-- real column is mapped via source_registry.column_mapping's 'loaded_ts' key).
-- ---------------------------------------------------------------------
CREATE OR REPLACE VIEW governance.dq.v_freshness_status AS
WITH last_seen AS (
  SELECT domain, sub_domain, MAX(loaded_ts) AS last_seen_ts
  FROM governance.dq.v_stats_unified
  GROUP BY domain, sub_domain
)
SELECT
  dr.domain, dr.sub_domain, dr.owner_team, dr.criticality, dr.freshness_sla_minutes,
  ls.last_seen_ts,
  CAST((unix_timestamp(current_timestamp()) - unix_timestamp(ls.last_seen_ts)) / 60 AS BIGINT)
    AS minutes_since_last_run,
  CASE
    WHEN ls.last_seen_ts IS NULL THEN true   -- never reported at all -> stale
    WHEN dr.freshness_sla_minutes IS NULL THEN false   -- no SLA configured -> can't judge
    WHEN (unix_timestamp(current_timestamp()) - unix_timestamp(ls.last_seen_ts)) / 60
         > dr.freshness_sla_minutes THEN true
    ELSE false
  END AS is_stale
FROM governance.dq.dataset_registry dr
LEFT JOIN last_seen ls ON dr.domain = ls.domain AND (dr.sub_domain <=> ls.sub_domain)
WHERE dr.active;

-- ---------------------------------------------------------------------
-- v_volume_trend — daily input/error/output counts per domain, deduped per
-- job_run_id first (input_count etc. repeat once per exploded rule row within
-- a run — summing raw v_stats_unified rows would massively over-count).
-- ---------------------------------------------------------------------
CREATE OR REPLACE VIEW governance.dq.v_volume_trend AS
WITH per_run AS (
  SELECT domain, sub_domain, job_run_id,
         date_trunc('day', MAX(loaded_ts)) AS day,
         MAX(input_count)  AS input_count,
         MAX(error_count)  AS error_count,
         MAX(output_count) AS output_count
  FROM governance.dq.v_stats_unified
  WHERE result_level = 'row'
  GROUP BY domain, sub_domain, job_run_id
)
SELECT domain, sub_domain, day,
       SUM(input_count)  AS input_count,
       SUM(error_count)  AS error_count,
       SUM(output_count) AS output_count,
       COUNT(*)          AS run_count
FROM per_run
GROUP BY domain, sub_domain, day;

-- ---------------------------------------------------------------------
-- v_rule_outcomes_latest — every ACTIVE rule for a domain, with PASS / FAIL /
-- NOT_RUN for the most recent run. NOT_RUN (not PASS) for a rule with no
-- matching stats row — it wasn't checked, which is a different fact than
-- "checked and passed" and dq_get_full_report should be able to say so.
-- ---------------------------------------------------------------------
CREATE OR REPLACE VIEW governance.dq.v_rule_outcomes_latest AS
WITH latest_run AS (
  SELECT domain, sub_domain, max_by(job_run_id, loaded_ts) AS job_run_id
  FROM governance.dq.v_stats_unified
  WHERE result_level = 'row'
  GROUP BY domain, sub_domain
),
outcomes AS (
  SELECT s.domain, s.sub_domain, s.rule_name, MAX(s.failed_row_count) AS failed_row_count
  FROM governance.dq.v_stats_unified s
  JOIN latest_run lr
    ON s.domain = lr.domain AND (s.sub_domain <=> lr.sub_domain) AND s.job_run_id = lr.job_run_id
  WHERE s.result_level = 'row'
  GROUP BY s.domain, s.sub_domain, s.rule_name
)
SELECT
  r.domain, r.sub_domain, r.rule_name, r.rule_type, r.severity, r.description, r.action_if_failed,
  COALESCE(o.failed_row_count, 0) AS failed_row_count,
  CASE
    WHEN o.rule_name IS NULL THEN 'NOT_RUN'
    WHEN o.failed_row_count > 0 THEN 'FAIL'
    ELSE 'PASS'
  END AS status
FROM governance.dq.v_rules_unified r
LEFT JOIN outcomes o
  ON r.domain = o.domain AND (r.sub_domain <=> o.sub_domain) AND r.rule_name = o.rule_name
WHERE r.is_active;
