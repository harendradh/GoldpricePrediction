-- =====================================================================
-- v2 scale optimizations. Run AFTER 01_control_tables.sql.
-- Adds: enforcement modes, incremental scanning state, execution audit,
-- Lakehouse Monitoring registry, liquid clustering, retention, predictive optimization.
-- =====================================================================

-- ---- enforcement + scale knobs on the registry ----------------------
ALTER TABLE governance.dq.dataset_registry
  ADD COLUMNS (
    enforcement_mode STRING    COMMENT 'monitor | quarantine | block (DLT)'      ,
    incremental      BOOLEAN   COMMENT 'scan only new data since last watermark'  ,
    sample_fraction  DOUBLE    COMMENT 'TABLESAMPLE fraction for tier-3 (NULL=full)',
    enable_monitor   BOOLEAN   COMMENT 'create a Lakehouse Monitor for drift/freshness'
  );
UPDATE governance.dq.dataset_registry
  SET enforcement_mode = COALESCE(enforcement_mode,'monitor'),
      incremental      = COALESCE(incremental,false),
      enable_monitor   = COALESCE(enable_monitor,false);

-- ---- per-dataset incremental state (watermark) ----------------------
CREATE TABLE IF NOT EXISTS governance.dq.dataset_state (
  dataset_id        STRING    NOT NULL,
  last_watermark_ts TIMESTAMP COMMENT 'max freshness_ts_column processed last run',
  last_delta_version BIGINT   COMMENT 'Delta table version last processed (CDF path)',
  last_run_id       STRING,
  updated_ts        TIMESTAMP NOT NULL DEFAULT current_timestamp(),
  CONSTRAINT pk_dataset_state PRIMARY KEY (dataset_id)
) USING DELTA;

-- ---- platform execution audit (observability of DQA itself) ---------
CREATE TABLE IF NOT EXISTS governance.dq.execution_log (
  run_id          STRING,
  dataset_id      STRING,
  job_run_id      STRING,
  status          STRING    COMMENT 'SUCCEEDED | FAILED | SKIPPED',
  rules_evaluated INT,
  rows_scanned    BIGINT,
  scan_mode       STRING    COMMENT 'full | incremental | sample',
  duration_ms     BIGINT,
  error           STRING,
  run_ts          TIMESTAMP NOT NULL DEFAULT current_timestamp()
) USING DELTA
PARTITIONED BY (dataset_id);

-- ---- Lakehouse Monitoring registry (native drift/freshness) ---------
CREATE TABLE IF NOT EXISTS governance.dq.monitor_registry (
  dataset_id        STRING NOT NULL,
  fq_table          STRING NOT NULL,
  profile_type      STRING COMMENT 'TimeSeries | Snapshot',
  timestamp_col     STRING,
  granularities     STRING COMMENT 'e.g. 1 day',
  profile_metrics_table STRING,
  drift_metrics_table   STRING,
  monitor_status    STRING,
  updated_ts        TIMESTAMP NOT NULL DEFAULT current_timestamp(),
  CONSTRAINT pk_monitor_registry PRIMARY KEY (dataset_id)
) USING DELTA;

-- ---- scale-out storage: liquid clustering + auto optimize ----------
ALTER TABLE governance.dq.results        CLUSTER BY (dataset_id, run_ts);
ALTER TABLE governance.dq.run_summary    CLUSTER BY (dataset_id, run_ts);
ALTER TABLE governance.dq.results
  SET TBLPROPERTIES (delta.autoOptimize.optimizeWrite = true,
                     delta.autoOptimize.autoCompact = true);
-- Enable Predictive Optimization at the schema level (UC) so Databricks auto-runs
-- OPTIMIZE/VACUUM. Requires the feature enabled for the metastore.
ALTER SCHEMA governance.dq ENABLE PREDICTIVE OPTIMIZATION;

-- ---- retention: keep raw results 400 days, summary indefinitely -----
-- (run on a schedule; example one-off)
-- DELETE FROM governance.dq.results WHERE run_ts < current_timestamp() - INTERVAL 400 DAYS;

-- ---- enterprise scorecard view (feeds AI/BI dashboard) --------------
CREATE OR REPLACE VIEW governance.dq.v_bu_scorecard AS
SELECT r.owner_bu, r.criticality,
       COUNT(*) AS datasets,
       ROUND(AVG(s.overall_score), 1) AS avg_score,
       SUM(CASE WHEN s.rag_status='RED'   THEN 1 ELSE 0 END) AS red,
       SUM(CASE WHEN s.rag_status='AMBER' THEN 1 ELSE 0 END) AS amber,
       SUM(CASE WHEN s.rag_status='GREEN' THEN 1 ELSE 0 END) AS green,
       SUM(s.critical_failures) AS critical_failures
FROM governance.dq.v_latest_scorecard s
JOIN governance.dq.dataset_registry r ON s.dataset_id = r.dataset_id
GROUP BY r.owner_bu, r.criticality;
