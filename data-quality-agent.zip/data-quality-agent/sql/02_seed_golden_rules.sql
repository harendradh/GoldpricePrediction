-- =====================================================================
-- Registration examples — the ONLY setup step for onboarding a team.
-- Real tables, real columns, from the Ingestion team's actual production
-- tables (not a hypothetical). Copy this pattern for the next team (e.g.
-- Data Panel) once you have their table + column names.
-- =====================================================================

-- ---------------------------------------------------------------------
-- Register the Ingestion team's rule table (prod_dcs_catalog.df_app_configs.dq_rules).
-- column_mapping values are SQL expressions evaluated against that table's own
-- columns — jobs/dq_view_refresh.py uses these to build v_rules_unified (sql/03).
-- ---------------------------------------------------------------------
MERGE INTO governance.dq.source_registry t
USING (SELECT 'ingestion_dq_rules' AS source_id) s
ON t.source_id = s.source_id
WHEN NOT MATCHED THEN INSERT (
  source_id, owner_team, source_type, fq_table, column_mapping, enabled
) VALUES (
  'ingestion_dq_rules', 'Ingestion', 'rules',
  'prod_dcs_catalog.df_app_configs.dq_rules',
  map(
    'rule_id',          'CAST(rule_id AS STRING)',
    'domain',           'domain',
    'sub_domain',       'sub_domain',
    'product_id',       'product_id',
    'rule_name',        'rule',
    'description',      'description',
    'rule_type',        'rule_type',
    'condition',        'condition',
    'action_if_failed', 'action_if_failed',
    'is_active',        'is_active',
    'created_at',       'created_at',
    'updated_at',       'updated_at'
  ),
  true
);

-- ---------------------------------------------------------------------
-- Register the Ingestion team's stats table (prod_dcs_catalog.df_app_configs.dq_stats).
-- row_dq_results / agg_dq_results are array<map<string,string>> — jobs/dq_view_refresh.py
-- explodes them; column_mapping here covers the columns OUTSIDE those arrays.
-- ---------------------------------------------------------------------
MERGE INTO governance.dq.source_registry t
USING (SELECT 'ingestion_dq_stats' AS source_id) s
ON t.source_id = s.source_id
WHEN NOT MATCHED THEN INSERT (
  source_id, owner_team, source_type, fq_table, column_mapping, enabled
) VALUES (
  'ingestion_dq_stats', 'Ingestion', 'stats',
  'prod_dcs_catalog.df_app_configs.dq_stats',
  map(
    'domain',           'domain',
    'sub_domain',       'sub_domain',
    'product_id',       'product_id',
    'job_run_id',       'job_run_id',
    'task_name',        'task_name',
    'dataset_id',       'coalesce(dataset_name, dataset)',
    'input_count',      'input_count',
    'error_count',      'error_count',
    'output_count',     'output_count'
  ),
  true
);

-- ---------------------------------------------------------------------
-- Dataset registry — ownership/criticality/SLA for the domains already visible
-- in dq_rules today. This is the only genuinely new metadata in this system.
-- ---------------------------------------------------------------------
MERGE INTO governance.dq.dataset_registry t
USING (SELECT 'TELETRACK' AS domain, 'TELETRACK' AS sub_domain) s
ON t.domain = s.domain AND t.sub_domain <=> s.sub_domain
WHEN NOT MATCHED THEN INSERT (domain, sub_domain, owner_team, owner_email, criticality, freshness_sla_minutes)
VALUES ('TELETRACK', 'TELETRACK', 'Ingestion', 'ingestion-data@fiserv.com', 'tier1', 60);

MERGE INTO governance.dq.dataset_registry t
USING (SELECT 'corebanking_tran_ct' AS domain, 'corebanking_tran_ct' AS sub_domain) s
ON t.domain = s.domain AND t.sub_domain <=> s.sub_domain
WHEN NOT MATCHED THEN INSERT (domain, sub_domain, owner_team, owner_email, criticality, freshness_sla_minutes)
VALUES ('corebanking_tran_ct', 'corebanking_tran_ct', 'Ingestion', 'ingestion-data@fiserv.com', 'tier1', 30);

MERGE INTO governance.dq.dataset_registry t
USING (SELECT 'zeta' AS domain, 'zeta' AS sub_domain) s
ON t.domain = s.domain AND t.sub_domain <=> s.sub_domain
WHEN NOT MATCHED THEN INSERT (domain, sub_domain, owner_team, owner_email, criticality, freshness_sla_minutes)
VALUES ('zeta', 'zeta', 'Ingestion', 'ingestion-data@fiserv.com', 'tier2', 240);

-- ---------------------------------------------------------------------
-- TEMPLATE for the next team — Data Panel has NOT been onboarded yet, this is what that
-- MERGE will look like once they share their actual table/column names. Left commented out
-- so running this file doesn't try to build a view against a table that doesn't exist.
-- The point: Data Panel's columns are named completely differently (chk_nm vs rule, chk_typ
-- vs rule_type, biz_domain vs domain, ...) — column_mapping is exactly the layer that
-- absorbs that difference. See docs/MULTI_TEAM_INTEGRATION.md for the full walkthrough.
--
-- MERGE INTO governance.dq.source_registry t
-- USING (SELECT 'datapanel_chk_rules' AS source_id) s
-- ON t.source_id = s.source_id
-- WHEN NOT MATCHED THEN INSERT (
--   source_id, owner_team, source_type, fq_table, column_mapping, enabled
-- ) VALUES (
--   'datapanel_chk_rules', 'DataPanel', 'rules',
--   'prod_dcs_catalog.data_panel.chk_rules',        -- Data Panel's own table, own catalog
--   map(
--     'rule_id',          'CAST(chk_id AS STRING)',   -- their PK is chk_id, not rule_id
--     'domain',           'biz_domain',                -- their grouping column is biz_domain
--     'sub_domain',       'biz_subdomain',
--     'rule_name',        'chk_nm',                    -- their rule-name column is chk_nm
--     'description',      'chk_desc',
--     'rule_type',        'chk_typ',                   -- their rule-type column is chk_typ
--     'condition',        'chk_expr',
--     'action_if_failed', "CASE WHEN severity = 'H' THEN 'BLOCK' ELSE 'WARN' END",  -- their
--                                                       -- severity is a single-letter code,
--                                                       -- translated to the shape v_rules_
--                                                       -- unified expects, right here
--     'is_active',        'active_flag'
--   ),
--   true
-- );
--
-- Then repeat the pattern for their stats/results table, and re-run jobs/dq_view_refresh.py.
-- Nothing else in this file, or anywhere else in the repo, needs to change.
--
-- If Data Panel's profiler table ALSO doesn't follow the dp_<pipeline>_status naming
-- convention (so auto-discovery would never find it — see sql/03/jobs/dq_view_refresh.py),
-- register it too, the same way:
--
-- MERGE INTO governance.dq.source_registry t
-- USING (SELECT 'datapanel_profile_ingestion' AS source_id) s
-- ON t.source_id = s.source_id
-- WHEN NOT MATCHED THEN INSERT (
--   source_id, owner_team, source_type, fq_table, column_mapping, enabled
-- ) VALUES (
--   'datapanel_profile_ingestion', 'DataPanel', 'profile',
--   'prod_dcs_catalog.data_panel.DQ_profile_ingestion',  -- doesn't match dp_*_status
--   map(
--     'domain',          'biz_domain',
--     'sub_domain',       'biz_subdomain',
--     'pipeline_name',    'pipeline',
--     'column_name',      'col_nm',
--     'failed_metrics',   'bad_metrics',
--     'metric_values',    'metric_vals',
--     'status',           'chk_status',
--     'formatted_date',   'dt',
--     'year',             'yr',
--     'month',            'mo',
--     'day_of_month',     'dom',
--     'loaddt',           'load_ts'
--   ),
--   true
-- );
