-- =====================================================================
-- Golden rules + example onboarding.
-- "Golden rules" = a baseline set every tier-1 dataset gets on day one.
-- Copy this pattern for each BU dataset (or generate via the Rule-Gen tool).
-- =====================================================================

-- Example: onboard a payments transaction table -----------------------
MERGE INTO governance.dq.dataset_registry t
USING (SELECT 'payments.txn_master' AS dataset_id) s
ON t.dataset_id = s.dataset_id
WHEN NOT MATCHED THEN INSERT (
  dataset_id, target_catalog, target_schema, target_table,
  owner_bu, owner_email, criticality,
  freshness_sla_minutes, freshness_ts_column, primary_keys
) VALUES (
  'payments.txn_master', 'prod', 'payments', 'txn_master',
  'Payments', 'payments-data@fiserv.com', 'tier1',
  60, 'load_ts', array('txn_id')
);

-- Golden rules for that dataset ---------------------------------------
INSERT INTO governance.dq.rule_catalog
  (rule_id, rule_name, dataset_id, dimension, rule_type, target_column, params, threshold, severity)
VALUES
  ('payments.txn_master::pk_not_null',
   'txn_id not null', 'payments.txn_master', 'completeness', 'not_null', 'txn_id',
   map(), 0.0, 'critical'),

  ('payments.txn_master::pk_unique',
   'txn_id unique', 'payments.txn_master', 'uniqueness', 'unique', 'txn_id',
   map(), 0.0, 'critical'),

  ('payments.txn_master::amount_range',
   'amount within bounds', 'payments.txn_master', 'validity', 'range', 'amount',
   map('min','0','max','1000000'), 0.001, 'high'),

  ('payments.txn_master::status_domain',
   'status in accepted set', 'payments.txn_master', 'validity', 'accepted_values', 'status',
   map('values','PENDING,SETTLED,FAILED,REVERSED'), 0.0, 'high'),

  ('payments.txn_master::currency_regex',
   'currency ISO-4217', 'payments.txn_master', 'validity', 'regex', 'currency',
   map('pattern','^[A-Z]{3}$'), 0.0, 'medium'),

  ('payments.txn_master::settle_after_create',
   'settle_ts >= create_ts', 'payments.txn_master', 'consistency', 'expression', NULL,
   map('expr','settle_ts IS NULL OR settle_ts >= create_ts'), 0.0, 'high'),

  ('payments.txn_master::account_fk',
   'account_id exists in accounts', 'payments.txn_master', 'integrity', 'referential', 'account_id',
   map('ref_table','prod.accounts.account_master','ref_column','account_id'), 0.0, 'critical'),

  ('payments.txn_master::freshness',
   'loaded within SLA', 'payments.txn_master', 'timeliness', 'freshness', 'load_ts',
   map('sla_minutes','60'), 0.0, 'high'),

  ('payments.txn_master::volume',
   'row count not anomalous', 'payments.txn_master', 'volume', 'row_count_anomaly', NULL,
   map('lookback_runs','7','max_pct_drop','30','max_pct_spike','300'), 0.0, 'medium');
