"""Inline enforcement via DLT / Lakeflow Declarative Pipelines expectations.

This is the third execution tier (write-time enforcement) from ARCHITECTURE.md. Unlike the
batch engine (which *observes* quality after the fact), expectations *enforce* it as data
flows, and route bad rows to a quarantine table — bad data never reaches the clean table.

Rules are still driven by the SAME `rule_catalog`, so there is ONE source of truth. Here we
compile the catalog's column-level rules into DLT expectations. Set a dataset's
`enforcement_mode` to 'quarantine' or 'block' to opt it into this pipeline.

Deploy as a DLT pipeline (serverless). Parameterize `dataset_id` via pipeline config.
"""
import dlt  # type: ignore
from pyspark.sql import SparkSession

from dq_agent.engine.dimensions import PREDICATE_TYPES, violation_predicate
from dq_agent.models.schemas import Rule, RuleType

spark = SparkSession.builder.getOrCreate()
CONTROL = spark.conf.get("dqa.control_schema", "governance.dq")
DATASET_ID = spark.conf.get("dqa.dataset_id")


def _load_expectations(dataset_id: str) -> dict[str, str]:
    """Compile column-level catalog rules into {name: valid_expression} for DLT.

    DLT expects a predicate that is TRUE for VALID rows, so we negate the engine's
    violation predicate. Only per-row rules apply inline (unique/referential/freshness
    remain in the batch engine + Lakehouse Monitoring).
    """
    rows = spark.sql(
        f"SELECT * FROM {CONTROL}.rule_catalog "
        f"WHERE dataset_id = '{dataset_id}' AND enabled "
        f"AND rule_type IN ('not_null','range','regex','accepted_values','expression')"
    ).collect()
    expectations = {}
    for row in rows:
        d = row.asDict()
        d["params"] = dict(d.get("params") or {})
        rule = Rule(**{k: d.get(k) for k in Rule.model_fields})
        if rule.rule_type in PREDICATE_TYPES:
            valid = f"NOT ({violation_predicate(rule)})"
            expectations[rule.rule_id] = valid
    return expectations


def _source_table(dataset_id: str) -> str:
    r = spark.sql(
        f"SELECT target_catalog, target_schema, target_table "
        f"FROM {CONTROL}.dataset_registry WHERE dataset_id = '{dataset_id}'"
    ).first()
    return f"{r['target_catalog']}.{r['target_schema']}.{r['target_table']}"


_EXPECTATIONS = _load_expectations(DATASET_ID)
_SOURCE = _source_table(DATASET_ID)
_CLEAN = f"{DATASET_ID.replace('.', '_')}_validated"
_QUARANTINE = f"{DATASET_ID.replace('.', '_')}_quarantine"


@dlt.table(name=_CLEAN, comment=f"Rows from {_SOURCE} passing all enabled DQ expectations")
@dlt.expect_all_or_drop(_EXPECTATIONS)   # drop violators from the clean table
def validated():
    return spark.readStream.table(_SOURCE)


@dlt.table(name=_QUARANTINE, comment=f"Rows from {_SOURCE} that FAILED a DQ expectation")
def quarantine():
    df = spark.readStream.table(_SOURCE)
    if not _EXPECTATIONS:
        return df.filter("1=0")
    fail_any = " OR ".join(f"NOT ({expr})" for expr in _EXPECTATIONS.values())
    return df.filter(fail_any)
