# Data Quality Agent (DQA)

A chat agent that reports on data quality **teams already check** — it reads existing
rule/results/profiling tables (Ingestion's `dq_rules`/`dq_stats`, any other team's
equivalent) through 3 thin views. **It copies nothing and runs nothing new** for the common
case; see **[`docs/UNIFIED_VIEWS.md`](docs/UNIFIED_VIEWS.md)** for the whole design in one
page — read that first.

> **Integration path:** Agent Studio is already deployed on Azure Container Apps. You build
> the agent **in the Agent Studio UI** — 7 Tools as **Python Functions** (5 are thin wrappers
> over governed **Unity Catalog Functions** — see below) + 1 native **Databricks Genie** tool,
> 2 RAG collections, 1 Agent. A native **Lakeview dashboard** covers the enterprise/cross-team
> view.
> **Start with [`docs/SETUP_GUIDE.md`](docs/SETUP_GUIDE.md)**, or
> [`agent_studio/BUILD_GUIDE.md`](agent_studio/BUILD_GUIDE.md) for the Agent Studio steps alone.

---

## What it does

1. **Reads** a team's own rule table + results table through a unified view — no copy.
2. **Scores** each domain (pass rate + severity derived from `action_if_failed`) live, from
   whatever the owning pipeline already wrote.
3. **Explains** failures in business terms, most-severe-first.
4. **Surfaces** everything in chat and on one shared dashboard, filtered by team.

There is no rule-proposal or staging tool — the agent never writes into, or tracks changes
for, another team's own table. A new-rule idea is advisory conversation only.

Onboarding a new team's table is a manual, platform-team step (2 `MERGE` statements) — not
something the agent does. See "Design principles" below for why.

## Architecture

```
User ──► Agent Studio (DQ Agent) ──► Databricks: 3 unified views over each team's own tables
                                       (dq_rules, dq_stats, dp_*_status — read-only)
```

Full diagram: `docs/UNIFIED_VIEWS.md`. The agent never reads a raw source row — only
rule/results/profiling metadata the owning team's pipeline already computed.

## Components

| Path | Purpose |
|------|---------|
| `sql/01_control_tables.sql` | `source_registry`, `dataset_registry` — 2 small tables, nothing else |
| `sql/02_seed_golden_rules.sql` | Registers the Ingestion team's real tables (the worked example) |
| `sql/03_scale_optimizations.sql` | The 3 unified views + derived scorecard views |
| `sql/04`, `sql/05` | Dashboard-serving views + SQL alerts |
| `sql/06_uc_functions.sql` | Unity Catalog Functions — the governed layer every read-only tool calls |
| `agent_studio/tools/` | The 10 Python Function tools pasted into Agent Studio |
| `agent_studio/rag/` | `DQ Knowledge` (static policy doc) |
| `jobs/dq_view_refresh.py` | The one required job — rebuilds the unified views + RAG reference |
| `jobs/dq_check_job.py` etc. | OPTIONAL fallback engine, not deployed by default — see file headers |
| `deploy/databricks.job.yml` | Asset Bundle: `dq_view_refresh` + the Lakeview dashboard, `dev`/`staging`/`prod` targets |
| `.github/workflows/` | CI (lint/test/validate) + CD (promote with approval gate) |
| `tests/` | Unit tests for the (optional) engine + scoring |

## Quick start

```bash
# 1. Control tables + unified views + dashboard views (Databricks SQL Warehouse)
databricks sql -f sql/01_control_tables.sql
databricks sql -f sql/02_seed_golden_rules.sql
databricks sql -f sql/03_scale_optimizations.sql
databricks sql -f sql/04_dashboard_and_alerts.sql
databricks sql -f sql/05_dashboard_extensions.sql
databricks sql -f sql/06_uc_functions.sql

# 2. Deploy the view-refresh job + Lakeview dashboard
cd deploy && databricks bundle deploy --var="warehouse_id=<your warehouse id>"

# 3. Build the 11 tools (10 Python Function + 1 Genie) + 2 RAG collections + Agent in Agent
#    Studio — no separate service to run
```

Full walkthrough: **[`docs/SETUP_GUIDE.md`](docs/SETUP_GUIDE.md)**.
Onboarding a second team: **[`docs/MULTI_TEAM_INTEGRATION.md`](docs/MULTI_TEAM_INTEGRATION.md)**.
Day-2 operations: **[`docs/RUNBOOK.md`](docs/RUNBOOK.md)**.
Every table/view/tool/RAG collection with example data, traced end to end:
**[`docs/END_TO_END_EXAMPLE.md`](docs/END_TO_END_EXAMPLE.md)** (same content, with visuals:
**[`docs/presentations/DQ_Agent_End_to_End_Example.docx`](docs/presentations/DQ_Agent_End_to_End_Example.docx)**).
Scheduled email digest, leveraging Agent Studio's native Workflow schedule:
**[`agent_studio/agents/workflow_scheduled_digest.md`](agent_studio/agents/workflow_scheduled_digest.md)**.

## Design principles

- **Read, don't reinvent**: leverage the rule/results/profiling tables teams already have.
- **Nothing copied**: every view reads a team's own table live — no second copy to secure.
- **Never write into another team's table, no exceptions**: no rule-proposal or staging
  tool exists; a new-rule idea is a conversation with the owning team, not a tracked request.
- **Views, not sync jobs**: onboarding a team is a config row, not a CDF pipeline.
- **Governed once, reused everywhere**: tool logic lives in Unity Catalog Functions, not
  duplicated per Python file — callable by any authorized caller, not just this one agent.
- **Onboarding is manual, on purpose**: registering a team's table changes a *shared* view
  every team reads — the platform team does it with a reviewed `MERGE`, the same way a schema
  change would be reviewed, not through a chat command the agent executes unsupervised.
- **Compute stays in Databricks**: the agent orchestrates, never processes rows.
