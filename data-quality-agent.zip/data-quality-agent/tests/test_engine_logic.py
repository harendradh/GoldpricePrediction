"""Unit tests for the OPTIONAL fallback engine's pure logic (predicate compilation, safety,
scoring, scan scoping) — see jobs/dq_check_job.py's header. The primary path (unified views
over each team's own dq_rules/dq_stats, docs/UNIFIED_VIEWS.md) has no Python engine to test;
its scoring is a SQL view (sql/03_scale_optimizations.sql v_run_summary).
These run without Spark/Databricks (the parts most likely to hide bugs)."""
import pytest

from dq_agent.engine.dimensions import violation_predicate
from dq_agent.engine.scoping import build_scope
from dq_agent.engine.scoring import score_run
from dq_agent.engine.sql_safe import quote_ident, validate_expression
from dq_agent.models.schemas import (
    Dataset, Dimension, Rule, RuleResult, RuleType, Severity,
)


class _FakeRow(dict):
    def __getitem__(self, k):
        return dict.get(self, k)


class _FakeSpark:
    """Minimal spark stub: returns a preset watermark row for the state query."""
    def __init__(self, watermark=None):
        self._wm = watermark

    def sql(self, q):
        wm = self._wm
        class _R:
            def first(self_inner):
                return _FakeRow(last_watermark_ts=wm)
        return _R()


def _rule(rt, col=None, params=None, sev="medium", thr=0.0, dim=Dimension.validity):
    return Rule(rule_id="r", rule_name="r", dataset_id="d", dimension=dim,
               rule_type=rt, target_column=col, params=params or {},
               severity=Severity(sev), threshold=thr)


# ---- predicate compilation ------------------------------------------------
def test_not_null_predicate():
    assert violation_predicate(_rule(RuleType.not_null, "amount")) == "`amount` IS NULL"


def test_range_predicate():
    p = violation_predicate(_rule(RuleType.range, "amount", {"min": "0", "max": "100"}))
    assert "`amount` < 0" in p and "`amount` > 100" in p


def test_accepted_values_predicate():
    p = violation_predicate(_rule(RuleType.accepted_values, "status", {"values": "A,B,C"}))
    assert "NOT IN ('A', 'B', 'C')" in p


def test_expression_rejects_injection():
    with pytest.raises(ValueError):
        violation_predicate(_rule(RuleType.expression, params={"expr": "1=1); DROP TABLE x;--"}))


def test_regex_requires_pattern():
    with pytest.raises(ValueError):
        violation_predicate(_rule(RuleType.regex, "currency", {}))


# ---- sql safety -----------------------------------------------------------
def test_quote_ident_blocks_bad_names():
    with pytest.raises(ValueError):
        quote_ident("col; DROP TABLE t")


def test_validate_expression_blocks_ddl():
    with pytest.raises(ValueError):
        validate_expression("x = 1 OR delete from t")
    validate_expression("settle_ts >= create_ts")  # ok


# ---- scoring --------------------------------------------------------------
def _ds():
    return Dataset(dataset_id="d", target_catalog="c", target_schema="s",
                   target_table="t", owner_team="Card Payments", owner_email="x@y.com")


def _res(passed, sev="medium", dim=Dimension.validity):
    return RuleResult(run_id="run", rule_id="r", dataset_id="d", fq_table="c.s.t",
                      dimension=dim, rule_type=RuleType.not_null, severity=Severity(sev),
                      total_rows=100, failed_rows=0 if passed else 10,
                      violation_rate=0.0 if passed else 0.1, passed=passed)


def test_all_pass_is_green_100():
    s = score_run("run", _ds(), [_res(True), _res(True, "high")], "test")
    assert s.overall_score == 100.0 and s.rag_status == "GREEN"


def test_critical_failure_forces_red():
    s = score_run("run", _ds(), [_res(True, "high"), _res(False, "critical")], "test")
    assert s.rag_status == "RED" and s.critical_failures == 1


def test_weighted_score_and_dimension_breakdown():
    results = [
        _res(True, "low", Dimension.completeness),
        _res(False, "high", Dimension.validity),
    ]
    s = score_run("run", _ds(), results, "test")
    # earned=1(low) of total weight 1+5=6 -> 16.67
    assert round(s.overall_score, 1) == 16.7
    assert s.dimension_scores["completeness"] == 100.0
    assert s.dimension_scores["validity"] == 0.0


# ---- scan scoping ---------------------------------------------------------
def test_scope_full_default():
    sc = build_scope(_FakeSpark(), _ds(), "governance.dq")
    assert sc.mode == "full" and sc.predicate is None
    assert sc.source == "`c`.`s`.`t`"


def test_scope_sample_wraps_tablesample():
    ds = _ds()
    ds.sample_fraction = 0.1
    sc = build_scope(_FakeSpark(), ds, "governance.dq")
    assert sc.mode == "sample" and "TABLESAMPLE (10.0 PERCENT)" in sc.source


def test_scope_incremental_builds_watermark_predicate():
    ds = _ds()
    ds.incremental = True
    ds.freshness_ts_column = "load_ts"
    sc = build_scope(_FakeSpark(watermark="2026-07-01 00:00:00"), ds, "governance.dq")
    assert sc.mode == "incremental"
    assert sc.predicate == "`load_ts` > '2026-07-01 00:00:00'"


def test_scope_incremental_first_run_no_watermark():
    ds = _ds()
    ds.incremental = True
    ds.freshness_ts_column = "load_ts"
    sc = build_scope(_FakeSpark(watermark=None), ds, "governance.dq")
    assert sc.mode == "incremental" and sc.predicate is None  # scans all on first run
