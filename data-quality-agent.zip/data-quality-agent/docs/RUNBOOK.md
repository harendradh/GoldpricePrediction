# DQA Production Runbook

## Deployment topology

```
Agent Studio (Azure Container Apps)  ──REST + OAuth2──►  Databricks
  DQ Agent + 11 Tools + 2 RAG collections                  ├─ dq_rules / dq_stats / dp_*_status
                                                             │  (Ingestion team's own tables, read-only)
                                                             ├─ 3 unified views + governance.dq.fn_*
                                                             │  (UC Functions) + 2 small control tables
                                                             ├─ Genie Space (governance.dq.* only)
                                                             └─ Lakeview dashboard
```

No separate FastAPI/Docker service, no sync engine to keep running. See
`docs/UNIFIED_VIEWS.md` for the design and `docs/SETUP_GUIDE.md` for the full walkthrough.

## One-time setup

1. Run `sql/01` through `sql/06` on a SQL Warehouse (control tables, unified views,
   dashboard views, UC Functions — see `docs/SETUP_GUIDE.md` Phase 1).
2. Deploy: `databricks bundle deploy --var="warehouse_id=<id>"` — one job
   (`dq_view_refresh`), one dashboard.
3. Grant the service principal `SELECT` on the source teams' tables, `SELECT/MODIFY` on
   `governance.dq.*`, and `EXECUTE` on `governance.dq.fn_*`. Nothing broader — no copied data.
4. Build in Agent Studio: `agent_studio/BUILD_GUIDE.md`.

## Onboarding a new team (manual, platform-team action, no redeploy)

This is deliberately NOT something the agent can do itself — a new `source_registry` row
changes what a shared view returns to every team, so a human writes it, the same way you'd
review a schema change:
```sql
-- Two rows, once, per team:
MERGE INTO governance.dq.source_registry ... (their rule table)
MERGE INTO governance.dq.source_registry ... (their stats table)
```
Then `databricks bundle run dq_view_refresh`. Full worked example, including a team whose
columns are named completely differently from Ingestion's: `docs/MULTI_TEAM_INTEGRATION.md`.

## Onboarding a new domain within an existing team (even faster)

```sql
INSERT INTO governance.dq.dataset_registry (domain, sub_domain, owner_team, owner_email, criticality)
VALUES (...);
```
Their rules/results are already visible the moment they exist in the team's own tables — this
INSERT only adds ownership metadata.

## Optional: Lakehouse Monitoring setup

Not part of the required one-time setup. Attaches statistical-drift monitors to every table
registered in `source_registry` — catches things no rule was written for (a null-rate
creeping up, a row count quietly dropping). See `docs/PRODUCTION_READINESS.md` → Monitoring
for exactly what this does and doesn't cover.
```bash
databricks bundle run dq_lakehouse_monitors_setup   # after uncommenting the job in
                                                       # deploy/databricks.job.yml
```
Idempotent — safe to re-run after onboarding a new team; it only creates monitors for tables
that don't have one yet.

## Daily operations

- **`dq_view_refresh`**: runs nightly at 1:30am. Re-run manually
  (`databricks bundle run dq_view_refresh`) after registering a new team, or if a new
  `dp_*_status` profiler table appears and you want it picked up immediately.
- **On-demand**: users chat with the agent ("check TELETRACK", or "give me a full report on
  TELETRACK" for score + all rule outcomes + freshness + volume + profile in one answer).
- **Scheduled digest (optional)**: an Agent Studio Workflow, not a Databricks Job — emails a
  daily posture summary without anyone asking. See
  `agent_studio/agents/workflow_scheduled_digest.md`.
- **Alerts**: `alert_red_datasets` (any RED domain) and `alert_stats_gaps` (a domain that's
  gone quiet for 24h) — wire these as Databricks SQL Alerts to Teams/ServiceNow. Note:
  `alert_stats_gaps` only works if `loaded_ts` is mapped to a real timestamp column (see
  `docs/PRODUCTION_READINESS.md` → Monitoring) — unmapped, it can never fire.

## Guardrails baked in

| Concern | Control |
|---------|---------|
| SQL injection | Parameterized queries everywhere (fixed 2 real f-string interpolation bugs this pass) |
| Data exfiltration | This system never reads raw rows from any target table — only rule/stats/profile metadata teams already computed |
| Writing into another team's table | Never happens — no tool exists that can write to a source table; new-rule requests are advisory conversation only |
| A new source going live unreviewed | Not possible today — onboarding a table is a manual `MERGE` by the platform team, not an agent action; there's no self-service tool that could bypass review |
| Runaway rules | N/A — this system doesn't execute checks, it reads existing results |
| Secrets | OAuth service principal preferred; PAT dev-only |

## Scaling across teams

- One `source_registry` row per rules/stats table, one `dq_view_refresh` run — not one
  integration script per team.
- Profiler tables (`dp_*_status`) are auto-discovered — zero registration for a new pipeline
  that follows the existing naming convention.
- The dashboard and RAG Rule Reference automatically include every registered team.

## Roadmap hooks

- **Fallback engine** (`jobs/dq_check_job.py`, optional, not deployed by default): for a
  domain with genuinely no owning pipeline. Needs its own schema update before use — see the
  file's own header.
- **Self-service onboarding**: intentionally not built — onboarding is manual for now. If
  volume ever makes that a bottleneck, the natural shape is a staged-row, human-approved tool
  — not built today, by choice.
- **Lakehouse Monitoring on each domain's own business data**: still blocked — needs a
  domain → physical target table mapping that doesn't exist upstream. (Monitoring the
  metadata tables themselves — dq_rules, dq_stats, dp_*_status — is no longer blocked; see
  "Optional: Lakehouse Monitoring setup" below.) See `docs/PRODUCTION_READINESS.md` →
  Monitoring for the full explanation of the difference.
- **Rule suggestions**: intentionally advisory-only, with no staging mechanism — `dq_profile_dataset`
  can surface column stats to support a proposal, but adding a rule is always done by the
  owning team, in their own table, outside this system.
