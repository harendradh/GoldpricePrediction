# DQA Production Runbook

## Deployment topology

```
Agent Studio (Azure Container Apps)  ──REST + OAuth2──►  Databricks
  DQ Agent + 9 Tools + RAG + (optional) Workflow            ├─ DQ Job (engine)
                                                             ├─ SQL Warehouse (control tables)
                                                             ├─ Genie Space (governance.dq.* only)
                                                             └─ Unity Catalog / Delta
```

Agent Studio is already deployed on ACA — there is **no separate FastAPI/Docker service** to
build or run for this agent. `src/dq_agent/api/` + `deploy/Dockerfile` are an optional
standalone service, useful only if you need this engine outside Agent Studio; skip them for
the Agent Studio path below. **For the full step-by-step, see `agent_studio/BUILD_GUIDE.md`**
(or `docs/SETUP_GUIDE.md` for the complete end-to-end walkthrough including this section's
Databricks-side prerequisites).

## One-time setup

1. **Control tables** — run `sql/01_control_tables.sql` on a SQL Warehouse (creates
   `governance.dq.*`). Grant the DQA service principal:
   - `SELECT` on target data schemas (read-only — the agent never writes data).
   - `SELECT, MODIFY` on `governance.dq.*` (results + proposed rules).
2. **Deploy the Jobs** — `databricks bundle deploy -t prod` (see `deploy/databricks.job.yml`).
   Note the resulting `dq_check` **job_id** and your **warehouse_id**. By default this runs in
   **POC mode**: no wheel build — the bundle syncs `src/` alongside `jobs/` and each job
   imports the package straight from source (see the comments in `deploy/databricks.job.yml`).
   Once past POC, build a real wheel (`python -m build`) and flip the commented-out `whl:`
   library lines on in that file — see `docs/SETUP_GUIDE.md` Phase 2 for the full switch.
4. **Create the Genie Space + OAuth service principal**, then **build the 9 Tools + RAG
   Collection + Agent in Agent Studio** — follow `agent_studio/BUILD_GUIDE.md` end to end.

## Onboarding a new BU / dataset (self-service, no redeploy)

```sql
INSERT INTO governance.dq.dataset_registry (...) VALUES (...);   -- register
INSERT INTO governance.dq.rule_catalog     (...) VALUES (...);   -- add rules
```
Or ask the agent: *"profile prod.sales.orders and propose golden rules"* → it calls
`profile_dataset` + `propose_rule` (rules land **disabled**; a human enables them).

## Daily operations

- **Scheduled sweep**: enable the cron in `databricks.job.yml`, or add a driver task that
  loops tier-1 datasets and fans out `run_checks`.
- **On-demand**: users chat with the agent ("check payments.txn_master").
- **Alerts**: `run_checks(..., notify=true)` posts RED/AMBER scorecards to Teams.

## Guardrails baked in

| Concern | Control |
|---------|---------|
| SQL injection via rules | `sql_safe.py` — identifier validation + DDL/DML screen |
| Data exfiltration | Agent reads aggregates + ≤20 sampled keys only; data stays in Databricks |
| Runaway rules | one bad rule is recorded as an errored check, never crashes the run |
| Auto-damage | agent cannot write/delete/backfill data; remediation is advisory |
| Rule sprawl | proposed rules created **disabled**; human approval to enable |
| Secrets | OAuth service principal + Key Vault; PAT only for dev |

## Scaling across teams

- Multi-tenant by `owner_bu`; enforce with Unity Catalog grants so a BU sees only its rules.
- The engine batches all column checks into **one scan per table** → cheap even on wide tables.
- Score history in `run_summary` powers an exec Databricks dashboard (`v_latest_scorecard`).

## Roadmap hooks (already stubbed)

- **Rule-Gen agent**: `profile_dataset` + `propose_rule` → LLM-suggested rules w/ approval.
- **Drift/anomaly**: wire Lakehouse Monitoring metrics into a `monitoring` rule_type.
- **Auto-remediation**: promote low-risk `remediation_advice` actions behind an approval flag.
```
