# Data Quality Agent — Complete End-to-End Setup Guide

Start to finish: an empty `governance` catalog to a working `DQ Agent` a team can chat with.
Read **[UNIFIED_VIEWS.md](UNIFIED_VIEWS.md)** first — it explains the whole design in one
page. This guide is shorter than it used to be because the design is: no sync job, no engine
to deploy for the common case, 2 small tables instead of 6.

**Time estimate:** ~1 hour, mostly waiting on Databricks access approvals.

---

## Phase 0 — Prerequisites

- [ ] A Databricks workspace with Unity Catalog, and permission to create a catalog/schema.
- [ ] `SELECT` access to `prod_dcs_catalog.df_app_configs.dq_rules`,
      `prod_dcs_catalog.df_app_configs.dq_stats`, `prod_dcs_catalog.data_profile.*` (or your
      workspace's equivalents — the tables from Screenshot 1-3, whatever they're called here).
- [ ] A SQL Warehouse and the `databricks` CLI configured.
- [ ] Access to Fiserv DCS Agent Studio with permission to create Tools/Agents/RAG.

## Phase 1 — Create the control tables + unified views

```bash
databricks sql -f sql/01_control_tables.sql        # source_registry, dataset_registry
databricks sql -f sql/02_seed_golden_rules.sql      # registers the Ingestion team's real tables (the worked example)
databricks sql -f sql/03_scale_optimizations.sql    # v_rules_unified, v_stats_unified, v_run_summary, v_profile_unified
databricks sql -f sql/04_dashboard_and_alerts.sql   # dashboard-serving views + SQL alerts
databricks sql -f sql/05_dashboard_extensions.sql   # rule-type breakdown + RAG distribution
databricks sql -f sql/06_uc_functions.sql           # governed function layer — see docs/UNIFIED_VIEWS.md
databricks sql -f sql/07_freshness_and_reports.sql  # freshness/volume/full-rule-outcome views
databricks sql -f "CREATE VOLUME IF NOT EXISTS governance.dq.rag_exports"
```

Verify:
```sql
SELECT * FROM governance.dq.v_rules_unified LIMIT 10;   -- should show real Ingestion rules
SELECT * FROM governance.dq.v_latest_scorecard LIMIT 10; -- may be empty until dq_stats has rows for a registered domain
```

## Phase 2 — Deploy the view-refresh job + dashboard

```bash
cd deploy
databricks bundle deploy --var="warehouse_id=<your SQL warehouse id>"
```

This deploys **one** job (`dq_view_refresh` — rebuilds the unified views + the RAG reference,
nightly) and the `DQ Enterprise Scorecard` dashboard. No wheel, no engine, POC or prod —
`dq_view_refresh.py` only touches `pyspark`/`spark.sql`.

Write down the dashboard id: `databricks lakeview list --output json | grep -B2 "DQ Enterprise"`.

## Phase 3 — Service principal

One SP covers the whole read path:
- `SELECT` on the Ingestion team's tables (Phase 0) — read-only, this system never writes to
  source tables.
- `SELECT`/`MODIFY` on `governance.dq.*` (its own 3 small tables + views).
- `EXECUTE` on `governance.dq.fn_*` (the UC Function layer, `sql/06`).

That's the entire grant set — there's no copied data, no second engine, nothing broader.

## Phase 4 — Genie Space

Scope it to `governance.dq.*` views only. Create an OAuth service principal for it
(`GENIE_CLIENT_ID`/`GENIE_CLIENT_SECRET`), set once in Agent Studio's `backend/.env`.

## Phase 5 — Build in Agent Studio

Full field-by-field walkthrough: **[`agent_studio/BUILD_GUIDE.md`](../agent_studio/BUILD_GUIDE.md)**.
In short: 10 Python Function tools (7 are thin wrappers over `governance.dq.fn_*` UC
Functions) + 1 native Genie tool, 2 RAG collections (`DQ Knowledge` static +
`DQ Rule Reference` generated), 1 Agent, ~40 minutes.

## Phase 6 — Register your first real domain

If a domain from Phase 0's tables isn't in `dataset_registry` yet:
```sql
INSERT INTO governance.dq.dataset_registry
  (domain, sub_domain, owner_team, owner_email, criticality, freshness_sla_minutes)
VALUES ('TELETRACK', 'TELETRACK', 'Ingestion', 'owner@fiserv.com', 'tier1', 60);
```
Their rules and results are already visible via the unified views the moment they exist in
`dq_rules`/`dq_stats` — this INSERT only adds ownership/criticality/SLA, nothing else.

## Phase 7 — Smoke test

Run the 6 prompts in `agent_studio/BUILD_GUIDE.md` Step 5. **Definition of done**: all 6
return correct, sensibly-worded answers with no tool errors.

## Phase 8 — Onboard a second team

Checklist and a worked example for a team whose columns are named nothing like Ingestion's:
**[`docs/MULTI_TEAM_INTEGRATION.md`](MULTI_TEAM_INTEGRATION.md)**. This is a manual,
platform-team step by design — no self-service tool. The platform team writes two `MERGE`
statements into `source_registry` (`sql/02` is the template), then
`databricks bundle run dq_view_refresh` — nothing in Agent Studio changes.

## Phase 9 — CI/CD (optional, recommended before scaling past a pilot)

`.github/workflows/ci.yml` + `deploy.yml` promote `dev → staging → prod` with a manual
approval gate on staging/prod. See `docs/PRODUCTION_READINESS.md`.

---

## Troubleshooting

| Symptom | Likely cause | Check |
|---|---|---|
| `v_rules_unified` is empty | `source_registry` has no `enabled` rows, or `sql/02` wasn't run | `SELECT * FROM governance.dq.source_registry` |
| `dq_get_summary` says "no dq_stats rows" | The domain isn't in `dataset_registry`, or Ingestion's pipeline hasn't run for it | Check `dq_stats` directly for that domain |
| `dq_get_dashboard_link` returns a bad URL | `DQ_DASHBOARD_ID` unset or stale | Re-check Phase 2's `databricks lakeview list` output |
| A new team's rules don't show up | `dq_view_refresh` hasn't run since their `source_registry` row was added, or the row has `enabled = false` | `databricks bundle run dq_view_refresh` |
| A tool errors with "permission denied" on `fn_*` | Service principal is missing `EXECUTE` on `governance.dq.fn_*` | See Phase 3's grant list |
| Score looks wrong | Severity is derived from `action_if_failed`, not stored — a `WARN` rule failing never turns a domain RED by itself | See `agent_studio/rag/dq_knowledge.md` |
