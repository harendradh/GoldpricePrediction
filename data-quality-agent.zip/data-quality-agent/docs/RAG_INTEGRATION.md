# RAG Integration — What's Indexed, What's Mapped, What It Connects To

## The core rule: RAG for prose, tools for numbers

Retrieval is approximate and only as fresh as the last re-index. Every number this agent
reports must be exact and current. So:

- **Never index `v_run_summary`/`v_latest_scorecard`** (live scores). Those are exactly what
  `dq_get_summary`/`dq_get_failures`/`dq_scorecard_genie` already serve, live, from `dq_stats`.
  A retrieved chunk saying "score was 91 last Tuesday" can go stale; a tool call can't.
- **Do index prose with no home in a fast, exact query** — rule justifications, remediation
  playbooks, glossary. That's what embeddings are good at: fuzzy, cross-cutting questions.

## Two RAG collections

| Collection | Content | Refresh | Purpose |
|---|---|---|---|
| `DQ Knowledge` | `agent_studio/rag/dq_knowledge.md` — scoring rubric, remediation playbook, escalation matrix, FAQ, glossary | Manual, on doc edit | Ground the agent in *policy* |
| `DQ Rule Reference` | Generated markdown, one section per domain: its rules, severities, and `description`, in prose | Nightly, `jobs/dq_rag_refresh.py` | Ground the agent in *what exists* — fuzzy, cross-domain questions a single `dq_get_rules(domain=...)` call can't answer |

## What maps into `DQ Rule Reference`

`jobs/dq_rag_refresh.py` (runs right after `jobs/dq_view_refresh.py`, same job) queries
`v_rules_unified` + `dataset_registry` and renders prose — not a raw table export:

```markdown
## TELETRACK (Ingestion team, tier1)
Freshness SLA: 60 minutes.

- **address_should_be_valid** (validity, medium, action_if_failed=WARN)
  Address should be valid
- **name_should_be_standardized** (validity, medium, action_if_failed=WARN)
  Address should be standardized
```

A question like *"which domains have address validation rules?"* — across every domain, not
just one — is a natural-language match against text like this. It's a poor fit for
`dq_get_rules` (needs a `domain` you may not know yet) and a poor fit for
`dq_scorecard_genie` (no column holds "is about address validation"). That gap is what
`DQ Rule Reference` closes.

## Pipeline

1. `jobs/dq_view_refresh.py` rebuilds `v_rules_unified` (task `refresh`).
2. `jobs/dq_rag_refresh.py` renders it to `/Volumes/governance/dq/rag_exports/dq_rule_reference.md`
   (task `rag_refresh`, `depends_on` task 1 — same job, see `deploy/databricks.job.yml`).
3. Agent Studio's `DQ Rule Reference` collection is (re-)uploaded from that file, or pointed at
   the Volume path if your platform supports Volume-backed sync.
4. Query time: both collections retrieve together into `{rag_context}`; the agent still calls
   a tool for any number it states.

## Build steps

1. `CREATE VOLUME IF NOT EXISTS governance.dq.rag_exports;` (one-time).
2. Deploy `dq_view_refresh` (see `deploy/databricks.job.yml`).
3. Create RAG Collection `DQ Rule Reference` in Agent Studio (same embedding model/chunking as
   `DQ Knowledge`), upload the generated file.
4. Attach both collections to `DQ Agent`.
