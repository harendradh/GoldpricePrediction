# Production Readiness — Governance, Scalability, Monitoring, Security, CI/CD

What exists, what's new, what's still manual. Five areas, kept short on purpose — see
`docs/UNIFIED_VIEWS.md` for the design these all build on.

## Governance

- **No Delta PK/FK constraints declared** anywhere (`sql/01_control_tables.sql`) — Delta
  doesn't enforce them; uniqueness comes from `MERGE` write discipline instead.
- **Nothing is copied.** Every team's rule/results table stays theirs; this system only reads
  it through a view. There's no second copy of their data to secure or reconcile.
- **The agent never writes into another team's table — there is no path that could.** No
  rule-proposal or staging tool exists; suggesting a new rule is advisory conversation only.
- **Environment isolation**: `dev_governance.dq` / `stg_governance.dq` / `governance.dq` are
  separate catalogs per environment (`deploy/databricks.job.yml` `targets:`).
- **Still manual**: Agent Studio has no config-as-code export/promotion yet (see
  `docs/reviews/agent_studio_capability_roadmap.md` #1–#2) — the Tools/Agent/RAG build is
  walked by hand per environment. The SQL/jobs/dashboard layer *is* CI-promotable today.

## Scalability

- There is no sync job to scale — `v_rules_unified`/`v_stats_unified`/`v_profile_unified` are
  views, so query performance is whatever the underlying team tables' own layout supports
  (their partitioning, their clustering — not something this system adds a second copy of).
- `jobs/dq_view_refresh.py` only runs when a source is added or a new `dp_*_status` table
  appears — nightly is generous headroom, not a freshness requirement.
- **No serverless compute in this workspace**: `deploy/databricks.job.yml` gives
  `dq_view_refresh` an explicit single-node job cluster (`job_cluster_node_type`/
  `job_cluster_spark_version` variables) instead of relying on a serverless default — it's
  DDL + markdown rendering, not a data scan, so single-node is generous headroom here too.
- The optional fallback engine (`dq_check_job.py`, not deployed by default) does real
  row-level scanning if you ever turn it on — size its job cluster (node type, worker count,
  `for_each` concurrency) for your actual data volume before enabling; the commented-out
  block in `deploy/databricks.job.yml` is a starting point, not a sized default.

## Monitoring

**Implemented today:**
- The `DQ Enterprise Scorecard` Lakeview dashboard reads the unified views directly — no
  separate metrics pipeline (`deploy/dashboards/dq_enterprise_scorecard.lvdash.json`). Two
  pages: **Executive Overview** (counters, score trend, RAG distribution, team scorecard) and
  **Freshness, Volume & Failures** (freshness-vs-SLA table, volume trend by domain, rule-type
  breakdown, top failures) — split so a leader's at-a-glance view isn't cluttered by what an
  owner triaging an issue actually needs.
- `alert_stats_gaps` (`sql/04_dashboard_and_alerts.sql`), `v_freshness_status`
  (`sql/07_freshness_and_reports.sql`, `dq_get_freshness`, now also the dashboard's "Stale
  domains" counter and freshness table), and `v_volume_trend` (same file, `dq_get_full_report`,
  now also the dashboard's volume trend chart) give dataset- and date-level freshness/volume
  visibility that didn't exist before this pass.
- **Real caveat, not a "not yet built" item**: all three above depend on
  `v_stats_unified.loaded_ts` meaning something. It defaults to `current_timestamp()` — the
  moment the *view* is queried, not the moment the row was *written* — unless
  `source_registry.column_mapping` maps `loaded_ts` to a real write-timestamp column from the
  source. Unmapped, every row looks "just written" no matter how old it actually is, and
  `alert_stats_gaps`/`dq_get_freshness` can't detect staleness at all. `dq_get_freshness`
  itself flags this when it sees a suspiciously-fresh timestamp — see
  `agent_studio/tools/dq_get_freshness.py`'s caveat logic. Map a real column per source to
  fix it for good.
- **Not yet built**: no SLO on `dq_view_refresh` itself (e.g. "completes within N minutes");
  no synthetic canary domain to catch a broken view definition before a real user does.

**Partially available — Lakehouse Monitoring (`jobs/dq_lakehouse_monitors.py`, optional, not
deployed by default):** `dq_rules` is *rule-based* — someone wrote "amount must be >= 0," and
this system reports on that rule's pass/fail. Databricks' native Lakehouse Monitoring is
*statistical* — it auto-profiles a table on a schedule and flags drift nobody wrote a rule
for: a column's null-rate creeping up, a distribution shift, a row-count that quietly
dropped. The two are complementary, not redundant.

This is now available for the tables this system already knows the physical location of —
every `source_registry.fq_table` (`dq_rules`, `dq_stats`, `dp_*_status`, and whatever else
gets registered later). Run `jobs/dq_lakehouse_monitors.py` once (see the commented-out
`dq_lakehouse_monitors_setup` job in `deploy/databricks.job.yml`) to attach a Snapshot-type
monitor to each — it catches pipeline-level drift on the metadata/results tables themselves
(e.g. `dq_stats`' row count or null rates shifting between runs).

**Still not possible**: drift on each domain's own underlying *business* data (e.g. the real
TELETRACK transaction table) — `dq_rules` only carries `domain`/`sub_domain`/`product_id`,
not a physical pointer to that table, so this system still has no way to know which table
that is. That gap is unchanged and stays a roadmap item (see `docs/RUNBOOK.md`).

## Security

- **Two real SQL-injection paths were found and fixed** while building this: raw f-string
  interpolation of caller-supplied filters in `jobs/dq_sweep_driver.py` and in a legacy
  custom-tool file since removed as dead code. Both were converted to parameterized queries
  before the fix landed.
- **This system's access footprint shrank**, not grew: it needs `SELECT` on Ingestion's
  `dq_rules`/`dq_stats`/`dp_*_status` and read/write on its own 3 small tables — nothing else.
  No new copy of any team's data to grant broader access to.
- **Recommended, not yet built**: split the one SQL-reading service principal from the
  Genie service principal (already separate) if the SELECT grants on team tables need to be
  narrower than what the dashboard/tools SP has; secrets rotation cadence for both.

## CI/CD

- **`.github/workflows/ci.yml`**: lint, unit tests, wheel build (packaging check only),
  SQL sanity check (`scripts/ci/check_sql_syntax.py`), Lakeview JSON validation,
  `databricks bundle validate -t dev`.
- **`.github/workflows/deploy.yml`**: `dev` auto-deploys on merge; `staging`/`prod` sit behind
  a GitHub Environment approval gate. SQL scripts are idempotent (`IF NOT EXISTS`/`MERGE`),
  safe to re-run every deploy. `sql/02` (example registrations) is **not** run automatically in
  staging/prod — onboarding a real team is a reviewed change, not a CI script.
- **Not yet built**: a migration-tracking table (which `sql/NN_*.sql` ran where) — every script
  is idempotent so this isn't required for correctness, just for "is staging caught up" at a
  glance.
