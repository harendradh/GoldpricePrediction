# DQA — Architecture

**Read what teams already collect. Copy nothing. Run nothing (for the common case).** Full
design: `docs/UNIFIED_VIEWS.md`. This page covers scale, coverage, and governance.

## 1. Component map

```
                       ┌────────────────────────── Agent Studio (ACA) ──────────────────────────┐
   User          ────► │  DQ Agent (Single) + 10 Python-Function Tools + Genie + 2 RAG collections│
                       └───────────────┬─────────────────────────────────────────────────────────┘
                                       │ Databricks REST (SQL Statement Execution + Genie)
   ┌───────────────────────────────────┼────────────────────────────────────────────────────────┐
   │ DATABRICKS LAKEHOUSE               ▼                                                          │
   │  Team-owned tables (unchanged, read-only)     3 unified views (governance.dq)                 │
   │  • dq_rules, dq_stats (Ingestion)      ────►  • v_rules_unified                                │
   │  • dp_*_status (any team's profiler)   ────►  • v_stats_unified                                │
   │  • <Data Panel's own tables>           ────►  • v_profile_unified                              │
   │                                                • v_run_summary / v_latest_scorecard (derived) │
   │                                                       │                                        │
   │                                                       ▼                                        │
   │                                  governance.dq.fn_*  (UC Functions — the governed layer         │
   │                                  7 of the 10 tools call one of these, not raw SQL)              │
   │                                                                                                │
   │  governance.dq (2 small tables, nothing else)                                                  │
   │  • source_registry (which tables to union — MANUAL, platform-team MERGE only, no               │
   │    self-service tool) • dataset_registry (owner/criticality/SLA)                                │
   │  • no rule-staging table — this system has no rule-proposal mechanism at all                    │
   │                                                                                                │
   │  Serving  • DQ Enterprise Scorecard (Lakeview) • SQL Alerts → Teams/ServiceNow                  │
   └────────────────────────────────────────────────────────────────────────────────────────────┘
```

## 2. Why this scales without a sweep job

The old design ran its own check engine across every table nightly. The new design doesn't
need to: **Ingestion's own pipeline already runs at whatever scale their business requires** —
this system doesn't add a second engine scanning the same data. What actually needs to scale
is the *view layer*, and views don't have a scale problem of their own:

- `v_rules_unified`/`v_stats_unified` are `UNION ALL` over each team's table — query cost is
  whatever their own table's partitioning/clustering already gives you, not something this
  system adds overhead to.
- `jobs/dq_view_refresh.py` only *rebuilds the view definition* (a `CREATE OR REPLACE VIEW`,
  milliseconds) — it doesn't scan data. It runs nightly out of caution, not because anything
  needs refreshing faster than that; a view has zero replication lag by construction.
- Onboarding team #10 adds one more `UNION ALL` branch, not a 10x increase in scanned data or
  compute.

## 3. Coverage — what's checked, and by whom

Every check that exists today was written by the team that owns the data (Ingestion's
`dq_rules`), using their own judgment about what matters for their pipeline. This system adds
a **shared way to ask about it, score it, and see it on one dashboard** — it does not add new
checks. If a domain has genuinely no owning pipeline, the optional fallback engine
(`jobs/dq_check_job.py`, not deployed by default) can run a minimal set — see its file header
for what that needs before use.

## 4. Governance

- **Nothing is copied.** The strongest governance property here isn't a control this system
  added — it's that there's no second copy of anyone's data to secure, retain, or reconcile
  against drift from the source of truth.
- **This system never writes into another team's table — and has no mechanism to.** There is
  no rule-proposal or staging tool. A new-rule request is a conversation the agent redirects
  to the owning team; nothing is recorded or tracked on this system's side.
- **Onboarding a new source is manual, not agent-driven.** There's no self-service tool —
  a `column_mapping` value becomes SQL text the service principal executes, so a new
  `source_registry` row is a platform-team `MERGE` (sql/02), reviewed like a schema change.
- **Read-only access is the entire grant**: `SELECT` on source tables, `SELECT/MODIFY` on its
  own tables, `EXECUTE` on `governance.dq.fn_*`. No broader footprint than that.
- **Environment isolation**: `dev_governance.dq`/`stg_governance.dq`/`governance.dq` are
  separate catalogs (`deploy/databricks.job.yml` `targets:`).

## 5. Reliability & observability

- `alert_stats_gaps` (`sql/04`) fires when a domain that normally reports to `dq_stats` has
  gone quiet for 24h — catches an upstream pipeline failure, not just a rule failure.
- `alert_red_datasets` fires on any RED domain in the latest scorecard.
- **Lakeview dashboard** (`deploy/dashboards/dq_enterprise_scorecard.lvdash.json`): score by
  team, score trend, RAG distribution, pass rate by rule_type, top failures — all reading the
  unified views directly.

## 6. CI/CD

`.github/workflows/ci.yml` (lint, test, SQL sanity check, bundle validate) gates every PR;
`.github/workflows/deploy.yml` promotes `dev → staging → prod` behind a manual approval gate
on staging/prod. See `docs/PRODUCTION_READINESS.md`.
