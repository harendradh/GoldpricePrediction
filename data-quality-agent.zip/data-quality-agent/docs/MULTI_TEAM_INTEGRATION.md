# Multi-Team Integration — How a Team With Completely Different Columns Fits In

Full design: **[UNIFIED_VIEWS.md](UNIFIED_VIEWS.md)**. This page answers one question in
detail: *Ingestion's `dq_rules` and Data Panel's rule table will never have the same column
names — so how does one view (`v_rules_unified`) read both?*

The short answer: **`column_mapping`**. One row per source table, one small `MAP<STRING,STRING>`
that says "our column X = your column Y (or this expression over your columns)." Nothing about
the source table changes, and nothing about the unified view's shape changes — the mapping is
the only thing that's different per team. Everything below makes that concrete.

## The problem, made concrete with two real-shaped tables

Ingestion's actual production table and a **hypothetical** Data Panel table, side by side —
same *meaning*, unrelated column *names*:

| What it means | Ingestion's `dq_rules` column | Data Panel's `panel_rules` column (hypothetical) |
|---|---|---|
| Row's unique id | `rule_id` (long) | `id` (int) |
| Which domain this rule belongs to | `domain` | `area` |
| Finer-grained grouping | `sub_domain` | `sub_area` |
| The rule's name | `rule` | `name` |
| The check itself | `condition` | `expr` |
| What to do if it fails | `action_if_failed` (string: `WARN`/`BLOCK`/...) | `on_fail` (string, same idea, different values) |
| Whether the rule is live | `is_active` (boolean) | `active` (boolean) |

Neither table is wrong — they're two teams' own schemas, built independently, years apart.
**This framework does not ask either team to change a single column.** It asks the platform
team to write down, once, how their columns line up with a common set of names.

## Where that mapping lives: one row in `source_registry`

```sql
MERGE INTO governance.dq.source_registry t
USING (SELECT 'datapanel_rules' AS source_id) s ON t.source_id = s.source_id
WHEN NOT MATCHED THEN INSERT (source_id, owner_team, source_type, fq_table, column_mapping, enabled)
VALUES (
  'datapanel_rules', 'Data Panel', 'rules', 'panel_catalog.dq.panel_rules',
  map(
    'rule_id',          'CAST(id AS STRING)',
    'domain',           'area',
    'sub_domain',       'sub_area',
    'rule_name',        'name',
    'condition',        'expr',
    'action_if_failed', 'on_fail',
    'is_active',        'active'
  ),
  true
);
```

Read the `map(...)` as a table of **"unified column" → "SQL expression against Data Panel's
own table."** Most entries are a plain rename (`'domain' → 'area'`). If Data Panel's
`on_fail` used single-letter codes instead of matching Ingestion's `WARN`/`BLOCK` strings, the
right side can be a full expression instead of a bare column — e.g.
`'action_if_failed', "CASE WHEN on_fail = 'H' THEN 'BLOCK' ELSE 'WARN' END"` — the mapping
absorbs value-shape differences too, not just name differences. A runnable version of this
exact example (plus the matching `panel_results`/stats-table MERGE) is in
`sql/02_seed_golden_rules.sql`, commented out until Data Panel is actually onboarded.

## What `dq_view_refresh.py` does with that row

It reads every `enabled` row in `source_registry`, and for each one generates one `SELECT`
branch of a `UNION ALL` (see `jobs/dq_view_refresh.py`'s `_rules_select()`) — literally
substituting your mapping's right-hand side in place of each unified column name, and filling
in `NULL` for anything you didn't map. For the two rows above (Ingestion + Data Panel), the
view it creates looks like this (trimmed to the columns that differ between the two teams —
`severity` is always derived from `action_if_failed`, the same formula for every team):

```sql
CREATE OR REPLACE VIEW governance.dq.v_rules_unified AS
SELECT
  CAST(rule_id AS STRING) AS rule_id, 'Ingestion' AS owner_team,
  domain AS domain, sub_domain AS sub_domain, rule AS rule_name, condition AS condition,
  action_if_failed AS action_if_failed,
  CASE upper(coalesce(action_if_failed,'')) WHEN 'BLOCK' THEN 'critical' ... END AS severity,
  is_active AS is_active
FROM prod_dcs_catalog.df_app_configs.dq_rules

UNION ALL

SELECT
  CAST(id AS STRING) AS rule_id, 'Data Panel' AS owner_team,
  area AS domain, sub_area AS sub_domain, name AS rule_name, expr AS condition,
  on_fail AS action_if_failed,
  CASE upper(coalesce(on_fail,'')) WHEN 'BLOCK' THEN 'critical' ... END AS severity,
  active AS is_active
FROM panel_catalog.dq.panel_rules;
```

Every branch has the **same output column names** (`rule_id`, `domain`, `rule_name`, ...) —
that's the whole trick. The `FROM` clause and the right-hand side of each `AS` differ per
team; everything reading the view downstream (the UC Functions, the tools, the dashboard, the
RAG export) only ever sees the left-hand names, so it doesn't know or care that one team calls
it `rule` and the other calls it `name`. Note `on_fail` gets plugged into the *same* severity
formula as Ingestion's `action_if_failed` — because the mapping made both columns line up
under one name, one formula now works for every team without a per-team branch.

## What this looks like from chat, end to end

```
User:  "What rules does Data Panel's checkout domain have?"

Agent: calls dq_get_rules(domain='checkout')
         → SELECT * FROM governance.dq.fn_get_rules('checkout')
             → reads v_rules_unified WHERE domain = 'checkout'
                 → which is really: SELECT ... FROM panel_catalog.dq.panel_rules
                                     WHERE area = 'checkout'      <- their real column
       returns rows shaped like:
         { rule_id: "17", domain: "checkout", rule_name: "amount_not_negative",
           condition: "amount >= 0", action_if_failed: "BLOCK", is_active: true }
```

The agent, the UC Function, and every other tool only ever work with `domain`/`rule_name`/etc.
— they never see `area`/`name`. Data Panel's table, column names, and pipeline schedule never
changed. If Data Panel renames a column next year, exactly one line — their `column_mapping`
entry — needs to change; nothing downstream does.

## Profiling tables usually need zero mapping — but not always

If Data Panel's column-profiling table follows the same naming convention Ingestion's does
(`data_profile.dp_<pipeline>_status`, same column shapes), `v_profile_unified` finds it
automatically via `information_schema` — no `source_registry` row at all.

If their profiler table is named or shaped differently — say `DQ_profile_ingestion` instead
of `dp_<pipeline>_status` — auto-discovery will never find it, silently. Register it exactly
like a rules/stats table: `source_type = 'profile'`, plus a `column_mapping` to
`domain`/`sub_domain`/`pipeline_name`/`column_name`/`failed_metrics`/`metric_values`/`status`/
`formatted_date`/`year`/`month`/`day_of_month`/`loaddt`. `sql/02_seed_golden_rules.sql` has a
runnable template. `jobs/dq_view_refresh.py` unions both auto-discovered and explicitly
registered profile tables into `v_profile_unified`.

## Doing the registration — manual, by design

Onboarding a new team's table is a **platform-team action**, not something the DQ Agent does
on request. There is no self-service tool for this: a `column_mapping` value becomes SQL text
that gets executed inside a `CREATE VIEW` the service principal runs against a *shared* view
every team reads from — that's worth the same review a schema change gets, done by a person
who can see the actual source table, not a chat-driven form. See
`docs/UNIFIED_VIEWS.md` → "Why onboarding is manual" for the full reasoning.

## Checklist

- [ ] Get their rule table's fully-qualified name + column names (name, description,
      condition/expression, what happens on failure, active flag).
- [ ] Get their stats/results table's fully-qualified name + column names (which rule, how
      many rows failed, which run).
- [ ] Write the `column_mapping` for each — see the worked example above and the runnable
      template in `sql/02_seed_golden_rules.sql`.
- [ ] `MERGE` both rows into `source_registry` (`enabled = true` once ready to go live).
- [ ] Run `jobs/dq_view_refresh.py` once (or wait for its nightly 1:30am schedule).
- [ ] Add their domains to `dataset_registry` (owner, criticality, freshness SLA) — the one
      thing not already in their table.
- [ ] Profiling tables need **nothing** if they follow the `dp_<pipeline>_status` convention
      (see above) — otherwise register them the same way as a rules/stats table.

## What never happens

- Their table is never copied. Every unified view reads their table directly, live.
- This system never writes into their table, and has no mechanism to stage or propose a
  change to it either — a new-rule idea is a conversation with their team, not a tracked
  request.
- Their pipeline's schedule, format, and tooling don't change — `column_mapping` is a read-time
  translation, not a migration.
