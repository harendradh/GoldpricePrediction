# End-to-End Worked Example — Every Table, View, Tool, and RAG Collection, With Real Shapes

This is a reference doc, not a design doc — `docs/UNIFIED_VIEWS.md` explains *why* things are
built this way; this shows *what actually flows through each piece*, with example data, so the
whole chain from a team's own table to a chat answer is traceable end to end.

**One example runs through the entire doc**: `TELETRACK`, owned by the Ingestion team — the
same domain used in `agent_studio/rag/dq_knowledge.md`'s worked example, kept consistent here.
A second example — `card_fraud_alerts`, owned by a hypothetical **Data Panel** team with
completely different column names — appears wherever it's useful to show that the same views
handle two differently-shaped source tables identically. All values below are illustrative
mock data with the real column names and types; no real row values are reproduced.

```
1. SOURCE TABLES (each team's own, unchanged)
        |
2. CONTROL TABLES (governance.dq — source_registry, dataset_registry)
        |  tells jobs/dq_view_refresh.py which source tables exist and how their columns map
        v
3. UNIFIED VIEWS (v_rules_unified, v_stats_unified, v_profile_unified)
        |
4. DERIVED VIEWS (v_run_summary, v_latest_scorecard) + DASHBOARD VIEWS (sql/04, sql/05)
        |
5. UC FUNCTIONS (governance.dq.fn_*) — governed, parameterized entry points
        |
6. TOOLS (Python) + GENIE (NL-to-SQL) + RAG (generated prose)
        |
7. THE ANSWER, in chat
```

---

## 1. Source tables — what's actually in them

These are never touched by this system beyond `SELECT` — owned, written, and scheduled
entirely by the team whose data it is.

### `prod_dcs_catalog.df_app_configs.dq_rules` (Ingestion team)

| Column | Type | Example value |
|---|---|---|
| `rule_id` | bigint | `48213` |
| `domain` | string | `TELETRACK` |
| `sub_domain` | string | `TELETRACK` |
| `product_id` | string | `TT-CORE` |
| `rule` | string | `address_should_be_valid` |
| `description` | string | `Address should be a valid US postal address` |
| `rule_type` | string | `address_should_be_valid` |
| `condition` | string | `regexp_like(address, '^[0-9]+\\s+\\S+')` |
| `action_if_failed` | string | `WARN` |
| `is_active` | boolean | `true` |
| `created_at` / `updated_at` | timestamp | `2025-11-02 09:14:00` |

Five example rows for `TELETRACK` (of the 20 this domain actually has registered):

| rule | rule_type | action_if_failed | is_active |
|---|---|---|---|
| `address_should_be_valid` | `address_should_be_valid` | `WARN` | `true` |
| `name_should_be_valid` | `name_should_be_valid` | `WARN` | `true` |
| `phone_should_be_valid` | `phone_should_be_valid` | `WARN` | `true` |
| `address_should_be_standardized` | `address_should_be_standardized` | `WARN` | `true` |
| `teletrack_key_OVERLAP` | `OVERLAP` | `BLOCK` | `true` |

### `prod_dcs_catalog.df_app_configs.dq_stats` (Ingestion team)

| Column | Type | Example value |
|---|---|---|
| `domain` / `sub_domain` / `product_id` | string | `TELETRACK` / `TELETRACK` / `TT-CORE` |
| `job_type` / `load_type` / `batch` | string | `incremental` / `daily` / `20260707` |
| `job_run_id` | string | `20260707013000-teletrack` |
| `task_name` | string | `teletrack_dq_check` |
| `dataset_name` (or `dataset`) | string | `teletrack_daily` |
| `input_count` | bigint | `48213` |
| `error_count` | bigint | `612` |
| `output_count` | bigint | `47601` |
| `unique_pii_count` | bigint | `48213` |
| `row_dq_results` | `array<map<string,string>>` | see below |
| `agg_dq_results` | `array<map<string,string>>` | see below |

One row's `row_dq_results` array (each map is one rule's outcome for that run):
```json
[
  {"rule": "address_should_be_valid", "failed_row_count": "612", "details": "612 rows failed format check"},
  {"rule": "name_should_be_valid", "failed_row_count": "0", "details": ""},
  {"rule": "phone_should_be_valid", "failed_row_count": "0", "details": ""},
  {"rule": "address_should_be_standardized", "failed_row_count": "0", "details": ""},
  {"rule": "teletrack_key_OVERLAP", "failed_row_count": "0", "details": ""}
]
```
`agg_dq_results` holds the same shape for aggregate-level (not row-level) checks — usually
empty for domains without a dataset-wide rule.

### `prod_dcs_catalog.data_profile.dp_bp_bill_payment_tm_status` (Ingestion team, one table per pipeline)

| Column | Type | Example value |
|---|---|---|
| `domain` / `subdomain` | string | `TELETRACK` / `TELETRACK` |
| `pipeline_name` | string | `bp_bill_payment_tm` |
| `column_name` | string | `address` |
| `failed_metrics` | string | `null_rate` |
| `metric_values` | string | `0.002` |
| `status` | string | `PASS` |
| `formatted_date` / `year` / `month` / `day_of_month` / `loaddt` | string | `2026-07-07` / `2026` / `7` / `7` / `2026-07-07T01:35:00` |

---

## 2. Control tables — `governance.dq.source_registry` and `dataset_registry`

These are the *only* two tables this system owns. `source_registry` tells
`jobs/dq_view_refresh.py` which physical tables to union and how to translate their columns;
`dataset_registry` carries the one thing genuinely missing upstream — ownership.

### `source_registry` — two real rows (Ingestion, already registered)

| source_id | owner_team | source_type | fq_table | column_mapping (excerpt) | enabled |
|---|---|---|---|---|---|
| `ingestion_dq_rules` | `Ingestion` | `rules` | `prod_dcs_catalog.df_app_configs.dq_rules` | `{'domain':'domain', 'rule_name':'rule', 'rule_type':'rule_type', ...}` | `true` |
| `ingestion_dq_stats` | `Ingestion` | `stats` | `prod_dcs_catalog.df_app_configs.dq_stats` | `{'domain':'domain', 'dataset_id':'coalesce(dataset_name, dataset)', ...}` | `true` |

### `source_registry` — Data Panel's two rows (different columns entirely, `sql/02`'s template)

| source_id | owner_team | source_type | fq_table | column_mapping (excerpt) |
|---|---|---|---|---|
| `datapanel_chk_rules` | `DataPanel` | `rules` | `prod_dcs_catalog.data_panel.chk_rules` | `{'rule_id':'CAST(chk_id AS STRING)', 'domain':'biz_domain', 'rule_name':'chk_nm', 'rule_type':'chk_typ', 'action_if_failed': "CASE WHEN severity='H' THEN 'BLOCK' ELSE 'WARN' END"}` |
| `datapanel_chk_stats` | `DataPanel` | `stats` | `prod_dcs_catalog.data_panel.chk_results` | *(their results table, mapped the same way)* |

Data Panel's own table has a PK column called `chk_id`, not `rule_id`; a grouping column called
`biz_domain`, not `domain`; a rule-name column called `chk_nm`; and severity encoded as a
single letter (`H`/`L`) instead of Ingestion's `action_if_failed` strings. None of that leaks
past `column_mapping` — every view downstream only ever sees `domain`, `rule_name`, etc.

### `dataset_registry` — one row per domain (ownership metadata only)

| domain | sub_domain | owner_team | owner_email | criticality | freshness_sla_minutes |
|---|---|---|---|---|---|
| `TELETRACK` | `TELETRACK` | `Ingestion` | `ingestion-data@fiserv.com` | `tier1` | `60` |
| `card_fraud_alerts` | `card_fraud_alerts` | `DataPanel` | `datapanel-data@fiserv.com` | `tier1` | `30` |

---

## 3. Unified views — what a query against them actually returns

### `v_rules_unified`
```sql
SELECT rule_id, rule_name, rule_type, action_if_failed, severity, is_active
FROM governance.dq.v_rules_unified
WHERE domain = 'TELETRACK';
```
| rule_id | rule_name | rule_type | action_if_failed | severity (derived) | is_active |
|---|---|---|---|---|---|
| `ingestion:48213` | `address_should_be_valid` | `address_should_be_valid` | `WARN` | `medium` | `true` |
| `ingestion:48214` | `name_should_be_valid` | `name_should_be_valid` | `WARN` | `medium` | `true` |
| `ingestion:48217` | `teletrack_key_OVERLAP` | `OVERLAP` | `BLOCK` | `critical` | `true` |

`severity` isn't a column anywhere upstream — it's a `CASE` on `action_if_failed`
(`BLOCK`/`FAIL_JOB`/`REJECT` → `critical`, `QUARANTINE` → `high`, `WARN` → `medium`, else
`low`), computed the same way for every team's rows, Ingestion's or Data Panel's.

### `v_stats_unified` (exploded from `row_dq_results`)
```sql
SELECT dataset_id, job_run_id, rule_name, failed_row_count, result_level
FROM governance.dq.v_stats_unified
WHERE domain = 'TELETRACK' AND job_run_id = '20260707013000-teletrack';
```
3 of the 20 rows this run actually produces (one per rule TELETRACK has registered):

| dataset_id | job_run_id | rule_name | failed_row_count | result_level |
|---|---|---|---|---|
| `teletrack_daily` | `20260707013000-teletrack` | `address_should_be_valid` | `612` | `row` |
| `teletrack_daily` | `20260707013000-teletrack` | `name_should_be_valid` | `0` | `row` |
| `teletrack_daily` | `20260707013000-teletrack` | `teletrack_key_OVERLAP` | `0` | `row` |

One row per rule per run — `row_dq_results`'s array is gone; each map entry became its own row.

### `v_profile_unified`
```sql
SELECT pipeline_name, column_name, failed_metrics, status
FROM governance.dq.v_profile_unified
WHERE domain = 'TELETRACK';
```
| pipeline_name | column_name | failed_metrics | status |
|---|---|---|---|
| `bp_bill_payment_tm` | `address` | `null_rate` | `PASS` |
| `bp_bill_payment_tm` | `phone` | `null_rate` | `PASS` |

---

## 4. Derived views — how a score actually gets computed

### `v_run_summary` (the math, worked through for TELETRACK's `20260707013000-teletrack` run)

```
rules_checked        = COUNT(DISTINCT rule_name) over v_stats_unified rows  = 20
rules_failed         = COUNT(rules where failed_row_count > 0)              = 1   (address_should_be_valid)
has_critical_failure = MAX(1 if severity='critical' AND failed > 0 else 0)  = 0   (the failing rule is 'medium')
overall_score        = ROUND(100.0 * (20 - 1) / 20, 1)                      = 95.0
rag_status            = has_critical_failure=0, score >= 95                  = GREEN
```
| dataset_id | domain | rules_checked | rules_failed | has_critical_failure | overall_score | rag_status |
|---|---|---|---|---|---|---|
| `teletrack_daily` | `TELETRACK` | `20` | `1` | `0` | `95.0` | `GREEN` |

Change nothing except `address_should_be_valid`'s `action_if_failed` from `WARN` to `BLOCK`:
`severity` becomes `critical`, so `has_critical_failure = 1` → **`rag_status` flips to `RED`**
regardless of the 95.0 score — a single critical failure always overrides the score.

### `v_latest_scorecard`
Same shape as `v_run_summary`, filtered to the single most-recent `run_ts` per `dataset_id` —
this is what `dq_get_summary` and the dashboard actually read.

---

## 4b. Freshness & volume — dataset and date level (`sql/07`)

Two views close a real gap: nothing previously surfaced freshness or volume as a queryable
metric at all.

### `v_freshness_status` — TELETRACK
| domain | freshness_sla_minutes | minutes_since_last_run | is_stale |
|---|---|---|---|
| `TELETRACK` | `60` | `47` | `false` |

### `v_volume_trend` — TELETRACK, last 3 days
| day | input_count | error_count | output_count | run_count |
|---|---|---|---|---|
| `2026-07-07` | `48213` | `612` | `47601` | `1` |
| `2026-07-06` | `47990` | `598` | `47392` | `1` |
| `2026-07-05` | `48105` | `605` | `47500` | `1` |

**Real caveat, not a hypothetical**: both depend on `v_stats_unified.loaded_ts` meaning
something. It defaults to `current_timestamp()` (query time, not write time) unless
`source_registry.column_mapping` maps `loaded_ts` to a real timestamp column — unmapped,
`minutes_since_last_run` always reads near zero. `dq_get_freshness` detects and flags this
rather than reporting a fabricated-looking "just now." See
`docs/PRODUCTION_READINESS.md` → Monitoring.

### `v_rule_outcomes_latest` — every active rule, not just failures
| rule_name | status | severity | failed_row_count |
|---|---|---|---|
| `address_should_be_valid` | `FAIL` | `medium` | `612` |
| `name_should_be_valid` | `PASS` | `medium` | `0` |
| `teletrack_key_OVERLAP` | `PASS` | `critical` | `0` |

`status` is `NOT_RUN` (not `PASS`) for a registered active rule with no matching outcome row
in the latest run — a different fact than "checked and passed."

---

## 5. Dashboard-serving views (`sql/04`, `sql/05`) — example output

### `v_team_scorecard`
| owner_team | criticality | datasets | avg_score | red | amber | green |
|---|---|---|---|---|---|---|
| `Ingestion` | `tier1` | `3` | `96.7` | `0` | `0` | `3` |
| `DataPanel` | `tier1` | `1` | `88.0` | `0` | `1` | `0` |

### `v_top_failures`
| dataset_id | rule_name | severity | failed_row_count | violation_rate |
|---|---|---|---|---|
| `teletrack_daily` | `address_should_be_valid` | `medium` | `612` | `0.0127` |

### `v_rule_type_breakdown`
| rule_type | outcomes | pass_rate |
|---|---|---|
| `address_should_be_valid` | `1` | `0.0` |
| `name_should_be_valid` | `1` | `100.0` |
| `OVERLAP` | `1` | `100.0` |

### `v_rag_distribution`
| rag_status | datasets |
|---|---|
| `GREEN` | `3` |
| `AMBER` | `1` |
| `RED` | `0` |

---

## 6. UC Functions — example calls and results

```sql
SELECT * FROM governance.dq.fn_get_summary('TELETRACK');
```
→ the exact `v_latest_scorecard` row shown in section 4.

```sql
SELECT * FROM governance.dq.fn_get_failures('TELETRACK');
```
| rule_name | severity | description | failed_row_count | violation_rate |
|---|---|---|---|---|
| `address_should_be_valid` | `medium` | `Address should be a valid US postal address` | `612` | `0.0127` |

```sql
SELECT * FROM governance.dq.fn_list_datasets('Ingestion');
```
| domain | sub_domain | owner_team | criticality |
|---|---|---|---|
| `TELETRACK` | `TELETRACK` | `Ingestion` | `tier1` |
| `corebanking_tran_ct` | `corebanking_tran_ct` | `Ingestion` | `tier1` |
| `zeta` | `zeta` | `Ingestion` | `tier2` |

```sql
SELECT * FROM governance.dq.fn_team_scorecard();
```
→ the `v_team_scorecard` rows shown in section 5 — this is what `dq_scorecard_genie` reads
for "which team is doing worse" questions.

`fn_get_rules`, `fn_profile_dataset`, `fn_get_freshness`, and `fn_get_volume_trend` follow the
same pattern — `SELECT * FROM governance.dq.fn_X('TELETRACK')` and get back exactly the
unified-view rows filtered to that domain. Any of these nine is callable directly by a SQL
analyst or notebook — nothing here is locked inside a Python tool.

```sql
SELECT * FROM governance.dq.fn_get_rule_outcomes('TELETRACK');
```
→ every active rule with `PASS`/`FAIL`/`NOT_RUN` for the latest run — the section 4b table.

---

## 7. Tools — example call and example JSON response

Every tool call below is exactly what Agent Studio sends the tool and gets back — real
argument names, real response shape, taken from the tool's own source in
`agent_studio/tools/`.

**`dq_get_summary(domain="TELETRACK")`**
```json
{
  "domain": "TELETRACK", "sub_domain": "TELETRACK",
  "job_run_id": "20260707013000-teletrack",
  "input_count": 48213, "rules_checked": 20, "rules_failed": 1,
  "has_critical_failure": 0, "overall_score": 95.0, "rag_status": "GREEN"
}
```

**`dq_get_failures(domain="TELETRACK")`** — adds a `suggested_action` per row, from a small
Python playbook lookup keyed on the rule name (not a database call):
```json
{
  "domain": "TELETRACK", "failure_count": 1,
  "failures": [
    {"rule_name": "address_should_be_valid", "severity": "medium",
     "failed_row_count": 612, "violation_rate": 0.0127,
     "suggested_action": "Reconcile the domain/enum or format with source reference data."}
  ]
}
```

**`dq_get_rules(domain="corebanking_tran_ct")`**
```json
{"domain": "corebanking_tran_ct", "sub_domain": "", "count": 14, "rules": [ /* fn_get_rules rows */ ]}
```

**`dq_list_datasets(owner_team="Ingestion")`**
```json
{"count": 3, "domains": [
  {"domain": "TELETRACK", "criticality": "tier1"},
  {"domain": "corebanking_tran_ct", "criticality": "tier1"},
  {"domain": "zeta", "criticality": "tier2"}
]}
```

**`dq_profile_dataset(domain="TELETRACK")`**
```json
{"domain": "TELETRACK", "count": 2, "profile": [
  {"pipeline_name": "bp_bill_payment_tm", "column_name": "address", "status": "PASS"},
  {"pipeline_name": "bp_bill_payment_tm", "column_name": "phone", "status": "PASS"}
]}
```

**`dq_get_dashboard_link(team="Ingestion")`** — no SQL at all, just formats a URL:
```json
{"dashboard_url": "https://<workspace>/sql/dashboardsv3/<dashboard-id>/published",
 "note": "Open the dashboard, then use its team filter to select 'Ingestion'."}
```

**`dq_run_checks(domain="some_domain_with_no_pipeline")`** — fallback-only; without a fallback
engine deployed:
```json
{"domain": "some_domain_with_no_pipeline",
 "error": "No fallback engine configured for this deployment. This system reads existing team pipelines (dq_stats, dp_*_status) — it doesn't run checks itself unless the optional fallback engine is deployed."}
```

**`dq_get_freshness(domain="TELETRACK")`**
```json
{"domain": "TELETRACK", "freshness_sla_minutes": 60,
 "minutes_since_last_run": 47, "is_stale": false}
```

**`dq_get_full_report(domain="TELETRACK")`** — the "everything about this dataset" tool,
assembled from 5 function calls in one response:
```json
{
  "domain": "TELETRACK",
  "summary": {"overall_score": 95.0, "rag_status": "GREEN", "rules_checked": 20},
  "rule_outcomes": {
    "total_rules": 20, "passed": 19, "failed": 1, "not_run": 0,
    "failing_rules": [{"rule_name": "address_should_be_valid", "status": "FAIL",
                        "suggested_action": "Reconcile the domain/enum or format with source reference data."}],
    "not_run_rules": [], "passing_rule_names": ["name_should_be_valid", "teletrack_key_OVERLAP", "..."]
  },
  "freshness": {"minutes_since_last_run": 47, "freshness_sla_minutes": 60, "is_stale": false},
  "volume_trend_7d": [{"day": "2026-07-07", "input_count": 48213, "error_count": 612}, "..."],
  "profile": [{"column_name": "address", "status": "PASS"}, "..."]
}
```

**`dq_send_email_report(to="dq-digest-distribution@fiserv.com", subject="Data Quality Digest — 2026-07-09", body_html="...")`**
— scheduled-digest-only, not called from interactive chat:
```json
{"sent": true, "to": ["dq-digest-distribution@fiserv.com"], "subject": "Data Quality Digest — 2026-07-09"}
```
Without `SMTP_HOST` configured: `{"error": "SMTP_HOST not configured for this deployment. ..."}`
— no exception raised, the agent can report the failure plainly.

---

## 8. Genie — example question, illustrative SQL, example answer

Genie's Space is scoped to all of `governance.dq` — every view and function above, never a
raw source table. It writes its own SQL per question; the query below is illustrative of what
Genie would generate, not a fixed query this system ships.

> **User asks:** "Which team has the most RED domains this week?"

Genie translates that into something like:
```sql
SELECT owner_team, red FROM governance.dq.v_team_scorecard ORDER BY red DESC LIMIT 1;
```
→ **Genie's answer:** *"DataPanel has the most AMBER domains this week (1), and no team
currently has any RED domains."* — reading straight from the same `v_team_scorecard` view
section 5 shows, translated into a sentence.

---

## 8b. Scheduled email digest — proactive, not just Q&A

Everything above is reactive — a user asks, the agent answers. Agent Studio's own Workflow +
Schedule feature (not a separate scheduler) pushes a daily posture summary without anyone
asking. Full agent-by-agent build: `agent_studio/agents/workflow_scheduled_digest.md`.

1. **Schedule trigger fires** — e.g. daily 07:00, no live user, a fixed prompt.
2. **Orchestrator runs `dq_digest_builder`** — tools `dq_list_datasets`, `dq_scorecard_genie`,
   `dq_get_full_report`.
3. **Builder composes the digest** — team rollup, then drills into any RED/AMBER domain,
   output as clean HTML.
4. **Orchestrator runs `dq_digest_sender`** — tool `dq_send_email_report(to, subject,
   body_html)`.
5. **Email delivered via SMTP relay** — `SMTP_HOST`/`PORT`/`USERNAME`/`PASSWORD`, a genuinely
   new external dependency this system didn't have before.

---

## 9. RAG collections — the actual content

### `DQ Knowledge` (static — `agent_studio/rag/dq_knowledge.md`, uploaded once)

A real excerpt of what's indexed (verbatim from that file):
```
## Scoring
- overall_score = 100 x (rules passed / rules checked) for a domain's latest job run.
- RAG: any critical failure -> RED; else score >= 95 -> GREEN; >= 80 -> AMBER; else RED.
```
This is *policy* — how to compute and interpret a score. It never contains a live number.

### `DQ Rule Reference` (generated nightly by `jobs/dq_rag_refresh.py`, from `v_rules_unified`)

The actual markdown this system renders and uploads — for TELETRACK, using the same 5 example
rules from section 1:
```markdown
## TELETRACK / TELETRACK (Ingestion team, tier1)
Freshness SLA: 60 minutes.

- **address_should_be_valid** (address_should_be_valid, medium, action_if_failed=WARN)
  Address should be a valid US postal address
- **name_should_be_valid** (name_should_be_valid, medium, action_if_failed=WARN)
  Name should be valid
- **teletrack_key_OVERLAP** (OVERLAP, critical, action_if_failed=BLOCK)
  No duplicate/overlapping records on the merge key
```
This is *inventory* — what rules exist, in prose, so a fuzzy cross-domain question ("which
domains have address validation rules?") can match against it. It never carries a score
either — see `docs/RAG_INTEGRATION.md` for why live numbers are deliberately excluded from
both collections.

---

## 10. Putting it together — one question, traced end to end

> **User asks the agent:** *"What's the data quality of TELETRACK, and why?"*

1. Agent identifies the domain (`TELETRACK`) and calls **`dq_get_summary(domain="TELETRACK")`**.
2. The tool calls **`SELECT * FROM governance.dq.fn_get_summary('TELETRACK')`**.
3. The function reads **`v_latest_scorecard`**, which reads **`v_run_summary`**, which reads
   **`v_stats_unified`** JOIN **`v_rules_unified`**.
4. Those views are `UNION ALL`s built by `jobs/dq_view_refresh.py` from the two rows in
   **`source_registry`** — which is why they know to read
   **`prod_dcs_catalog.df_app_configs.dq_rules`** and **`...dq_stats`**, Ingestion's own
   tables, live, with zero copies.
5. The tool returns `{"overall_score": 95.0, "rag_status": "GREEN", ...}` — the agent leads
   with that verdict.
6. Since the score isn't 100, the agent also calls **`dq_get_failures(domain="TELETRACK")`**,
   which walks the same view chain filtered to failing rows, and reports:
   *"1 rule failed: address_should_be_valid (medium severity), 612 of 48,213 rows (1.27%).
   Suggested action: reconcile the domain/enum or format with source reference data."*

Nothing above was copied, cached, or pre-computed outside of the views themselves — every
number in that answer was read live from Ingestion's own tables, through the exact chain this
document walks top to bottom.
