# Fiserv DCS Agent Studio — Design Review

Observations and recommendations from building the Data Quality Agent end-to-end in Agent
Studio. Companion docs: `agent_studio_additional_findings.md` (5 more findings, #8-12) and
`agent_studio_capability_roadmap.md` (capability gaps to add). Also available as a slide deck:
`docs/presentations/Agent_Studio_Design_Review.pptx`.

## Method

Five screens, exercised while onboarding a real product:

| Screen | What it's for |
|---|---|
| Sandbox / Chat | Testing an agent or workflow end-to-end |
| New Tool | Python Function, REST API, MCP, or Databricks Genie |
| New Agent | Provider, model, tools, RAG, callbacks |
| New RAG Collection | Embedding model, chunk size/overlap |
| Workflow Builder | Sequential / Parallel / Custom canvas |

## What's working well

- **Unified tool model** — one `Type` dropdown covers Python Function, REST API, MCP, and
  native Databricks Genie. No hand-rolled glue code needed — this is what made a custom
  `dq_ask_genie.py` REST wrapper unnecessary once we saw the native Genie tool type existed.
- **Recommended defaults** — RAG's embedding model flags a ★ recommended choice, cutting
  decision fatigue for builders.
- **Clean workflow canvas** — Start→End with drag-in agents and an explicit
  Sequential/Parallel/Custom type chosen up front.
- **Guardrails as first-class checkboxes** — Content Filter, Rate Limit, and Log Requests are
  attached at agent-creation time, not bolted on later.

## Findings at a glance

| # | Screen | Finding | Severity |
|---|---|---|---|
| 1 | New Tool | No pre-flight "test connection" before saving | High |
| 2 | New Agent / Workflow | No search or filter as the tool/agent catalog grows | High |
| 3 | New Tool (Genie) | OAuth2 scope defaults to `all-apis`, one shared secret | High |
| 4 | New Agent | Tool/RAG checkboxes carry no description tooltip | Medium |
| 5 | New Agent | No "recommended default" affordance for Callbacks | Medium |
| 6 | Workflow Builder | No visible conditional / branch routing | Medium |
| 7 | Sandbox | Workflow-selector dropdown truncates long names | Low |

## Deep dive #1 (High) — No pre-flight validation before a tool goes live

**Screen:** New Tool (Genie / REST API / MCP)

**Issue:** Space ID, host, and credential fields are free text with no way to confirm they're
correct before clicking Create Tool.

**Why it matters:** A typo in a Genie Space ID or a stale token only surfaces the first time an
agent calls it live — in front of a user, not a builder.

**Recommendation:** add a "Test Connection" action on the tool form: for Genie, start a
throwaway conversation and confirm a response; for REST/MCP, ping a lightweight health
endpoint.

## Deep dive #2 (High) — The catalog won't stay scannable as more teams onboard

**Screen:** New Agent · Workflow Builder

**Issue:** Tools, RAG Collections, and the Workflow's Available Agents are plain checkbox
lists with no search, filter, or grouping.

**Why it matters:** Agent Studio's whole premise is many teams sharing one instance. At
today's handful of tools it's fine; at dozens per team it stops being scannable.

**Recommendation:** reuse the Sandbox's existing Search box pattern on the Agent and Workflow
builders; add a team/domain facet so tools group by owner.

## Deep dive #3 (High) — Genie credentials are broad and shared by default

**Screen:** New Tool · Databricks Genie

**Issue:** OAuth2 scope defaults to `all-apis`, and `GENIE_CLIENT_ID`/`GENIE_CLIENT_SECRET` are
one platform-wide secret pair in `backend/.env` shared by every Genie tool.

**Why it matters:** A single over-scoped credential used across every team's Genie space is a
bigger blast radius than necessary — one compromised tool config affects all of them.

**Recommendation:** support narrower, space-scoped OAuth grants where Unity Catalog allows it,
and default new tools to a distinct credential pair instead of the shared platform default.

## Prioritized roadmap

| Bucket | Items |
|---|---|
| **Now** | #1 Test Connection on tool forms · #3 Scope Genie credentials per space |
| **Next** | #2 Search/filter on Agent & Workflow builders · #4 Tooltip descriptions on Tools/RAG checkboxes · #5 ★ recommended defaults for Callbacks |
| **Later** | #6 Conditional/branch routing in Workflows · #7 Widen or tooltip the Sandbox selector |

## Summary

The Tool Type model (Python Function / REST / MCP / Genie) is the platform's strongest asset —
lean into it. The main gaps are pre-flight validation, catalog scale, and credential scoping.
