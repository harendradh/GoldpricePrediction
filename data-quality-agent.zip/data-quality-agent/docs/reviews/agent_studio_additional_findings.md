# Fiserv DCS Agent Studio — Additional Review Findings

Follow-up to the original 7 findings (see the Design Review deck / `code-review` history).
These surfaced from re-reading the same 5 screens more closely, plus friction points from
writing `agent_studio/BUILD_GUIDE.md` and `agent_studio/rag/dq_knowledge.md`. Numbered 8-12 to
continue the original sequence.

| # | Screen | Finding | Severity |
|---|--------|---------|----------|
| 8 | New Agent | `Output Key` is free text with no collision check across a Workflow's chained sub-agents | Medium |
| 9 | New RAG Collection | No chunk preview — you only discover a bad split after upload + query | Medium |
| 10 | New Tool (Python Function / REST / MCP) | Only the Genie type gets an inline credential-location hint; the others don't | Medium |
| 11 | Sandbox | "Recents" list has no per-conversation labels | Low |
| 12 | New Agent | Callback toggles (Content Filter, Rate Limit) expose no visible parameters | Low/Medium |

---

## #8 — Output Key collisions aren't guarded against in Workflows

**Screen:** New Agent (Output Key field), relevant to Custom Workflows.

**Issue:** Each Single agent in a Workflow writes its response to an `Output Key`, and
downstream agents read it via `{agent_name.output}`. The field is plain free text with no
validation against keys already used elsewhere in the same workflow.

**Why it matters:** In `workflow_subagents.md` we deliberately gave `dq_profiler`,
`dq_runner`, and `dq_analyst` distinct output keys (`profile`, `run_result`, `analysis`). A
less careful builder could give two sub-agents the same key (or the platform's own default,
e.g. `result`) and silently clobber one agent's output with another's — a bug that only shows
up as "the analyst seems to be reasoning about the wrong data," which is hard to diagnose from
the Sandbox chat alone.

**Recommendation:** warn (or block) when a new agent's Output Key duplicates one already used
elsewhere in a Workflow the agent belongs to.

---

## #9 — RAG chunking has no preview before commit

**Screen:** New RAG Collection.

**Issue:** Chunk Size (512 chars) and Chunk Overlap (50 chars) are numeric fields with sensible
defaults, but there's no way to see how an actual uploaded document will be split before
committing to a collection.

**Why it matters:** `dq_knowledge.md` structures its "10 quality dimensions" and "rule types"
as numbered lists and a markdown table — if a 512-char chunk boundary lands mid-list-item or
mid-table-row, retrieval quality degrades in a way that's invisible until the agent gives a
subtly wrong answer in chat. This is exactly the kind of document (structured markdown,
short list items) where naive character-count chunking is riskiest.

**Recommendation:** a "preview chunks" step after upload, before the collection is attached to
any agent — show the first few chunk boundaries so a builder can sanity-check them against the
document's structure.

---

## #10 — Credential-location guidance is inconsistent across Tool types

**Screen:** New Tool — compare the Databricks Genie form (which has a yellow callout: *"Set
GENIE_CLIENT_ID and GENIE_CLIENT_SECRET in backend/.env"*) against the Python Function form
(no equivalent guidance for `DATABRICKS_HOST`/`DATABRICKS_TOKEN`/etc.).

**Why it matters:** Discoverability of *where* a tool's runtime credentials live is the single
thing `BUILD_GUIDE.md` Step 0 has to spell out by hand ("confirm with your Agent Studio
platform team how to set env vars / secrets for tool sandboxes") because the UI itself doesn't
say. The Genie form proves the platform already has the right pattern — it's just not applied
uniformly.

**Recommendation:** extend the same inline callout pattern to Python Function/REST/MCP tool
forms, listing whatever env vars the pasted code references (or at minimum a static reminder of
where tool-sandbox env vars are configured).

---

## #11 — Sandbox conversations aren't labeled

**Screen:** Sandbox, "Recents" panel.

**Issue:** Recent conversations show as an unlabeled list (a chat icon, no title/summary).

**Why it matters:** Onboarding a new BU means running the 5-prompt smoke test from
`BUILD_GUIDE.md` Step 5 — across 5+ conversations, there's no way to tell which recent chat
was "list datasets" vs. "run checks" vs. "ask Genie" without opening each one.

**Recommendation:** auto-title conversations from the first message (many chat products do
this), and allow manual rename/pin. Also feeds capability #3 in the roadmap doc (saved eval
sets) — labeled conversations are a natural stepping stone to reusable test fixtures.

---

## #12 — Callback toggles show no configurable parameters

**Screen:** New Agent — Callbacks section (Content Filter, Rate Limit, Log Requests).

**Issue:** These render as plain checkboxes. It's unclear from the form alone whether Rate
Limit's cap (mentioned as "default 500" in a tooltip we glimpsed) or Content Filter's
blocklist/policy are configurable anywhere, or are fixed platform defaults.

**Why it matters:** `BUILD_GUIDE.md` recommends enabling Log Requests + Rate Limit "as a
guardrail" without being able to say *what* the guardrail actually enforces for the DQ Agent's
traffic pattern (e.g. is 500 calls/session enough headroom for a `dq_sweep`-triggered burst of
chat traffic, or too generous for a single interactive user?).

**Recommendation:** either surface the actual configured values inline on the Agent form (even
read-only), or confirm they're intentionally fixed platform-wide — and document which, since we
can't tell from the form alone. Lowest-confidence finding in this set; worth a direct question
to the platform team rather than treating it as settled.
