# Unified Views — The Core of the Simplified Design

One sentence: **read what teams already collect, through 3 views — copy nothing, sync nothing.**

## Why this replaced the earlier design

The first pass of this system invented its own `rule_catalog`, `results`, `run_summary`, and
a CDF-based sync job to pull other teams' rules in. That was solving a problem that didn't
exist: the Ingestion team already runs checks and already writes the results — to real,
production tables:

| Table | What it is |
|---|---|
| `prod_dcs_catalog.df_app_configs.dq_rules` | Every rule Ingestion checks, 259 rows today |
| `prod_dcs_catalog.df_app_configs.dq_stats` | Every check outcome, per job run, written by their own pipeline |
| `prod_dcs_catalog.data_profile.dp_<pipeline>_status` | Column profiling, one table per pipeline |

Nothing needed copying. It needed *reading*.

## The picture

```
Ingestion team's OWN tables          governance.dq (this system)
(unchanged, still theirs)             3 views, 2 tiny tables

dq_rules  ─────────────┐
                        ├──►  v_rules_unified  ──┐
dq_stats  ─────────────┘                          ├──►  v_run_summary  ──►  scorecard
                                                    │      (score, RAG status)
dq_stats  ──────────────────►  v_stats_unified ───┘

dp_bp_bill_payment_tm_status ─┐
dp_<other>_status ─────────────┼──►  v_profile_unified
(auto-discovered)              ┘

Data Panel's OWN tables (different columns) — same pattern, one more
UNION ALL branch per view once their table/column names are known.

                                                    │
                                                    ▼
                                   governance.dq.fn_*  (Unity Catalog Functions)
                                   the governed, reusable "skill" layer — see below
                                                    │
                                                    ▼
                                   Agent Studio Python Function tools (thin wrappers)
```

Nothing on the left changes. Nothing is copied to the middle — every view box is a
`CREATE VIEW`, not a table with rows in it. The functions on the right aren't a copy either —
they're just a governed, callable name for a query against the views.

## The 3 views

- **`v_rules_unified`** — every team's rule definitions, one shape. `severity` is *derived*
  from `action_if_failed` (dq_rules has no severity column — `BLOCK`/`FAIL_JOB`/`REJECT` →
  critical, `QUARANTINE` → high, `WARN` → medium, else low).
- **`v_stats_unified`** — every rule *outcome*, one row each. dq_stats stores results as
  `row_dq_results`/`agg_dq_results` (`array<map<string,string>>`) — the view explodes them.
- **`v_profile_unified`** — every pipeline's column profiling. Two ways in: tables named
  `data_profile.dp_*_status` are **auto-discovered** via `information_schema` — zero
  registration. A table that doesn't follow that naming convention (e.g. a team's own
  `DQ_profile_ingestion`) needs one `source_registry` row with `source_type = 'profile'` and
  a `column_mapping` — same mechanism rules/stats already use. `jobs/dq_view_refresh.py`
  unions both; an explicit registration wins if a table somehow matches both paths.

Two derived views ride on top: `v_run_summary` (score + RAG status per domain per run) and
`v_latest_scorecard` (the latest row per domain — what the dashboard and chat read).

## How fresh is "fresh"? (a worked example)

Say Ingestion's own job writes a new row to their stats table right now. What happens, and
when, depends on who's asking:

- **A user asks the agent** ("what's TELETRACK's score?") → `dq_get_summary` →
  `fn_get_summary` → reads `v_run_summary`, which is built on `v_stats_unified` — a view, not
  a copy. The query re-executes against the *current* table state every time it runs, so the
  new row is visible **immediately** — there's no batch job to wait for, because nothing was
  ever copied in the first place.
- **Nobody asks — does anyone get told automatically?** That's `alert_red_datasets` /
  `alert_stats_gaps` (`sql/04`), wired as a Databricks SQL Alert on whatever schedule you
  configure it (`docs/RUNBOOK.md`). The underlying data is instantly current the moment
  someone looks; *unprompted* notification latency is however often that alert is scheduled
  to run — a few minutes, typically, not literally zero.
- **A brand-new team, or a brand-new table for an existing team** — this is the one place
  "instant" doesn't apply. A physical table has to be registered in `source_registry` (rules/
  stats: always explicit; profile: auto-discovered *or* explicit, see above) before anything
  in it is visible anywhere. That's a deliberate one-time, reviewed step
  (`docs/MULTI_TEAM_INTEGRATION.md`), not something that happens on its own — once it's done,
  every future row from that table is live from then on, same as any other registered source.
- **A real, separate caveat: `loaded_ts` has to be mapped to mean anything.**
  `v_stats_unified.loaded_ts` defaults to `current_timestamp()` — the moment the *view* is
  queried, not the moment the *row* was written — unless `source_registry.column_mapping`
  maps `loaded_ts` to a real write-timestamp column. Unmapped, `dq_get_freshness` and
  `alert_stats_gaps` can't actually detect staleness (every row looks "just written," no
  matter how old it is). `jobs/dq_view_refresh.py`'s `_stats_select()` supports the mapping;
  it just needs a real column identified per source. See `sql/03`'s comment on
  `v_stats_unified` and `sql/07_freshness_and_reports.sql`.

## Freshness, volume, and full rule outcomes (`sql/07_freshness_and_reports.sql`)

Three more views close a real gap: nothing previously surfaced dataset/date-level freshness
or volume as a queryable metric (only a binary 24h-silence alert), and nothing returned a
domain's full rule list with pass/fail status — only the failures, or the rule definitions
with no outcome.

- **`v_freshness_status`** — per domain, last-seen timestamp vs `dataset_registry`'s
  `freshness_sla_minutes`, and an `is_stale` flag. `fn_get_freshness` / `dq_get_freshness`.
- **`v_volume_trend`** — daily `input_count`/`error_count`/`output_count`, deduped per
  `job_run_id` first (those columns repeat once per exploded rule row within a run — summing
  raw `v_stats_unified` rows would massively over-count). `fn_get_volume_trend` /
  `dq_get_freshness`'s sibling tool.
- **`v_rule_outcomes_latest`** — every *active* rule for a domain with `PASS`/`FAIL`/`NOT_RUN`
  for the latest run (`NOT_RUN`, not `PASS`, for a rule with no matching stats row — it wasn't
  checked, which is a different fact than "checked and passed"). `fn_get_rule_outcomes`.

`dq_get_full_report` (`agent_studio/tools/`) is the "give me everything about this dataset"
tool — it calls `fn_get_summary`, `fn_get_rule_outcomes`, `fn_get_freshness`,
`fn_get_volume_trend`, and (best-effort) `fn_profile_dataset` and assembles one consolidated
answer, instead of making a user chain 4-5 narrower questions themselves.

## The governed function layer (`sql/06_uc_functions.sql` + `sql/07`) — and is this a "Skill"?

**What it is, plainly:** 9 SQL objects (`fn_list_datasets`, `fn_get_rules`, `fn_get_summary`,
`fn_get_failures`, `fn_profile_dataset`, `fn_team_scorecard`, `fn_get_freshness`,
`fn_get_volume_trend`, `fn_get_rule_outcomes`), each `CREATE FUNCTION ... RETURNS TABLE ...
RETURN <query>`. A UC Function is just a named, saved, permissioned SQL query — call it with
`SELECT * FROM governance.dq.fn_get_summary('TELETRACK')` instead of pasting the underlying
`SELECT ... FROM v_run_summary WHERE domain = ...` everywhere.

**What problem it actually solves** — without this layer, "how do I compute a domain's
score" would be a SQL query living *inside* the Python source of `dq_get_summary.py`, copy-
pasted (with drift risk) into `dq_get_failures.py`, again into any future Genie prompt, again
into any BI tool someone points at this later. With the function, that logic exists exactly
once, in the database, versioned by `sql/06`'s file history, permissioned by a normal
`GRANT EXECUTE`. 7 of the 10 Python tools are now thin files that just call one or more
functions and format the JSON — the tool file is a thin adapter, not where the logic lives.

**Why only 7 of the 10 Python tools call a function** — the other 3, and Genie, don't fit the
pattern a `RETURNS TABLE` function is for (a repeatable, parameterized SELECT):

| Tool | Why no `fn_*` |
|---|---|
| `dq_get_dashboard_link` | Runs no SQL at all — it just formats a URL string from `DQ_DASHBOARD_ID`. |
| `dq_run_checks` | Fallback-only: it triggers a Databricks Job via the Jobs API, then reads `v_latest_scorecard` directly with one-off SQL rather than through `fn_get_summary` — a reasonable target to migrate later, just not done, since this path is rare by design. |
| `dq_send_email_report` | Delivery only — formats and sends an email, no SQL at all. |
| `dq_scorecard_genie` (Genie) | Generates a *different* ad-hoc SQL query per question — that's Genie's whole value, so there's no single fixed query to wrap in a function. |

`fn_team_scorecard` is the one function no Python tool wraps on its own — it's there for
Genie's ad-hoc use and any future tool that needs a cross-team rollup. `dq_get_full_report`
is the outlier in the other direction: it calls *five* functions in one tool call
(`fn_get_summary`, `fn_get_rule_outcomes`, `fn_get_freshness`, `fn_get_volume_trend`,
`fn_profile_dataset`) rather than one — see the previous section.

**Is this "Skills"?** Fiserv DCS Agent Studio has no separate "Skill" object distinct from
"Tool." So literally, no: there's no Skills tab to fill in. What UC Functions give you is the
*property* people usually mean by "Skill" — a capability that's defined once, governed, and
reusable by more than one caller — implemented at the database layer instead of the
agent-platform layer. Concretely: a data analyst in a SQL notebook, a completely different
agent, or a future BI dashboard can all call `fn_get_summary` directly, with the exact same
governed logic the DQ Agent's tool uses — none of them need to know a Python Function tool
exists. This design attaches every tool as a plain **Python Function** — see
`agent_studio/BUILD_GUIDE.md`.

## The 2 tables (down from 6)

- **`source_registry`** — one row per team's rules/stats table + a column mapping. Added by
  the platform team writing a `MERGE` directly (see the worked example in
  `sql/02_seed_golden_rules.sql` — the Ingestion team's actual tables, registered, plus a
  commented template for a team with completely different column names). This is
  intentionally a manual step, not something the agent can do — see below.
- **`dataset_registry`** — the one thing genuinely missing upstream: who owns a domain, how
  critical it is, its freshness SLA. Everything else already exists in `dq_rules`/`dq_stats`.

That's the whole schema — no third table. This system has no rule-proposal or staging
mechanism at all; see "New rules," below.

**Why onboarding is manual, not a chat command**: a `column_mapping` value becomes SQL text
embedded directly into a `CREATE VIEW` statement the service principal runs, and a new row
changes what a *shared* view returns to every team reading it — that's a change worth the
same review a schema change gets, not a self-service form. If volume ever makes the manual
step a bottleneck, `docs/RUNBOOK.md`'s roadmap notes the natural next step — not built today,
by choice.

## What this deleted

No more CDF, no more `MERGE`/watermark sync job, no more `source_adapter_registry` with
per-column mapping tracked through a stateful pipeline. `jobs/dq_view_refresh.py` replaced
`jobs/dq_adapter_sync.py` — it only runs when a *new* source is registered, not on every data
change, because a view has no lag to begin with.

## Onboarding a second team (e.g. Data Panel)

Full checklist, plus a detailed worked example for a team whose columns are named nothing
like Ingestion's: `docs/MULTI_TEAM_INTEGRATION.md`. Short version:

1. Get their rule table's and stats table's fully-qualified names + column names.
2. Platform team registers two rows in `source_registry` — a `MERGE` per table
   (`sql/02_seed_golden_rules.sql`'s pattern; each `column_mapping` entry says "their column
   X is our column Y," so differently-named/shaped source columns are absorbed right here).
3. Run `jobs/dq_view_refresh.py` once.
4. Done — their rules and results now show up in `v_rules_unified`/`v_stats_unified`
   alongside Ingestion's, the dashboard, and chat. Their table is still theirs; nothing moved.

## New rules

The agent never writes into `dq_rules` (or any team's own table) — it has no write access to
another team's system by design, and no staging table to record a proposal in either. If a
user wants new coverage, the agent can profile the data (`dq_profile_dataset`) to help shape
the idea, but adding the rule itself is always done by a human on the owning team, directly
in their own table — this system doesn't track the request afterward.

## A real example: TELETRACK domain, `address_should_be_valid` rule

```
domain = TELETRACK, rule = address_should_be_valid, rule_type = validity,
action_if_failed = WARN  →  severity = medium (derived)
```
Ask the agent *"what rules does TELETRACK have?"* → tool `dq_get_rules(domain='TELETRACK')` →
calls `SELECT * FROM governance.dq.fn_get_rules('TELETRACK')` → the function reads
`v_rules_unified` → returns this row (and every other TELETRACK rule) straight from
`dq_rules`, live. Any SQL user with `EXECUTE` grant can run that same function call directly,
outside the agent entirely.
