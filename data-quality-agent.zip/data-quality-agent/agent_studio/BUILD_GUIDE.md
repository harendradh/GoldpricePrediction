# Build the Data Quality Agent in Fiserv DCS Agent Studio (copy-paste walkthrough)

Everything is built in the Agent Studio UI. There is NO separate FastAPI/Docker service —
Agent Studio already runs on ACA. Tools are **Python Functions** you paste in, or **native
Databricks Genie** tools (config only, no code). This system reads existing team tables
directly through 3 views, via a **Unity Catalog Function layer** — see
`../docs/UNIFIED_VIEWS.md` before you start; it explains why there's no engine to deploy, no
sync job, and only 2 small control tables.

```
Agent Studio (ACA)                              Databricks
  Agent "DQ Agent" (databricks-claude-sonnet-4-6)  ┌───────────────────────────────┐
    └─ Tools                                        │ dq_rules, dq_stats,           │
    │    ├─ 10 × Python Function ──REST──►           │ dp_*_status  (Ingestion, etc.)│
    │    └─ 1 × Databricks Genie ──OAuth2──►         │      │ (read-only, via view)   │
    └─ RAG: DQ Knowledge + DQ Rule Reference          │ v_rules_unified / v_stats_    │
                                                       │ unified / v_profile_unified   │
                                                       │      │                       │
                                                       │ governance.dq.fn_*            │
                                                       │ (UC Functions — the governed, │
                                                       │  reusable layer; 9 functions, │
                                                       │  7 of the 10 Python tools     │
                                                       │  are thin wrappers over these)│
                                                       │      │                       │
                                                       │ Lakeview: DQ Enterprise       │
                                                       │ Scorecard                    │
                                                       └───────────────────────────────┘
```

## Prerequisites (do these on Databricks once)

1. Run, in order: `../sql/01_control_tables.sql`, `../sql/02_seed_golden_rules.sql`
   (registers the Ingestion team's real tables — the worked example),
   `../sql/03_scale_optimizations.sql` (the 3 unified views), `../sql/04_dashboard_and_alerts.sql`,
   `../sql/05_dashboard_extensions.sql`, `../sql/06_uc_functions.sql` (the governed function
   layer every read-only tool calls), `../sql/07_freshness_and_reports.sql` (freshness/volume/
   full-rule-outcome views — see its header for the `loaded_ts` mapping caveat) on a SQL
   Warehouse.
2. `CREATE VOLUME IF NOT EXISTS governance.dq.rag_exports;` (feeds the RAG Rule Reference).
3. Deploy: `databricks bundle deploy --var="warehouse_id=<your warehouse id>"` (see
   `../deploy/databricks.job.yml` — installs `dq_view_refresh` and the
   `DQ Enterprise Scorecard` dashboard). Note the **dashboard id**.
4. Create a **service principal / PAT** with `SELECT` on `prod_dcs_catalog.df_app_configs.*`
   and `prod_dcs_catalog.data_profile.*` (read-only — this system never writes to source
   tables), `SELECT`/`MODIFY` on `governance.dq.*`, and `EXECUTE` on the `governance.dq.fn_*`
   functions (`sql/06_uc_functions.sql`'s footer has a grant example).
5. Create a **Genie Space** scoped to `governance.dq.*` views only — never raw source tables.
   Grab the **space id** from its URL: `.../genie/spaces/<space-id>`.
6. Create an **OAuth service principal** for Genie: `GENIE_CLIENT_ID`/`GENIE_CLIENT_SECRET`,
   set once in `backend/.env`.

## Step 0 — Credentials

| Used by | Vars | Where set |
|---|---|---|
| 10 Python Function tools | `DATABRICKS_HOST`, `DATABRICKS_TOKEN`, `SQL_WAREHOUSE_ID`, `DQ_CONTROL_SCHEMA` (default `governance.dq`), `DQ_DASHBOARD_ID`, `DQ_FALLBACK_JOB_ID` (optional, see Step 1) | Tool-sandbox env vars — **confirm the exact mechanism with your platform admin before Step 1**, see note below |
| `dq_send_email_report` only | `SMTP_HOST`, `SMTP_PORT` (default 587), `SMTP_USERNAME`, `SMTP_PASSWORD`, `EMAIL_FROM` — a genuinely new external dependency; get these from your infra team | Tool-sandbox env vars |
| 1 native Genie tool | `GENIE_CLIENT_ID`, `GENIE_CLIENT_SECRET` | `backend/.env` |

**Where exactly do "tool-sandbox env vars" live?** Unconfirmed, and worth checking before you
paste anything: the Python Function tool creation form has no visible credential-config
section the way the Genie tool type does (see
`../docs/reviews/agent_studio_additional_findings.md` #10 — a platform gap, not something this
guide is glossing over). All 10 Python tools read the identical `DATABRICKS_HOST`/
`DATABRICKS_TOKEN` pair independently at call time, so ask your platform admin which of these
it actually is, in this order of preference:
1. **Agent-level shared env vars** — set once, applied to every tool attached to `DQ Agent`.
2. **A reusable Connection/Secret resource** — attached per-tool but backed by one credential
   store, so rotation is still one action.
3. **Per-tool env var fields** — pasted into each of the 10 tools' own config screens
   individually. If this is genuinely the only option, treat it as a known limitation, not a
   normal setup step: one `DATABRICKS_TOKEN` copied 10 times means 10 places to rotate it, and
   an OAuth service-principal token (rather than a static PAT) is worth asking for instead of
   `DATABRICKS_TOKEN` for the same reason `GENIE_CLIENT_ID`/`SECRET` uses OAuth below.

## Step 1 — Create the 10 Python Function tools  (left nav → Tools → New Tool)

For EACH file in `./tools/`:
- **Type**: `Python Function`
- **Name** / **Function Name**: the function name
- **Description**: copy the first line of the function's docstring
- **Code**: paste the ENTIRE file contents

| Tool | Description to paste | Calls |
|---|---|---|
| `dq_list_datasets` | List domains with data-quality coverage, optionally filtered by owning team. | `fn_list_datasets` |
| `dq_get_summary` | Return the latest data-quality scorecard for a domain, straight from dq_stats. | `fn_get_summary` |
| `dq_get_failures` | Return failing rules from the most recent job run, with suggested remediation. | `fn_get_failures` |
| `dq_get_rules` | List the data-quality rules configured for a domain. | `fn_get_rules` |
| `dq_profile_dataset` | Return column profiling for a domain's pipeline, from the existing profiler. | `fn_profile_dataset` |
| `dq_get_freshness` | Is this domain's pipeline still reporting on schedule, vs its configured SLA. | `fn_get_freshness` |
| `dq_get_full_report` | The complete report for one domain: score, every rule's pass/fail, freshness, volume trend, profile. | 5 functions (see below) |
| `dq_run_checks` | OPTIONAL fallback — only does something if a fallback engine is deployed. | — |
| `dq_get_dashboard_link` | Return the URL of the enterprise Data Quality dashboard. | — |
| `dq_send_email_report` | Send an email — only used by the scheduled digest workflow. | — |

7 of these are thin wrappers over `governance.dq.fn_*` (`sql/06_uc_functions.sql` +
`sql/07_freshness_and_reports.sql`) — the actual query logic lives there, once, governed by
Unity Catalog grants, not duplicated per tool file. `dq_get_full_report` alone calls 5:
`fn_get_summary`, `fn_get_rule_outcomes`, `fn_get_freshness`, `fn_get_volume_trend`, and
(best-effort) `fn_profile_dataset`. `fn_team_scorecard` is the one function no Python tool
wraps — it's there for Genie's ad-hoc NL queries and future reuse.

**This agent has no rule-proposal or staging tool.** It can profile a dataset and describe
what a new rule should check, but adding the rule itself is always a conversation with the
owning team, done in their own rule table — never something this system records or tracks.

**Onboarding a new team's table is a platform-team action, not something the agent does.**
There's no self-service registration tool by design — a new `source_registry` row changes
what a shared view returns to every team, so it goes through the same review a schema change
would. See `../docs/MULTI_TEAM_INTEGRATION.md`.

## Step 2 — Create the native Genie tool

- **Name**: `dq_scorecard_genie`
- **Type**: `Databricks Genie`
- **Genie Space ID**: from Prerequisite 5
- **OAuth2 scope**: `all-apis`

## Step 3 — Create the RAG collections

- **`DQ Knowledge`** (static): upload `./rag/dq_knowledge.md`. `BGE Model · 1024d`, chunk 512/50.
- **`DQ Rule Reference`** (generated nightly by `dq_view_refresh`'s `rag_refresh` task):
  upload `/Volumes/governance/dq/rag_exports/dq_rule_reference.md` after the first job run.

## Step 4 — Create the Agent

- **Name**: `DQ Agent`, **Type**: `Single`, **Provider**: `Databricks`,
  **Model**: `databricks-claude-sonnet-4-6`
- **System Instruction**: paste `./agents/single_agent_system_instruction.txt` verbatim
- **Output Key**: `dq_result`
- **Tools**: all 11 (10 Python Function + `dq_scorecard_genie`)
- **RAG Collections**: both `DQ Knowledge` and `DQ Rule Reference`
- **Callbacks**: **Log Requests** + **Rate Limit**

## Step 5 — Smoke-test in Sandbox

1. `What domains are registered for the Ingestion team?` → `dq_list_datasets`.
2. `What's the data quality of TELETRACK?` → `dq_get_summary`.
3. `Why did it fail?` → `dq_get_failures`.
4. `What rules does corebanking_tran_ct have?` → `dq_get_rules`.
5. `Is TELETRACK's data current?` → `dq_get_freshness`.
6. `Give me a full DQ report on TELETRACK.` → `dq_get_full_report`.
7. `Which team has the most RED domains this week?` → `dq_scorecard_genie`.
8. `Show me the dashboard.` → `dq_get_dashboard_link`.

`dq_send_email_report` isn't part of this smoke test — it needs real SMTP credentials (Step
0) and is meant to be called by the scheduled digest workflow, not tested ad hoc in Sandbox
unless you want a real email sent.

## Rollout to another team

Full checklist, and a worked example for a team whose columns are named completely
differently: `../docs/MULTI_TEAM_INTEGRATION.md`. In short — the platform team writes 2
`MERGE` statements into `source_registry` (see `sql/02` for the pattern), maps their column
names to the shape each view expects, then re-runs `dq_view_refresh`. Nothing here — tools,
agent, RAG — needs to change.

## Optional: scheduled email digest

Leverages Agent Studio's own Workflow + Schedule feature to send a daily posture digest
without anyone asking. See `agents/workflow_scheduled_digest.md`.
