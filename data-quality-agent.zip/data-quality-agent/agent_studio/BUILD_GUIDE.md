# Build the Data Quality Agent in Fiserv DCS Agent Studio (copy-paste walkthrough)

Everything is built in the Agent Studio UI at `dcs-agent-studio.<...>.azurecontainerapps.io`.
There is NO separate FastAPI/Docker service — Agent Studio already runs on ACA. Tools are
either **Python Functions** you paste in, or **native Databricks Genie** tools (config only,
no code). Checks execute as a Databricks **Job** (the native engine in `../jobs/` +
`../src/dq_agent/engine/`).

```
Agent Studio (ACA)                              Databricks
  Agent "DQ Agent" (databricks-claude-sonnet-4-6)  ┌───────────────────────────────┐
    └─ Tools                                       │ Jobs API      ► DQ Job (engine)│──► Delta results
    │    ├─ 8 × Python Function ──REST──►           │ SQL Warehouse ► control tables │◄── read scorecard
    │    └─ 1 × Databricks Genie ──OAuth2──►        │ Genie Space   ► governance.dq.* │◄── NL Q&A
    └─ RAG Collection: DQ Knowledge                 └───────────────────────────────┘
    └─ (optional) Workflow: DQ Workflow
```

RAG and Genie are complementary, not either/or: RAG grounds the agent in static knowledge
(dimension definitions, scoring rubric, remediation playbook); the Genie tool is a live
capability the agent calls for ad-hoc natural-language questions over the DQ result tables.
Both attach to the same agent.

## Prerequisites (do these on Databricks once)

1. Run `../sql/01_control_tables.sql`, `../sql/03_scale_optimizations.sql`,
   `../sql/04_dashboard_and_alerts.sql`, then `../sql/02_seed_golden_rules.sql` on a SQL Warehouse.
2. Deploy the jobs: `databricks bundle deploy` (see `../deploy/databricks.job.yml` — installs
   `dq_check`, the `dq_sweep` for-each fan-out, and the monitor refresh). Note the
   **dq_check job_id** and your **warehouse_id**. Runs in **POC mode** by default (no wheel
   build — see `../docs/SETUP_GUIDE.md` Phase 2 for the production switch).
3. Create a **service principal / PAT** with: run the DQ jobs, use the warehouse,
   SELECT on target data, SELECT+MODIFY on `governance.dq.*`, and (for monitors) `USE`/manage
   Lakehouse Monitoring on target schemas. This is the identity behind `DATABRICKS_TOKEN` below.
4. Scale/coverage design and the aspect→capability matrix live in `../docs/ARCHITECTURE.md`.
   The nightly `dq_sweep` job (serverless `for_each`) is what scales to thousands of tables;
   the agent's `dq_run_checks` is for on-demand single-dataset runs.
5. Create a **Genie Space** scoped ONLY to `governance.dq.*` tables (`results`, `run_summary`,
   `dataset_registry`, `rule_catalog`) — never raw source data. This keeps the "agent never
   reads raw rows" guarantee even for free-form NL questions. Grab the **space id** from its
   URL: `.../genie/spaces/<space-id>`.
6. Create (or reuse) an **OAuth service principal** for Genie: `GENIE_CLIENT_ID` /
   `GENIE_CLIENT_SECRET`, scoped to that Genie Space. This is a platform-level secret, set
   once in `backend/.env` — ask your Agent Studio platform admin if you don't have access.

## Step 0 — Credentials

Two separate credential paths:

| Used by | Vars | Where set |
|---|---|---|
| 8 Python Function tools (REST calls) | `DATABRICKS_HOST`, `DATABRICKS_TOKEN`, `DQ_JOB_ID`, `SQL_WAREHOUSE_ID`, `DQ_CONTROL_SCHEMA` (default `governance.dq`) | Tool-sandbox env vars — confirm with the platform team how these are injected (Container App env vars or a secrets store) |
| 1 native Genie tool (OAuth2) | `GENIE_CLIENT_ID`, `GENIE_CLIENT_SECRET` | `backend/.env` (platform-wide default). Only override the var names on the tool form if you need a second, differently-scoped Genie space later. |

## Step 1 — Create the 8 Python Function tools  (left nav → Tools → New Tool)

For EACH file in `./tools/`:
- **Type**: `Python Function`
- **Name** / **Function Name**: the function name, e.g. `dq_run_checks`
- **Description**: copy the first line of the function's docstring
- **Code**: paste the ENTIRE file contents

| Tool name | Description (paste as-is) |
|---|---|
| `dq_list_datasets` | List registered datasets, optionally filtered by business unit. |
| `dq_get_summary` | Return the latest data-quality scorecard for a dataset without re-running checks. |
| `dq_run_checks` | Trigger the Databricks DQ job for a dataset, wait for completion, return the scorecard. |
| `dq_get_failures` | Return failing rules and remediation guidance for a dataset's latest run. |
| `dq_get_rules` | List configured data-quality rules for a dataset. |
| `dq_profile_dataset` | Return schema, null%, and distinct-value profile for a dataset. |
| `dq_propose_rule` | Create a DISABLED candidate rule for a dataset (human-in-the-loop). |
| `dq_get_drift` | Return native Lakehouse Monitoring drift/distribution signals for a dataset. |

## Step 2 — Create the native Genie tool  (left nav → Tools → New Tool)

- **Name**: `dq_scorecard_genie`
- **Description**: `Ask ad-hoc natural-language questions over DQ control/result tables (governance.dq.* only — never raw source data).`
- **Type**: `Databricks Genie`
- **Genie Space ID**: `<the space id from Prerequisite 5>`
- **Databricks Host**: `https://<your-workspace>.azuredatabricks.net`
- **Token URL**: leave blank (defaults to `{host}/oidc/v1/token`)
- **Client ID / secret env var**: leave as the defaults `GENIE_CLIENT_ID` / `GENIE_CLIENT_SECRET`
  unless this is a second Genie space
- **OAuth2 scope**: `all-apis`
- Click **Create Tool**.

No code needed — this replaces what would otherwise be a hand-written REST wrapper.

## Step 3 — Create the RAG collection  (left nav → RAG → New Collection)

- **Name**: `DQ Knowledge`
- **Description**: `Data quality dimensions, rule types, scoring, and remediation playbook`
- **Embedding Model**: `BGE Model · 1024d` (default/recommended — leave as-is)
- **Chunk Size**: `512`   **Chunk Overlap**: `50`   (defaults are fine for this doc)
- Click **Create Collection**, then upload `./rag/dq_knowledge.md`.

## Step 4 — Create the Agent  (left nav → Agents → New Agent)

- **Name**: `DQ Agent`
- **Description**: `Assesses, monitors, and explains data quality for Delta tables across BUs.`
- **Agent Type**: `Single`
- **Provider**: `Databricks`   **Model**: `databricks-claude-sonnet-4-6`
- **System Instruction**: paste `./agents/single_agent_system_instruction.txt` verbatim
  (it already uses the `{user_question}` and `{rag_context}` placeholders)
- **Output Key**: `dq_result`
- **Tools**: check all 9 — the 8 Python Function tools from Step 1 + `dq_scorecard_genie`
- **RAG Collections**: check `DQ Knowledge`
- **Callbacks**: enable **Log Requests** (audit) and **Rate Limit** (guardrail);
  enable **Content Filter** too if your BU policy requires it
- Click **Create Agent**.

## Step 5 — Smoke-test in Sandbox  (left nav → Sandbox → select "DQ Agent" → New Chat)

Run these in order before calling it onboarded:

1. `What datasets are registered for the payments BU?` → exercises `dq_list_datasets`.
2. `What's the data quality of payments.txn_master?` → exercises `dq_run_checks`, verdict
   should lead with score + RAG status.
3. `Why did it fail?` → exercises `dq_get_failures`, should explain in business terms.
4. `Profile payments.txn_master and suggest any missing rules.` → exercises
   `dq_profile_dataset` + `dq_propose_rule`; confirm the agent states the new rule is
   **disabled pending owner approval**.
5. `Which BU has the most RED datasets this week?` → exercises `dq_scorecard_genie`
   (a question the fixed tools can't answer directly).

If step 5 errors, re-check the Genie Space ID/host and that `GENIE_CLIENT_ID`/`SECRET` are
set in `backend/.env`.

## Step 6 (optional) — Workflow for staged/audited execution

Only if you want separation of duties (profile → run → analyze as distinct audited steps).
Follow `./agents/workflow_subagents.md` to create `dq_profiler`, `dq_runner`, `dq_analyst`
Single agents first, then:

- left nav → Workflows → **New Workflow**
- **Name**: `DQ Workflow`   **Description**: `Staged data-quality review: profile, run, analyze.`
- **Type**: `Custom` (Orchestrator coordinates sub-agents)
- Drag `dq_profiler` → `dq_runner` → `dq_analyst` onto the canvas between Start and End
- Test it the same way as Step 5, via Sandbox, selecting "DQ Workflow" instead of the agent

## Rollout across BUs

- Onboard a dataset = INSERT into `dataset_registry` + `rule_catalog` (or ask the agent to
  profile it and `dq_propose_rule`, then approve). No agent change, no redeploy.
- Add BU-specific agents by cloning `DQ Agent` and attaching the same 9 tools + RAG collection.
- Schedule nightly sweeps via Agent Studio **Schedules** or a Databricks Job cron.
