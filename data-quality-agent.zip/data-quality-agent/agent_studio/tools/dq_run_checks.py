# =====================================================================
# Agent Studio Tool  ::  dq_run_checks
# Type: Python Function   |   Function Name: dq_run_checks
# Paste this ENTIRE block into the "Code" box of a New Tool.
# ---------------------------------------------------------------------
# Requires these env vars available to the Agent Studio sandbox:
#   DATABRICKS_HOST      e.g. https://adb-xxxx.azuredatabricks.net
#   DATABRICKS_TOKEN     PAT or SP token with run + SQL access
#   DQ_JOB_ID            job id of the "[DQA] Data Quality Check" job
#   SQL_WAREHOUSE_ID     warehouse id for reading control tables
#   DQ_CONTROL_SCHEMA    (optional) default governance.dq
# =====================================================================
import os, json, time, urllib.request, urllib.parse


def _dbx(method, path, body=None):
    host = os.environ["DATABRICKS_HOST"].rstrip("/")
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(
        host + path, data=data, method=method,
        headers={"Authorization": "Bearer " + os.environ["DATABRICKS_TOKEN"],
                 "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=90) as r:
        return json.loads(r.read().decode() or "{}")


def _sql(statement, params=None):
    body = {"warehouse_id": os.environ["SQL_WAREHOUSE_ID"], "statement": statement,
            "wait_timeout": "30s", "on_wait_timeout": "CONTINUE"}
    if params:
        body["parameters"] = params
    out = _dbx("POST", "/api/2.0/sql/statements", body)
    sid = out.get("statement_id")
    st = out.get("status", {}).get("state")
    deadline = time.time() + 900
    while st in ("PENDING", "RUNNING") and time.time() < deadline:
        time.sleep(1.5)
        out = _dbx("GET", "/api/2.0/sql/statements/" + sid)
        st = out.get("status", {}).get("state")
    if st != "SUCCEEDED":
        raise RuntimeError("SQL failed: " + json.dumps(out.get("status")))
    cols = [c["name"] for c in out.get("manifest", {}).get("schema", {}).get("columns", [])]
    return [dict(zip(cols, row)) for row in out.get("result", {}).get("data_array", [])]


def dq_run_checks(dataset_id: str, rule_ids: str = "") -> dict:
    """Run data-quality checks on a registered Delta dataset and return its scorecard.

    Triggers the Databricks DQ job, waits for it to finish, then returns the overall
    quality score (0-100), RAG status, pass/fail counts, and per-dimension scores.

    Args:
        dataset_id: registered dataset id, e.g. 'payments.txn_master'.
        rule_ids: optional comma-separated rule ids to run a subset; empty = all enabled rules.
    """
    schema = os.environ.get("DQ_CONTROL_SCHEMA", "governance.dq")
    # 1. trigger the job (job-level parameters match the asset bundle)
    run = _dbx("POST", "/api/2.1/jobs/run-now", {
        "job_id": int(os.environ["DQ_JOB_ID"]),
        "job_parameters": {"dataset_id": dataset_id, "rule_ids": rule_ids, "triggered_by": "agent"},
    })
    run_id = str(run["run_id"])

    # 2. poll to completion
    deadline = time.time() + 1800
    state = {}
    while time.time() < deadline:
        info = _dbx("GET", "/api/2.1/jobs/runs/get?" + urllib.parse.urlencode({"run_id": run_id}))
        state = info.get("state", {})
        if state.get("life_cycle_state") in ("TERMINATED", "SKIPPED", "INTERNAL_ERROR"):
            break
        time.sleep(10)

    # 3. read the scored summary the engine wrote to Delta
    rows = _sql(
        "SELECT overall_score, rag_status, total_rules, passed_rules, failed_rules, "
        "critical_failures, dimension_scores, run_id, run_ts "
        f"FROM {schema}.v_latest_scorecard WHERE dataset_id = :dataset_id",
        [{"name": "dataset_id", "value": dataset_id}])
    summary = rows[0] if rows else {"note": "no summary written; check job run " + run_id}
    return {"dataset_id": dataset_id, "job_run_id": run_id,
            "result_state": state.get("result_state"), "summary": summary}
