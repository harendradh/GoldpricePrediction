# =====================================================================
# Agent Studio Tool  ::  dq_run_checks
# Type: Python Function   |   Function Name: dq_run_checks
# ---------------------------------------------------------------------
# OPTIONAL / FALLBACK ONLY. For any domain the Ingestion team (or another
# team) already checks, dq_get_summary is the right tool — it reads dq_stats
# directly, which is always at least as fresh as that team's own pipeline
# schedule. This tool exists only for a domain with NO existing DQ pipeline:
# it triggers the fallback engine (src/dq_agent/engine — optional, see
# docs/ARCHITECTURE.md) to run a one-off check and write a row this system
# CAN read back through the same v_latest_scorecard view.
#
# Requires (only if you deploy the optional fallback engine — see
# deploy/databricks.job.yml "optional_fallback_engine" jobs, commented out
# by default):
#   DATABRICKS_HOST, DATABRICKS_TOKEN, SQL_WAREHOUSE_ID, DQ_FALLBACK_JOB_ID
# =====================================================================
import os, json, time, urllib.request, urllib.parse


def _dbx(method, path, body=None):
    host = os.environ["DATABRICKS_HOST"].rstrip("/")
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(
        host + path, data=data, method=method,
        headers={"Authorization": "Bearer " + os.environ["DATABRICKS_TOKEN"],
                 "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=90) as r:
        return json.loads(r.read().decode() or "{}")


def _sql(statement, params=None):
    body = {"warehouse_id": os.environ["SQL_WAREHOUSE_ID"], "statement": statement,
            "wait_timeout": "30s", "on_wait_timeout": "CONTINUE"}
    if params:
        body["parameters"] = params
    out = _dbx("POST", "/api/2.0/sql/statements", body)
    sid = out.get("statement_id")
    st = out.get("status", {}).get("state")
    deadline = time.time() + 900
    while st in ("PENDING", "RUNNING") and time.time() < deadline:
        time.sleep(1.5)
        out = _dbx("GET", "/api/2.0/sql/statements/" + sid)
        st = out.get("status", {}).get("state")
    if st != "SUCCEEDED":
        raise RuntimeError("SQL failed: " + json.dumps(out.get("status")))
    cols = [c["name"] for c in out.get("manifest", {}).get("schema", {}).get("columns", [])]
    return [dict(zip(cols, row)) for row in out.get("result", {}).get("data_array", [])]


def dq_run_checks(domain: str, sub_domain: str = "") -> dict:
    """Trigger a one-off fallback check for a domain that has NO existing DQ pipeline.

    Most domains already have quality checked by the team that owns them (Ingestion's
    dq_check pipeline, etc.) — for those, call dq_get_summary instead; it's just as fresh and
    doesn't spend compute re-running anything. Only call this when dq_get_summary comes back
    empty AND the domain genuinely has no owning pipeline yet.

    Args:
        domain: e.g. 'TELETRACK', 'corebanking_tran_ct', 'zeta'.
        sub_domain: optional.
    """
    schema = os.environ.get("DQ_CONTROL_SCHEMA", "governance.dq")
    fallback_job_id = os.environ.get("DQ_FALLBACK_JOB_ID")
    if not fallback_job_id:
        return {"domain": domain, "sub_domain": sub_domain,
                "error": "No fallback engine configured for this deployment. This system reads "
                          "existing team pipelines (dq_stats, dp_*_status) — it doesn't run "
                          "checks itself unless the optional fallback engine is deployed. "
                          "See docs/ARCHITECTURE.md."}

    run = _dbx("POST", "/api/2.1/jobs/run-now", {
        "job_id": int(fallback_job_id),
        "job_parameters": {"domain": domain, "sub_domain": sub_domain, "triggered_by": "agent"},
    })
    run_id = str(run["run_id"])

    deadline = time.time() + 1800
    state = {}
    while time.time() < deadline:
        info = _dbx("GET", "/api/2.1/jobs/runs/get?" + urllib.parse.urlencode({"run_id": run_id}))
        state = info.get("state", {})
        if state.get("life_cycle_state") in ("TERMINATED", "SKIPPED", "INTERNAL_ERROR"):
            break
        time.sleep(10)

    where = "domain = :d" + (" AND sub_domain = :sd" if sub_domain else " AND sub_domain IS NULL")
    params = [{"name": "d", "value": domain}]
    if sub_domain:
        params.append({"name": "sd", "value": sub_domain})
    rows = _sql(f"SELECT * FROM {schema}.v_latest_scorecard WHERE {where}", params)
    summary = rows[0] if rows else {"note": "no summary written; check job run " + run_id}
    return {"domain": domain, "sub_domain": sub_domain, "job_run_id": run_id,
            "result_state": state.get("result_state"), "summary": summary}
