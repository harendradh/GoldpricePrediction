# Agent Studio Tool :: dq_get_failures  (Type: Python Function, Function Name: dq_get_failures)
# Thin wrapper over governance.dq.fn_get_failures (see sql/06_uc_functions.sql). This tool
# adds only the remediation playbook lookup — a pure-Python narrative layer over the
# governed function's rows, not a second copy of the query logic.
import os, json, time, urllib.request


def _dbx(method, path, body=None):
    host = os.environ["DATABRICKS_HOST"].rstrip("/")
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(host + path, data=data, method=method,
        headers={"Authorization": "Bearer " + os.environ["DATABRICKS_TOKEN"],
                 "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=90) as r:
        return json.loads(r.read().decode() or "{}")


def _sql(statement, params=None):
    body = {"warehouse_id": os.environ["SQL_WAREHOUSE_ID"], "statement": statement,
            "wait_timeout": "30s", "on_wait_timeout": "CONTINUE"}
    if params:
        body["parameters"] = params
    out = _dbx("POST", "/api/2.0/sql/statements", body)
    sid, st = out.get("statement_id"), out.get("status", {}).get("state")
    while st in ("PENDING", "RUNNING"):
        time.sleep(1.5)
        out = _dbx("GET", "/api/2.0/sql/statements/" + sid)
        st = out.get("status", {}).get("state")
    if st != "SUCCEEDED":
        raise RuntimeError("SQL failed: " + json.dumps(out.get("status")))
    cols = [c["name"] for c in out.get("manifest", {}).get("schema", {}).get("columns", [])]
    return [dict(zip(cols, row)) for row in out.get("result", {}).get("data_array", [])]


_PLAYBOOK = {
    "not_null": "Backfill or reject nulls upstream; add a NOT NULL constraint once stable.",
    "unique": "Deduplicate on the key; check for double-load or a missing MERGE key.",
    "referential": "Quarantine orphan rows; fix load order so the parent lands first.",
    "freshness": "Check the upstream job/scheduler SLA; alert the data owner.",
    "range": "Validate source mapping/units; clamp or reject out-of-range values.",
    "standardization": "Reconcile formatting rules (e.g. address/name standardization) with source.",
    "validity": "Reconcile the domain/enum or format with source reference data.",
    "overlap": "Investigate duplicate/overlapping records across the merge/dedup key.",
}


def dq_get_failures(domain: str, sub_domain: str = "") -> dict:
    """Return failing rules from the most recent job run for a domain, with suggested
    remediation per failure.

    Args:
        domain: e.g. 'TELETRACK', 'corebanking_tran_ct', 'zeta'.
        sub_domain: optional; most domains only have one.
    """
    schema = os.environ.get("DQ_CONTROL_SCHEMA", "governance.dq")
    rows = _sql(f"SELECT * FROM {schema}.fn_get_failures(:d, :sd)",
                [{"name": "d", "value": domain}, {"name": "sd", "value": sub_domain or None}])
    for r in rows:
        rt = (r.get("rule_name") or "").lower()
        key = next((k for k in _PLAYBOOK if k in rt), None)
        r["suggested_action"] = _PLAYBOOK.get(key, "Investigate with the data owner.")
    return {"domain": domain, "sub_domain": sub_domain, "failure_count": len(rows), "failures": rows}
