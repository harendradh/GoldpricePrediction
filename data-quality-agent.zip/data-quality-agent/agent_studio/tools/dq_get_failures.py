# Agent Studio Tool :: dq_get_failures  (Type: Python Function, Function Name: dq_get_failures)
import os, json, time, urllib.request


def _dbx(method, path, body=None):
    host = os.environ["DATABRICKS_HOST"].rstrip("/")
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(host + path, data=data, method=method,
        headers={"Authorization": "Bearer " + os.environ["DATABRICKS_TOKEN"],
                 "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=90) as r:
        return json.loads(r.read().decode() or "{}")


def _sql(statement, params=None):
    body = {"warehouse_id": os.environ["SQL_WAREHOUSE_ID"], "statement": statement,
            "wait_timeout": "30s", "on_wait_timeout": "CONTINUE"}
    if params:
        body["parameters"] = params
    out = _dbx("POST", "/api/2.0/sql/statements", body)
    sid, st = out.get("statement_id"), out.get("status", {}).get("state")
    while st in ("PENDING", "RUNNING"):
        time.sleep(1.5)
        out = _dbx("GET", "/api/2.0/sql/statements/" + sid)
        st = out.get("status", {}).get("state")
    if st != "SUCCEEDED":
        raise RuntimeError("SQL failed: " + json.dumps(out.get("status")))
    cols = [c["name"] for c in out.get("manifest", {}).get("schema", {}).get("columns", [])]
    return [dict(zip(cols, row)) for row in out.get("result", {}).get("data_array", [])]


# Deterministic remediation playbook the agent narrates (no data mutation happens here).
_PLAYBOOK = {
    "not_null": "Backfill or reject nulls upstream; add a NOT NULL constraint once stable.",
    "unique": "Deduplicate on the key; check for double-load or a missing MERGE key.",
    "referential": "Quarantine orphan rows; fix load order so the parent lands first.",
    "freshness": "Check the upstream job/scheduler SLA; alert the data owner.",
    "range": "Validate source mapping/units; clamp or reject out-of-range values.",
    "accepted_values": "Reconcile the domain/enum with source reference data.",
    "regex": "Standardize formatting at ingestion before load.",
    "expression": "Review the business rule with the owner; correct upstream logic.",
    "row_count_anomaly": "Check for partial load, duplicate load, or a source outage.",
    "custom_sql": "Review the custom rule with its author.",
}


def dq_get_failures(dataset_id: str) -> dict:
    """Return the failing rules from the latest run plus suggested remediation per failure.

    Use this for triage / root-cause when a dataset is AMBER or RED.

    Args:
        dataset_id: registered dataset id, e.g. 'payments.txn_master'.
    """
    schema = os.environ.get("DQ_CONTROL_SCHEMA", "governance.dq")
    rows = _sql(
        "SELECT rule_id, dimension, rule_type, target_column, severity, failed_rows, "
        "total_rows, violation_rate, message, sample_bad_keys "
        f"FROM {schema}.results WHERE dataset_id = :d AND passed = false "
        f"AND run_id = (SELECT run_id FROM {schema}.run_summary WHERE dataset_id = :d "
        "ORDER BY run_ts DESC LIMIT 1) ORDER BY severity",
        [{"name": "d", "value": dataset_id}])
    for r in rows:
        r["suggested_action"] = _PLAYBOOK.get(r.get("rule_type"), "Investigate with the data owner.")
    return {"dataset_id": dataset_id, "failure_count": len(rows), "failures": rows}
