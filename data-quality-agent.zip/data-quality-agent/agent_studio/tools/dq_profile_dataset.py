# Agent Studio Tool :: dq_profile_dataset  (Type: Python Function, Function Name: dq_profile_dataset)
import os, json, time, urllib.request


def _dbx(method, path, body=None):
    host = os.environ["DATABRICKS_HOST"].rstrip("/")
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(host + path, data=data, method=method,
        headers={"Authorization": "Bearer " + os.environ["DATABRICKS_TOKEN"],
                 "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=90) as r:
        return json.loads(r.read().decode() or "{}")


def _sql(statement, params=None):
    body = {"warehouse_id": os.environ["SQL_WAREHOUSE_ID"], "statement": statement,
            "wait_timeout": "30s", "on_wait_timeout": "CONTINUE"}
    if params:
        body["parameters"] = params
    out = _dbx("POST", "/api/2.0/sql/statements", body)
    sid, st = out.get("statement_id"), out.get("status", {}).get("state")
    while st in ("PENDING", "RUNNING"):
        time.sleep(1.5)
        out = _dbx("GET", "/api/2.0/sql/statements/" + sid)
        st = out.get("status", {}).get("state")
    if st != "SUCCEEDED":
        raise RuntimeError("SQL failed: " + json.dumps(out.get("status")))
    cols = [c["name"] for c in out.get("manifest", {}).get("schema", {}).get("columns", [])]
    return [dict(zip(cols, row)) for row in out.get("result", {}).get("data_array", [])]


def dq_profile_dataset(dataset_id: str) -> dict:
    """Profile a registered dataset: schema, row count, and per-column null% + distinct count.

    Use this before proposing new rules (call dq_propose_rule with what you learn).

    Args:
        dataset_id: registered dataset id, e.g. 'payments.txn_master'.
    """
    schema = os.environ.get("DQ_CONTROL_SCHEMA", "governance.dq")
    reg = _sql(
        "SELECT target_catalog, target_schema, target_table "
        f"FROM {schema}.dataset_registry WHERE dataset_id = :d",
        [{"name": "d", "value": dataset_id}])
    if not reg:
        return {"dataset_id": dataset_id, "error": "dataset not registered"}
    r = reg[0]
    fq = f"{r['target_catalog']}.{r['target_schema']}.{r['target_table']}"

    cols = [c for c in _sql(f"DESCRIBE {fq}")
            if c.get("col_name") and not c["col_name"].startswith("#")]
    total = _sql(f"SELECT COUNT(*) AS c FROM {fq}")[0]["c"]

    # one aggregate scan for null% + approx distinct across all columns
    parts = []
    for c in cols[:60]:
        name = c["col_name"]
        parts.append(f"SUM(CASE WHEN `{name}` IS NULL THEN 1 ELSE 0 END) AS `null__{name}`")
        parts.append(f"approx_count_distinct(`{name}`) AS `dist__{name}`")
    stats = _sql(f"SELECT {', '.join(parts)} FROM {fq}")[0] if parts else {}

    profile = []
    for c in cols[:60]:
        name = c["col_name"]
        nulls = int(stats.get(f"null__{name}", 0) or 0)
        distinct = int(stats.get(f"dist__{name}", 0) or 0)
        profile.append({
            "column": name, "data_type": c.get("data_type"),
            "null_pct": round(nulls / total * 100, 3) if total else 0.0,
            "approx_distinct": distinct,
            "candidate_key": bool(total and distinct >= total * 0.99),
        })
    return {"dataset_id": dataset_id, "fq_table": fq, "row_count": total, "columns": profile}
