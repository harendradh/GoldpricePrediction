# Agent Studio Tool :: dq_get_drift  (Type: Python Function, Function Name: dq_get_drift)
# Reads native Lakehouse Monitoring drift/profile metrics for a dataset.
import os, json, time, urllib.request


def _dbx(method, path, body=None):
    host = os.environ["DATABRICKS_HOST"].rstrip("/")
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(host + path, data=data, method=method,
        headers={"Authorization": "Bearer " + os.environ["DATABRICKS_TOKEN"],
                 "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=90) as r:
        return json.loads(r.read().decode() or "{}")


def _sql(statement, params=None):
    body = {"warehouse_id": os.environ["SQL_WAREHOUSE_ID"], "statement": statement,
            "wait_timeout": "30s", "on_wait_timeout": "CONTINUE"}
    if params:
        body["parameters"] = params
    out = _dbx("POST", "/api/2.0/sql/statements", body)
    sid, st = out.get("statement_id"), out.get("status", {}).get("state")
    while st in ("PENDING", "RUNNING"):
        time.sleep(1.5)
        out = _dbx("GET", "/api/2.0/sql/statements/" + sid)
        st = out.get("status", {}).get("state")
    if st != "SUCCEEDED":
        raise RuntimeError("SQL failed: " + json.dumps(out.get("status")))
    cols = [c["name"] for c in out.get("manifest", {}).get("schema", {}).get("columns", [])]
    return [dict(zip(cols, row)) for row in out.get("result", {}).get("data_array", [])]


def dq_get_drift(dataset_id: str) -> dict:
    """Return native Lakehouse Monitoring drift signals for a dataset's most recent window.

    Use this for distribution drift, null-rate shifts, and volume anomalies that static
    rules can't capture. Requires the dataset to have monitoring enabled.

    Args:
        dataset_id: registered dataset id, e.g. 'payments.txn_master'.
    """
    schema = os.environ.get("DQ_CONTROL_SCHEMA", "governance.dq")
    reg = _sql(f"SELECT drift_metrics_table FROM {schema}.monitor_registry WHERE dataset_id = :d",
               [{"name": "d", "value": dataset_id}])
    if not reg or not reg[0].get("drift_metrics_table"):
        return {"dataset_id": dataset_id,
                "note": "no monitor configured; set enable_monitor=true and run the sweep"}
    drift_tbl = reg[0]["drift_metrics_table"]
    # Most recent window; surface columns with meaningful drift. Column set varies by
    # Databricks version, so select * for the latest window and let the agent interpret.
    rows = _sql(
        f"SELECT * FROM {drift_tbl} "
        f"WHERE window.end = (SELECT MAX(window.end) FROM {drift_tbl}) "
        f"AND drift_type = 'CONSECUTIVE' LIMIT 200")
    return {"dataset_id": dataset_id, "drift_metrics_table": drift_tbl,
            "window_columns": len(rows), "drift": rows}
