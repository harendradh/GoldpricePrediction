# Agent Studio Tool :: dq_get_rules  (Type: Python Function, Function Name: dq_get_rules)
# Thin wrapper over governance.dq.fn_get_rules (see sql/06_uc_functions.sql).
import os, json, time, urllib.request


def _dbx(method, path, body=None):
    host = os.environ["DATABRICKS_HOST"].rstrip("/")
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(host + path, data=data, method=method,
        headers={"Authorization": "Bearer " + os.environ["DATABRICKS_TOKEN"],
                 "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=90) as r:
        return json.loads(r.read().decode() or "{}")


def _sql(statement, params=None):
    body = {"warehouse_id": os.environ["SQL_WAREHOUSE_ID"], "statement": statement,
            "wait_timeout": "30s", "on_wait_timeout": "CONTINUE"}
    if params:
        body["parameters"] = params
    out = _dbx("POST", "/api/2.0/sql/statements", body)
    sid, st = out.get("statement_id"), out.get("status", {}).get("state")
    while st in ("PENDING", "RUNNING"):
        time.sleep(1.5)
        out = _dbx("GET", "/api/2.0/sql/statements/" + sid)
        st = out.get("status", {}).get("state")
    if st != "SUCCEEDED":
        raise RuntimeError("SQL failed: " + json.dumps(out.get("status")))
    cols = [c["name"] for c in out.get("manifest", {}).get("schema", {}).get("columns", [])]
    return [dict(zip(cols, row)) for row in out.get("result", {}).get("data_array", [])]


def dq_get_rules(domain: str, sub_domain: str = "") -> dict:
    """List the data-quality rules configured for a domain — reads v_rules_unified (every
    team's own rule table, in one shape) via the governed fn_get_rules function.

    Args:
        domain: e.g. 'TELETRACK', 'corebanking_tran_ct', 'zeta'.
        sub_domain: optional; most domains only have one.
    """
    schema = os.environ.get("DQ_CONTROL_SCHEMA", "governance.dq")
    rows = _sql(f"SELECT * FROM {schema}.fn_get_rules(:d, :sd)",
                [{"name": "d", "value": domain}, {"name": "sd", "value": sub_domain or None}])
    return {"domain": domain, "sub_domain": sub_domain, "count": len(rows), "rules": rows}
