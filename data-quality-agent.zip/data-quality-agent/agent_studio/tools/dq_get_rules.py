# Agent Studio Tool :: dq_get_rules  (Type: Python Function, Function Name: dq_get_rules)
import os, json, time, urllib.request


def _dbx(method, path, body=None):
    host = os.environ["DATABRICKS_HOST"].rstrip("/")
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(host + path, data=data, method=method,
        headers={"Authorization": "Bearer " + os.environ["DATABRICKS_TOKEN"],
                 "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=90) as r:
        return json.loads(r.read().decode() or "{}")


def _sql(statement, params=None):
    body = {"warehouse_id": os.environ["SQL_WAREHOUSE_ID"], "statement": statement,
            "wait_timeout": "30s", "on_wait_timeout": "CONTINUE"}
    if params:
        body["parameters"] = params
    out = _dbx("POST", "/api/2.0/sql/statements", body)
    sid, st = out.get("statement_id"), out.get("status", {}).get("state")
    while st in ("PENDING", "RUNNING"):
        time.sleep(1.5)
        out = _dbx("GET", "/api/2.0/sql/statements/" + sid)
        st = out.get("status", {}).get("state")
    if st != "SUCCEEDED":
        raise RuntimeError("SQL failed: " + json.dumps(out.get("status")))
    cols = [c["name"] for c in out.get("manifest", {}).get("schema", {}).get("columns", [])]
    return [dict(zip(cols, row)) for row in out.get("result", {}).get("data_array", [])]


def dq_get_rules(dataset_id: str) -> dict:
    """List the data-quality rules configured for a dataset (enabled and disabled/pending).

    Args:
        dataset_id: registered dataset id, e.g. 'payments.txn_master'.
    """
    schema = os.environ.get("DQ_CONTROL_SCHEMA", "governance.dq")
    rows = _sql(
        "SELECT rule_id, rule_name, dimension, rule_type, target_column, severity, "
        f"threshold, enabled FROM {schema}.rule_catalog WHERE dataset_id = :d "
        "ORDER BY enabled DESC, severity, dimension",
        [{"name": "d", "value": dataset_id}])
    return {"dataset_id": dataset_id, "count": len(rows), "rules": rows}
