# =====================================================================
# Agent Studio Tool  ::  dq_send_email_report
# Type: Python Function   |   Function Name: dq_send_email_report
# ---------------------------------------------------------------------
# Sends an email — the delivery half of the scheduled digest workflow (see
# agent_studio/agents/workflow_scheduled_digest.md). Generic on purpose: the AGENT composes
# the subject/body (usually from dq_get_full_report / dq_scorecard_genie output), this tool
# only delivers it. Not tied to one fixed report format.
#
# REQUIRES a real SMTP relay — this is a genuinely NEW external dependency this system didn't
# have before (everything else only ever talked to Databricks). Get these from your platform/
# infra team, the same way DATABRICKS_HOST/TOKEN were sourced:
#   SMTP_HOST, SMTP_PORT (default 587), SMTP_USERNAME, SMTP_PASSWORD, EMAIL_FROM
# If your workspace's egress rules block outbound SMTP from wherever this tool actually runs
# (Agent Studio's tool sandbox, not Databricks), this will fail at connect time with a clear
# error — that's a network/firewall conversation with your platform team, not a code fix.
# =====================================================================
import os
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText


def dq_send_email_report(to: str, subject: str, body_html: str, body_text: str = "") -> dict:
    """Send an email — e.g. a data-quality digest or an on-demand full report. The caller
    (the agent) composes the subject and body; this tool only delivers it.

    Args:
        to: one address, or comma-separated for multiple (e.g. 'a@fiserv.com,b@fiserv.com').
        subject: email subject line.
        body_html: HTML body — the primary content. Keep it self-contained (inline styles);
            most mail clients strip <style> blocks and external CSS.
        body_text: optional plain-text fallback for clients that don't render HTML. If empty,
            a minimal fallback is generated from body_html by stripping tags.
    """
    host = os.environ.get("SMTP_HOST")
    if not host:
        return {"error": "SMTP_HOST not configured for this deployment. This tool needs a "
                          "real SMTP relay — see the file header for what to request from "
                          "your platform/infra team. No email was sent."}

    port = int(os.environ.get("SMTP_PORT", "587"))
    username = os.environ.get("SMTP_USERNAME")
    password = os.environ.get("SMTP_PASSWORD")
    sender = os.environ.get("EMAIL_FROM", username or "dq-agent@fiserv.com")

    recipients = [addr.strip() for addr in to.split(",") if addr.strip()]
    if not recipients:
        return {"error": "No valid recipient address in 'to'."}

    if not body_text:
        import re
        body_text = re.sub(r"<[^>]+>", " ", body_html)
        body_text = re.sub(r"\s+", " ", body_text).strip()

    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = sender
    msg["To"] = ", ".join(recipients)
    msg.attach(MIMEText(body_text, "plain"))
    msg.attach(MIMEText(body_html, "html"))

    try:
        with smtplib.SMTP(host, port, timeout=30) as server:
            server.starttls()
            if username and password:
                server.login(username, password)
            server.sendmail(sender, recipients, msg.as_string())
    except Exception as e:
        return {"error": f"Send failed: {e}", "to": recipients, "subject": subject}

    return {"sent": True, "to": recipients, "subject": subject}
