# Agent Studio Tool :: dq_get_freshness  (Type: Python Function, Function Name: dq_get_freshness)
# Thin wrapper over governance.dq.fn_get_freshness (see sql/06_uc_functions.sql / sql/07).
import os, json, time, urllib.request


def _dbx(method, path, body=None):
    host = os.environ["DATABRICKS_HOST"].rstrip("/")
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(host + path, data=data, method=method,
        headers={"Authorization": "Bearer " + os.environ["DATABRICKS_TOKEN"],
                 "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=90) as r:
        return json.loads(r.read().decode() or "{}")


def _sql(statement, params=None):
    body = {"warehouse_id": os.environ["SQL_WAREHOUSE_ID"], "statement": statement,
            "wait_timeout": "30s", "on_wait_timeout": "CONTINUE"}
    if params:
        body["parameters"] = params
    out = _dbx("POST", "/api/2.0/sql/statements", body)
    sid, st = out.get("statement_id"), out.get("status", {}).get("state")
    while st in ("PENDING", "RUNNING"):
        time.sleep(1.5)
        out = _dbx("GET", "/api/2.0/sql/statements/" + sid)
        st = out.get("status", {}).get("state")
    if st != "SUCCEEDED":
        raise RuntimeError("SQL failed: " + json.dumps(out.get("status")))
    cols = [c["name"] for c in out.get("manifest", {}).get("schema", {}).get("columns", [])]
    return [dict(zip(cols, row)) for row in out.get("result", {}).get("data_array", [])]


def dq_get_freshness(domain: str, sub_domain: str = "") -> dict:
    """Is this domain's pipeline still reporting on schedule? Reads v_freshness_status, which
    compares the most recent dq_stats row against dataset_registry's freshness_sla_minutes.

    Accuracy note: this depends on source_registry mapping a REAL write-timestamp column for
    the source's 'loaded_ts'. If unmapped, minutes_since_last_run always reads ~0 (it falls
    back to query time, not write time) — this tool says so explicitly when it detects that.

    Args:
        domain: e.g. 'TELETRACK', 'corebanking_tran_ct', 'zeta'.
        sub_domain: optional; most domains only have one.
    """
    schema = os.environ.get("DQ_CONTROL_SCHEMA", "governance.dq")
    rows = _sql(f"SELECT * FROM {schema}.fn_get_freshness(:d, :sd)",
                [{"name": "d", "value": domain}, {"name": "sd", "value": sub_domain or None}])
    if not rows:
        return {"domain": domain, "sub_domain": sub_domain,
                "note": "No dataset_registry row for this domain — ownership/SLA metadata was "
                         "never registered for it."}
    r = rows[0]
    if r.get("minutes_since_last_run") is not None and int(r["minutes_since_last_run"]) <= 1:
        r["caveat"] = ("minutes_since_last_run is near zero — if this domain's source isn't "
                        "actually reporting every minute, its loaded_ts mapping is likely "
                        "unset and falling back to query time, not real write time.")
    return r
