# Agent Studio Tool :: dq_get_dashboard_link  (Type: Python Function, Function Name: dq_get_dashboard_link)
# Hands back a direct link to the "DQ Enterprise Scorecard" Lakeview dashboard so
# "show me the dashboard" works in chat, not just single-dataset questions.
import os


def dq_get_dashboard_link(team: str = "") -> dict:
    """Return the URL of the enterprise Data Quality dashboard.

    Use this when the user asks to see the dashboard, the scorecard across teams, trends over
    time, or anything better shown visually than read out in chat (e.g. "show me the
    dashboard", "what does the enterprise view look like").

    Args:
        team: optional team to mention filtering by once the dashboard opens (e.g.
            'Card Payments'). The dashboard's own team filter widget must be set manually — this
            tool does not deep-link a pre-applied filter, since that URL scheme is not
            stable across Databricks releases.
    """
    host = os.environ["DATABRICKS_HOST"].rstrip("/")
    dashboard_id = os.environ["DQ_DASHBOARD_ID"]
    url = f"{host}/sql/dashboardsv3/{dashboard_id}/published"
    note = ("Open the dashboard, then use its team filter to select "
            f"'{team}'.") if team else "Open the dashboard for the full enterprise view."
    return {"dashboard_url": url, "note": note}
