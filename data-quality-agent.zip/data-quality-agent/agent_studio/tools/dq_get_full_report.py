# Agent Studio Tool :: dq_get_full_report  (Type: Python Function, Function Name: dq_get_full_report)
# The "everything about this dataset" tool — for "give me a full DQ report on X." Orchestrates
# 4 UC Functions into one consolidated answer instead of making the user ask 4 separate
# questions: fn_get_summary (score), fn_get_rule_outcomes (every rule, pass AND fail — not
# just failures), fn_get_freshness (is the pipeline current), fn_get_volume_trend (is the row
# count doing anything unusual). Profile data is included best-effort (fn_profile_dataset) —
# not every domain has a profiler table, so its absence isn't an error.
import os, json, time, urllib.request


def _dbx(method, path, body=None):
    host = os.environ["DATABRICKS_HOST"].rstrip("/")
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(host + path, data=data, method=method,
        headers={"Authorization": "Bearer " + os.environ["DATABRICKS_TOKEN"],
                 "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=90) as r:
        return json.loads(r.read().decode() or "{}")


def _sql(statement, params=None):
    body = {"warehouse_id": os.environ["SQL_WAREHOUSE_ID"], "statement": statement,
            "wait_timeout": "30s", "on_wait_timeout": "CONTINUE"}
    if params:
        body["parameters"] = params
    out = _dbx("POST", "/api/2.0/sql/statements", body)
    sid, st = out.get("statement_id"), out.get("status", {}).get("state")
    while st in ("PENDING", "RUNNING"):
        time.sleep(1.5)
        out = _dbx("GET", "/api/2.0/sql/statements/" + sid)
        st = out.get("status", {}).get("state")
    if st != "SUCCEEDED":
        raise RuntimeError("SQL failed: " + json.dumps(out.get("status")))
    cols = [c["name"] for c in out.get("manifest", {}).get("schema", {}).get("columns", [])]
    return [dict(zip(cols, row)) for row in out.get("result", {}).get("data_array", [])]


_PLAYBOOK = {
    "not_null": "Backfill or reject nulls upstream; add a NOT NULL constraint once stable.",
    "unique": "Deduplicate on the key; check for double-load or a missing MERGE key.",
    "referential": "Quarantine orphan rows; fix load order so the parent lands first.",
    "freshness": "Check the upstream job/scheduler SLA; alert the data owner.",
    "range": "Validate source mapping/units; clamp or reject out-of-range values.",
    "standardization": "Reconcile formatting rules (e.g. address/name standardization) with source.",
    "validity": "Reconcile the domain/enum or format with source reference data.",
    "overlap": "Investigate duplicate/overlapping records across the merge/dedup key.",
}


def dq_get_full_report(domain: str, sub_domain: str = "") -> dict:
    """Return the complete data-quality report for one domain in a single call: score, every
    rule's pass/fail/not-run status (not just failures), freshness vs SLA, 7-day volume
    trend, and column profiling where available. Use this for "give me a full DQ report on
    X" / "everything you know about X" — for a narrower question (just the score, just the
    failures), the single-purpose tools are cheaper and faster.

    Args:
        domain: e.g. 'TELETRACK', 'corebanking_tran_ct', 'zeta'.
        sub_domain: optional; most domains only have one.
    """
    schema = os.environ.get("DQ_CONTROL_SCHEMA", "governance.dq")
    sd_param = [{"name": "d", "value": domain}, {"name": "sd", "value": sub_domain or None}]

    summary_rows = _sql(f"SELECT * FROM {schema}.fn_get_summary(:d, :sd)", sd_param)
    outcome_rows = _sql(f"SELECT * FROM {schema}.fn_get_rule_outcomes(:d, :sd)", sd_param)
    freshness_rows = _sql(f"SELECT * FROM {schema}.fn_get_freshness(:d, :sd)", sd_param)
    volume_rows = _sql(f"SELECT * FROM {schema}.fn_get_volume_trend(:d, :sd)", sd_param)
    try:
        profile_rows = _sql(f"SELECT * FROM {schema}.fn_profile_dataset(:d, :sd)", sd_param)
    except Exception:
        profile_rows = []   # no profiler table for this domain — not an error for a full report

    for r in outcome_rows:
        if r.get("status") == "FAIL":
            rt = (r.get("rule_name") or "").lower()
            key = next((k for k in _PLAYBOOK if k in rt), None)
            r["suggested_action"] = _PLAYBOOK.get(key, "Investigate with the data owner.")

    failed = [r for r in outcome_rows if r.get("status") == "FAIL"]
    not_run = [r for r in outcome_rows if r.get("status") == "NOT_RUN"]
    passed = [r for r in outcome_rows if r.get("status") == "PASS"]

    return {
        "domain": domain,
        "sub_domain": sub_domain,
        "summary": summary_rows[0] if summary_rows else
            {"note": "No dq_stats rows found for this domain yet."},
        "freshness": freshness_rows[0] if freshness_rows else
            {"note": "No dataset_registry row — ownership/SLA metadata not registered."},
        "rule_outcomes": {
            "total_rules": len(outcome_rows),
            "passed": len(passed), "failed": len(failed), "not_run": len(not_run),
            "failing_rules": failed,
            "not_run_rules": not_run,
            "passing_rule_names": [r["rule_name"] for r in passed],
        },
        "volume_trend_7d": volume_rows,
        "profile": profile_rows,
    }
