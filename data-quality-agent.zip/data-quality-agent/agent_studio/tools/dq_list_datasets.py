# Agent Studio Tool :: dq_list_datasets  (Type: Python Function, Function Name: dq_list_datasets)
import os, json, time, urllib.request


def _dbx(method, path, body=None):
    host = os.environ["DATABRICKS_HOST"].rstrip("/")
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(host + path, data=data, method=method,
        headers={"Authorization": "Bearer " + os.environ["DATABRICKS_TOKEN"],
                 "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=90) as r:
        return json.loads(r.read().decode() or "{}")


def _sql(statement, params=None):
    body = {"warehouse_id": os.environ["SQL_WAREHOUSE_ID"], "statement": statement,
            "wait_timeout": "30s", "on_wait_timeout": "CONTINUE"}
    if params:
        body["parameters"] = params
    out = _dbx("POST", "/api/2.0/sql/statements", body)
    sid, st = out.get("statement_id"), out.get("status", {}).get("state")
    while st in ("PENDING", "RUNNING"):
        time.sleep(1.5)
        out = _dbx("GET", "/api/2.0/sql/statements/" + sid)
        st = out.get("status", {}).get("state")
    if st != "SUCCEEDED":
        raise RuntimeError("SQL failed: " + json.dumps(out.get("status")))
    cols = [c["name"] for c in out.get("manifest", {}).get("schema", {}).get("columns", [])]
    return [dict(zip(cols, row)) for row in out.get("result", {}).get("data_array", [])]


def dq_list_datasets(owner_bu: str = "") -> dict:
    """List datasets registered for data-quality monitoring, optionally filtered by business unit.

    Use this when the user is vague about which dataset they mean.

    Args:
        owner_bu: optional business-unit filter, e.g. 'Payments'; empty = all.
    """
    schema = os.environ.get("DQ_CONTROL_SCHEMA", "governance.dq")
    if owner_bu:
        rows = _sql(
            "SELECT dataset_id, owner_bu, criticality, "
            "concat(target_catalog,'.',target_schema,'.',target_table) AS fq_table "
            f"FROM {schema}.dataset_registry WHERE active AND owner_bu = :bu ORDER BY criticality",
            [{"name": "bu", "value": owner_bu}])
    else:
        rows = _sql(
            "SELECT dataset_id, owner_bu, criticality, "
            "concat(target_catalog,'.',target_schema,'.',target_table) AS fq_table "
            f"FROM {schema}.dataset_registry WHERE active ORDER BY criticality, dataset_id")
    return {"count": len(rows), "datasets": rows}
