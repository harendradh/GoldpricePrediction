# Agent Studio Tool :: dq_list_datasets  (Type: Python Function, Function Name: dq_list_datasets)
# Thin wrapper over governance.dq.fn_list_datasets (see sql/06_uc_functions.sql) — the actual
# logic lives there, governed by Unity Catalog, reusable by anything that can query SQL.
import os, json, time, urllib.request


def _dbx(method, path, body=None):
    host = os.environ["DATABRICKS_HOST"].rstrip("/")
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(host + path, data=data, method=method,
        headers={"Authorization": "Bearer " + os.environ["DATABRICKS_TOKEN"],
                 "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=90) as r:
        return json.loads(r.read().decode() or "{}")


def _sql(statement, params=None):
    body = {"warehouse_id": os.environ["SQL_WAREHOUSE_ID"], "statement": statement,
            "wait_timeout": "30s", "on_wait_timeout": "CONTINUE"}
    if params:
        body["parameters"] = params
    out = _dbx("POST", "/api/2.0/sql/statements", body)
    sid, st = out.get("statement_id"), out.get("status", {}).get("state")
    while st in ("PENDING", "RUNNING"):
        time.sleep(1.5)
        out = _dbx("GET", "/api/2.0/sql/statements/" + sid)
        st = out.get("status", {}).get("state")
    if st != "SUCCEEDED":
        raise RuntimeError("SQL failed: " + json.dumps(out.get("status")))
    cols = [c["name"] for c in out.get("manifest", {}).get("schema", {}).get("columns", [])]
    return [dict(zip(cols, row)) for row in out.get("result", {}).get("data_array", [])]


def dq_list_datasets(owner_team: str = "") -> dict:
    """List domains with data-quality coverage, optionally filtered by owning team.

    A "dataset" in this system is a (domain, sub_domain) pair — the same grouping the
    Ingestion team's own dq_rules table already uses.

    Args:
        owner_team: optional team filter, e.g. 'Ingestion'; empty = all.
    """
    schema = os.environ.get("DQ_CONTROL_SCHEMA", "governance.dq")
    rows = _sql(f"SELECT * FROM {schema}.fn_list_datasets(:team)",
                [{"name": "team", "value": owner_team or None}])
    return {"count": len(rows), "domains": rows}
