# Agent Studio Tool :: dq_propose_rule  (Type: Python Function, Function Name: dq_propose_rule)
# Creates a DISABLED candidate rule for human approval. Never auto-enabled.
import os, re, json, time, urllib.request


def _dbx(method, path, body=None):
    host = os.environ["DATABRICKS_HOST"].rstrip("/")
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(host + path, data=data, method=method,
        headers={"Authorization": "Bearer " + os.environ["DATABRICKS_TOKEN"],
                 "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=90) as r:
        return json.loads(r.read().decode() or "{}")


def _sql(statement, params=None):
    body = {"warehouse_id": os.environ["SQL_WAREHOUSE_ID"], "statement": statement,
            "wait_timeout": "30s", "on_wait_timeout": "CONTINUE"}
    if params:
        body["parameters"] = params
    out = _dbx("POST", "/api/2.0/sql/statements", body)
    sid, st = out.get("statement_id"), out.get("status", {}).get("state")
    while st in ("PENDING", "RUNNING"):
        time.sleep(1.5)
        out = _dbx("GET", "/api/2.0/sql/statements/" + sid)
        st = out.get("status", {}).get("state")
    if st != "SUCCEEDED":
        raise RuntimeError("SQL failed: " + json.dumps(out.get("status")))
    cols = [c["name"] for c in out.get("manifest", {}).get("schema", {}).get("columns", [])]
    return [dict(zip(cols, row)) for row in out.get("result", {}).get("data_array", [])]


_DIMENSIONS = {"completeness", "uniqueness", "validity", "accuracy", "consistency",
               "integrity", "timeliness", "volume", "schema"}
_RULE_TYPES = {"not_null", "unique", "range", "regex", "accepted_values", "expression",
               "referential", "freshness", "row_count_anomaly", "custom_sql"}
_SEVERITY = {"critical", "high", "medium", "low"}
_SLUG = re.compile(r"[^a-z0-9]+")


def dq_propose_rule(dataset_id: str, rule_name: str, dimension: str, rule_type: str,
                    target_column: str = "", params_json: str = "{}",
                    severity: str = "medium", threshold: float = 0.0) -> dict:
    """Propose a NEW data-quality rule. It is created DISABLED and requires human approval.

    Args:
        dataset_id: registered dataset id, e.g. 'payments.txn_master'.
        rule_name: human-readable name, e.g. 'amount within bounds'.
        dimension: one of completeness|uniqueness|validity|accuracy|consistency|
                   integrity|timeliness|volume|schema.
        rule_type: one of not_null|unique|range|regex|accepted_values|expression|
                   referential|freshness|row_count_anomaly|custom_sql.
        target_column: column under test (empty for table-level rules).
        params_json: JSON object of rule params, e.g. '{"min":"0","max":"1000000"}'.
        severity: critical|high|medium|low.
        threshold: fail if violation_rate exceeds this (0..1).
    """
    if dimension not in _DIMENSIONS:
        return {"error": f"invalid dimension '{dimension}'", "allowed": sorted(_DIMENSIONS)}
    if rule_type not in _RULE_TYPES:
        return {"error": f"invalid rule_type '{rule_type}'", "allowed": sorted(_RULE_TYPES)}
    if severity not in _SEVERITY:
        return {"error": f"invalid severity '{severity}'", "allowed": sorted(_SEVERITY)}
    try:
        params = json.loads(params_json or "{}")
        if not isinstance(params, dict):
            raise ValueError
    except Exception:
        return {"error": "params_json must be a JSON object string"}

    rule_id = dataset_id + "::" + _SLUG.sub("_", rule_name.lower()).strip("_")

    # build a validated map() literal; keys/values are constrained to safe chars
    safe_kv = []
    for k, v in params.items():
        if not re.fullmatch(r"[A-Za-z0-9_]+", str(k)):
            return {"error": f"unsafe param key '{k}'"}
        vs = str(v).replace("'", "''")
        safe_kv.append(f"'{k}', '{vs}'")
    map_literal = "map(" + ", ".join(safe_kv) + ")"
    col_val = "NULL" if not target_column else f"'{target_column.replace(chr(39), chr(39)*2)}'"

    _sql(
        f"INSERT INTO {os.environ.get('DQ_CONTROL_SCHEMA','governance.dq')}.rule_catalog "
        "(rule_id, rule_name, dataset_id, dimension, rule_type, target_column, params, "
        "threshold, severity, enabled) VALUES "
        f"(:rid, :rname, :did, :dim, :rtype, {col_val}, {map_literal}, :thr, :sev, false)",
        [{"name": "rid", "value": rule_id}, {"name": "rname", "value": rule_name},
         {"name": "did", "value": dataset_id}, {"name": "dim", "value": dimension},
         {"name": "rtype", "value": rule_type}, {"name": "thr", "value": str(threshold)},
         {"name": "sev", "value": severity}])
    return {"rule_id": rule_id, "status": "PENDING_APPROVAL",
            "note": "Rule created DISABLED. A data owner must review and enable it before it runs."}
