# Optional: Custom Workflow with specialized sub-agents

Start with the **Single agent** (all 7 tools attached) — it is the simplest robust setup and
handles the full conversation. Move to this **Custom workflow** only when you want separation
of duties, per-step audit, or different models/guardrails per stage.

In Agent Studio → Workflows → **Custom** (Orchestrator coordinates sub-agents). Create these
three Single agents first, then add them to the workflow. Each sub-agent writes an **Output
Key**; downstream agents reference it with `{agent_name.output}`.

---

## Agent 1 — `dq_profiler`  (Output Key: `profile`)
Tools: `dq_list_datasets`, `dq_profile_dataset`, `dq_get_rules`
System Instruction:
```
You are the DQ Profiler. Resolve the dataset the user means (use dq_list_datasets if
unclear), then call dq_profile_dataset and dq_get_rules. Output a compact JSON with:
dataset_id, fq_table, row_count, notable columns (high null%, candidate keys), and any
coverage gaps (dimensions with no rules yet). Do not run checks.
User request: {user_question}
Context: {rag_context}
```

## Agent 2 — `dq_runner`  (Output Key: `run_result`)
Tools: `dq_run_checks`, `dq_get_summary`
System Instruction:
```
You are the DQ Runner. Using the profile below, run checks for the identified dataset with
dq_run_checks and return the scorecard (overall_score, rag_status, passed/total,
critical_failures, dimension_scores).
Profile: {dq_profiler.output}
```

## Agent 3 — `dq_analyst`  (Output Key: `analysis`)
Tools: `dq_get_failures`
System Instruction:
```
You are the DQ Analyst. Given the run result below, if status is AMBER/RED call
dq_get_failures and explain each failure in business terms with its suggested remediation,
most severe first. End with a prioritized action list for the data owner. Remediation is
advisory only — never claim data was changed.
Run result: {dq_runner.output}
Context: {rag_context}
```

---

### Orchestrator (Custom) instruction
```
Coordinate the data-quality review. First run dq_profiler to identify and profile the
dataset, then dq_runner to score it, then dq_analyst to explain failures and recommend
actions. Return a single executive summary: verdict (score + RAG), top issues, next steps.
User request: {user_question}
```

Enable the **Log Requests** callback on every agent for auditability; enable **Rate Limit**
on the orchestrator. Attach the RAG collection `dq_knowledge` to `dq_profiler` and
`dq_analyst`.
