# Optional: Scheduled DQ Digest Workflow (Agent Studio's native Schedule trigger)

Leverages Agent Studio's own Workflow + Schedule feature — not a Databricks Job, not a
second scheduler to maintain. Sends a daily (or whatever cadence you pick) email digest:
overall posture across tier-1 domains, called out by name if anything is RED/AMBER, without
anyone having to ask.

**Confirm the exact Schedule-trigger screen against your live Agent Studio instance before
building this** — this doc was written from the platform's documented Workflow/Custom
building blocks (Orchestrator + sub-agents, per `workflow_subagents.md`) plus the observed
capability that Workflows can run on a schedule; the precise field names on the scheduling
screen (cron expression vs. fixed interval picker, timezone field, whether a workflow can
run with no live user message) weren't captured in the screens this design was built from.
If your instance's Schedule trigger can't run a workflow unattended (no user in the loop),
see "Fallback" at the bottom.

---

## Agent 1 — `dq_digest_builder`  (Output Key: `digest`)
Tools: `dq_list_datasets`, `dq_scorecard_genie`, `dq_get_full_report`
System Instruction:
```
You build a daily data-quality digest. No user is asking a question — you are triggered on a
schedule. Steps:
1. Ask dq_scorecard_genie for the current team scorecard rollup (datasets/avg_score/red/
   amber/green per team).
2. For every domain currently RED or AMBER (call dq_list_datasets filtered to tier1
   criticality, then check each with dq_get_full_report), pull the top failing rule(s) and
   the suggested action.
3. Compose the digest as clean HTML: a one-line overall verdict at the top (e.g. "14 tier-1
   domains, 12 GREEN, 2 AMBER, 0 RED"), then one short section per non-GREEN domain (domain
   name, score, top failure, suggested action), then a closing line pointing to the full
   dashboard.
4. Output ONLY the HTML digest body — no preamble, no markdown fences. This becomes the
   email body verbatim.
Do not editorialize beyond what the tool data supports. If everything is GREEN, say so in one
line and stop — don't pad a clean report with invented detail.
```

## Agent 2 — `dq_digest_sender`  (Output Key: `send_result`)
Tools: `dq_send_email_report`
System Instruction:
```
Send the digest below as an email.
To: dq-digest-distribution@fiserv.com   (replace with your real distribution list)
Subject: Data Quality Digest — {current_date}
Body (HTML): {dq_digest_builder.output}
Call dq_send_email_report with these exact values. Report back whether it sent successfully.
```

---

### Orchestrator (Custom) instruction
```
Run dq_digest_builder to compose today's data-quality digest, then dq_digest_sender to email
it. No user input is expected — this runs on a schedule. Return a one-line status: sent
successfully, or what failed.
```

## Wiring the schedule

1. Agent Studio → Workflows → **Custom** → build `dq_digest_builder` and `dq_digest_sender`
   as Single agents first (same pattern as `workflow_subagents.md`), then add both to the
   workflow with the Orchestrator instruction above.
2. On the workflow (not the individual agents): find the **Schedule** / **Trigger** setting —
   set cadence (e.g. daily 07:00), timezone, and whatever fixed input the trigger requires
   (a literal string like `"Run the scheduled digest."` if the workflow needs a
   `{user_question}` value even when unattended).
3. Enable **Log Requests** on both agents so a failed send is visible without waiting for
   someone to notice a missing email.
4. `dq_send_email_report` needs real SMTP credentials — see `agent_studio/BUILD_GUIDE.md`
   Step 0. Test with a real recipient before trusting the schedule.

## Fallback: if Workflows can't run fully unattended

If your Agent Studio instance's Schedule trigger requires a live invocation context this
workflow shape doesn't fit, the same two tools still work from a plain Databricks Job — a
Python task that queries `v_team_scorecard`/`v_freshness_status` directly (no LLM call, fully
deterministic) and calls the same email-sending logic `dq_send_email_report.py` uses. That's
a simpler, guaranteed-to-run alternative at the cost of losing the LLM-composed narrative —
not built here since the ask was to leverage Agent Studio's own scheduling first; flag if you
want this fallback built out too.
