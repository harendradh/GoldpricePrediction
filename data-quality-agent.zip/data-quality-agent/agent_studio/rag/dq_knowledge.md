# Data Quality Knowledge Base (upload to RAG collection: dq_knowledge)

This document grounds the DQ Agent so its terminology, rule suggestions, and remediation
advice are consistent across every team and BU. Upload it as the sole (or primary) document
in a RAG collection named `dq_knowledge` and attach that collection to the agent(s).

## The 10 quality dimensions (what "quality" means here)

1. Completeness — required values are present (nulls, blanks, missing rows vs source).
2. Uniqueness — no unexpected duplicates on a key.
3. Validity / Conformity — values match type, format, range, or an accepted domain.
4. Accuracy — values agree with a trusted reference / golden source.
5. Consistency — cross-column and cross-table logic holds (e.g. end >= start).
6. Integrity — referential: foreign keys exist in the parent table (no orphans).
7. Timeliness / Freshness — data arrives within its SLA; not stale.
8. Volume / Anomaly — row counts are within expected bounds (no partial/double loads).
9. Distribution / Drift — statistical shape (mean, quantiles, category mix) is stable.
10. Schema — columns and types are stable; unexpected adds/drops/type-changes flagged.

## Rule types the engine supports (map a need to one of these)

| rule_type | Dimension | Key params |
|-----------|-----------|------------|
| not_null | completeness | — |
| unique | uniqueness | (uses target_column or dataset PKs) |
| range | validity | min, max |
| regex | validity | pattern |
| accepted_values | validity | values (comma-separated) |
| expression | consistency | expr (must be TRUE for valid rows) |
| referential | integrity | ref_table, ref_column |
| freshness | timeliness | sla_minutes |
| row_count_anomaly | volume | lookback_runs, max_pct_drop, max_pct_spike |
| custom_sql | any | sql (SELECT COUNT(*) AS failed_rows [, total_rows]) |

## Severity and scoring

- Severity weights: critical=10, high=5, medium=2, low=1.
- Overall score = severity-weighted pass rate × 100.
- RAG: any critical failure => RED; else score >= 95 GREEN, >= 80 AMBER, else RED.
- A rule "fails" when violation_rate > its threshold (threshold 0 = zero tolerance).

## Golden rules (baseline every tier-1 dataset should have)

- Primary key: not_null (critical) + unique (critical).
- Freshness against the load-timestamp SLA (high).
- Domain checks on status/enum columns (accepted_values, high).
- Referential integrity on foreign keys (critical).
- Row-count anomaly guard (medium).

## Remediation playbook (advisory — the agent never changes data)

- not_null: backfill/reject nulls upstream; add NOT NULL once stable.
- unique: dedupe on key; check double-load or missing MERGE key.
- referential: quarantine orphans; fix load order (parent first).
- freshness: check upstream job/scheduler SLA; alert owner.
- range/accepted_values/regex: reconcile source mapping/units/reference; standardize at ingest.
- expression: review business rule with owner; fix upstream logic.
- row_count_anomaly: check partial load, duplicate load, or source outage.

## How to phrase results to users

Lead with the verdict (score + RAG). Then the biggest issues first, in business terms
(what broke, how many rows, how severe). Then a short prioritized action list. Never expose
raw records — only counts, rates, and a small sample of offending keys.

## Escalation matrix (who gets notified, and how fast)

| RAG status | Notify | Channel | SLA to acknowledge |
|---|---|---|---|
| RED (any critical failure) | Dataset owner + BU data lead | Teams + ServiceNow incident | 1 business hour |
| AMBER (score 80-94) | Dataset owner | Teams | 1 business day |
| GREEN (score >= 95) | No notification | — | — |
| Freshness SLA missed | Dataset owner + upstream job owner | Teams | 30 minutes (tier-1), 4 hours (others) |

A dataset's tier (1/2/3, set in `dataset_registry.criticality`) can tighten these defaults —
tier-1 datasets always escalate one level faster than shown above.

## Worked example: reading a scorecard

```json
{
  "overall_score": 82.4,
  "rag_status": "AMBER",
  "total_rules": 14, "passed_rules": 12, "failed_rules": 2,
  "critical_failures": 0,
  "dimension_scores": {"completeness": 100, "uniqueness": 100, "validity": 61, "timeliness": 100}
}
```
Read this as: *"payments.txn_master is AMBER at 82.4 — no critical failures, but validity is
the weak dimension (61) from 2 failing rules; nothing here needs a 1-hour page, but the owner
should look at it today."* Always name the weakest dimension_scores entry, not just the
overall number — it tells the owner where to look first.

## Frequently asked questions

- **"Why is my score AMBER when only 1 rule failed?"** — severity weighting, not rule count,
  drives the score. One `critical` failure can outweigh ten `low` failures. Check which
  severity failed before assuming "1 of 14 rules" sounds fine.
- **"Can the agent fix the data?"** — no. Every remediation suggestion is advisory. A human
  (or a separate, explicitly-approved pipeline) performs any backfill, dedupe, or quarantine.
- **"Why did dq_run_checks take a long time?"** — it triggers a real Databricks Job and polls
  to completion; large tables or a busy job queue add latency. dq_get_summary reads the last
  finished run instantly if a fresh run isn't required.
- **"How do I add a rule without waiting on the platform team?"** — ask the agent to
  `dq_profile_dataset` then `dq_propose_rule`. It lands **disabled**; a data owner reviews and
  enables it in `rule_catalog`. No agent redeploy needed either way.
- **"The agent said a dataset isn't registered — now what?"** — register it: insert one row
  into `dataset_registry` (owner BU, criticality, freshness SLA, primary keys) and at least
  the golden rules into `rule_catalog`. That's the entire onboarding step.
- **"Can I ask about trends over time, not just the latest run?"** — yes, that's what
  `dq_scorecard_genie` is for (e.g. "trend of payments.txn_master score over 30 days",
  "which BU has the most RED datasets this week"). It only reads governance.dq.* history.

## Glossary

- **Dataset** — one registered Delta table (fully-qualified `catalog.schema.table`), the unit
  every rule, run, and score attaches to.
- **Rule** — one check (`rule_type` + params + severity + threshold) attached to a dataset in
  `rule_catalog`.
- **Run** — one execution of the DQ job against a dataset at a point in time; produces rows in
  `results` and one row in `run_summary`.
- **Scorecard** — the `run_summary` row for the latest run: overall_score, rag_status, and the
  per-dimension breakdown.
- **HITL (human-in-the-loop)** — any change that requires human approval before it takes
  effect; used here for proposed rules (disabled until enabled) and remediation (advisory only).
- **Sweep** — the nightly `for_each` job that runs checks across every registered dataset in
  parallel, as opposed to an on-demand single-dataset run.
- **Quarantine** — rows that fail a hard (`expect_or_drop`) DLT expectation are diverted to a
  `<table>_quarantine` table instead of the target table, rather than being dropped silently.
