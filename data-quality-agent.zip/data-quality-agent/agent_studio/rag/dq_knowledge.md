# Data Quality Knowledge Base (upload to RAG collection: DQ Knowledge)

Grounds the DQ Agent in policy: scoring, severity, escalation, remediation. Rule *inventory*
(what actually exists) comes from the second collection, `DQ Rule Reference` — see
`docs/RAG_INTEGRATION.md`.

## What a "domain" is

A `(domain, sub_domain)` pair — the same grouping the Ingestion team's own `dq_rules` table
uses (e.g. `TELETRACK`, `corebanking_tran_ct`, `zeta`). Not a new naming scheme invented here.

## Severity — derived, not stored

`dq_rules` has no severity column. Severity comes from `action_if_failed`:

| action_if_failed | severity |
|---|---|
| BLOCK, FAIL_JOB, REJECT | critical |
| QUARANTINE | high |
| WARN | medium |
| anything else / unset | low |

## Scoring

- `overall_score` = 100 × (rules passed / rules checked) for a domain's latest job run.
- RAG: any **critical** failure → RED; else score ≥ 95 → GREEN; ≥ 80 → AMBER; else RED.
- A rule "fails" when `dq_stats.row_dq_results` records a nonzero `failed_row_count` for it.

This is a simpler formula than a severity-weighted composite — deliberately. `v_run_summary`
(`sql/03`) is the single source of truth for the exact computation.

## Common rule_type patterns, and which DQ dimension they cover

`dq_rules` has no fixed `dimension` column — `rule_type` is free text every team defines
themselves. This mapping is this system's own interpretation for explaining coverage in
familiar terms (leadership decks, dimension roll-ups) — it is not a schema constraint, and it
is only as complete as the patterns actually seen in real rule data.

| Pattern in rule name/rule_type | Dimension | What it's checking |
|---|---|---|
| `*_not_null` | Completeness | Is a required field populated? |
| `*_should_be_valid` | Validity | Does a value match an expected format/domain? |
| `*_should_be_standardized` | Consistency | Does it match a reference format across systems? |
| `OVERLAP` | Uniqueness | Are there duplicate/overlapping records on a key? |
| `*_threshold_check` | Accuracy | Is a count/rate within an expected/reasonable range? |
| *(not a rule_type at all)* | Timeliness | `dataset_registry.freshness_sla_minutes` + `alert_stats_gaps` — did the pipeline report on schedule? A structurally different check: it's about the pipeline running, not a row's content. |

There is no fixed enum here — every team's `rule_type` text is their own. Don't assume a
closed list; read what `dq_get_rules(domain=...)` actually returns. If asked "what dimensions
do you cover for domain X," answer from that domain's actual `rule_type` values via
`dq_get_rules` — never claim a dimension is covered without a rule backing it up.

## Remediation playbook (advisory — the agent never changes data)

- Validity/standardization failures: reconcile source mapping/format with the reference the
  rule checks against; fix at ingestion, not after the fact.
- OVERLAP: investigate the merge/dedup key for a double-load or a missing uniqueness guard.
- Threshold checks (e.g. `merchant_drop_threshold_check`): confirm whether the spike/drop is a
  real business event (promo, outage) before treating it as a data defect.
- Completeness failures: backfill or reject nulls upstream.
- Always defer to the owning team's own judgment — this system doesn't own their rules or
  their remediation process, only surfaces what their own pipeline already found.

## How to phrase results to users

Lead with the verdict (score + RAG). Then the biggest issues first, in business terms. Never
expose raw records — `dq_stats`/`dq_get_failures` already only carry counts and rule names,
not row-level data.

## Escalation matrix

| RAG status | Notify | SLA to acknowledge |
|---|---|---|
| RED (any critical failure) | Domain owner + team data lead | 1 business hour |
| AMBER (score 80-94) | Domain owner | 1 business day |
| GREEN (score ≥ 95) | No notification | — |
| Stale (no dq_stats rows in 24h, `alert_stats_gaps`) | Domain owner + upstream job owner | 4 hours |

A domain's `criticality` tier (`dataset_registry`) can tighten these — tier1 escalates one
level faster.

## Worked example: TELETRACK domain

```
domain = TELETRACK, sub_domain = TELETRACK
rules checked = 20 (address_should_be_valid, name_should_be_valid, phone_should_be_valid,
                    address_should_be_standardized, ...)
1 failing: address_should_be_valid (validity pattern, action_if_failed=WARN → severity medium)
overall_score = 100 * 19/20 = 95.0   rag_status = GREEN  (no critical failure, score >= 95)
```
Change the failing rule's `action_if_failed` to `BLOCK` instead, everything else the same, and
the verdict flips entirely: severity becomes **critical**, so `rag_status = RED` regardless of
the 95.0 score — a single critical failure always overrides the score. Always recompute both
from the actual rows; don't eyeball either one. `dq_get_failures` names which rule failed and
why, which is what actually matters to the domain owner — not the number alone.

## Frequently asked questions

- **"Why does my domain show no data at all?"** — it may not be checked by any registered
  pipeline yet. `dq_get_summary` returns a note when `v_latest_scorecard` has no row for that
  domain; that's different from a GREEN score.
- **"Can the agent fix the data?"** — no. Every remediation suggestion is advisory.
- **"Can I trigger a fresh check right now?"** — usually no need: `dq_get_summary` reads
  `dq_stats` directly, which is exactly as fresh as the Ingestion team's own pipeline.
  `dq_run_checks` only does something if a *fallback* engine is deployed for a domain with no
  owning pipeline at all — most domains don't need it.
- **"Can the agent add a rule for me?"** — no, there is no mechanism for that, by design. Ask
  it to `dq_profile_dataset` for the column stats you'd need, then take the rule idea directly
  to a data owner on the *owning* team — they add it to their own rule table if they agree.
  This system never writes into, stages for, or tracks changes to another team's table.
- **"Can I ask about trends over time, or across domains?"** — yes, that's what
  `dq_scorecard_genie` is for. It only reads `governance.dq.*` — never raw source data.
- **"Is this domain's data current, or is the pipeline stuck?"** — `dq_get_freshness` compares
  the latest run against the domain's configured SLA (`dataset_registry.freshness_sla_minutes`)
  and returns how many minutes since the last run and whether that breaches the SLA.
- **"Did the row count/volume look normal?"** — `dq_get_full_report` includes a 7-day volume
  trend (input/error/output row counts per day); `dq_scorecard_genie` can also answer a
  longer or more specific volume question directly.
- **"Can I get one complete report instead of asking five questions?"** — yes,
  `dq_get_full_report(domain)` returns the score, every rule's pass/fail/not-run status (not
  just failures), freshness, a 7-day volume trend, and profiling, all in one call.

## Glossary

- **Domain / sub_domain** — the unit every rule and score attaches to; matches how `dq_rules`
  already groups things.
- **Source table** — a team's own rules/stats table (e.g. `dq_rules`, `dq_stats`); never
  copied, only read through a view.
- **Unified view** — `v_rules_unified` / `v_stats_unified` / `v_profile_unified`; one shape
  over every registered team's own tables. See `docs/UNIFIED_VIEWS.md`.
- **Scorecard** — a `v_run_summary` row: `overall_score`, `rag_status` for one domain's latest
  job run.
- **Adapter / registration** — adding a team's table to `source_registry` so it's included in
  the unified views. Not a copy, not a sync job — a config row, added by the platform team.
