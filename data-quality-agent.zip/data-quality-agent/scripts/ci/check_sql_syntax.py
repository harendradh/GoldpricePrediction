#!/usr/bin/env python3
"""Minimal SQL sanity check for CI — not a real parser, just cheap checks that catch the
most common copy-paste mistakes before they reach a SQL Warehouse: unbalanced parentheses
and an odd number of unescaped single quotes outside of doubled ('') escapes.

Usage: python scripts/ci/check_sql_syntax.py sql/*.sql
"""
import re
import sys


def _strip_line_comments(text: str) -> str:
    """Remove `-- ...` to end-of-line, but only outside of string literals — a `--` inside
    a quoted string (rare, but possible in a rule's custom_sql) must not be treated as a
    comment start. Track quote state char-by-char to tell the difference."""
    out = []
    in_string = False
    i = 0
    while i < len(text):
        ch = text[i]
        if in_string:
            out.append(ch)
            if ch == "'":
                # doubled '' is an escaped quote, stays inside the string
                if text[i + 1:i + 2] == "'":
                    out.append("'")
                    i += 2
                    continue
                in_string = False
            i += 1
            continue
        if ch == "'":
            in_string = True
            out.append(ch)
            i += 1
            continue
        if ch == "-" and text[i + 1:i + 2] == "-":
            nl = text.find("\n", i)
            i = len(text) if nl == -1 else nl
            continue
        out.append(ch)
        i += 1
    return "".join(out)


def check_file(path: str) -> list[str]:
    raw = open(path, encoding="utf-8").read()
    text = _strip_line_comments(raw)
    errors = []

    depth = 0
    for i, ch in enumerate(text):
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
            if depth < 0:
                errors.append(f"unmatched ')' at byte {i}")
                depth = 0
    if depth != 0:
        errors.append(f"{depth} unclosed '(' at end of file")

    # Collapse doubled single-quotes ('') which are the SQL escape for a literal quote,
    # then the remainder should have an even count (each string opens and closes).
    collapsed = re.sub(r"''", "", text)
    if collapsed.count("'") % 2 != 0:
        errors.append("odd number of single quotes outside of '' escapes — likely an unclosed string literal")

    return errors


def main() -> int:
    paths = sys.argv[1:]
    if not paths:
        print("usage: check_sql_syntax.py <file.sql> [...]")
        return 2
    failed = False
    for path in paths:
        errors = check_file(path)
        if errors:
            failed = True
            print(f"FAIL {path}")
            for e in errors:
                print(f"  - {e}")
        else:
            print(f"OK   {path}")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
