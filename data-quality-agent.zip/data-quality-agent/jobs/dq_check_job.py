"""Databricks Job entrypoint — runs the native DQ engine on a cluster.

Deploy as a Job task (Python wheel or this file as a notebook/spark_python_task).
It receives params from the agent via `run-now`:
    dataset_id, rule_ids (comma-sep or empty), triggered_by

The engine reads rules from the control tables and writes results back to Delta.
The agent then reads run_summary via the SQL Warehouse — it never sees raw rows.
"""
import os
import sys

# POC mode: no wheel needed. Asset Bundle deploy syncs this whole repo, so `src/` sits right
# next to this file on the cluster — add it to sys.path and import the package directly.
# For production, build the wheel (`python -m build`) and add it back as a job library in
# deploy/databricks.job.yml; this sys.path insert is then a harmless no-op.
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))

from dq_agent.engine.rule_engine import DQEngine

try:
    from pyspark.sql import SparkSession
    from pyspark.dbutils import DBUtils  # type: ignore
except Exception:  # pragma: no cover - only runs on Databricks
    SparkSession = None  # type: ignore


def _get_params(spark) -> dict:
    """Read widget/job params. Works for notebook widgets and spark_python_task argv."""
    params = {}
    try:
        dbutils = DBUtils(spark)  # type: ignore
        for k in ("dataset_id", "rule_ids", "triggered_by"):
            try:
                params[k] = dbutils.widgets.get(k)
            except Exception:
                params[k] = ""
    except Exception:
        # spark_python_task: --dataset_id=... style
        for arg in sys.argv[1:]:
            if arg.startswith("--") and "=" in arg:
                k, v = arg[2:].split("=", 1)
                params[k] = v
    return params


def main() -> None:
    spark = SparkSession.builder.getOrCreate()
    params = _get_params(spark)

    dataset_id = params.get("dataset_id") or os.environ.get("DATASET_ID")
    if not dataset_id:
        raise SystemExit("dataset_id is required")
    rule_ids = [r for r in (params.get("rule_ids") or "").split(",") if r.strip()] or None
    triggered_by = params.get("triggered_by") or "job"
    job_run_id = params.get("job_run_id") or os.environ.get("DATABRICKS_RUN_ID")

    control = os.environ.get("DQA_CONTROL_SCHEMA", "governance.dq")
    engine = DQEngine(spark, control_schema=control)
    summary = engine.run(
        dataset_id=dataset_id,
        rule_ids=rule_ids,
        triggered_by=triggered_by,
        job_run_id=job_run_id,
    )
    # Surface a compact result the Job UI / agent can log.
    print(
        f"DQ RUN {summary.run_id} dataset={summary.dataset_id} "
        f"score={summary.overall_score} rag={summary.rag_status} "
        f"passed={summary.passed_rules}/{summary.total_rules} "
        f"critical_failures={summary.critical_failures}"
    )


if __name__ == "__main__":
    main()
