"""Sweep driver — part of the OPTIONAL fallback engine (see jobs/dq_check_job.py's header).
Not deployed by default (see deploy/databricks.job.yml) — the simplified design reads
dq_stats directly instead of sweeping datasets with a second, parallel check engine.

Reads the active dataset registry (optionally filtered by team / criticality) and publishes
a JSON array of dataset_ids as a task value. The `for_each` task consumes it and runs the
engine once per dataset in parallel. This replaces any Python poll-loop and scales via native
Workflow `for_each` fan-out — no serverless compute assumed; size the `for_each` task's job
cluster (node type, worker count, max concurrency) for your actual table count before turning
this on. See deploy/databricks.job.yml's commented-out fallback job for the pattern.
"""
import os
import sys

from pyspark.sql import SparkSession
from pyspark.dbutils import DBUtils  # type: ignore


def _args() -> dict:
    out = {}
    for a in sys.argv[1:]:
        if a.startswith("--") and "=" in a:
            k, v = a[2:].split("=", 1)
            out[k] = v
    return out


def main() -> None:
    spark = SparkSession.builder.getOrCreate()
    dbutils = DBUtils(spark)
    a = _args()
    schema = os.environ.get("DQA_CONTROL_SCHEMA", "governance.dq")

    where = ["active"]
    query_args = {}
    if a.get("team_filter"):
        where.append("owner_team = :team_filter")
        query_args["team_filter"] = a["team_filter"]
    if a.get("criticality"):
        where.append("criticality = :criticality")
        query_args["criticality"] = a["criticality"]

    # Parameterized (not f-string interpolated) — team_filter/criticality come from job
    # parameters, which a caller could otherwise use to inject SQL.
    rows = spark.sql(
        f"SELECT dataset_id FROM {schema}.dataset_registry "
        f"WHERE {' AND '.join(where)} ORDER BY criticality",
        args=query_args,
    ).collect()
    datasets = [r["dataset_id"] for r in rows]

    # Publish for the for_each task; also print for the run log.
    dbutils.jobs.taskValues.set(key="datasets", value=datasets)
    print(f"DQ SWEEP: {len(datasets)} datasets queued -> {datasets[:20]}"
          + (" ..." if len(datasets) > 20 else ""))


if __name__ == "__main__":
    main()
