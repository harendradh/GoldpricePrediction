"""Sweep driver — builds the work-list for the for_each fan-out.

Reads the active dataset registry (optionally filtered by BU / criticality) and publishes
a JSON array of dataset_ids as a task value. The `for_each` task consumes it and runs the
engine once per dataset in parallel. This replaces any Python poll-loop and scales to
thousands of tables via native Workflow orchestration + serverless.
"""
import os
import sys

from pyspark.sql import SparkSession
from pyspark.dbutils import DBUtils  # type: ignore


def _args() -> dict:
    out = {}
    for a in sys.argv[1:]:
        if a.startswith("--") and "=" in a:
            k, v = a[2:].split("=", 1)
            out[k] = v
    return out


def main() -> None:
    spark = SparkSession.builder.getOrCreate()
    dbutils = DBUtils(spark)
    a = _args()
    schema = os.environ.get("DQA_CONTROL_SCHEMA", "governance.dq")

    where = ["active"]
    if a.get("bu_filter"):
        where.append(f"owner_bu = '{a['bu_filter']}'")
    if a.get("criticality"):
        where.append(f"criticality = '{a['criticality']}'")

    rows = spark.sql(
        f"SELECT dataset_id FROM {schema}.dataset_registry "
        f"WHERE {' AND '.join(where)} ORDER BY criticality"
    ).collect()
    datasets = [r["dataset_id"] for r in rows]

    # Publish for the for_each task; also print for the run log.
    dbutils.jobs.taskValues.set(key="datasets", value=datasets)
    print(f"DQ SWEEP: {len(datasets)} datasets queued -> {datasets[:20]}"
          + (" ..." if len(datasets) > 20 else ""))


if __name__ == "__main__":
    main()
