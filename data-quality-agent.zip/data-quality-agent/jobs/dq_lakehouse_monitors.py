"""Lakehouse Monitoring setup — OPTIONAL, not deployed by default. See
docs/PRODUCTION_READINESS.md -> Monitoring for the full explanation of what this does and
does not cover.

WHAT THIS ADDS: statistical drift detection (schema changes, null-rate creep, row-count
swings, distribution shifts) on every table registered in source_registry — dq_rules,
dq_stats, dp_*_status, and whatever else a team registers later. This is a DIFFERENT kind of
check than dq_rules' business rules: nobody has to write a rule in advance for this to catch
something. Complementary to alert_stats_gaps (which only catches total silence), this catches
partial degradation too — e.g. dq_stats' row count quietly dropping 80%, or a new NULL rate
creeping into a mapped column.

WHAT THIS STILL DOES NOT ADD: drift on each domain's own underlying BUSINESS data (e.g. the
real TELETRACK transaction table). dq_rules only carries domain/sub_domain/product_id, not a
physical catalog.schema.table pointer to that data — so this system still has no way to know
which physical table a domain's business data lives in. That gap is unchanged. What changed
is realizing we already know the physical location of the METADATA tables themselves
(source_registry.fq_table) — monitoring those is a real, running capability, not a roadmap
item, even though it's a narrower thing than "monitor every domain's business data."

Uses the databricks-sdk quality-monitors API (`w.quality_monitors`), targeting sdk>=0.20 —
verify the exact method/parameter names against the databricks-sdk version pinned in your
workspace before relying on this; the SDK surface for Lakehouse Monitoring has moved before.
Idempotent: skips any table that already has a monitor. Run manually, once per new
registration — monitors don't need re-creation on every dq_view_refresh run, only their
own scheduled refresh (set on the monitor itself, not here).
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))

from pyspark.sql import SparkSession


def _existing_monitor(w, fq_table: str) -> bool:
    try:
        w.quality_monitors.get(table_name=fq_table)
        return True
    except Exception:
        return False


def main() -> None:
    from databricks.sdk import WorkspaceClient
    from databricks.sdk.service.catalog import MonitorSnapshot

    spark = SparkSession.builder.getOrCreate()
    schema = os.environ.get("DQA_CONTROL_SCHEMA", "governance.dq")
    assets_root = os.environ.get(
        "DQA_MONITOR_ASSETS_DIR",
        "/Workspace/Shared/dq-agent-monitoring",
    )
    output_schema = os.environ.get("DQA_MONITOR_OUTPUT_SCHEMA", schema)

    sources = spark.sql(
        f"SELECT DISTINCT fq_table FROM {schema}.source_registry WHERE enabled"
    ).collect()

    w = WorkspaceClient()
    created, skipped, failed = [], [], []

    for row in sources:
        fq_table = row["fq_table"]
        if _existing_monitor(w, fq_table):
            skipped.append(fq_table)
            continue
        try:
            w.quality_monitors.create(
                table_name=fq_table,
                assets_dir=f"{assets_root}/{fq_table.replace('.', '_')}",
                output_schema_name=output_schema,
                # Snapshot: profiles the table's CURRENT full state on every refresh and
                # compares it to the previous refresh — no timestamp column required. Right
                # fit here: these are metadata/results tables, not append-only event logs.
                snapshot=MonitorSnapshot(),
            )
            created.append(fq_table)
        except Exception as e:
            failed.append((fq_table, str(e)))

    print(f"LAKEHOUSE MONITORS: created {len(created)}, already existed {len(skipped)}, "
          f"failed {len(failed)}")
    for t in created:
        print(f"  created: {t}")
    for t in skipped:
        print(f"  skipped (already monitored): {t}")
    for t, err in failed:
        print(f"  FAILED: {t} -- {err}")
    if failed:
        raise RuntimeError(f"{len(failed)} monitor(s) failed to create — see output above")


if __name__ == "__main__":
    main()
