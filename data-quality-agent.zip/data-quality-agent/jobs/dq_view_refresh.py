"""View refresh — rebuilds the 3 unified views from governance.dq.source_registry,
plus auto-discovers every data_profile.dp_*_status table for v_profile_unified.

No CDF, no MERGE, no sync state, no watermark. These are VIEWS over each team's
own table, so there is nothing to keep in sync — a view always reflects the
latest write, with zero lag. This job only needs to run when a row is ADDED to
source_registry (a new team/table), or a new dp_*_status table appears. See
docs/UNIFIED_VIEWS.md for the design and sql/03_scale_optimizations.sql for the
hand-written reference version of what this job generates.
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))

from pyspark.sql import SparkSession

RULES_COLUMNS = ["rule_id", "owner_team", "source_table", "domain", "sub_domain", "product_id",
                  "rule_name", "description", "rule_type", "condition", "action_if_failed",
                  "severity", "is_active", "created_at", "updated_at"]

STATS_COLUMNS = ["owner_team", "domain", "sub_domain", "product_id", "job_type", "load_type",
                  "batch", "job_run_id", "task_name", "dataset_id", "input_count", "error_count",
                  "output_count", "unique_pii_count", "rule_name", "failed_row_count", "details",
                  "result_level", "loaded_ts"]

PROFILE_COLUMNS = ["domain", "sub_domain", "pipeline_name", "column_name", "failed_metrics",
                    "metric_values", "status", "formatted_date", "year", "month", "day_of_month",
                    "loaddt"]

def _severity_case(action_expr: str) -> str:
    return f"""CASE upper(coalesce({action_expr}, ''))
    WHEN 'BLOCK' THEN 'critical' WHEN 'FAIL_JOB' THEN 'critical' WHEN 'REJECT' THEN 'critical'
    WHEN 'QUARANTINE' THEN 'high' WHEN 'WARN' THEN 'medium' ELSE 'low' END"""


def _rules_select(source_id, owner_team, fq_table, mapping: dict) -> str:
    return f"""SELECT
  {mapping.get('rule_id', 'NULL')} AS rule_id,
  '{owner_team}' AS owner_team,
  '{fq_table}' AS source_table,
  {mapping.get('domain', 'NULL')} AS domain,
  {mapping.get('sub_domain', 'NULL')} AS sub_domain,
  {mapping.get('product_id', 'NULL')} AS product_id,
  {mapping.get('rule_name', 'NULL')} AS rule_name,
  {mapping.get('description', 'NULL')} AS description,
  {mapping.get('rule_type', 'NULL')} AS rule_type,
  {mapping.get('condition', 'NULL')} AS condition,
  {mapping.get('action_if_failed', 'NULL')} AS action_if_failed,
  {_severity_case(mapping.get('action_if_failed', 'NULL'))} AS severity,
  {mapping.get('is_active', 'true')} AS is_active,
  {mapping.get('created_at', 'NULL')} AS created_at,
  {mapping.get('updated_at', 'NULL')} AS updated_at
FROM {fq_table}"""


def _stats_select(owner_team, fq_table, mapping: dict) -> str:
    base = ",\n  ".join(f"{mapping.get(c, 'NULL')} AS {c}" for c in
                         ["domain", "sub_domain", "product_id", "job_type", "load_type", "batch",
                          "job_run_id", "task_name", "dataset_id", "input_count", "error_count",
                          "output_count", "unique_pii_count"])
    # dq_stats-style array<map> columns are the common case; a team without them can map
    # rule_name/failed_row_count directly instead — see the ELSE branch.
    #
    # loaded_ts: map this to a REAL write-timestamp column from the source table if one
    # exists (e.g. created_at, insert_ts, run_date). Left unmapped, it falls back to
    # current_timestamp() — the moment the VIEW is QUERIED, not the moment the row was
    # actually written. That fallback makes v_run_summary.run_ts and alert_stats_gaps
    # useless for freshness (every row looks "just written" no matter how old it is) — see
    # docs/PRODUCTION_READINESS.md -> Monitoring for why this matters and what to do about it.
    loaded_ts_expr = mapping.get('loaded_ts', 'current_timestamp()')
    if "row_dq_results_col" in mapping or "row_results_array" in mapping:
        array_col = mapping.get("row_results_array", "row_dq_results")
        agg_col = mapping.get("agg_results_array", "agg_dq_results")
        return f"""SELECT '{owner_team}' AS owner_team,
  {base},
  r['rule'] AS rule_name, TRY_CAST(r['failed_row_count'] AS BIGINT) AS failed_row_count,
  r['details'] AS details, 'row' AS result_level, {loaded_ts_expr} AS loaded_ts
FROM {fq_table}
LATERAL VIEW OUTER explode({array_col}) t AS r
UNION ALL
SELECT '{owner_team}' AS owner_team,
  {base},
  r['rule'], TRY_CAST(r['failed_row_count'] AS BIGINT), r['details'], 'agg', {loaded_ts_expr}
FROM {fq_table}
LATERAL VIEW OUTER explode({agg_col}) t AS r"""
    return f"""SELECT '{owner_team}' AS owner_team,
  {base},
  {mapping.get('rule_name', 'NULL')} AS rule_name,
  {mapping.get('failed_row_count', 'NULL')} AS failed_row_count,
  {mapping.get('details', 'NULL')} AS details,
  'row' AS result_level, {loaded_ts_expr} AS loaded_ts
FROM {fq_table}"""


def _discover_profile_tables(spark) -> list:
    rows = spark.sql("""
        SELECT table_catalog, table_schema, table_name
        FROM system.information_schema.tables
        WHERE table_schema = 'data_profile' AND table_name LIKE 'dp\\_%\\_status' ESCAPE '\\\\'
    """).collect()
    return [f"{r['table_catalog']}.{r['table_schema']}.{r['table_name']}" for r in rows]


def _profile_select(fq_table, mapping: dict) -> str:
    # For a team's profile table that doesn't follow the dp_*_status naming convention, so
    # _discover_profile_tables() would never find it — an explicit source_registry row (like
    # rules/stats already support) is the fallback. Same column_mapping mechanism.
    cols = ["domain", "sub_domain", "pipeline_name", "column_name", "failed_metrics",
            "metric_values", "status", "formatted_date", "year", "month", "day_of_month", "loaddt"]
    select_list = ",\n  ".join(f"{mapping.get(c, 'NULL')} AS {c}" for c in cols)
    return f"SELECT\n  {select_list}\nFROM {fq_table}"


def main() -> None:
    spark = SparkSession.builder.getOrCreate()
    schema = os.environ.get("DQA_CONTROL_SCHEMA", "governance.dq")

    # Only enabled rows feed the shared views — onboarding a table is a manual, reviewed
    # MERGE by the platform team (sql/02), not something the agent can do itself.
    sources = spark.sql(
        f"SELECT * FROM {schema}.source_registry WHERE enabled"
    ).collect()
    rules_sources = [s for s in sources if s["source_type"] == "rules"]
    stats_sources = [s for s in sources if s["source_type"] == "stats"]
    profile_sources = [s for s in sources if s["source_type"] == "profile"]

    if rules_sources:
        rules_sql = "\nUNION ALL\n".join(
            _rules_select(s["source_id"], s["owner_team"], s["fq_table"], s["column_mapping"])
            for s in rules_sources)
        spark.sql(f"CREATE OR REPLACE VIEW {schema}.v_rules_unified AS\n{rules_sql}")
        print(f"v_rules_unified: {len(rules_sources)} source(s)")

    if stats_sources:
        stats_sql = "\nUNION ALL\n".join(
            _stats_select(s["owner_team"], s["fq_table"], s["column_mapping"])
            for s in stats_sources)
        spark.sql(f"CREATE OR REPLACE VIEW {schema}.v_stats_unified AS\n{stats_sql}")
        print(f"v_stats_unified: {len(stats_sources)} source(s)")

    # Two ways into v_profile_unified: auto-discovery (zero-config, for tables that follow the
    # dp_*_status naming convention) and explicit registration (for tables that don't — same
    # column_mapping mechanism rules/stats already use). Explicit registration wins on overlap.
    registered_profile_fq = {s["fq_table"] for s in profile_sources}
    discovered = [t for t in _discover_profile_tables(spark) if t not in registered_profile_fq]

    profile_selects = [f"""SELECT
  domain, subdomain AS sub_domain, pipeline_name, column_name,
  failed_metrics, metric_values, status, formatted_date, year, month, day_of_month, loaddt
FROM {t}""" for t in discovered]
    profile_selects += [_profile_select(s["fq_table"], s["column_mapping"]) for s in profile_sources]

    if profile_selects:
        profile_sql = "\nUNION ALL\n".join(profile_selects)
        spark.sql(f"CREATE OR REPLACE VIEW {schema}.v_profile_unified AS\n{profile_sql}")
        print(f"v_profile_unified: {len(discovered)} auto-discovered + "
              f"{len(profile_sources)} explicitly registered")

    print("VIEW REFRESH complete — v_run_summary and v_latest_scorecard read the "
          "views above by name and need no changes.")


if __name__ == "__main__":
    main()
