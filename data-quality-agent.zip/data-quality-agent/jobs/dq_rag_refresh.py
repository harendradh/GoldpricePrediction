"""RAG refresh — renders v_rules_unified + dataset_registry into readable markdown for the
"DQ Rule Reference" RAG collection.

Run right after dq_view_refresh.py (same job, next task) so the rendered rules are current.
See docs/RAG_INTEGRATION.md for why this is a *generated document*, not a raw table export,
and why v_run_summary (live scores) is deliberately excluded — that's tool/Genie territory.
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))

from pyspark.sql import SparkSession

OUTPUT_VOLUME_PATH = "/Volumes/governance/dq/rag_exports/dq_rule_reference.md"


def _render_domain_section(ds_row, rules) -> str:
    label = ds_row["domain"] + (f" / {ds_row['sub_domain']}" if ds_row["sub_domain"] else "")
    lines = [f"## {label} ({ds_row['owner_team']} team, {ds_row['criticality']})"]
    if ds_row["freshness_sla_minutes"]:
        lines.append(f"Freshness SLA: {ds_row['freshness_sla_minutes']} minutes.")
    lines.append("")
    for r in rules:
        lines.append(f"- **{r['rule_name']}** ({r['rule_type']}, {r['severity']}, "
                      f"action_if_failed={r['action_if_failed']})")
        if r["description"]:
            lines.append(f"  {r['description']}")
        if r["owner_team"] and r["owner_team"] != ds_row["owner_team"]:
            lines.append(f"  _From {r['owner_team']}'s own table (`{r['source_table']}`) — "
                          f"edit it there, not here._")
    lines.append("")
    return "\n".join(lines)


def main() -> None:
    spark = SparkSession.builder.getOrCreate()
    schema = os.environ.get("DQA_CONTROL_SCHEMA", "governance.dq")

    domains = spark.sql(
        f"SELECT domain, sub_domain, owner_team, criticality, freshness_sla_minutes "
        f"FROM {schema}.dataset_registry WHERE active ORDER BY domain"
    ).collect()
    rules = spark.sql(
        f"SELECT domain, sub_domain, owner_team, source_table, rule_name, description, "
        f"rule_type, severity, action_if_failed FROM {schema}.v_rules_unified "
        f"WHERE is_active ORDER BY domain, CASE severity WHEN 'critical' THEN 0 "
        f"WHEN 'high' THEN 1 WHEN 'medium' THEN 2 ELSE 3 END"
    ).collect()

    rules_by_domain: dict = {}
    for r in rules:
        rules_by_domain.setdefault((r["domain"], r["sub_domain"]), []).append(r)

    doc = ["# DQ Rule Reference (generated — do not edit by hand)",
           "", "Regenerated on every scheduled run by jobs/dq_rag_refresh.py, right after "
           "dq_view_refresh.py. Upload to the `DQ Rule Reference` RAG collection in Agent "
           "Studio. Every rule here still lives in its owning team's own table — this is a "
           "read-only rendering, not a copy of record.", ""]
    for ds in domains:
        key = (ds["domain"], ds["sub_domain"])
        doc.append(_render_domain_section(ds, rules_by_domain.get(key, [])))

    content = "\n".join(doc)
    try:
        from pyspark.dbutils import DBUtils  # type: ignore
        DBUtils(spark).fs.put(OUTPUT_VOLUME_PATH, content, overwrite=True)
    except Exception as e:
        print(f"WARN: could not write to {OUTPUT_VOLUME_PATH} ({e}). Content was computed "
              f"correctly (see below) — if the Volume doesn't exist yet, create it and rerun, "
              f"or upload this manually as a fallback.")
        print(content)
        raise

    print(f"RAG REFRESH: wrote {len(domains)} domain sections, {len(rules)} rules to {OUTPUT_VOLUME_PATH}")


if __name__ == "__main__":
    main()
