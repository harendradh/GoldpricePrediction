"""Job task: create/refresh Lakehouse Monitors for all monitor-enabled datasets.

NOT deployed by default (see deploy/databricks.job.yml) — descoped along with
agent_studio/tools/dq_get_drift.py in the simplified design; needs a domain -> physical
target table mapping that doesn't exist yet. Kept as a reference for when that mapping exists.

Runs after the nightly sweep so drift/freshness metrics stay current. Native Lakehouse
Monitoring does the statistical heavy lifting; we just ensure monitors exist and are refreshed.
"""
import os
import sys

# POC mode: no wheel needed — see the comment in jobs/dq_check_job.py.
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))

from pyspark.sql import SparkSession

from dq_agent.engine.monitoring import refresh_all


def main() -> None:
    spark = SparkSession.builder.getOrCreate()
    control = os.environ.get("DQA_CONTROL_SCHEMA", "governance.dq")
    output_schema = os.environ.get("DQA_MONITOR_OUTPUT_SCHEMA", control)
    results = refresh_all(spark, control, output_schema)
    ok = sum(1 for r in results if "error" not in r)
    print(f"MONITOR REFRESH: {ok}/{len(results)} monitors ensured/refreshed")
    for r in results:
        if "error" in r:
            print(f"  ! {r['dataset_id']}: {r['error']}")


if __name__ == "__main__":
    main()
