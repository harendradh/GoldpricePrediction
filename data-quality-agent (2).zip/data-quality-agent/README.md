# Data Quality Agent (DQA)

A production-grade, **metadata-driven Data Quality Agent** built on the Fiserv Agent Studio
framework. The agent orchestrates data-quality checks; **all compute stays on Databricks**
(Spark SQL, Delta, Lakehouse Monitoring). No third-party check engines (no Great Expectations).

It is designed as a **shared product** across teams and BUs: a team onboards a dataset by
inserting rows into control tables — no code changes, no redeploy.

> **Integration path:** Agent Studio is already deployed on Azure Container Apps. You build
> the agent **in the Agent Studio UI** — 8 Tools as **Python Functions** + 1 native
> **Databricks Genie** tool (NL Q&A over `governance.dq.*` only, no code), plus an Agent, a
> RAG collection, and (optionally) a Workflow.
> **Start with [`agent_studio/BUILD_GUIDE.md`](agent_studio/BUILD_GUIDE.md).**
> The `src/dq_agent/api/` + `deploy/Dockerfile` are an **optional** standalone service and are
> NOT required when using Agent Studio.

---

## What it does

1. **Discover & profile** any Delta table via Unity Catalog.
2. **Generate / fetch** data-quality rules from a Delta-backed rule catalog.
3. **Execute checks** as a Databricks Job (native Spark SQL engine — `src/dq_agent/engine`).
4. **Detect drift / anomalies / freshness** via Databricks Lakehouse Monitoring.
5. **Score** each dataset (0–100 + RAG) and persist results to Delta.
6. **Explain & remediate** — root-cause narrative + suggested actions (quarantine, backfill, notify).
7. **Alert** owners (Teams / email / ServiceNow).

## Architecture

```
User / Scheduler
      │
      ▼
Agent Studio  ──►  DQA Supervisor Agent (LLM on Databricks model)
(Azure Container App)      │   orchestrates Tools (thin, deterministic)
      │                    │
   FastAPI  ───────────────┘
      │
      ▼ (Databricks REST: Jobs API + SQL Statement Execution API)
Databricks Workspace
      ├── DQ Check Job  ──►  native rule engine (PySpark)  ──►  Delta: dq_results
      ├── Lakehouse Monitoring (drift / freshness / anomaly)
      └── Unity Catalog (metadata, lineage, governance)
```

The agent runtime **never reads data rows**. It triggers jobs and reads aggregated results.
This keeps PII/PCI inside the Databricks governance boundary — important for Fiserv.

## Components

| Path | Purpose |
|------|---------|
| `sql/` | Delta control-table DDL + golden-rule seeds (the metadata backbone) |
| `src/dq_agent/engine/` | Native Spark SQL DQ engine (rule compilation, scoring, profiler) |
| `src/dq_agent/databricks/` | Databricks REST clients (Jobs API, SQL Execution, Monitoring) |
| `src/dq_agent/tools/` | Agent Studio tools (JSON in/out) |
| `src/dq_agent/agents/` | Supervisor prompt + orchestration contract |
| `src/dq_agent/models/` | Pydantic schemas = the data contracts |
| `src/dq_agent/api/` | FastAPI service deployed to the Azure Container App |
| `jobs/dq_check_job.py` | Databricks Job entrypoint (runs the engine on a cluster) |
| `deploy/` | Dockerfile + Azure Container App IaC |
| `tests/` | Unit tests for the engine + scoring |

## Control tables (metadata backbone)

| Table | Role |
|-------|------|
| `dq.dataset_registry` | Datasets onboarded (owner BU, criticality, freshness SLA, PKs) |
| `dq.rule_catalog` | Every rule (dimension, type, target, threshold, severity) |
| `dq.results` | Row-level check outcomes per run |
| `dq.run_summary` | Per-run rollup: score + RAG + dimension breakdown |

Onboarding a new BU = `INSERT` into `dataset_registry` + `rule_catalog`. That's it.

## DQ dimensions covered

Completeness · Uniqueness · Validity/Conformity · Accuracy · Consistency ·
Integrity (referential) · Timeliness/Freshness · Volume/Anomaly · Distribution/Drift · Schema.

## Quick start

```bash
# 1. Create control tables + seed golden rules (run on a Databricks SQL warehouse)
databricks sql -f sql/01_control_tables.sql
databricks sql -f sql/02_seed_golden_rules.sql

# 2. Deploy the DQ engine job — POC mode by default: no wheel, runs straight from src/
databricks bundle deploy      # see jobs/ and deploy/databricks.job.yml
# (switch to a wheel for production — see docs/SETUP_GUIDE.md Phase 2)

# 3. Build & run the agent API locally
cp .env.example .env          # fill Databricks host/token, job id
pip install -e ".[dev]"
uvicorn dq_agent.api.main:app --reload

# 4. Register the tools in Agent Studio (point to /tools/* endpoints)
```

See `docs/RUNBOOK.md` for the production deployment path.

## Design principles

- **Metadata-driven**: rules are data, not code → reuse across BUs.
- **Compute stays in Databricks**: agent orchestrates, never processes rows.
- **Deterministic tools, reasoning LLM**: the model decides *when*; tools decide *what*.
- **Human-in-the-loop** for rule creation and remediation until trusted.
- **Everything auditable**: every run + LLM rationale is logged.
