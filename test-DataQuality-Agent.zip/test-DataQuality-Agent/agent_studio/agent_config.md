# Agent Studio — "Create Agent" Configuration

This document records the exact field values to enter into DCS Agent Studio's
**Create Agent** form for the Data Quality AI Agent. It is onboarding
alongside other teams' already-live agents in the same Agent Studio instance,
so naming must be specific enough not to collide (avoid generic names like
"DQ Agent" or "Data Agent").

## Basic Info

| Field | Value |
|---|---|
| **Agent Name** | `Data Quality Investigation Agent` |
| **Agent ID / Slug** | `dq-investigation-agent` |
| **Description** (shown in Agent Studio catalog) | "Investigates data quality issues across Unity Catalog tables by reasoning over human-curated business rules, execution history, profiling statistics, schema/lineage system tables, and automated DQX checks. Answers root-cause, freshness, volume, schema-drift, and lineage-impact questions with cited evidence, a stated confidence score, and human-reviewable SQL/YAML recommendations. Never executes or deploys changes." |
| **Owning Team** | Data Quality / Data Governance (central DQ team) |
| **Environment** | Databricks Lakehouse / Unity Catalog — no Serverless compute available yet (does not affect this agent; Genie + Databricks-hosted model serving do not require it) |

## Model

| Field | Value |
|---|---|
| **Model** | Databricks-hosted Claude endpoint (DCS Agent Studio's model serving endpoint) — select the workspace's provisioned endpoint, e.g. `<databricks-model-serving-endpoint-name>` (Claude, hosted on Databricks Model Serving; do not point at an external Anthropic API endpoint — this must stay inside the governed Databricks boundary). |
| **Temperature** | Low (0–0.2) — this agent reports facts and cites sources; it should not be creative. |
| **Max output tokens** | Set to the Agent Studio default for investigative/analytical agents (large enough for a synthesized answer with cited evidence + a SQL/YAML recommendation block, typically 2–4K tokens). |

## Agent Type

| Field | Value |
|---|---|
| **Type** | `Sequential` — the agent orchestrates a sequence of tool calls (one or more Genie space queries) and reasons over the combined results before responding. It does not run tools in an autonomous/looping ReAct mode with unbounded steps; each user turn resolves through a bounded, ordered set of Genie calls followed by one synthesis step. |
| **Orchestration behavior** | Understand intent → identify table/dimension/scope → call the routed Genie space(s) → (optionally) call a second space to cross-reference (e.g. Schema Intelligence + Lineage & Impact) → synthesize → respond. See `agent_studio/system_instruction.md` for the full reasoning loop. |

## Tools Wired to This Agent

All 8 tools are **Genie-type** tools, one per Genie space defined in
`docs/03_GENIE_WORKSPACES.md`. Full per-tool Agent Studio form values (Genie
Space ID, host, description, auth) are in `agent_studio/tools_manifest.md` —
listed here for the agent-level configuration view only:

1. `rule_intelligence_genie` — Rule Intelligence (`team_rule`)
2. `profiling_intelligence_genie` — Profiling Intelligence (`data_profile`)
3. `dq_execution_analytics_genie` — DQ Execution Analytics (`dq_stats`, `dqx_results`)
4. `schema_intelligence_genie` — Schema Intelligence (`information_schema`, Delta history)
5. `freshness_intelligence_genie` — Freshness Intelligence (`dq_stats`, `data_profile`, `system.lakeflow`)
6. `volume_intelligence_genie` — Volume Intelligence (`dq_stats`, `data_profile`, `system.lakeflow`)
7. `lineage_impact_genie` — Lineage & Impact Analysis (`system.access.table_lineage`, `system.access.column_lineage`)
8. `governance_intelligence_genie` — Governance Intelligence (cross-team scorecard, ownership, DQX governance/support status)

### Additional (non-Genie) tools

**None required, and none added.** Per the brief's design principle
("orchestrate, don't execute" — §4, §7), essentially all of this agent's
capability comes from (a) the 8 Genie spaces, each of which already reaches
its underlying Unity Catalog tables including `information_schema` and the
relevant `system.*` tables, and (b) the model's own reasoning to combine,
cross-reference, and synthesize across those spaces. Adding a separate UC
function or generic SQL-execution tool would duplicate what a Genie space
already exposes and would risk the agent bypassing the narrow, guardrailed
table scoping each Genie space enforces — so it is deliberately omitted. If a
future gap is found (e.g. an ad hoc query no Genie space's table list
covers), prefer widening that space's table list over adding a raw SQL tool.

## Timeout / Retry Settings

| Setting | Value | Rationale |
|---|---|---|
| **Per-tool-call timeout** | 90 seconds | Genie conversational queries run async server-side (submit → poll → fetch result); 90s covers typical warehouse cold-start + query time without stalling the whole turn. |
| **Per-tool-call retries** | 2 retries, exponential backoff (e.g. 2s, 8s) | Handles transient Genie API/warehouse throttling; do not retry on a definitive "no data" or permission-denied response — surface that immediately per the anti-fabrication rule (a retry storm must never be mistaken for, or reported as, a result). |
| **Overall turn timeout** | 180 seconds | This agent may call more than one Genie space per turn (routing + cross-reference); budget for two sequential tool calls plus synthesis. |
| **Max tool calls per turn** | 3 | One primary routed space, one optional cross-reference space, one optional Governance Intelligence rollup call. Prevents unbounded fan-out across all 8 spaces on a single question. |
| **On timeout/failure** | Report the gap honestly ("Freshness Intelligence did not return a result in time — unable to confirm freshness status") rather than fabricating or silently omitting the dimension. |

## Access / Permission Notes (Unity Catalog)

The agent (via its service principal — see `tools_manifest.md` for the
per-tool auth binding) requires **read-only** grants, matching the
non-negotiable that this agent never writes to any production table:

- `SELECT` on `team_rule`, `dq_stats`, `data_profile` (the three shared,
  multi-tenant metadata tables — one grant covers all onboarded teams' rows,
  since these are row-filtered by `team_name`/`catalog_name`/`schema_name`/
  `table_name`, not per-team physical copies).
- `SELECT` on `dqx_results` (the DQ-team-owned central results schema that
  Tier-1 DQX runs write to).
- `SELECT` on `information_schema` for every catalog/schema the agent needs
  Schema Intelligence coverage over (column definitions, table properties).
- `SELECT` (via the workspace's system schema enablement) on the relevant
  `system.access.*` and `system.lakeflow.*` tables — specifically
  `system.access.table_lineage`, `system.access.column_lineage`, and
  `system.lakeflow.job_run_timeline` — required for Lineage & Impact Analysis
  and Freshness/Volume Intelligence respectively. These system tables require
  a metastore admin to enable the corresponding system schema before grants
  are usable; note this as a one-time platform-level prerequisite, not a
  per-team onboarding step.
- `USE CATALOG` / `USE SCHEMA` on every catalog/schema containing tables the
  agent must reach (Tier 1 DQX coverage depends on the agent/service
  principal having at least `SELECT` on the target table itself, per the
  brief's cold-start design).
- **No `MODIFY`, `INSERT`, `UPDATE`, `DELETE`, or `CREATE` grants anywhere.**
  This is not a hardening afterthought — it is the mechanism that makes
  "AI-assisted, not AI-autonomous" true at the platform level, not just at
  the prompt level: even if the model attempted a write, Unity Catalog would
  reject it.
