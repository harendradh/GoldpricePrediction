# Tools Manifest — Agent Studio "Create New Tool → Type: Databricks Genie"

One entry per Genie space wired to `dq-investigation-agent` (8 total, per
`docs/03_GENIE_WORKSPACES.md`). Each entry lists exactly the fields Agent
Studio's Genie tool form requires. Genie Space IDs and the workspace host are
placeholders — fill in the real values when each space is provisioned; do not
invent IDs.

The **description** field is the single most important value here: it is the
only signal the orchestrating model sees when deciding which tool to call for
a given question, so each one below is written to be unambiguous against the
other seven — differentiated by which table(s) it owns and which question
shapes route to it, not just by dimension name.

---

## 1. Rule Intelligence

| Field | Value |
|---|---|
| **Tool name** | `rule_intelligence_genie` |
| **Tool type** | Databricks Genie |
| **Genie Space ID** | `<genie-space-id-rule-intel>` |
| **Workspace host** | `<databricks-workspace-host>` |
| **Description** | "Answers questions about human-authored business rules from the `team_rule` table only: what rules exist for a table/column, their SQL/Python expression, severity, action-if-failed, active status, and effective dates. Use for 'what rule checks X', 'why does this rule exist', 'who owns this rule', or 'is there a business rule for column Y'. Does NOT contain execution results (pass/fail history) or profiling stats — route those to DQ Execution Analytics or Profiling Intelligence instead." |
| **Credential / auth** | Service principal `sp-dq-agent` with `SELECT`-only grant on `team_rule` (shared multi-tenant table, row-filtered by team/catalog/schema/table — no per-team grant needed). No `MODIFY`/`INSERT` grant exists for this principal. |

## 2. Profiling Intelligence

| Field | Value |
|---|---|
| **Tool name** | `profiling_intelligence_genie` |
| **Tool type** | Databricks Genie |
| **Genie Space ID** | `<genie-space-id-profiling-intel>` |
| **Workspace host** | `<databricks-workspace-host>` |
| **Description** | "Answers questions about column-level statistical profiles from the `data_profile` table only: null percentage, distinct count, min/max, distribution histograms, cardinality ratio, and row count at profile time for a given column/table/date. Use for 'what's the null rate on column X', 'has the distribution shifted', 'how many distinct values'. Does NOT contain rule definitions or pass/fail execution results — route those to Rule Intelligence or DQ Execution Analytics instead. For freshness timestamps specifically, prefer Freshness Intelligence." |
| **Credential / auth** | Service principal `sp-dq-agent` with `SELECT`-only grant on `data_profile` (shared multi-tenant table). No write grants. |

## 3. DQ Execution Analytics

| Field | Value |
|---|---|
| **Tool name** | `dq_execution_analytics_genie` |
| **Tool type** | Databricks Genie |
| **Genie Space ID** | `<genie-space-id-dq-exec-analytics>` |
| **Workspace host** | `<databricks-workspace-host>` |
| **Description** | "Answers questions about rule EXECUTION history and outcomes, from `dq_stats` (Tier 2, team-run jobs) and `dqx_results` (Tier 1, automated DQX sweeps) only: run status (SUCCESS/FAILED/PARTIAL/NOT_RUN), pass/fail counts, pass-rate trend over time, failed rule IDs, duration, error messages. Use for 'did this rule pass today', 'what's the pass rate this week', 'was this even run'. Never infer PASS from a missing row — a rule absent from today's results is NOT_RUN, not passed. Does NOT define what a rule checks (see Rule Intelligence) or profile column statistics (see Profiling Intelligence)." |
| **Credential / auth** | Service principal `sp-dq-agent` with `SELECT`-only grant on `dq_stats` (shared multi-tenant table) and `dqx_results` (central DQ-owned schema). No write grants. |

## 4. Schema Intelligence

| Field | Value |
|---|---|
| **Tool name** | `schema_intelligence_genie` |
| **Tool type** | Databricks Genie |
| **Genie Space ID** | `<genie-space-id-schema-intel>` |
| **Workspace host** | `<databricks-workspace-host>` |
| **Description** | "Answers questions about table structure and schema evolution using native Unity Catalog `information_schema` and Delta table history (`DESCRIBE HISTORY` / Time Travel) only — no custom schema-snapshot table exists. Use for 'was a column added/dropped/renamed', 'did a data type change', 'what does this table's schema look like today vs last week'. Does NOT contain rule results, profiling stats, or lineage — route pass/fail questions to DQ Execution Analytics and blast-radius questions to Lineage & Impact Analysis." |
| **Credential / auth** | Service principal `sp-dq-agent` with `SELECT` on `information_schema` for every onboarded catalog/schema, plus implicit read access to each table's Delta transaction log via existing table `SELECT` grants (no separate grant required for `DESCRIBE HISTORY` beyond table `SELECT`). No write grants. |

## 5. Freshness Intelligence

| Field | Value |
|---|---|
| **Tool name** | `freshness_intelligence_genie` |
| **Tool type** | Databricks Genie |
| **Genie Space ID** | `<genie-space-id-freshness-intel>` |
| **Workspace host** | `<databricks-workspace-host>` |
| **Description** | "Answers questions about the Timeliness dimension only: how stale a table/column is, last-updated timestamps, late-arrival patterns, and SLA breaches — drawn from `data_profile.freshness_last_updated_ts`, `dq_stats.execution_timestamp`, and `system.lakeflow.job_run_timeline` (actual pipeline run times). Use for 'when did this table last update', 'is this data stale', 'did the job run late today'. Does NOT answer volume/row-count questions (see Volume Intelligence) or schema questions (see Schema Intelligence) even though both can look like 'something changed' questions." |
| **Credential / auth** | Service principal `sp-dq-agent` with `SELECT` on `data_profile`, `dq_stats`, and the enabled `system.lakeflow` system schema (requires one-time metastore-admin enablement of the Lakeflow system schema; not a per-team grant). No write grants. |

## 6. Volume Intelligence

| Field | Value |
|---|---|
| **Tool name** | `volume_intelligence_genie` |
| **Tool type** | Databricks Genie |
| **Genie Space ID** | `<genie-space-id-volume-intel>` |
| **Workspace host** | `<databricks-workspace-host>` |
| **Description** | "Answers questions about the Volume dimension only: row-count anomalies, unexpected spikes/drops in `dq_stats.input_record_count` and `data_profile.row_count_at_profile_time`, correlated against `system.lakeflow.job_run_timeline` for run-level context. Use for 'did row counts drop today', 'is this an unusual volume for this table', 'how many rows came in on this run'. Does NOT answer 'is the data stale' (see Freshness Intelligence) or 'did a column change' (see Schema Intelligence) — those are different dimensions even when triggered by the same underlying incident." |
| **Credential / auth** | Service principal `sp-dq-agent` with `SELECT` on `dq_stats`, `data_profile`, and the enabled `system.lakeflow` system schema. No write grants. |

## 7. Lineage & Impact Analysis

| Field | Value |
|---|---|
| **Tool name** | `lineage_impact_genie` |
| **Tool type** | Databricks Genie |
| **Genie Space ID** | `<genie-space-id-lineage-impact>` |
| **Workspace host** | `<databricks-workspace-host>` |
| **Description** | "Answers upstream/downstream blast-radius questions only, using native Unity Catalog `system.access.table_lineage` and `system.access.column_lineage` system tables — no other space in this agent may claim a lineage/impact finding without a result from this tool. Use for 'what depends on this table', 'what feeds this table', 'if this column is wrong, what breaks downstream'. Do NOT use this space for schema structure (see Schema Intelligence) or execution status (see DQ Execution Analytics) — it answers 'what connects to what', not 'is it correct' or 'did it run'." |
| **Credential / auth** | Service principal `sp-dq-agent` with `SELECT` on the enabled `system.access` system schema (`table_lineage`, `column_lineage`) — requires one-time metastore-admin enablement. No write grants. |

## 8. Governance Intelligence

| Field | Value |
|---|---|
| **Tool name** | `governance_intelligence_genie` |
| **Tool type** | Databricks Genie |
| **Genie Space ID** | `<genie-space-id-governance-intel>` |
| **Workspace host** | `<databricks-workspace-host>` |
| **Description** | "Answers cross-team, organization-wide questions only: the aggregate data quality scorecard across all 7 dimensions and all onboarded teams, which teams have Tier 2 (`team_rule`/`dq_stats`/`data_profile`) coverage vs. Tier-1-only, table/rule ownership, and DQX governance/support posture (source-available Databricks Labs license, no official SLA — flag when asked about DQX's support status). Use for 'give me the org-wide DQ scorecard', 'which teams have no rule coverage yet', 'what's the daily health summary'. Does NOT answer a single-table root-cause question — route those to the dimension-specific space instead (this space aggregates across tables/teams, it does not drill into one)." |
| **Credential / auth** | Service principal `sp-dq-agent` with `SELECT` on `team_rule`, `dq_stats`, `data_profile`, `dqx_results` at the aggregate/rollup level (same grants as the other spaces — no elevated or additional access; aggregation is a query pattern, not a permission tier). No write grants. |

---

## Cross-cutting auth note

All 8 tools authenticate as the same service principal, `sp-dq-agent`,
holding **`SELECT`-only** Unity Catalog grants across every table and system
schema listed above, plus `USE CATALOG`/`USE SCHEMA` on each containing
catalog/schema. This single-identity, read-only pattern is deliberate: it is
what makes "AI-assisted, not AI-autonomous" enforceable at the platform layer
rather than only at the prompt layer (§4 of `system_instruction.md`) — there
is no write path for any of the 8 tools to use even under adversarial or
malformed instructions.
