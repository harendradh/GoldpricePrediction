# Onboarding Runbook — Data Quality AI Agent

## Purpose

This is the step-by-step deployment runbook for standing up the Data Quality
AI Agent in DCS Agent Studio, from initial grants through go-live, plus the
repeatable path for onboarding each additional team afterward. It assumes
the design in `CONTEXT_BRIEF.md`, `docs/01_ARCHITECTURE.md`,
`docs/03_GENIE_WORKSPACES.md`, and `docs/04_DQX_INTEGRATION.md` as given —
this document sequences the work, it does not re-specify it.

Follow the steps in order. Steps 1–6 are one-time platform setup. Step 7 is
the repeatable per-team onboarding path and is intentionally near-zero-effort
by design (see `CONTEXT_BRIEF.md` §1.4).

---

## Step 1 — Grant the agent's service principal read access

Create (or reuse) a dedicated service principal for the agent and the
central DQX job, and grant it read-only access — the agent never needs
write access to any source or team table.

Minimum grants:

- `SELECT` on the three shared, multi-tenant Delta tables:
  `team_rule`, `dq_stats`, `data_profile`.
- `SELECT` on the DQX-owned results tables: `dqx_results`, `dqx_quarantine`,
  `dqx_run_metrics` (`dq_catalog.dq_results`, see
  `dqx/ddl/dqx_metadata_tables_ddl.sql` and `docs/04_DQX_INTEGRATION.md`).
- `SELECT` (or `USE CATALOG` / `USE SCHEMA` + `SELECT`) on
  `information_schema` for every catalog/schema the agent needs to reason
  about — required for schema understanding, drift comparison, and
  disambiguating table references.
- `SELECT` on the relevant native system tables:
  - `system.access.table_lineage` and `system.access.column_lineage`
    (Lineage & Impact Analysis).
  - `system.lakeflow.job_run_timeline` (Freshness Intelligence /
    root-cause correlation with job runs).
  - Delta history access (`DESCRIBE HISTORY`, Time Travel) on every table
    in scope — this is a property of `SELECT` plus table-history retention,
    not a separate grant, but confirm retention settings
    (`delta.logRetentionDuration`) are long enough for the schema-drift
    lookback window the agent needs (see `docs/03_GENIE_WORKSPACES.md`,
    Schema Intelligence).
  - `SELECT` on any source tables the central DQX job checks under Tier 1 —
    this is the *only* grant a new team needs to provide for zero-effort
    Tier 1 coverage (see Step 7).

**No write grants are issued anywhere.** The agent and the DQX job are
read-only against every team's data; DQX writes only to its own
`dqx_results`/output schema, and the agent never writes to `team_rule`,
`dq_stats`, `data_profile`, or any production table (non-negotiable, see
`CONTEXT_BRIEF.md` §8).

**Exit criteria:** service principal exists, all grants above are applied
and verified with a test query against each object as the service principal
identity (not an admin identity).

---

## Step 2 — Set table/column descriptions and declare PK/FK relationships

Genie's documented best practice is that table/column **comments and declared
relationships are the "mission statements" Genie reads to understand
intent** — without them, Genie has to infer meaning from names alone, which
degrades answer quality and increases hallucination risk. Do this before
creating the Genie spaces in Step 3.

For each of the four shared tables (`team_rule`, `dq_stats`, `data_profile`,
`dqx_results`):

1. Set a table-level comment describing its purpose and grain (e.g., for
   `dq_stats`: "One row per rule-execution run. Multi-tenant, filtered by
   `team_name`/`catalog_name`/`schema_name`/`table_name`. `status = NOT_RUN`
   or an absent row means the rule did not execute — never treat as pass.").
2. Set column-level comments on every column, especially the ones an LLM is
   likely to misread without context:
   - `status` on `dq_stats` — enumerate the values (`SUCCESS`, `FAILED`,
     `PARTIAL`, `NOT_RUN`) and state the anti-fabrication rule inline.
   - `quality_dimension_tag` on `team_rule` — list the exact 7 allowed
     values (Completeness, Validity, Consistency, Uniqueness, Timeliness,
     Volume, Schema Drift) plus `Custom`, and note it is human-set and
     nullable.
   - `action_if_failed` on `team_rule` — enumerate `REJECT`/`QUARANTINE`/
     `FLAG`/`ALERT_ONLY`.
   - `failed_rule_ids` on `dq_stats` — note it is an `array<string>` of
     rule IDs, joinable back to `team_rule.rule_id`.
   - `distribution_summary` on `data_profile` — note it is a JSON histogram,
     not a scalar.
3. Declare primary keys and foreign-key-style relationships explicitly
   (Unity Catalog supports informational/non-enforced PK/FK constraints —
   use them even though they aren't enforced):
   - `team_rule.rule_id` as primary key.
   - `dq_stats.execution_id` as primary key; `dq_stats` join path to
     `team_rule` via `(team_name, catalog_name, schema_name, table_name)` and,
     where applicable, `failed_rule_ids` → `team_rule.rule_id`.
   - `data_profile.profile_id` as primary key; join path to `team_rule`/
     `dq_stats` via `(team_name, catalog_name, schema_name, table_name,
     column_name)`.
   - `dqx_results` primary key and its shared shape/join path to `dq_stats`
     so DQ Execution Analytics can query both uniformly (per
     `docs/04_DQX_INTEGRATION.md`).
4. Repeat table/column comments for any native system tables the agent
   relies on that don't already have adequate built-in descriptions
   (usually unnecessary for `information_schema`/`system.access.*`/
   `system.lakeflow.*`, which are already well-documented by Databricks, but
   verify).

**Exit criteria:** every column on the four shared tables has a non-empty
comment; PK/FK relationships are declared and visible in
`information_schema.table_constraints` / the catalog UI; a manual spot-check
confirms Unity Catalog Explorer renders the comments correctly.

---

## Step 3 — Create the 8 Genie spaces

Create the eight dimension-named Genie spaces exactly as specified in
`docs/03_GENIE_WORKSPACES.md`: Rule Intelligence, Profiling Intelligence, DQ
Execution Analytics, Schema Intelligence, Freshness Intelligence, Volume
Intelligence, Lineage & Impact Analysis, Governance Intelligence.

For each space:

1. Add its fixed table list (small, scoped — per `docs/03`, not every table
   in the catalog).
2. Add the space's **instructions** (what the space is for, how to interpret
   ambiguous questions, which columns matter).
3. Add the space's **context** (the business/domain framing — e.g., Schema
   Intelligence's context should state it uses `information_schema` and
   Delta history/Time Travel natively, with no custom snapshot table).
4. Add the space's **guardrails** — the anti-fabrication and scope rules
   specific to that space (e.g., DQ Execution Analytics' guardrail that
   `NOT_RUN`/absent rows are never reported as pass; Lineage & Impact
   Analysis' guardrail that no downstream impact is asserted without an
   actual lineage row).
5. Add the space's **certified sample queries** from `docs/03` — these seed
   Genie's example-question matching and materially improve first-query
   accuracy; do not skip this even though it's optional in the Genie UI.
6. Verify the space's table list resolves correctly against the grants from
   Step 1, and that the PK/FK relationships and comments from Step 2 are
   visible to Genie (Genie space creation should happen *after* Step 2, not
   before, so it can read the finished metadata rather than needing a
   refresh).

**Exit criteria:** all 8 spaces exist, each with its table list, instructions,
context, guardrails, and certified queries populated; each space returns a
correct answer to at least its own certified sample queries when tested
manually in the Genie UI before wiring the agent to it.

---

## Step 4 — Deploy the DQX central job against a pilot table set

Deploy the DQX central job per `docs/04_DQX_INTEGRATION.md`, scoped
initially to a small pilot set of tables (not the entire estate) to validate
before wide rollout.

1. Pin a specific `databricks-labs-dqx` version (do not float to latest —
   this is pre-1.0 with real breaking changes; see
   `CONTEXT_BRIEF.md` §3 and `docs/04`).
2. Configure the job to run on a standard job cluster (Spark ≥3.5.0, DBR
   ≥15.4 recommended) — no Serverless dependency for the core engine.
3. Configure `output_config`/`quarantine_config`/`metrics_config` to write
   only to the DQ-owned `dqx_results` schema, shaped to mirror `dq_stats` so
   DQ Execution Analytics can query both tiers uniformly.
4. Select the pilot table set (a handful of representative tables across at
   least two teams, ideally including one team with existing Tier 2 data
   and one team with none, to validate both onboarding paths).
5. Enable the built-in checks relevant to Tier 1's stated scope
   (completeness, validity, uniqueness, freshness, schema) via the profiler
   + built-in check catalog.
6. **Explicitly review the ML anomaly detection setting.** v0.15.0 enables
   ML anomaly detection (SHAP/LLM explanations) by default, and it incurs
   Model Serving cost — decide and document whether it stays on for the
   pilot, and gate/disable it if cost control is a concern before wider
   rollout.
7. Run the job against the pilot set, confirm `dqx_results` rows land with
   the expected shape, and spot-check a few results by hand against the
   source table.

**Exit criteria:** the central DQX job runs successfully end-to-end against
the pilot table set on a standard job cluster, `dqx_results` is populated
and queryable, the DQX version is pinned and recorded, and the anomaly-
detection cost decision is documented.

---

## Step 5 — Create the agent in DCS Agent Studio

Create the agent itself using the three `agent_studio/` specification
documents as the literal configuration source:

1. `agent_studio/agent_config.md` — agent identity, model/endpoint binding
   (the Databricks-hosted Claude endpoint), and space/tool bindings.
2. `agent_studio/system_instruction.md` — the system prompt encoding the
   agent's reasoning loop (per `docs/01_ARCHITECTURE.md` §6), the
   non-negotiables (anti-fabrication, AI-assisted not autonomous, Tier 2 >
   Tier 1, always state tier), and the 8-space routing logic.
3. `agent_studio/tools_manifest.md` — the tool/space bindings that let the
   agent call each of the 8 Genie spaces (and any AI Functions used for
   synthesis), with no direct raw-SQL execution path against source tables
   outside of what a Genie space itself executes.
4. Wire the RAG references (`rag/business_glossary.md`,
   `rag/dimension_playbooks.md`, `rag/historical_incident_patterns.md`,
   `rag/dqx_reference.md`) as the agent's knowledge sources, if DCS Agent
   Studio's configuration supports attaching them at this stage.
5. Confirm the agent has no write-capable tool bound to it anywhere in the
   manifest — this is the enforcement point for the AI-assisted-not-
   autonomous non-negotiable, not just a system-instruction statement.

**Exit criteria:** the agent exists in DCS Agent Studio, is bound to all 8
Genie spaces, has no write-capable tool in its manifest, and responds to a
smoke-test question end-to-end (question → space query → synthesized
answer).

---

## Step 6 — Run every case in `evals/eval_cases.md`

Run the full eval suite from `evals/eval_cases.md` against the deployed
agent before promoting it to any production consumer (dashboards, chat
surfaces, downstream automations).

1. Run the 7 zero-tolerance cases (ZT-01 through ZT-07) first.
   **All 7 must pass with no exceptions — this is a hard go-live gate.** Any
   ZT failure means the agent is not ready for production regardless of how
   well it performs elsewhere; fix the underlying system-instruction,
   guardrail, or space-configuration gap and re-run the full ZT set (not
   just the failing case — a fix can regress another case).
2. Run the 13 general-coverage cases (GC-01 through GC-13). Track pass rate
   against the target agreed with the DQ team (e.g. ≥90%). Triage any
   failure: fix and re-run, or explicitly accept with documented rationale
   if it is a genuine edge case rather than a systemic gap.
3. Record results (pass/fail, response transcript, date, agent/config
   version) for audit purposes — this becomes the go-live evidence record
   and the baseline for regression comparison after future changes.
4. Re-run the full ZT set (at minimum) after any material change to system
   instructions, tools manifest, Genie space configuration, or DQX version —
   treat it as a regression suite, not a one-time gate.

**Exit criteria:** all 7 ZT cases pass; GC pass rate meets or exceeds the
agreed target or has documented exceptions; results are recorded.

---

## Step 7 — Onboard a new team (the cold-start path)

This is the repeatable step for every team after initial go-live. It is
designed to require **no new tables, no schema change, and no agent
redeployment** regardless of where the team starts.

**Case A — the team already writes to `team_rule`/`dq_stats`/
`data_profile`.**
Nothing to do. Because all three tables are shared and multi-tenant
(filtered by `team_name`/`catalog_name`/`schema_name`/`table_name`, not
per-team physical copies), the agent and all 8 Genie spaces already see
their rows the moment they land. Discovery is automatic — there is no
per-team Genie space update, no agent config change, and no new table.
Verify with a smoke-test question scoped to that team's table.

**Case B — the team does not yet write to those tables.**
Tier 1 coverage is *already live* for them from Step 4, at zero additional
effort, the instant their tables are granted `SELECT` to the central DQX
job's service principal (Step 1's grant pattern, extended to their tables).
If that grant is not yet in place for this team's tables:

1. Grant `SELECT` on the team's tables (or Parquet path, or Avro-schema
   file's data path) to the DQX Module's service principal (the only
   grant-side action required).
2. Add **one row** to `dq_catalog.dq_config.dq_control_table` naming the
   team's source (`source_type` = `DELTA_TABLE`/`PARQUET_PATH`/
   `AVSC_SCHEMA`, plus the identifying columns for that type) — leave
   `checks_override` `NULL` to run the DQX Module's full default built-in
   suite. See `dqx/ddl/control_table_ddl.sql` and `docs/04_DQX_INTEGRATION.md`
   §2.5. This is a plain `INSERT`, not a config-file edit or a wildcard
   pattern to construct.
3. Confirm the next scheduled DQX Module run produces `dqx_results` rows for
   the new source.
4. The agent immediately has Tier 1 coverage for this team with no
   redeployment — Genie spaces and the agent's routing logic are unchanged;
   only the row population and the grant list grew (see
   `docs/01_ARCHITECTURE.md` §8, Scalability Story).

**Graduating from Tier 1 to Tier 2 (opportunistic, whenever the team is
ready):** the team simply starts writing rows to `team_rule`, `dq_stats`,
and/or `data_profile`, filtered by their own `team_name`. No new tables, no
schema change, no agent redeployment — the same shared-table/shared-space
design that makes Case A automatic makes graduation automatic too. Tier 2
rows will then be preferred over Tier 1 for that team's tables/rules per the
non-negotiable precedence rule, the moment they exist.

**Exit criteria per team:** at minimum, `SELECT` is granted on the team's
tables (Tier 1 baseline); a smoke-test question scoped to that team returns
a correct, tier-labeled answer.

---

## Rollout Phasing Note — Quality Dimension Order

Ship dimension coverage in two waves rather than all seven at once, so early
production value lands on the lowest-infrastructure-cost dimensions first:

**Wave 1 — Completeness → Validity → Uniqueness.**
These are pure rule-execution plus DQX built-in checks — no new
infrastructure beyond what Steps 1–6 already stand up. Completeness,
Validity, and Uniqueness checks are core to DQX's built-in check catalog and
to the most common `team_rule` patterns, so both Tier 1 and Tier 2 answers
are available immediately at go-live for these three dimensions.

**Wave 2 — Consistency → Timeliness → Volume → Schema Drift.**
These lean more heavily on cross-table/cross-space correlation (Consistency
against a second table via `team_rule`/lineage; Timeliness against
`system.lakeflow.job_run_timeline`; Volume against historical
`data_profile`/`dq_stats` baselines; Schema Drift against Delta history
depth). Sequence these after Wave 1 is validated in production, once
`job_run_timeline` correlation, historical baselines, and adequate Delta
history retention are confirmed present for the tables in scope — the
eval cases in `evals/eval_cases.md` (GC-03, GC-05, GC-06, GC-07, plus
ZT-04) specifically test the "insufficient history/no baseline yet" edge
cases these later dimensions are more prone to.

This phasing is a rollout sequencing decision, not an architectural one —
all 8 Genie spaces and both tiers are already live from Step 3/Step 4;
Wave 2 dimensions simply take longer to reach reliable answer quality
because they depend on accumulated history/baseline depth rather than a
single day's execution result.
