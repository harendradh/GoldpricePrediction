# DQX Integration Design

## 1. What DQX Is, and Why It Fits This Use Case

`databricks-labs-dqx` is a **Python library**, not a hosted service. You
`pip install databricks-labs-dqx` (or install via the Databricks Labs CLI) and
call its `DQEngine` API from your own notebooks, jobs, or DLT pipelines. It
also offers a no-code path (YAML/JSON check definitions driven from the CLI)
and, separately, an optional web UI called **DQX Studio** that requires
serverless compute — we defer DQX Studio (see §7, Phase 3) for the same
reason we defer Lakehouse Monitoring (`docs/05`): no serverless compute is
available in this workspace yet. The core `DQEngine` has no such requirement.

Key facts, carried forward from the verified research in `CONTEXT_BRIEF.md`
§3 (do not re-derive or contradict these):

- **License and support model:** source-available under a proprietary
  Databricks Labs license (not OSI open source), and explicitly **not
  officially supported** by Databricks — an exploration/labs project with no
  SLA. This is a governance/support consideration to flag at sign-off, not a
  reason to avoid it (§6).
- **Compute:** runs on standard job clusters, Spark ≥3.5.0, DBR ≥15.4
  recommended. **No serverless requirement for the core engine.** Only DQX
  Studio (the no-code UI) requires serverless.
- **Capabilities:** 50+ built-in checks (nullability/completeness,
  range/pattern/regex validity, uniqueness, foreign-key, PII detection,
  temporal/freshness, dataset comparison, schema checks including ODCS data
  contracts), custom SQL/Python expression checks, a data profiler that
  samples tables (default 30%/1000 rows) to auto-generate candidate rules,
  and row/column/dataset-level validation that can run pre-commit (inline, in
  a writing pipeline) or post-factum (against an already-persisted table).

This is exactly the gap Tier 1 of this project's cold-start design (see §1.4
of the brief, and §3 below) needs filled: automated, no-onboarding-cost
quality coverage for any team, on day one, using only a Unity Catalog grant.

## 2. The Zero-Copy, Zero-Pipeline-Change Integration Pattern

This is the centerpiece of the DQX integration, and it directly answers the
question this design was asked to answer: **can DQX be used without copying
another team's data and without changing any other team's pipeline code?**
Yes — confirmed feasible, and this is the pattern:

### 2.1 One central job, owned by the DQ team

A single Databricks job (or notebook run on a schedule) — call it the
**central DQ job** — is owned and operated entirely by the central Data
Quality team. It runs on a **standard job cluster** (no serverless
requirement). No other team owns, edits, or deploys any part of it. This is
the only new piece of compute this design introduces; every other team's
existing jobs, DLT pipelines, and notebooks are untouched.

### 2.2 Read access only, granted once, per table

The DQ team requests (and target teams grant) **`SELECT`-only Unity Catalog
grants** on the tables to be checked:

```sql
GRANT SELECT ON TABLE prod_catalog.sales.orders TO `dq-team-service-principal`;
```

No `MODIFY`, no `CREATE`, no ownership transfer, no data movement into a
separate copy or staging area. The central job reads each target table
straight out of its existing location via `spark.read.table(...)` into a
DataFrame — the same table the owning team's own pipelines already write to.
There is no ETL step that duplicates the table into DQ-team storage; DQX
operates on a DataFrame view of the live table, in memory, for the duration
of the check run.

### 2.3 DQX runs checks against that DataFrame

`DQEngine` takes the DataFrame and a set of checks (built-in or custom,
expressed as YAML/JSON or the Python API) and evaluates them, producing a
result set: pass/fail per check per row (or per column/dataset, depending on
check level), plus profiling statistics if the profiler is invoked.

### 2.4 Results go only to a DQ-team-owned table — never back to source

This is the property that makes the pattern genuinely zero-pipeline-change:
**DQX never writes back to the table it read.** All outputs — validated
rows, quarantined rows, and check metrics — are written to destinations the
DQ team configures and owns:

- `output_config` → validated/annotated results
- `quarantine_config` → rows that failed checks, routed to a quarantine table
- `metrics_config` → run-level metrics (rows scanned, checks run, pass/fail
  counts, duration)

All three configs point at a schema the DQ team owns — illustratively,
`dq_catalog.dq_results.dqx_results` — never at the source team's schema.
The owning team's table is read, not touched. Their pipeline that populates
it keeps running exactly as it did before DQX existed; there is no hook, no
wrapper, no DLT Expectation inserted into their code unless that team
separately, voluntarily, chooses to adopt DLT Expectations themselves (a
Tier-2-adjacent, opt-in enhancement, not part of the Tier-1 sweep).

The `dqx_results` schema is intentionally shaped to mirror `dq_stats` (see
`CONTEXT_BRIEF.md` §1.2 / `docs/01_ARCHITECTURE.md`) — same grain concepts
(execution id, team/catalog/schema/table, timestamp, pass/fail counts,
duration) — so the DQ Execution Analytics Genie space (`docs/03`) can query
Tier 1 (`dqx_results`) and Tier 2 (`dq_stats`) results with a compatible
shape instead of two unrelated data models. See §5 for how the two tiers are
distinguished and reconciled at query time.

### 2.5 A control master table drives the DQX Module across many teams' sources

Instead of writing bespoke code per team, the DQX Module (see §8 below) reads
a **control master table** — a **Delta table**,
`dq_catalog.dq_config.dq_control_table`, not a YAML/JSON file — where a
team's entire onboarding action is **adding one row that names their
source**. This supersedes the earlier wildcard-pattern `dqx_rule_registry`
design (keyed by `catalog.schema.table_pattern` with a `checks` array): that
model asked a team to reason about a wildcard pattern and a checks array
before anything ran for them, which was too much ceremony for the common
case of "just run the default checks against my one table." A Delta table is
still deliberately preferred over a file for the same reasons as before: it's
queryable/joinable with `information_schema` and `dqx_results` in the same
SQL session, it's governed by the same Unity Catalog grants as everything
else in this design (no separate Workspace-file ACL to manage), it gets
Delta history/audit for free when a row changes, and a plain `INSERT`
statement is a lower-friction onboarding path than a Workspace file edit and
redeploy.

The control table also generalizes onboarding beyond Delta tables: a
`source_type` column lets a team register a Delta table, a raw Parquet
dataset (no Unity Catalog table required), or a dataset described by an
external Avro (`.avsc`) schema file — see `dqx/ddl/control_table_ddl.sql` for
the full DDL, column-by-column comments, and one seed row per `source_type`.

```sql
-- dq_catalog.dq_config.dq_control_table (see dqx/ddl/control_table_ddl.sql)
SELECT entry_id, team_name, source_type, catalog_name, schema_name, table_name,
       file_path, data_path, checks_override, is_active
FROM dq_catalog.dq_config.dq_control_table
WHERE is_active = true;
```

| team_name | source_type | table_name / file_path | checks_override |
|---|---|---|---|
| sales_team | `DELTA_TABLE` | `prod_catalog.sales.orders` | `NULL` (full default suite) |
| finance_team | `PARQUET_PATH` | `abfss://.../invoices/parquet/` | `[completeness, validity]` |
| iot_platform_team | `AVSC_SCHEMA` | `.../device_telemetry.avsc` (+ `data_path`) | `NULL` (full default suite) |

`checks_override` is nullable; `NULL` means "run the DQX Module's full
default built-in suite" (completeness/validity/uniqueness/freshness/schema)
— a team only sets `checks_override` to restrict the run to a subset of that
default suite. There is no `checks` column to author from scratch, and no
wildcard pattern to reason about.

The DQX Module's run loop is: read every `is_active = true` row from
`dq_control_table`, dispatch on `source_type` to read the target
(`spark.read.table(...)` for `DELTA_TABLE`, `spark.read.parquet(...)` for
`PARQUET_PATH`, an Avro-schema-driven read for `AVSC_SCHEMA`), run the
resolved checks (plus the profiler for sources with no prior run — see §3),
and write to `dqx_results`/`dqx_quarantine`/`dqx_run_metrics` (see §8 below).
Adding a new team or a new source to the Tier-1 sweep is one `INSERT` into
`dq_control_table` — never a new job, never a file redeploy, never a change
to any other team's code.

**Extension point, not implemented today:** if wildcard/pattern-based bulk
registration for "every table in a schema" is ever worth reintroducing as a
secondary, opt-in capability, it should live as its own table that expands
into rows here (or into ad hoc targets resolved at run time) — it should not
be folded back into `dq_control_table`'s schema, which is deliberately kept
to one row per onboarded source. See the comment block at the top of
`dqx/ddl/control_table_ddl.sql`.

### 2.6 Net effect

| Property | Result |
|---|---|
| Source table copied? | No — read via DataFrame, in place |
| Source pipeline code changed? | No — zero touches to any other team's job/DLT/notebook |
| Source table written to? | No — DQX writes only to DQ-owned `dqx_results` (+ quarantine) |
| Per-team onboarding effort | One UC `SELECT` grant, plus one control-table row |
| New job per team? | No — one shared job, control-table-driven |

## 3. Filling the Tier-1 Cold-Start Gap

`CONTEXT_BRIEF.md` §1.4 establishes the two-tier cold-start decision: a team
with zero rows in `team_rule`, `dq_stats`, or `data_profile` should not be
forced through a bootstrap-and-insert workflow before the agent is useful to
them. DQX is the mechanism that makes Tier 1 real:

- The moment a team's source is added as one row to `dq_control_table` and a
  `SELECT` grant exists, the DQX Module's next run produces automated
  **completeness, validity, uniqueness, freshness, and schema** results for
  that team — with **zero rows** in any of the three human-authored metadata
  tables.
- The DQX **profiler** (default 30%/1000-row sample) runs against
  never-before-seen tables to auto-generate candidate checks — completeness
  thresholds, distinct-value/uniqueness expectations, freshness windows
  inferred from timestamp columns — so Tier 1 coverage is not limited to a
  fixed, generic checklist; it adapts per table.
- This satisfies the brief's cold-start requirement exactly: "if a team
  doesn't have these tables yet, the answer is DQX, not a new custom
  onboarding table." No new physical table is created per team; the team's
  results land as rows in the shared `dqx_results` table, exactly as
  `team_rule`/`dq_stats`/`data_profile` are shared multi-tenant tables (brief
  §1).
- Onboarding effort for a new team, in full: a `SELECT` grant, plus one row
  in `dq_control_table` naming their source. No pipeline changes, no new
  tables for the team to populate, no code review of the team's own jobs.

## 4. Relationship to the Human-Authored Tier 2 Layer

DQX is the **floor**, not a replacement for `team_rule`. When a team has
invested in Tier 2 — rows in `team_rule` (business rules), `dq_stats`
(execution history), `data_profile` (profiling metrics) — those
human-curated signals **always take precedence** over a Tier 1/DQX finding
for the same table, column, or quality dimension. This is a non-negotiable
carried from the brief (§8): human-curated always outranks AI-inferred.

Concretely:

- If `team_rule` has an active, human-authored validity rule on
  `orders.total_amount`, and DQX's own generic validity check also evaluates
  that column, the agent surfaces the `team_rule`/`dq_stats` result as
  authoritative and reports the DQX result as corroborating context (or notes
  a disagreement if the two disagree — a signal worth surfacing, not
  hiding).
- Where no Tier 2 rule exists for a column/dimension/table, DQX's Tier 1
  result is the only signal — and the agent states plainly that this is a
  Tier-1/DQX-only answer, per the brief's requirement that the agent always
  state which tier answered a question.
- DQX findings are never written into `team_rule`, `dq_stats`, or
  `data_profile`. They live in `dqx_results` only. This keeps the boundary
  between human-curated and AI-inferred data structurally, not just
  procedurally, clean — there is no risk of a DQX row being mistaken for a
  human-authored one because they are, physically, different tables.

## 5. Relationship to Lakehouse Monitoring

DQX and Lakehouse Monitoring (LHM, `docs/05`) are **complementary, not
competing** layers, and the distinction matters for how the two are staged:

| | DQX | Lakehouse Monitoring |
|---|---|---|
| Posture | Proactive / inline | Reactive / periodic |
| When it runs | Before or at write time (custom Spark jobs), or via DLT Expectations (DLT pipelines) — or, for the Tier-1 sweep, on a schedule against already-written tables | On already-persisted tables, on a monitoring refresh schedule |
| Compute requirement | Standard job cluster | Requires serverless (not available in this workspace yet) |
| Role in this design | Tier-1 zero-onboarding sweep today; inline validation for custom Spark jobs going forward | Deferred; future periodic drift/profiling once serverless lands |

The recommended layering, once both are available: DLT Expectations inside
DLT pipelines, DQX for custom Spark jobs and for the Tier-1 sweep across
tables with no pipeline-level checks, and Lakehouse Monitoring layered on top
later for native periodic drift dashboards. None of the three compete for
the same table's checks — they cover different points in that table's
lifecycle. See `docs/05_LAKEHOUSE_MONITORING_ADOPTION.md` for the LHM
deferral rationale and migration approach in full.

## 6. Cost and Governance Gotchas — Flag These Explicitly at Sign-Off

- **ML anomaly detection is on by default and costs money.** DQX v0.15.0
  introduced ML-based anomaly detection with SHAP/LLM explanations, and it is
  **enabled by default**. It calls **Model Serving**, which is real,
  metered cost — not a free static check. **Recommendation: disable it for
  the initial rollout** (see the explicit config flag in
  `dqx/src/dq_dqx_framework/config.py`) and enable it deliberately, per table, once a
  team has a concrete anomaly-detection use case and the team/DQ team have
  agreed to the Model Serving cost. Do not let a default-on feature silently
  bill the workspace during the Tier-1 pilot.
- **Pre-1.0 API churn.** DQX is pre-1.0 with real breaking changes between
  releases — v0.15.0 itself changed the anomaly-detection defaults and the
  `_dq_info` result schema. **Pin the exact DQX version** in the job's
  cluster library spec (or `requirements.txt`/wheel), and review the
  changelog before any version bump. Do not let the central job silently
  auto-upgrade.
- **Not officially supported.** DQX is a Databricks Labs project: source
  available, but explicitly not covered by Databricks support SLAs. Governance
  sign-off should treat this the same way any other unsupported-but-valuable
  OSS-adjacent dependency is treated internally — documented ownership (the
  central DQ team owns operating it), a fallback plan if the project stalls
  (Tier 1 degrades gracefully to "no new automated checks," Tier 2 is
  unaffected), and no expectation of a Databricks support ticket resolving a
  DQX-specific bug.

## 7. The DQX Metadata Tables and the `dqx/` Package

### 7.1 Where the DQX Module writes its generated metadata

Previously `dqx_results`/`dqx_quarantine`/`dqx_run_metrics` were referenced
only as path strings inside the central job's `OUTPUT_CONFIG`/
`QUARANTINE_CONFIG`/`METRICS_CONFIG`, with no column schema defined anywhere
in the project. That gap is closed by `dqx/ddl/dqx_metadata_tables_ddl.sql`,
which defines all three tables in `dq_catalog.dq_results`:

- **`dqx_results`** — check-level grain, one row per check per run per
  source (`execution_id, entry_id, team_name, source_type, catalog_name,
  schema_name, table_name, file_path, check_name, check_column, criticality,
  check_status, failed_row_count, input_record_count, run_ts, run_date`).
  Shaped to mirror `dq_stats` (§2.4 above) so the DQ Execution Analytics
  Genie space can query Tier 1 and Tier 2 uniformly.
- **`dqx_quarantine`** — one row per quarantined record
  (`execution_id, entry_id, team_name, table_name, file_path, run_ts,
  quarantined_row` [JSON-serialized, since source schema varies per table],
  `failed_checks`).
- **`dqx_run_metrics`** — one row per run per source
  (`execution_id, entry_id, team_name, table_name, file_path,
  input_record_count, valid_count, quarantined_count, duration_seconds,
  run_ts, run_date`).

All three are DQX-owned (Tier 1): written to only by the central DQX Module
job, never by any team's own pipeline — the same zero-copy/
zero-pipeline-change guarantee as §2. `entry_id` on every table is a
foreign key back to `dq_catalog.dq_config.dq_control_table.entry_id` (§2.5),
so a result/quarantine/metrics row always traces back to the exact control
table row that registered its source.

### 7.2 The `dqx/` package

The illustrative job template (`central_dq_job.py`) and the wildcard rule
registry DDL have been restructured into a real, installable Python
package/framework rather than one flat script:

```
dqx/
  pyproject.toml               dq-dqx-framework, databricks-labs-dqx==0.15.0 pinned
  README.md                    What this project is, install/run instructions
  ddl/
    control_table_ddl.sql       dq_control_table (§2.5 above)
    dqx_metadata_tables_ddl.sql dqx_results / dqx_quarantine / dqx_run_metrics (§7.1 above)
  src/dq_dqx_framework/
    __init__.py
    config.py                   Catalog/schema constants, output/quarantine/metrics
                                 config, ANOMALY_DETECTION_CONFIG cost-control flag
    control_table.py            load_active_entries() -- reads dq_control_table
    source_readers.py           read_source(entry) -- dispatches on source_type
    checks.py                   built_in_checks_for() / profile_and_generate_checks()
    runner.py                   has_prior_dqx_run() / run_target() -- per-entry execution
    __main__.py                 Entrypoint a Databricks Job points at
  tests/
    test_control_table.py       Unit tests for control-table filtering
    test_source_readers.py      Unit tests for source_type dispatch
```

See `dqx/README.md` for install/run instructions and the full list of
design decisions (version pinning, cost control, cold-start profiler
fallback, read-only guarantee, standard-job-cluster requirement) carried
forward from the original flat script into this package's modules.

## 8. Phased Rollout Plan

- **Phase 1 — Pilot, no serverless needed.** Install and run the `dqx/`
  package (`dq-dqx-framework`, entrypoint `dqx/src/dq_dqx_framework/__main__.py`)
  against a pilot set of sources from 2-3 teams, using standard job clusters.
  Control table (`dq_control_table`) seeded with at least one row per
  `source_type` to validate the "one job, many sources" property. ML anomaly
  detection disabled. Validate that `dqx_results` rows are landing with the
  expected shape and that no source table or pipeline was touched.
- **Phase 2 — Wire into DQ Execution Analytics.** Once `dqx_results` is
  populated reliably, connect it as a queryable table in the **DQ Execution
  Analytics** Genie space (`docs/03_GENIE_WORKSPACES.md`), alongside
  `dq_stats`, so the agent can answer execution questions across both tiers
  in one pass and correctly label which tier answered.
- **Phase 3 — DQX Studio, once serverless is available.** Revisit the
  no-code DQX Studio UI as a convenience layer for rule authoring/browsing
  once serverless compute is provisioned in this workspace — the same
  trigger condition that unblocks Lakehouse Monitoring (`docs/05`). This is
  a UI convenience on top of the same `DQEngine`/checks already in place from
  Phase 1; it does not change the underlying integration pattern in §2.
