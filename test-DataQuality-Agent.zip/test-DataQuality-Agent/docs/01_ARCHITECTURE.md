# Architecture — Data Quality AI Agent

## 1. Overview

The Data Quality AI Agent is a single conversational agent running on the
Databricks-hosted Claude endpoint inside DCS Agent Studio. It does not own
any new data pipeline or data store beyond the results tables it already has
via DQX; its role is investigation and synthesis across metadata that
already exists in Unity Catalog, augmented by three shared, multi-tenant
Delta tables (`team_rule`, `dq_stats`, `data_profile`) and a DQX-owned
results table. It reasons through eight scoped Genie spaces rather than
issuing raw SQL directly, keeping data access governed, auditable, and
UC-permission-bounded.

## 2. Data Sources / Inputs

| Source | What it provides |
|---|---|
| `team_rule` | Human-authored business rules per team/table/column: expression, quality dimension tag, severity, action-if-failed. Tier 2. |
| `dq_stats` | One row per rule-execution run: pass/fail counts, status (including `NOT_RUN`), pass rate, duration, errors. Tier 2. |
| `data_profile` | Profiling metrics per team/table/column: null %, distinct count, min/max, distribution histogram, cardinality, freshness, row count. Tier 2. |
| `information_schema` | Native UC catalog metadata — tables, columns, data types, constraints — for schema understanding and drift comparison. |
| Delta history / Time Travel (`DESCRIBE HISTORY`) | Full commit-level schema and data snapshot history, used for Schema Drift detection without any custom snapshot table. |
| `system.access.table_lineage` / `column_lineage` | Native UC lineage system tables — upstream/downstream table and column dependencies, for impact analysis and root-cause tracing across pipeline hops. |
| `system.lakeflow.job_run_timeline` | Native job/pipeline run history — timing, status, duration — to correlate DQ incidents with job execution events. |
| `dqx_results` (DQX output table) | Automated, read-only DQX check results, written to a DQ-team-owned schema. Tier 1. Shaped to mirror `dq_stats` so Execution Analytics can query both uniformly. |

All three multi-tenant tables (`team_rule`, `dq_stats`, `data_profile`) are
single shared physical tables filtered by `team_name`/`catalog_name`/
`schema_name`/`table_name` — never per-team physical copies.

## 3. Two-Tier Investigation Model

**Tier 1 — DQX, zero onboarding, always on.** DQX runs read-only against any
Unity Catalog table the agent (via the central DQ job) has `SELECT` on. It
requires no `team_rule`/`dq_stats`/`data_profile` rows. Its own profiler
samples the table and its 50+ built-in checks cover completeness, validity,
uniqueness, freshness, and schema — from day zero, from a UC grant alone.
Results land only in `dqx_results`, never in a team's own tables.

**Tier 2 — human-curated, opportunistic.** When a team has already populated
`team_rule`/`dq_stats`/`data_profile`, those rows represent human judgment
about what quality means for that table and are preferred whenever both
tiers have an answer for the same table/rule. Tier 2 corroborates or
overrides Tier 1; it never gets silently outranked by an automated
inference.

The agent always states which tier produced a given answer, so a user can
distinguish "this is a business rule your team wrote" from "this is DQX's
automated inference."

## 4. The 8 Genie Spaces

The agent never queries raw tables directly — it delegates to one of eight
narrowly-scoped Genie spaces, each with a small fixed table list and its own
guardrails. Full space-by-space specs (table lists, sample questions,
guardrail SQL) live in `docs/03_GENIE_WORKSPACES.md`; summarized here:

1. **Rule Intelligence** — what business rules exist, for which team/table/
   column, their dimension tags, severity, and active/expired status
   (`team_rule`).
2. **Profiling Intelligence** — column-level profiling metrics and trends:
   null rates, distinct counts, distributions, cardinality, freshness
   (`data_profile`).
3. **DQ Execution Analytics** — rule-execution outcomes, pass rates, failure
   patterns, `NOT_RUN` detection, across both Tier 2 (`dq_stats`) and Tier 1
   (`dqx_results`).
4. **Schema Intelligence** — schema drift and structural change detection
   via `information_schema` and Delta history/Time Travel — no custom
   snapshot table.
5. **Freshness Intelligence** — data timeliness and staleness, combining
   `data_profile.freshness_last_updated_ts` with `system.lakeflow.job_run_timeline`.
6. **Volume Intelligence** — row-count trends and volume anomalies from
   `data_profile.row_count_at_profile_time` and `dq_stats.input_record_count`.
7. **Lineage & Impact Analysis** — upstream/downstream dependency tracing via
   `system.access.table_lineage` and `column_lineage`, for blast-radius and
   root-cause propagation questions.
8. **Governance Intelligence** — cross-team scorecards, ownership,
   dimension-coverage gaps, and Tier 1 vs Tier 2 coverage reporting.

## 5. DQX as the Automated Read-Only Check Layer

DQX (`databricks-labs-dqx`) is the engine behind Tier 1, wrapped by the
installable `dq-dqx-framework` package (`dqx/`, see `dqx/README.md`). It is a
Python library with a `DQEngine` API, run as a shared job-cluster workflow
owned by the central DQ team — not a hosted service. It reads a source
(Delta table, Parquet path, or Avro-schema-described dataset) into a
DataFrame, evaluates checks, and writes results only to its own configured
output/quarantine/metrics destinations; it never writes back to a source
table, so onboarding a new team costs only a `SELECT` grant plus one row in
the central control master table (`dq_catalog.dq_config.dq_control_table`)
naming their source — no wildcard pattern to configure, no other team's
pipeline changes. It runs on standard job clusters (no Serverless required);
only the optional DQX Studio no-code UI needs Serverless, and is deferred
for that reason, same as Lakehouse Monitoring. Full detail — check catalog,
control-table onboarding model, version-pinning guidance, and its
relationship to DLT Expectations and Lakehouse Monitoring — lives in
`docs/04_DQX_INTEGRATION.md`.

## 6. Agent Reasoning Loop

1. **Understand intent** — parse the natural-language question into a data
   quality concern (e.g. "why did completeness drop," "is this table
   fresh," "what changed in the schema").
2. **Identify table / dimension / scope** — resolve the target
   catalog.schema.table, column(s) if named, the relevant quality
   dimension(s) (Completeness, Validity, Consistency, Uniqueness,
   Timeliness, Volume, Schema Drift), and the team/time-window scope.
3. **Query relevant Genie space(s)** — route to one or more of the 8 spaces
   based on the dimension and question type; a root-cause question
   typically spans two or more spaces (e.g. DQ Execution Analytics +
   Lineage & Impact Analysis).
4. **Prefer Tier 2 over Tier 1 when both exist** — if `team_rule`/
   `dq_stats`/`data_profile` rows exist for the table/rule in question, use
   them as the primary answer; use Tier 1 (`dqx_results`) as the answer of
   record only when Tier 2 has nothing, and note the gap.
5. **Cross-reference across spaces** — correlate execution failures with
   schema changes (Schema Intelligence), job run timing (Freshness
   Intelligence / `job_run_timeline`), volume shifts (Volume Intelligence),
   and upstream dependency changes (Lineage & Impact Analysis) to build a
   causal chain instead of a single-signal guess.
6. **Synthesize root cause** — combine only the evidence actually returned
   by the queried spaces into a coherent explanation; no invented tables,
   columns, or values, and no lineage claim without an actual lineage-space
   result.
7. **Recommend** — propose a concrete, ready-to-review fix: a DQX check
   YAML, a `team_rule` INSERT statement, or a remediation SQL snippet.
   Recommendation only — never auto-applied.
8. **Score confidence** — attach a confidence score reflecting evidence
   strength (e.g. Tier 2 corroboration, number of cross-referenced spaces,
   recency of the underlying data) and state which tier(s) contributed.
9. **Report** — return the root-cause explanation, recommendation,
   confidence score, and tier attribution in a single structured response.

## 7. Governance and Guardrails

- **Anti-fabrication (non-negotiable):** `NOT_RUN`/no-result states are
  never reported as `PASS`; a rule absent from today's `dq_stats`/
  `dqx_results` rows "did not run," full stop. No invented table, column, or
  value is ever presented as fact; no lineage claim is made without an
  actual lineage-space query result.
- **AI-assisted, not AI-autonomous:** the agent recommends, with SQL/YAML
  and rationale attached; it never writes to `team_rule`, `dq_stats`,
  `data_profile`, or any production table.
- **Human review gate:** every recommendation (new rule, DQX check,
  remediation snippet) requires explicit human review and manual
  application. There is no auto-deploy path.
- **Human-curated outranks AI-inferred:** Tier 2 findings always take
  precedence over Tier 1/DQX findings for the same table/rule when both
  exist.
- **Native Databricks first:** Unity Catalog, `information_schema`, Delta
  history, lineage/lakeflow system tables, Genie, DQX, and AI Functions are
  the entire toolset — no external tooling introduced without strong
  justification (none exists in this design).

## 8. Scalability Story

This design is built to scale to hundreds of data products and thousands of
pipelines **without a new table or a new Genie space per team**, for two
structural reasons:

- **Multi-tenant shared tables.** `team_rule`, `dq_stats`, and
  `data_profile` are each a single physical table across all teams,
  partitioned/filtered logically by `team_name`/`catalog_name`/
  `schema_name`/`table_name`. Onboarding a new team's Tier 2 data means
  inserting rows into existing tables, not provisioning new infrastructure.
  The same applies to `dqx_results` for Tier 1.
- **UC-permission-based discovery, not per-team configuration.** Tier 1
  coverage is driven by Unity Catalog `SELECT` grants: any table the central
  DQX job can read, it can check. A new team's onboarding step is a grant,
  not a schema migration or a new pipeline. The 8 Genie spaces are fixed in
  number and each is scoped to a small, stable table list (the shared
  metadata tables plus native system tables); they do not need to grow with
  team count because Genie spaces reach beyond their listed tables through
  the querying principal's own UC permissions, and the questions asked of
  each space (rules, profiling, execution, schema, freshness, volume,
  lineage, governance) are the same shape regardless of how many teams or
  tables sit behind them.

This is the direct answer to "how does this not become an operational burden
at hundreds-of-teams scale": the schema and the space count are fixed;
only the row count and the grant list grow.

## 9. End-to-End Architecture Diagram

```
┌───────────────────────────────────────────────────────────────────────────┐
│                              DATA SOURCES                                 │
│                                                                             │
│  team_rule    dq_stats    data_profile    information_schema              │
│  Delta History/Time Travel    system.access.table_lineage/column_lineage  │
│  system.lakeflow.job_run_timeline                                          │
└───────────────────────────────┬────────────────────┬──────────────────────┘
                                 │                    │
                     ┌───────────▼───────────┐ ┌──────▼───────────────────┐
                     │  TIER 1 — DQX          │ │ TIER 2 — Human-Curated   │
                     │  (zero onboarding,     │ │ team_rule / dq_stats /   │
                     │  read-only, always on) │ │ data_profile             │
                     │  writes → dqx_results  │ │ (preferred when present)│
                     └───────────┬───────────┘ └──────────┬───────────────┘
                                 │                          │
                                 └────────────┬─────────────┘
                                              │
                     ┌────────────────────────▼────────────────────────┐
                     │                 8 GENIE SPACES                   │
                     │  Rule Intelligence      Profiling Intelligence   │
                     │  DQ Execution Analytics Schema Intelligence      │
                     │  Freshness Intelligence Volume Intelligence      │
                     │  Lineage & Impact       Governance Intelligence  │
                     └────────────────────────┬────────────────────────┘
                                              │
                     ┌────────────────────────▼────────────────────────┐
                     │              DQ AGENT (Claude on Databricks,     │
                     │              DCS Agent Studio)                   │
                     │  intent → scope → query space(s) → Tier 2 >      │
                     │  Tier 1 → cross-reference → synthesize →         │
                     │  recommend → confidence score → report           │
                     └────────────────────────┬────────────────────────┘
                                              │
                     ┌────────────────────────▼────────────────────────┐
                     │                     OUTPUTS                      │
                     │  Root cause explanation   Recommendations        │
                     │  (SQL/YAML, human-review) Data quality scorecard │
                     │  Daily health summary                            │
                     └───────────────────────────────────────────────────┘
```
