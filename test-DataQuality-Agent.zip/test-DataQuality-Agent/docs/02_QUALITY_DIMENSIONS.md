# 02 — Quality Dimensions

This document is the agent's reasoning playbook for the seven quality
dimensions in scope: **Completeness, Validity, Consistency, Uniqueness,
Timeliness, Volume, Schema Drift**. No other dimensions are in scope.

Every dimension is detected through the same two-tier model described in
`CONTEXT_BRIEF.md` §1.4:

- **Tier 1 (zero onboarding, always on):** DQX built-in checks running
  read-only against any Unity Catalog table the agent has `SELECT` on,
  writing results to the DQ-owned `dqx_results` table. Available from day
  zero, with no `team_rule` / `dq_stats` / `data_profile` rows required.
- **Tier 2 (richer, opportunistic):** `team_rule` (human-authored business
  rules), `dq_stats` (per-run execution outcomes), and `data_profile`
  (profiling metrics), populated once a team has onboarded. **Human-curated
  Tier 2 findings always outrank AI-inferred Tier 1/DQX findings** when both
  exist for the same table/column.

The agent must always state which tier answered a question, and must never
report `dq_stats.status = NOT_RUN` (or the absence of a row for the day) as a
`PASS` — a rule that did not execute is "did not run," never "passed." This
non-negotiable applies to every dimension below, not just Timeliness/Volume.

All recommendations produced by the agent are **proposals only**. The agent
never inserts into `team_rule`, never writes to `dq_stats`/`data_profile`,
and never mutates a production table — a human reviews and applies every
suggested SQL/YAML snippet.

---

## 1. Completeness

### Business problem
A regional finance team's month-end revenue consolidation job reads
`finance.gold.revenue_by_region`. A silent upstream join issue leaves
`revenue_amount` null for one region for three days running. Because the
consolidation report simply `SUM()`s the column (nulls are skipped, not
flagged), the regulatory submission understates total revenue for that
region by the full missing amount — an error that surfaces only when
auditors reconcile against the source ledger weeks later.

### Detection approach
- **Tier 1 (DQX built-in):** `is_not_null` / `is_not_null_and_not_empty`
  checks run against every column of any UC table the agent can read,
  written to `dqx_results` — active even for `finance.gold.revenue_by_region`
  before the finance team has authored a single rule.
- **Tier 2 (`team_rule`):** business-specific completeness rules where "not
  null" alone isn't the real requirement — e.g. a `rule_expression` of
  `revenue_amount IS NOT NULL OR (region_status = 'INACTIVE')`, tagged
  `quality_dimension_tag = 'Completeness'`, `severity = 'CRITICAL'`,
  `action_if_failed = 'REJECT'`.
- **Tier 2 (`data_profile`):** `null_pct` per `column_name`, trended across
  `profile_date`, is the primary quantitative signal — the agent looks for
  a step change in `null_pct`, not just a single high value.
- **Primary Genie space:** **Profiling Intelligence** (owns `null_pct`
  trends). Corroborated by **DQ Execution Analytics** (`dqx_results` /
  `dq_stats.failed_rule_ids`) and **Rule Intelligence** (does a Completeness
  `team_rule` exist and is it `is_active`).

### Investigation workflow
1. Query **Profiling Intelligence** for `data_profile.null_pct` on
   `revenue_amount` across the last N `profile_date`s to establish the
   trend (gradual drift vs. sudden step).
2. Query **Rule Intelligence** for any `team_rule` row with
   `quality_dimension_tag = 'Completeness'` on that
   `catalog_name.schema_name.table_name.column_name` — if none exists, this
   is a Tier-1-only finding and the agent says so explicitly.
3. Query **DQ Execution Analytics** for `dq_stats`/`dqx_results` rows on the
   same date range: was the rule evaluated at all (`rules_evaluated_count`),
   did it fail (`failed_rule_ids` contains this rule), or is there simply no
   row (`status = NOT_RUN`)?
4. Cross-reference **Schema Intelligence** to rule out a schema change (e.g.
   a new nullable column, or a rename that broke an upstream mapping) as the
   real driver of the null spike.
5. If the table is downstream of others, check **Lineage & Impact
   Analysis** for the immediate upstream table(s) and repeat steps 1–3 on
   those.

### Root cause strategy
The agent separates four distinct explanations for a rising `null_pct`:
(a) no completeness rule exists yet — a genuine onboarding gap, not a data
problem; (b) the rule exists and is evaluated, and is genuinely failing —
data quality problem; (c) `dq_stats.status = NOT_RUN` or `PARTIAL` for the
relevant `execution_date` — the apparent "improvement" in null rate is an
artifact of the check simply not running, and must not be reported as
passing; (d) an upstream schema or pipeline change (visible in Schema
Intelligence / Lineage & Impact Analysis) started producing nulls that
didn't exist before — root cause is upstream, not in this table.

### AI reasoning
Beyond a raw `SELECT AVG(null_pct)` query, the agent: recognizes whether a
null_pct trend is a step-change (single day, likely a job failure) versus a
gradual drift (likely a genuine upstream data issue); correlates the
step-change date against `dq_stats.execution_timestamp` of upstream jobs and
against Schema Intelligence's `DESCRIBE HISTORY` commit timestamps to test
causation rather than assuming coincidence; assigns a confidence score based
on how many consecutive `profile_date`s confirm the pattern (a single day's
spike is low-confidence, a 5-day sustained trend is high-confidence); and
flags when Tier 2 evidence (an active `team_rule`) contradicts or overrides
a Tier 1 DQX finding, deferring to Tier 2 per the non-negotiable ranking.

### Recommendation
Example proposal (never auto-applied):
```sql
-- Candidate team_rule (human review required before INSERT)
INSERT INTO team_rule (
  rule_id, team_name, catalog_name, schema_name, table_name, column_name,
  rule_name, rule_description, business_context, rule_expression,
  quality_dimension_tag, severity, action_if_failed, is_active,
  effective_from_date, created_by
) VALUES (
  uuid(), 'finance', 'finance', 'gold', 'revenue_by_region', 'revenue_amount',
  'revenue_amount_not_null_unless_inactive',
  'revenue_amount must be populated for active regions',
  'Feeds month-end regulatory revenue consolidation; nulls silently understate totals.',
  "revenue_amount IS NOT NULL OR region_status = 'INACTIVE'",
  'Completeness', 'CRITICAL', 'REJECT', true, current_date(), 'dq_agent_recommendation'
);
```
Rationale is always included in plain text alongside the SQL: which
`profile_date` range triggered the suggestion, current `null_pct`, and
whether this closes a Tier-1-only gap or tightens an existing Tier-2 rule.

### Example user questions
- "Why does `revenue_amount` in the regional revenue table keep showing
  nulls this week?"
- "Is there a completeness rule on `customer_id` for the onboarding table,
  or are we only relying on the automated checks?"
- "Did the null rate on `shipment_status` actually improve yesterday, or did
  the job just not run?"
- "Which columns in `finance.gold.revenue_by_region` have no completeness
  coverage at all?"
- "What's driving the jump in missing values for `account_type` since
  Tuesday?"

---

## 2. Validity

### Business problem
A customer-facing account dashboard displays `email_address` and
`phone_number` pulled from `crm.silver.customer_profile`. A source-system
change starts writing phone numbers without country codes and some emails
without an `@` (a parsing bug in a new intake form). The dashboard renders
malformed contact info to end customers, and a downstream marketing
compliance job that validates opt-in contact channels silently skips
malformed rows — producing an incomplete, non-compliant outreach list.

### Detection approach
- **Tier 1 (DQX built-in):** regex/pattern and range checks
  (`is_valid_email`, `is_in_range`, custom regex predicates) run
  zero-onboarding against any column, results in `dqx_results`.
- **Tier 2 (`team_rule`):** business-specific validity predicates DQX's
  generic checks can't express, e.g. `rule_expression` =
  `phone_number RLIKE '^\\+[1-9][0-9]{7,14}$'`, tagged
  `quality_dimension_tag = 'Validity'`.
- **Tier 2 (`data_profile`):** `min_value`/`max_value` for numeric/date
  columns and `distribution_summary` (JSON histogram) surface out-of-range
  or newly-appearing invalid buckets (e.g. a sudden cluster of
  `phone_number` values under 7 digits).
- **Primary Genie space:** **Profiling Intelligence** for the histogram/
  range evidence, cross-referenced with **Rule Intelligence** (does a
  Validity `team_rule` exist) and **DQ Execution Analytics** (is it
  failing).

### Investigation workflow
1. Query **Profiling Intelligence** for `data_profile.distribution_summary`
   and `min_value`/`max_value` on the suspect column across recent
   `profile_date`s to see if the shape of the distribution changed.
2. Query **Rule Intelligence** for any `team_rule` with
   `quality_dimension_tag = 'Validity'` on that column, and read
   `rule_expression` to understand exactly what's being enforced.
3. Query **DQ Execution Analytics** (`dq_stats`/`dqx_results`) for
   `pass_rate_pct` and `failed_rule_ids` on that rule over time — is this a
   new failure or a long-standing known issue with no rule yet.
4. If the pattern looks systemic rather than row-level, check **Schema
   Intelligence** for a recent type/format change upstream, and **Lineage &
   Impact Analysis** for which upstream source (e.g. the new intake form)
   feeds this column.

### Root cause strategy
The agent distinguishes: (a) a validity rule doesn't exist yet (Tier-1-only
gap — DQX's generic regex may be too loose for the real business format);
(b) the rule exists, is evaluated, and `pass_rate_pct` has genuinely
dropped — real invalid data arriving; (c) the distribution shift is a
one-time backfill or migration artifact, not an ongoing issue (compare a
single `profile_date` spike against surrounding days); (d) an upstream
schema/format change (new source system, new intake form) is the true root
cause, not the table itself.

### AI reasoning
The agent looks for co-occurrence between a validity failure spike and a
Schema Intelligence event (a column type change, a new source landing in
the table) to separate a systemic format change from scattered bad rows. It
scores confidence higher when the same invalid pattern (e.g. missing country
code) recurs across multiple `profile_date`s and multiple related columns
fed by the same upstream source (per Lineage & Impact Analysis), and lower
when it's an isolated one-off. It also flags when DQX's generic Tier-1
pattern check is materially looser than what the business actually needs,
recommending a tighter Tier-2 `team_rule` rather than treating Tier-1 as
sufficient.

### Recommendation
Example DQX check YAML for a tighter, business-specific validity check
(proposed, not deployed):
```yaml
- criticality: error
  check:
    function: regex_match
    arguments:
      column: phone_number
      regex: "^\\+[1-9][0-9]{7,14}$"
  name: phone_number_e164_format
  metadata:
    quality_dimension_tag: Validity
    rationale: "New intake form (May 2026) is dropping country codes; generic is_not_null check misses this."
```
The agent presents both this DQX YAML option and the equivalent `team_rule`
INSERT, with the same rationale, and lets the reviewer choose which
mechanism fits the team's operating model.

### Example user questions
- "Are we seeing more invalid phone numbers than usual in the customer
  profile table this month?"
- "What validity rules exist on `email_address`, and are they catching the
  malformed addresses from the new signup form?"
- "Why did the pass rate on the email format check drop last week?"
- "Is the invalid data in `customer_profile` coming from a specific
  upstream source?"
- "Show me the value distribution for `phone_number` before and after the
  intake form change."

---

## 3. Consistency

### Business problem
`orders.gold.order_summary.order_total` is expected to equal the sum of
`orders.silver.order_line_items.line_amount` for each order. A currency
conversion bug in one region's ETL causes `order_total` to be computed in
local currency while `line_items` are already in USD. Finance's
consolidated revenue report — which joins the two tables — silently
double-counts or under-counts, and the discrepancy isn't visible in either
table alone, only across them.

### Detection approach
- **Tier 1 (DQX built-in):** dataset comparison checks and foreign-key
  checks can catch structural referential-integrity breaks (e.g. an
  `order_id` in `order_summary` with no matching rows in
  `order_line_items`) with zero onboarding.
- **Tier 2 (`team_rule`):** cross-column and cross-table logical rules are
  almost always business-specific and belong here — e.g.
  `rule_expression` referencing a join/aggregate predicate such as
  `order_total = (SELECT SUM(line_amount) FROM order_line_items WHERE
  order_line_items.order_id = order_summary.order_id)`, tagged
  `quality_dimension_tag = 'Consistency'`. DQX's generic checks cannot
  express this kind of cross-table business logic on their own.
- **Primary Genie space:** **Rule Intelligence** (the `team_rule` definition
  and `rule_expression` is the ground truth for what "consistent" means
  here) combined with **DQ Execution Analytics** for pass/fail history.
  **Lineage & Impact Analysis** is consulted whenever the inconsistency
  spans more than one physical table.

### Investigation workflow
1. Query **Rule Intelligence** for any `team_rule` tagged `Consistency`
   involving the two tables in question, and read `rule_expression` and
   `business_context` to understand the exact expected relationship.
2. Query **DQ Execution Analytics** for `dq_stats.pass_rate_pct` and
   `failed_rule_ids` history on that rule to see when it started failing.
3. Query **Lineage & Impact Analysis** to confirm which table is upstream
   and which is downstream, and whether a recent pipeline change touched
   one side but not the other.
4. Cross-check **Schema Intelligence** for a type or unit change (e.g. a
   currency column silently changing semantics without a name change) on
   either table.
5. If no Tier-2 rule exists, fall back to DQX Tier-1 referential/foreign-key
   results in `dqx_results` as a structural (not business-logic) proxy, and
   say explicitly that full cross-table business consistency isn't covered
   yet.

### Root cause strategy
The agent separates: (a) no cross-table rule defined — a Tier-2 onboarding
gap that Tier-1 structural checks only partially cover; (b) the rule exists
and both sides of the join are complete and fresh, and the mismatch is
genuine business logic drift (e.g. the currency bug); (c) the mismatch is
actually a Timeliness problem in disguise — one side of the join is stale
(check Freshness Intelligence) so the "inconsistency" is really a
freshness lag, not a logic bug; (d) the mismatch is actually a Completeness
problem in disguise — missing rows on one side (check Profiling
Intelligence `null_pct`/row counts), not a genuine value mismatch.

### AI reasoning
Consistency findings are the most prone to false attribution, so the agent
explicitly checks adjacent dimensions before concluding "this is a
consistency bug": it queries Freshness Intelligence and Volume Intelligence
for the same two tables to rule out staleness or a row-count gap as the
real explanation, and only reports a genuine consistency failure once those
are ruled out. It weighs confidence by how many order IDs are affected
(a handful vs. a systemic percentage) and by whether the discrepancy
correlates with a specific dimension value (e.g. all affected rows share
`region = 'EMEA'`), which points at a scoped root cause rather than a
systemic one.

### Recommendation
```sql
-- Candidate team_rule (human review required before INSERT)
INSERT INTO team_rule (
  rule_id, team_name, catalog_name, schema_name, table_name, column_name,
  rule_name, rule_description, business_context, rule_expression,
  quality_dimension_tag, severity, action_if_failed, is_active,
  effective_from_date, created_by
) VALUES (
  uuid(), 'orders', 'orders', 'gold', 'order_summary', 'order_total',
  'order_total_matches_line_items_sum',
  'order_total must equal SUM(line_amount) in USD for the same order_id',
  'EMEA currency conversion bug (May 2026) desynced totals from line items, feeding finance consolidation.',
  'order_total = (SELECT SUM(line_amount) FROM orders.silver.order_line_items li WHERE li.order_id = order_summary.order_id)',
  'Consistency', 'HIGH', 'FLAG', true, current_date(), 'dq_agent_recommendation'
);
```

### Example user questions
- "Do order totals in the summary table actually match the line-item sums?"
- "Is the mismatch between `order_summary` and `order_line_items` a real
  data bug or is one of the tables just stale?"
- "Which region is driving the order_total inconsistency this week?"
- "Is there a rule that checks order totals against line items, and when
  did it start failing?"
- "Are the currency values consistent between the orders and line-items
  tables?"

---

## 4. Uniqueness

### Business problem
`billing.gold.customer_master` is keyed on `customer_id`, but a merge/dedup
job upstream fails to fully collapse records after a CRM migration,
producing duplicate `customer_id` rows with slightly different
`account_status`. The billing run join fans out on the duplicate, and a
subset of customers are billed twice in the same cycle — a direct financial
and customer-trust incident.

### Detection approach
- **Tier 1 (DQX built-in):** uniqueness / primary-key checks run
  zero-onboarding against the declared key column(s) of any UC table,
  written to `dqx_results` — catches the structural duplication from day
  one even before billing has authored a rule.
- **Tier 2 (`team_rule`):** business-defined uniqueness beyond a single key
  column, e.g. a composite-key or conditional uniqueness rule
  (`rule_expression` enforcing uniqueness of `customer_id` only where
  `account_status != 'MERGED'`), tagged `quality_dimension_tag =
  'Uniqueness'`.
- **Tier 2 (`data_profile`):** `distinct_count` vs. `row_count_at_profile_time`
  gives a direct duplication ratio per column; `cardinality_ratio`
  (`distinct_count / row_count_at_profile_time`) trended over
  `profile_date` is the primary quantitative signal — a ratio that should
  sit near 1.0 for a key column but is drifting down indicates growing
  duplication.
- **Primary Genie space:** **Profiling Intelligence** (`distinct_count`,
  `cardinality_ratio`), corroborated by **DQ Execution Analytics**
  (`dqx_results` uniqueness check outcomes).

### Investigation workflow
1. Query **Profiling Intelligence** for `data_profile.cardinality_ratio` and
   `distinct_count` on `customer_id` across recent `profile_date`s.
2. Query **DQ Execution Analytics** for `dqx_results`/`dq_stats` uniqueness
   check status and, if failing, how many duplicate keys were flagged.
3. Query **Rule Intelligence** for any Tier-2 conditional uniqueness
   `team_rule` that might explain "expected" duplicates (e.g. merged
   records intentionally retained) versus genuine duplication.
4. Query **Lineage & Impact Analysis** to identify the upstream dedup/merge
   job and whether its `dq_stats.status` shows `FAILED`/`PARTIAL` around the
   time the ratio started dropping.

### Root cause strategy
The agent distinguishes: (a) true duplication with no business
justification — the CRM migration case; (b) apparent duplication that is
actually expected by a Tier-2 rule (e.g. intentional retention of merged
history rows) — not a defect; (c) duplication caused by a specific known
event (the migration, a re-run of a job that double-appended instead of
upserting) traceable via Lineage & Impact Analysis and the upstream job's
`dq_stats.status`; (d) a Volume anomaly masquerading as a uniqueness problem
— row count is elevated with duplicates rather than key-cardinality
genuinely degrading, which the agent tells apart by checking Volume
Intelligence's row-count trend alongside the cardinality ratio.

### AI reasoning
The agent correlates the timing of a `cardinality_ratio` drop with
Lineage-visible upstream job runs (specifically a dedup/merge step) to
identify a likely triggering event rather than treating the drop as
unexplained. It distinguishes a step-change (single migration event) from a
steady erosion (an ongoing upstream process issue) and scores confidence
based on whether the same drop pattern recurs across related tables fed by
the same upstream source. It also checks whether an existing Tier-2 rule
already tolerates some duplication by design, to avoid raising a false
positive against intentional business behavior.

### Recommendation
```sql
-- Candidate team_rule (human review required before INSERT)
INSERT INTO team_rule (
  rule_id, team_name, catalog_name, schema_name, table_name, column_name,
  rule_name, rule_description, business_context, rule_expression,
  quality_dimension_tag, severity, action_if_failed, is_active,
  effective_from_date, created_by
) VALUES (
  uuid(), 'billing', 'billing', 'gold', 'customer_master', 'customer_id',
  'customer_id_unique_active_only',
  'customer_id must be unique among non-merged, active accounts',
  'CRM migration (May 2026) left unresolved duplicate customer_id rows, causing double billing.',
  "COUNT(*) OVER (PARTITION BY customer_id) = 1 OR account_status = 'MERGED'",
  'Uniqueness', 'CRITICAL', 'QUARANTINE', true, current_date(), 'dq_agent_recommendation'
);
```

### Example user questions
- "Are there duplicate customer IDs in the customer master table right
  now?"
- "Did the cardinality of `customer_id` drop after the CRM migration?"
- "Is the duplication in `customer_master` expected, or is there a rule
  that should be catching this?"
- "How many customers were potentially double-billed this cycle due to
  duplicate records?"
- "Which upstream job is producing the duplicate rows in customer_master?"

---

## 5. Timeliness

### Business problem
An executive daily-operations dashboard reads
`ops.gold.daily_shipment_metrics`, refreshed every morning by a scheduled
job. The upstream ingestion job silently fails one night (job errors out
after a partial write), but the dashboard has no way to know the data is
stale — it just renders yesterday's numbers as if they were today's,
leading leadership to make a same-day operational call on outdated
information.

### Detection approach
- **Tier 1 (DQX built-in):** temporal/freshness checks (e.g. "max
  timestamp within the last N hours") run zero-onboarding against any UC
  table with a timestamp column, written to `dqx_results`.
- **Tier 2 (`team_rule`):** business-specific SLA rules, e.g.
  `rule_expression` enforcing `freshness_last_updated_ts >= current_timestamp() - INTERVAL 6 HOURS`
  during business hours only, tagged `quality_dimension_tag = 'Timeliness'`.
- **Tier 2 (`data_profile`):** `freshness_last_updated_ts` is recorded per
  profiling run and trended.
- **Native signal:** `dq_stats`/`dqx_results` `execution_timestamp`,
  `execution_date`, and `status` directly show whether the producing job
  ran, and when — this is often the fastest way to detect a stale table,
  independent of any rule.
- **Primary Genie space:** **Freshness Intelligence**, cross-referenced with
  **DQ Execution Analytics** for the upstream job's run status.

### Investigation workflow
1. Query **Freshness Intelligence** for `data_profile.freshness_last_updated_ts`
   on the table, and compare against the expected SLA (from any Tier-2
   `team_rule`, or a default DQX threshold if none exists).
2. Query **DQ Execution Analytics** for the producing job's `dq_stats` row
   for the relevant `execution_date`: is `status` `SUCCESS`, `FAILED`,
   `PARTIAL`, or is there simply no row (`NOT_RUN`)? This is reported
   plainly — never inferred as passing.
3. If the job ran successfully but the table is still stale, check **Volume
   Intelligence** — did `input_record_count` collapse to near-zero,
   suggesting a partial/empty load that "succeeded" technically but
   delivered nothing meaningful?
4. Check **Lineage & Impact Analysis** for downstream consumers (dashboards,
   reports) so the agent can state the business impact concretely, not
   just "the table is stale."

### Root cause strategy
The agent separates: (a) the producing job simply didn't run
(`dq_stats.status = NOT_RUN` or missing row) — an operational/scheduling
issue; (b) the job ran and reported `FAILED`/`PARTIAL` — an execution
error, root cause is in the job itself; (c) the job reported `SUCCESS` but
the freshness timestamp still lags — a possible upstream source delay or a
watermark/incremental-load bug, investigated via Volume Intelligence
(did any new rows land at all) and Lineage; (d) an expected, known lag
(e.g. a weekly-refresh table being checked on a daily SLA by mistake) —
not a real incident, just a miscalibrated `team_rule` threshold.

### AI reasoning
The agent treats `dq_stats.status` as the primary evidence for whether a
freshness gap is a job failure versus a genuine SLA breach with no failure
recorded (the harder case — a job that "succeeds" but produces stale or
empty output). It cross-references Volume Intelligence's row-count history
to catch this harder case, and checks whether the current SLA threshold in
the `team_rule` matches the table's actual refresh cadence (avoiding false
alarms on intentionally low-frequency tables). Confidence is scored higher
when the staleness aligns exactly with a `FAILED`/`NOT_RUN` `dq_stats` row,
and lower when the job "succeeded" and the cause is unclear, in which case
the agent recommends investigation rather than asserting root cause.

### Recommendation
```yaml
# Candidate DQX check (proposed, not deployed)
- criticality: error
  check:
    function: is_data_fresh
    arguments:
      column: last_updated_ts
      max_age_hours: 6
      business_hours_only: true
  name: daily_shipment_metrics_freshness_sla
  metadata:
    quality_dimension_tag: Timeliness
    rationale: "Feeds exec daily-ops dashboard; a silent upstream failure produced stale data with no alert."
```

### Example user questions
- "Is `daily_shipment_metrics` up to date as of this morning?"
- "Did last night's ingestion job for the shipment metrics table actually
  run?"
- "Why is the executive dashboard showing yesterday's numbers?"
- "What's our current freshness SLA on the shipment metrics table, and are
  we meeting it?"
- "The job says it succeeded, so why does the data still look stale?"

---

## 6. Volume

### Business problem
`retail.gold.daily_sales_by_store` normally lands ~2M rows per day. One
Monday it lands with only 180K rows. A downstream regulatory sales-tax
filing job aggregates this table without any row-count sanity check, and
the filing is submitted understated by roughly 90% for that day — an error
that isn't caught until a subsequent audit reconciliation.

### Detection approach
- **Tier 1 (DQX built-in):** row-count/volume and dataset-comparison checks
  run zero-onboarding, comparing current load size against a rolling
  baseline, written to `dqx_results`.
- **Tier 2 (`team_rule`):** business-specific volume thresholds accounting
  for known seasonality, e.g. `rule_expression` comparing
  `input_record_count` against a day-of-week or month-end baseline rather
  than a flat threshold, tagged `quality_dimension_tag = 'Volume'`.
- **Tier 2 (`data_profile`):** `row_count_at_profile_time` trended by
  `profile_date`.
- **Native signal:** `dq_stats.input_record_count` per `execution_date` is
  the most direct, always-available volume signal, independent of any
  Tier-2 rule.
- **Primary Genie space:** **Volume Intelligence**, cross-referenced with
  **DQ Execution Analytics** (job status for the same run) and **Schema
  Intelligence** (did a schema change silently drop rows via a stricter
  join/filter).

### Investigation workflow
1. Query **Volume Intelligence** for `dq_stats.input_record_count` (or
   `data_profile.row_count_at_profile_time`) on the table for the affected
   `execution_date` versus the trailing N-day and same-weekday baseline.
2. Query **DQ Execution Analytics** for the run's `status`: did the
   producing job report `SUCCESS`, `FAILED`, `PARTIAL`, or is there no row
   at all (`NOT_RUN`) for that date?
3. Query **Governance Intelligence** / historical context (via `team_rule`
   `business_context` or prior incident notes) to check whether this date
   corresponds to a known seasonal event (holiday, promotion) that would
   explain a legitimate volume change rather than an anomaly.
4. Query **Schema Intelligence** (`DESCRIBE HISTORY`) to check whether a
   recent schema change (e.g. a stricter join key, a new NOT NULL
   constraint upstream, a changed partition column) could be silently
   filtering out rows rather than the source truly shrinking.
5. Query **Lineage & Impact Analysis** to identify the immediate upstream
   source and repeat volume checks there, to localize where in the pipeline
   the drop originates.

### Root cause strategy
This is the dimension where symptom-vs-cause separation matters most. The
agent works through, in order: (a) **genuine anomaly** — no known
seasonality, no schema change, no job failure, the source truly delivered
fewer records (real business event, e.g. a store outage); (b) **known
seasonality** — the date matches a recognized low-volume pattern (e.g.
a public holiday) already reflected in a Tier-2 `team_rule`'s baseline
logic, so this is not an incident; (c) **upstream job failure** —
`dq_stats.status` for the producing job is `FAILED`, `PARTIAL`, or absent
(`NOT_RUN`) for that date, which is the direct cause and must be reported
as such, never smoothed over; (d) **schema change silently dropping rows**
— a join or filter upstream started excluding rows after a column
rename/type change visible in Schema Intelligence's `DESCRIBE HISTORY`,
even though the job itself reported `SUCCESS`.

### AI reasoning
The agent does not simply flag "row count below threshold" — it builds a
same-weekday and same-day-of-month baseline from `data_profile`/`dq_stats`
history before deciding a drop is anomalous, explicitly checking for
recognized seasonal patterns first. It cross-correlates the drop date
against Schema Intelligence's commit history and DQ Execution Analytics'
job status in parallel, since a schema change can silently reduce volume
even when the job reports `SUCCESS` — the hardest case to catch with a
single query. It assigns higher confidence to a "job failure" explanation
when `dq_stats.status` directly confirms it, lower confidence to a "schema
change" explanation unless a `DESCRIBE HISTORY` commit timestamp lines up
closely with the volume drop, and explicitly labels a finding as "requires
human investigation" when no single cross-space signal is conclusive.

### Recommendation
```sql
-- Candidate team_rule (human review required before INSERT)
INSERT INTO team_rule (
  rule_id, team_name, catalog_name, schema_name, table_name, column_name,
  rule_name, rule_description, business_context, rule_expression,
  quality_dimension_tag, severity, action_if_failed, is_active,
  effective_from_date, created_by
) VALUES (
  uuid(), 'retail', 'retail', 'gold', 'daily_sales_by_store', NULL,
  'daily_sales_volume_within_seasonal_baseline',
  'Daily row count should stay within +/-20% of the trailing 4-week same-weekday average',
  'A 90% single-day volume drop fed an understated regulatory sales-tax filing with no alert.',
  'ABS(input_record_count - avg_same_weekday_baseline) / avg_same_weekday_baseline <= 0.20',
  'Volume', 'CRITICAL', 'ALERT_ONLY', true, current_date(), 'dq_agent_recommendation'
);
```

### Example user questions
- "Why did row counts for daily sales by store drop so much on Monday?"
- "Is the volume drop in the sales table a known seasonal dip or an actual
  problem?"
- "Did the sales ingestion job fail last night, or did it succeed with less
  data than expected?"
- "Could a recent schema change be silently dropping rows from the daily
  sales table?"
- "How does today's row count compare to the same weekday last month?"

---

## 7. Schema Drift

### Business problem
`supply_chain.gold.shipment_events` has a column
`carrier_code` renamed to `carrier_id` (with a type change from `STRING` to
`INT`) as part of an upstream system migration, with no advance notice to
the DQ team. A downstream regulatory customs-reporting feed that maps
`carrier_code` by name silently stops populating that field (the column no
longer exists under the expected name), and the submission goes out with a
blank carrier field for every shipment that week.

### Detection approach
- **Tier 1 (DQX built-in):** schema checks, including ODCS data-contract
  validation, run zero-onboarding to catch structural drift (added/removed/
  renamed/retyped columns) against a declared or inferred expected schema.
- **Native UC/Delta features (primary mechanism, per design decision):**
  `DESCRIBE HISTORY`, Delta Time Travel, and `information_schema.columns`
  are used directly — Delta's transaction log already stores a full schema
  snapshot at every commit, so **no custom schema-snapshot table is
  built or needed**.
- **Tier 2 (`team_rule`):** explicit schema-contract expectations where a
  business depends on a specific column existing/typed a specific way,
  tagged `quality_dimension_tag = 'SchemaDrift'`.
- **Primary Genie space:** **Schema Intelligence** (owns `DESCRIBE HISTORY`
  / `information_schema` access), cross-referenced with **Lineage & Impact
  Analysis** to identify affected downstream consumers.

### Investigation workflow
1. Query **Schema Intelligence** for `DESCRIBE HISTORY` on the table to find
   the commit that changed the schema (added/dropped/renamed/retyped
   column), its timestamp, and operation metadata.
2. Query `information_schema.columns` (also via Schema Intelligence) to
   confirm the current schema state versus the pre-change state (via Delta
   Time Travel to the prior version if needed).
3. Query **Rule Intelligence** for any `team_rule` tagged `SchemaDrift` that
   encoded an expectation about this column, to see if the change was
   supposed to be caught and wasn't (or was caught but not acted on).
4. Query **Lineage & Impact Analysis** to enumerate every downstream table,
   job, or dashboard that references the affected column by name, so the
   agent can state concrete blast radius rather than a generic warning.
5. Query **DQ Execution Analytics** for any downstream job's `dq_stats`
   showing a subsequent failure or a suspicious drop in
   `rules_passed_count` that correlates with the schema-change timestamp.

### Root cause strategy
The agent distinguishes: (a) an intentional, communicated schema change
(should have had, and did have, a corresponding `team_rule` or contract
update) — not an incident, just needs downstream consumers updated; (b) an
intentional but **uncommunicated** change — the real-world case here, where
`DESCRIBE HISTORY` shows the commit but no `team_rule`/contract was updated
in advance; (c) drift that looks structural but is actually a Volume or
Completeness symptom (e.g. a nullable column added upstream that starts
producing nulls downstream — checked against Profiling Intelligence rather
than treated purely as schema news); (d) a rename that breaks name-based
downstream references specifically, versus a type change that breaks
type-strict downstream consumers — these have different remediation paths
and the agent states which one occurred.

### AI reasoning
The agent correlates the exact `DESCRIBE HISTORY` commit timestamp against
downstream failure timestamps in DQ Execution Analytics to establish
causation, not just temporal proximity, and against Volume/Profiling
Intelligence to check whether the same event also produced a row-count or
null-rate symptom worth reporting together as one root cause rather than
three separate findings. It uses Lineage & Impact Analysis to size the
blast radius (number of downstream dependents) as an input to severity/
confidence, and flags with high confidence when a rename/retype commit
timestamp precisely precedes a downstream failure, versus lower confidence
when the timing is only loosely correlated.

### Recommendation
```yaml
# Candidate DQX check (proposed, not deployed)
- criticality: error
  check:
    function: has_column
    arguments:
      column: carrier_code
  name: shipment_events_carrier_code_contract
  metadata:
    quality_dimension_tag: SchemaDrift
    rationale: "carrier_code renamed to carrier_id without notice (May 2026), breaking the customs-reporting feed. Flags any future rename/removal before it silently reaches downstream consumers."
```
Paired with a `team_rule` proposal capturing the business contract in
human-readable form (`rule_description`, `business_context`) so the
expectation is documented, not just enforced mechanically.

### Example user questions
- "Did the shipment events table's schema change recently?"
- "What happened to the `carrier_code` column — was it renamed or
  removed?"
- "Which downstream tables or dashboards are affected by the schema change
  in shipment_events?"
- "Was there a schema contract rule that should have caught this rename?"
- "Show me the schema history for shipment_events over the last month."

---

## Cross-dimension note

Several investigation workflows above deliberately query more than one
Genie space and more than one adjacent dimension before concluding a root
cause — Consistency checks Freshness and Completeness, Volume checks
Schema and Execution Analytics, Schema Drift checks Volume and Profiling.
This reflects a real anti-pattern the agent must avoid: attributing a
symptom to the first matching dimension without ruling out neighboring
explanations. The agent's synthesis step (its own reasoning, not a
separate "aggregator" tool or agent — see `docs/06_SNAPSHOT_PATTERN_MAPPING.md`)
is what combines these cross-space signals into a single, confidence-scored,
explainable answer.
