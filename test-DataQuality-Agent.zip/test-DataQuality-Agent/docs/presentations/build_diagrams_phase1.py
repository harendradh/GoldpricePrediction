"""
Generates the Phase 1 scope + step-sequence diagram PNGs embedded in
DQ_Agent_Phase1_Implementation_Guide.docx. Run with:
    python build_diagrams_phase1.py
Requires: matplotlib (no other project dependency).

Content is sourced from CONTEXT_BRIEF.md, docs/02_QUALITY_DIMENSIONS.md,
docs/03_GENIE_WORKSPACES.md, and docs/08_ONBOARDING_RUNBOOK.md in this
project (DCS-DataQuality-Agent).

Visual style is REUSED, not reinvented: every helper, icon, and color
constant below is imported directly from build_diagrams.py in this same
folder, so this Phase 1 guide's diagrams read as one visual system with the
existing leadership deck's diagrams. build_diagrams.py is NOT modified, and
importing it here has no side effects -- its own diagram-generation calls
only run under `if __name__ == "__main__"` in that file.
"""
import os
from matplotlib.patches import Rectangle, Circle

from build_diagrams import (
    new_fig, box, arrow, flow_dots, add_sheen,
    icon_database, icon_gear, icon_robot, icon_shield, icon_clock, icon_chart,
    icon_link, icon_layers, icon_screen, icon_question, icon_flag, icon_grid,
    icon_key, icon_check, icon_magnifier, icon_book,
    NAVY, BLUE, LIGHT_BLUE, ORANGE, LIGHT_ORANGE, GREEN, LIGHT_GREEN, GRAY,
    LIGHT_GRAY, WHITE, RED, LIGHT_RED, PURPLE, LIGHT_PURPLE, TEAL, LIGHT_TEAL,
    SLATE, LIGHT_SLATE, AMBER, LIGHT_AMBER, plt,
)

OUT = os.path.dirname(os.path.abspath(__file__))


# ===========================================================================
# Diagram P1-A: Phase 1 scope -- 3 dimensions -> 3 tables -> 3 Genie spaces
# -> the agent, with only 3 of 8 spaces needed to start.
# ===========================================================================
def diagram_phase1_scope():
    fig, ax = new_fig(15.4, 12.7)

    ax.text(7.7, 12.35, "Phase 1 Scope: Completeness · Validity · Uniqueness",
            ha="center", fontsize=21.5, fontweight="bold", color=NAVY)
    ax.text(7.7, 11.9, "3 dimensions -> 3 shared tables already available -> 3 Genie spaces to build first -> the agent",
            ha="center", fontsize=12.6, color=GRAY, style="italic")

    box_w, gap = 3.6, 0.35
    xs = [0.5, 0.5 + box_w + gap, 0.5 + 2 * (box_w + gap)]  # 0.5, 4.45, 8.40
    row_span_right = xs[-1] + box_w  # 12.0

    # ---- Row 1: the 3 Phase 1 dimensions ----
    ax.text(0.5, 11.15, "PHASE 1 QUALITY DIMENSIONS  (Wave 1 -- see docs/08 rollout phasing)",
            fontsize=12.6, color=GREEN, fontweight="bold")
    dim_y, dim_h = 9.95, 1.05
    dims = [("Completeness", icon_layers), ("Validity", icon_shield), ("Uniqueness", icon_gear)]
    for x, (t, ic) in zip(xs, dims):
        box(ax, x, dim_y, box_w, dim_h, t, fc=LIGHT_GREEN, ec=GREEN, fontsize=14.5,
            fontweight="bold", icon=ic)

    # ---- Connector manifold: all 3 dimensions draw on Tier 2 evidence ----
    mid_x = (xs[0] + row_span_right) / 2
    arrow(ax, (mid_x, dim_y), (mid_x, dim_y - 0.32), color=GREEN, lw=2.0)
    man_y, man_h = dim_y - 0.68, 0.36
    box(ax, xs[0], man_y, row_span_right - xs[0], man_h,
        "all three dimensions are evaluated using Tier 2 human-curated evidence in:",
        fc="#EEF6F0", ec=GREEN, fontsize=10.6, fontweight="bold", accent=False)
    arrow(ax, (mid_x, man_y), (mid_x, man_y - 0.32), color=GREEN, lw=2.0)

    # ---- Row 2: the 3 shared metadata tables, live today ----
    tab_y_label = man_y - 0.45
    ax.text(0.5, tab_y_label, "3 SHARED METADATA TABLES -- AVAILABLE TODAY  (Tier 2, canonical names)",
            fontsize=12.6, color=GREEN, fontweight="bold")
    tab_y, tab_h = tab_y_label - 1.2, 1.15
    tables = [
        "team_rule\n(user shorthand: \"dq_rule\")",
        "dq_stats\n(execution outcomes)",
        "data_profile\n(user shorthand: \"df_profile\")",
    ]
    for x, t in zip(xs, tables):
        box(ax, x, tab_y, box_w, tab_h, t, fc=LIGHT_GREEN, ec=GREEN, fontsize=12.3,
            fontweight="bold", icon=icon_database)

    # ---- 1:1 arrows down into the matching Genie space ----
    gs_y_label = tab_y - 0.45
    ax.text(0.5, gs_y_label, "3 GENIE SPACES TO BUILD FIRST  (of 8 total -- see Section 9 for the rest)",
            fontsize=12.6, color=TEAL, fontweight="bold")
    gs_y, gs_h = gs_y_label - 1.2, 1.15
    genie = ["Rule\nIntelligence", "Profiling\nIntelligence", "DQ Execution\nAnalytics"]
    for x, t in zip(xs, genie):
        arrow(ax, (x + box_w / 2, tab_y), (x + box_w / 2, gs_y + gs_h + 0.08), color=TEAL, lw=1.8)
        flow_dots(ax, x + box_w / 2, tab_y, x + box_w / 2, gs_y + gs_h + 0.08, TEAL, n=1)
        box(ax, x, gs_y, box_w, gs_h, t, fc=LIGHT_TEAL, ec=TEAL, fontsize=13.5,
            fontweight="bold", icon=icon_gear)

    # ---- Tier 1 DQX side-feed into DQ Execution Analytics specifically ----
    dqx_x, dqx_w = row_span_right + 0.35, 2.6
    ax.text(dqx_x + dqx_w / 2, gs_y + gs_h + 0.22, "ALSO FEEDS", ha="center", fontsize=9.3,
            color=ORANGE, fontweight="bold")
    box(ax, dqx_x, gs_y, dqx_w, gs_h, "dqx_results\n(Tier 1 DQX --\nzero onboarding)",
        fc=LIGHT_ORANGE, ec=ORANGE, fontsize=10.3, fontweight="bold", icon=icon_database,
        dashed=True, accent=False)
    link_y = gs_y + gs_h * 0.5
    arrow(ax, (dqx_x, link_y), (xs[2] + box_w + 0.04, link_y), color=ORANGE, lw=2.0)
    flow_dots(ax, dqx_x, link_y, xs[2] + box_w + 0.04, link_y, ORANGE, n=1)

    # ---- Agent ----
    ag_y_label = gs_y - 0.45
    ax.text(0.5, ag_y_label, "AGENT", fontsize=12.6, color=NAVY, fontweight="bold")
    ag_y, ag_h = ag_y_label - 1.25, 1.2
    ag_w = row_span_right - xs[0]
    box(ax, xs[0], ag_y, ag_w, ag_h,
        "Data Quality Investigation Agent -- DCS Agent Studio\n(same agent config / instruction as all 7 dimensions)",
        fc=NAVY, ec=NAVY, fontsize=13.6, fontweight="bold", textcolor=WHITE, icon=icon_robot,
        icon_color=ORANGE, accent=False)
    mid_gs_x = xs[1] + box_w / 2
    arrow(ax, (mid_gs_x, gs_y), (mid_gs_x, ag_y + ag_h + 0.08), color=NAVY, lw=2.0)
    flow_dots(ax, mid_gs_x, gs_y, mid_gs_x, ag_y + ag_h + 0.08, NAVY, n=2)

    # ---- Phase 2 preview note (full-width, dashed) ----
    p2_y, p2_h = ag_y - 0.85, 0.62
    box(ax, xs[0], p2_y, row_span_right + dqx_w + 0.35 - xs[0], p2_h,
        "Phase 2 adds 4 more dimensions (Consistency, Timeliness, Volume, Schema Drift) and 5 more\n"
        "Genie spaces (Schema, Freshness, Volume, Lineage & Impact, Governance Intelligence) -- Section 9",
        fc=LIGHT_ORANGE, ec=ORANGE, fontsize=10.4, textcolor="#7A3B0E", dashed=True, accent=False)

    # ---- Bottom callout ----
    cb_y = p2_y - 0.95
    box(ax, xs[0], cb_y, row_span_right + dqx_w + 0.35 - xs[0], 0.75,
        "Only 3 of the 8 Genie spaces are needed to start Phase 1 -- zero new infrastructure beyond\n"
        "Steps 1-6 of the onboarding runbook.",
        fc=LIGHT_RED, ec=RED, fontsize=12.6, fontweight="bold", textcolor=RED, accent=False)

    ax.set_ylim(cb_y - 0.3, 12.7)
    fig.tight_layout()
    fig.savefig(os.path.join(OUT, "phase1_diagram_1_scope.png"), dpi=175)
    plt.close(fig)


# ===========================================================================
# Diagram P1-B: Step sequence 1-7, condensed to the Phase 1 subset of
# docs/08_ONBOARDING_RUNBOOK.md.
# ===========================================================================
def diagram_phase1_steps():
    fig, ax = new_fig(15.6, 6.7)
    ax.text(7.8, 6.25, "Phase 1 Setup, Step by Step",
            ha="center", fontsize=21.5, fontweight="bold", color=NAVY)
    ax.text(7.8, 5.82, "Condensed from docs/08_ONBOARDING_RUNBOOK.md -- Phase 1 subset only",
            ha="center", fontsize=12.4, color=GRAY, style="italic")

    steps = [
        ("1", "Grant SELECT", "3 tables + dqx_results\n+ information_schema", icon_key, BLUE, LIGHT_BLUE),
        ("2", "Document\nmetadata", "Table/column comments\n+ PK/FK declarations", icon_book, BLUE, LIGHT_BLUE),
        ("3", "Create 3\nGenie spaces", "Rule, Profiling,\nDQ Execution Analytics", icon_gear, TEAL, LIGHT_TEAL),
        ("4", "Deploy DQX\npilot", "Completeness/Validity/\nUniqueness checks", icon_shield, GREEN, LIGHT_GREEN),
        ("5", "Create the\nagent", "DCS Agent Studio,\n3 tools wired", icon_robot, NAVY, LIGHT_BLUE),
        ("6", "Run Phase 1\nevals", "All 7 ZT cases +\nGC-01/02/04", icon_check, GREEN, LIGHT_GREEN),
        ("7", "Onboard first\nteam", "Tier 1 (grant only) or\nTier 2 (already writing)", icon_flag, ORANGE, LIGHT_ORANGE),
    ]

    n = len(steps)
    w, h = 1.95, 1.85
    total_gap = 15.6 - n * w
    gap = total_gap / (n + 1)
    y = 2.85
    xs = []
    for i in range(n):
        x = gap + i * (w + gap)
        xs.append(x)

    for i, (x, (num, title, desc, ic, ec, fc)) in enumerate(zip(xs, steps)):
        box(ax, x, y, w, h, title, fc=fc, ec=ec, fontsize=11.2, fontweight="bold", icon=ic)
        ax.add_patch(Circle((x + w / 2, y + h + 0.32), 0.32, facecolor=ec, edgecolor="white", lw=1.5, zorder=6))
        ax.text(x + w / 2, y + h + 0.32, num, ha="center", va="center", fontsize=14,
                fontweight="bold", color="white", zorder=6.1)
        ax.text(x + w / 2, y - 0.28, desc, ha="center", va="top", fontsize=9.6, color=GRAY)
        if i < n - 1:
            arrow(ax, (x + w + 0.03, y + h / 2), (xs[i + 1] - 0.03, y + h / 2), color=GRAY, lw=1.6)

    box(ax, gap, 0.15, 15.6 - 2 * gap, 0.75,
        "Steps 1-6 are one-time platform setup; step 7 repeats for every additional team onboarded.",
        fc=LIGHT_GRAY, ec=GRAY, fontsize=11.6, textcolor="#111827", accent=False)

    fig.tight_layout()
    fig.savefig(os.path.join(OUT, "phase1_diagram_2_steps.png"), dpi=175)
    plt.close(fig)


if __name__ == "__main__":
    diagram_phase1_scope()
    diagram_phase1_steps()
    print("Phase 1 diagrams written to", OUT)
