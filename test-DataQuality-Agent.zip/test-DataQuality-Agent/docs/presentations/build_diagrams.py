"""
Generates the architecture diagram PNGs embedded in
DQ_Agent_Enterprise_Leadership_Architecture.docx. Run with:
    python build_diagrams.py
Requires: matplotlib (no other project dependency).

Content is sourced from CONTEXT_BRIEF.md and docs/00-08 in this project
(DCS-DataQuality-Agent) -- NOT from any prior project. Only the drawing
technique (shadowed rounded boxes, small vector icon library, matplotlib
patch helpers) is reused from an earlier, unrelated project's presentation
scripts.
"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle, Ellipse, Rectangle, Polygon
import os
import math

OUT = os.path.dirname(os.path.abspath(__file__))

NAVY = "#1F3557"
BLUE = "#2E6FB5"
LIGHT_BLUE = "#DCE8F5"
ORANGE = "#E8792B"
LIGHT_ORANGE = "#FBE6D4"
GREEN = "#3E8E5A"
LIGHT_GREEN = "#DCEFE2"
GRAY = "#6B7280"
LIGHT_GRAY = "#F0F1F3"
WHITE = "#FFFFFF"
SHADOW = "#0F1E33"
RED = "#C0392B"
LIGHT_RED = "#FBE4E1"
PURPLE = "#6B4C93"
LIGHT_PURPLE = "#E9E1F2"
TEAL = "#0E7C86"
LIGHT_TEAL = "#D9EEF0"
SLATE = "#3D5A80"
LIGHT_SLATE = "#E3E9F0"
AMBER = "#B8860B"
LIGHT_AMBER = "#F7ECD1"

plt.rcParams["font.family"] = "DejaVu Sans"


# ---------------------------------------------------------------------------
# Core helpers: shadowed rounded box + connectors
# ---------------------------------------------------------------------------
def shadow(ax, x, y, w, h, offset=0.045, layers=4):
    for i in range(layers, 0, -1):
        a = 0.05 * (layers - i + 1) / layers
        p = FancyBboxPatch((x + offset * i / layers, y - offset * i / layers), w, h,
                            boxstyle="round,pad=0.02,rounding_size=0.07",
                            linewidth=0, facecolor=SHADOW, alpha=a, zorder=0.5)
        ax.add_patch(p)


def box(ax, x, y, w, h, text, fc=LIGHT_BLUE, ec=BLUE, fontsize=11.5, fontweight="normal",
        textcolor="#111827", zorder=2, icon=None, icon_color=None, accent=True, dashed=False, alpha=1.0):
    if not dashed:
        shadow(ax, x, y, w, h)
    p = FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.07",
                        linewidth=1.8, edgecolor=ec, facecolor=fc, zorder=zorder,
                        linestyle="--" if dashed else "-", alpha=alpha)
    ax.add_patch(p)
    if accent and not dashed:
        bar = FancyBboxPatch((x, y), 0.09, h, boxstyle="round,pad=0.0,rounding_size=0.03",
                              linewidth=0, facecolor=ec, zorder=zorder + 0.5, alpha=0.85)
        ax.add_patch(bar)
    text_y = y + h / 2
    if icon is not None:
        icon(ax, x + w / 2, y + h - 0.3, 0.2, icon_color or ec)
        text_y = y + h / 2 - 0.14
    ax.text(x + w / 2, text_y, text, ha="center", va="center", fontsize=fontsize,
             fontweight=fontweight, color=textcolor, zorder=zorder + 1, wrap=True, alpha=alpha)
    return p


def arrow(ax, xy1, xy2, color=GRAY, style="-|>", lw=1.8, connectionstyle="arc3,rad=0.0", alpha=1.0):
    a = FancyArrowPatch(xy1, xy2, arrowstyle=style, mutation_scale=15, linewidth=lw,
                         color=color, connectionstyle=connectionstyle, zorder=1, alpha=alpha)
    ax.add_patch(a)


def new_fig(w=13, h=8):
    fig, ax = plt.subplots(figsize=(w, h))
    ax.set_xlim(0, w)
    ax.set_ylim(0, h)
    ax.axis("off")
    return fig, ax


def flow_dots(ax, x1, y1, x2, y2, color, n=3):
    for i in range(1, n + 1):
        t = i / (n + 1)
        ax.add_patch(Circle((x1 + (x2 - x1) * t, y1 + (y2 - y1) * t), 0.035,
                             facecolor=color, edgecolor="none", zorder=1.2, alpha=0.85))


def add_sheen(ax, x, y, w, h, zorder=2.7):
    """Adds a subtle darker band along the bottom + a light sheen near the top of an
    *already-drawn* box, at the same (x, y, w, h) footprint, so a flat-filled bar reads
    as gently gradient-shaded instead of perfectly flat. Purely decorative overlay --
    it never changes any box's position or size, so it cannot introduce a new overlap."""
    band = Rectangle((x + 0.02, y), w - 0.04, h * 0.28, facecolor=SHADOW, alpha=0.10,
                      edgecolor="none", zorder=zorder)
    ax.add_patch(band)
    sheen = Rectangle((x + 0.02, y + h * 0.6), w - 0.04, h * 0.22, facecolor="white", alpha=0.09,
                       edgecolor="none", zorder=zorder)
    ax.add_patch(sheen)


# ---------------------------------------------------------------------------
# Vector icon library
# ---------------------------------------------------------------------------
def icon_database(ax, cx, cy, r, color):
    w, h = r * 2.1, r * 1.9
    ax.add_patch(Ellipse((cx, cy + h * 0.32), w, h * 0.34, facecolor=color, edgecolor="none", zorder=5))
    ax.add_patch(Rectangle((cx - w / 2, cy - h * 0.18), w, h * 0.5, facecolor=color, edgecolor="none", zorder=4.8))
    ax.add_patch(Ellipse((cx, cy - h * 0.18), w, h * 0.34, facecolor=color, edgecolor="none", alpha=0.75, zorder=4.9))
    ax.add_patch(Ellipse((cx, cy + h * 0.32), w, h * 0.34, facecolor="none", edgecolor="white", lw=0.8, alpha=0.5, zorder=5.1))


def icon_gear(ax, cx, cy, r, color):
    n = 8
    outer, inner = r * 0.95, r * 0.62
    pts = []
    for i in range(n * 2):
        ang = math.pi * i / n
        rad = outer if i % 2 == 0 else outer * 0.75
        pts.append((cx + rad * math.cos(ang), cy + rad * math.sin(ang)))
    ax.add_patch(Polygon(pts, closed=True, facecolor=color, edgecolor="none", zorder=5))
    ax.add_patch(Circle((cx, cy), inner * 0.55, facecolor="white", edgecolor="none", zorder=5.1))


def icon_robot(ax, cx, cy, r, color):
    ax.add_patch(FancyBboxPatch((cx - r * 0.85, cy - r * 0.7), r * 1.7, r * 1.3,
                                 boxstyle="round,pad=0.0,rounding_size=0.05",
                                 facecolor=color, edgecolor="none", zorder=5))
    ax.add_patch(Circle((cx - r * 0.32, cy - r * 0.05), r * 0.14, facecolor="white", zorder=5.2))
    ax.add_patch(Circle((cx + r * 0.32, cy - r * 0.05), r * 0.14, facecolor="white", zorder=5.2))
    ax.plot([cx, cx], [cy + r * 0.6, cy + r * 0.95], color=color, lw=1.6, zorder=5)
    ax.add_patch(Circle((cx, cy + r * 1.0), r * 0.1, facecolor=color, zorder=5))
    ax.plot([cx - r * 0.85, cx - r * 1.05], [cy - r * 0.2, cy - r * 0.2], color=color, lw=2, zorder=4.9)
    ax.plot([cx + r * 0.85, cx + r * 1.05], [cy - r * 0.2, cy - r * 0.2], color=color, lw=2, zorder=4.9)


def icon_chat(ax, cx, cy, r, color):
    ax.add_patch(FancyBboxPatch((cx - r, cy - r * 0.7), r * 2, r * 1.25,
                                 boxstyle="round,pad=0.0,rounding_size=0.06",
                                 facecolor=color, edgecolor="none", zorder=5))
    ax.add_patch(Polygon([(cx - r * 0.35, cy - r * 0.45), (cx - r * 0.05, cy - r * 0.45), (cx - r * 0.35, cy - r * 0.9)],
                          closed=True, facecolor=color, edgecolor="none", zorder=5))
    for dx in (-0.35, 0, 0.35):
        ax.add_patch(Circle((cx + dx * r, cy - r * 0.05), r * 0.09, facecolor="white", zorder=5.2))


def icon_magnifier(ax, cx, cy, r, color):
    ax.add_patch(Circle((cx - r * 0.15, cy + r * 0.15), r * 0.55, facecolor="none", edgecolor=color, lw=2.2, zorder=5))
    ax.plot([cx + r * 0.25, cx + r * 0.68], [cy - r * 0.25, cy - r * 0.68], color=color, lw=2.6, solid_capstyle="round", zorder=5)


def icon_shield(ax, cx, cy, r, color):
    pts = [(cx, cy + r), (cx + r * 0.75, cy + r * 0.55), (cx + r * 0.75, cy - r * 0.35),
           (cx, cy - r), (cx - r * 0.75, cy - r * 0.35), (cx - r * 0.75, cy + r * 0.55)]
    ax.add_patch(Polygon(pts, closed=True, facecolor=color, edgecolor="none", zorder=5))
    ax.plot([cx - r * 0.32, cx - r * 0.05, cx + r * 0.38], [cy - r * 0.05, cy - r * 0.28, cy + r * 0.28],
            color="white", lw=1.8, solid_capstyle="round", solid_joinstyle="round", zorder=5.2)


def icon_clock(ax, cx, cy, r, color):
    ax.add_patch(Circle((cx, cy), r * 0.85, facecolor="none", edgecolor=color, lw=2.0, zorder=5))
    ax.plot([cx, cx], [cy, cy + r * 0.5], color=color, lw=1.8, solid_capstyle="round", zorder=5.1)
    ax.plot([cx, cx + r * 0.4], [cy, cy], color=color, lw=1.8, solid_capstyle="round", zorder=5.1)


def icon_chart(ax, cx, cy, r, color):
    heights = [0.5, 0.85, 1.15]
    for i, hh in enumerate(heights):
        x = cx - r * 0.7 + i * r * 0.7
        ax.add_patch(Rectangle((x, cy - r * 0.7), r * 0.42, r * hh, facecolor=color, edgecolor="none", zorder=5))


def icon_link(ax, cx, cy, r, color):
    ax.add_patch(Ellipse((cx - r * 0.35, cy), r * 0.75, r * 0.5, angle=35, facecolor="none", edgecolor=color, lw=2.2, zorder=5))
    ax.add_patch(Ellipse((cx + r * 0.35, cy), r * 0.75, r * 0.5, angle=35, facecolor="none", edgecolor=color, lw=2.2, zorder=5.1))


def icon_layers(ax, cx, cy, r, color):
    for i, dy in enumerate([-0.35, 0, 0.35]):
        ax.add_patch(Polygon([(cx - r * 0.8, cy + dy * r), (cx, cy + dy * r - r * 0.28), (cx + r * 0.8, cy + dy * r),
                               (cx, cy + dy * r + r * 0.28)],
                              closed=True, facecolor=color, edgecolor="white", lw=0.5,
                              alpha=0.55 + 0.15 * i, zorder=5 + i * 0.05))


def icon_screen(ax, cx, cy, r, color):
    ax.add_patch(FancyBboxPatch((cx - r * 0.9, cy - r * 0.55), r * 1.8, r * 1.15,
                                 boxstyle="round,pad=0.0,rounding_size=0.05",
                                 facecolor="none", edgecolor=color, lw=2.0, zorder=5))
    ax.plot([cx - r * 0.35, cx + r * 0.35], [cy - r * 0.85, cy - r * 0.85], color=color, lw=2.0, zorder=5)
    ax.plot([cx, cx], [cy - r * 0.55, cy - r * 0.85], color=color, lw=2.0, zorder=5)


def icon_question(ax, cx, cy, r, color):
    ax.add_patch(Circle((cx, cy), r * 0.95, facecolor="none", edgecolor=color, lw=2.0, zorder=5))
    ax.text(cx, cy - r * 0.03, "?", ha="center", va="center", fontsize=r * 34, fontweight="bold",
            color=color, zorder=5.1)


def icon_flag(ax, cx, cy, r, color):
    ax.plot([cx - r * 0.55, cx - r * 0.55], [cy - r * 0.9, cy + r * 0.9], color=color, lw=2.4,
            solid_capstyle="round", zorder=5)
    ax.add_patch(Polygon([(cx - r * 0.55, cy + r * 0.9), (cx + r * 0.75, cy + r * 0.5),
                           (cx - r * 0.55, cy + r * 0.1)], closed=True, facecolor=color,
                          edgecolor="none", zorder=5))


def icon_grid(ax, cx, cy, r, color):
    for dx in (-1, 0, 1):
        for dy in (-1, 0, 1):
            ax.add_patch(Rectangle((cx + dx * r * 0.42 - r * 0.13, cy + dy * r * 0.42 - r * 0.13),
                                    r * 0.26, r * 0.26, facecolor=color, edgecolor="none", zorder=5))


def icon_key(ax, cx, cy, r, color):
    ax.add_patch(Circle((cx - r * 0.4, cy), r * 0.4, facecolor="none", edgecolor=color, lw=2.2, zorder=5))
    ax.plot([cx - r * 0.05, cx + r * 0.8], [cy, cy], color=color, lw=2.2, solid_capstyle="round", zorder=5)
    ax.plot([cx + r * 0.45, cx + r * 0.45], [cy, cy - r * 0.3], color=color, lw=2.2, solid_capstyle="round", zorder=5)
    ax.plot([cx + r * 0.75, cx + r * 0.75], [cy, cy - r * 0.3], color=color, lw=2.2, solid_capstyle="round", zorder=5)


def icon_cross(ax, cx, cy, r, color):
    ax.add_patch(Circle((cx, cy), r * 0.95, facecolor="white", edgecolor=color, lw=2.4, zorder=5))
    ax.plot([cx - r * 0.55, cx + r * 0.55], [cy - r * 0.55, cy + r * 0.55], color=color, lw=2.6, solid_capstyle="round", zorder=5.1)
    ax.plot([cx - r * 0.55, cx + r * 0.55], [cy + r * 0.55, cy - r * 0.55], color=color, lw=2.6, solid_capstyle="round", zorder=5.1)


def icon_check(ax, cx, cy, r, color):
    ax.add_patch(Circle((cx, cy), r * 0.95, facecolor="none", edgecolor=color, lw=2.2, zorder=5))
    ax.plot([cx - r * 0.42, cx - r * 0.08, cx + r * 0.5], [cy - r * 0.05, cy - r * 0.4, cy + r * 0.45],
            color=color, lw=2.4, solid_capstyle="round", solid_joinstyle="round", zorder=5.1)


def icon_book(ax, cx, cy, r, color):
    ax.add_patch(FancyBboxPatch((cx - r * 0.85, cy - r * 0.7), r * 1.7, r * 1.4,
                                 boxstyle="round,pad=0.0,rounding_size=0.04",
                                 facecolor="none", edgecolor=color, lw=2.0, zorder=5))
    ax.plot([cx, cx], [cy - r * 0.7, cy + r * 0.7], color=color, lw=1.6, zorder=5)


# ===========================================================================
# Diagram 1: The Problem — 6 core investigation gaps a dashboard can't close
# ===========================================================================
def problem_card(ax, x, y, w, h, title, desc, icon):
    shadow(ax, x, y, w, h)
    p = FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.09",
                        linewidth=1.8, edgecolor=RED, facecolor=WHITE, zorder=2)
    ax.add_patch(p)
    bar = FancyBboxPatch((x, y), 0.1, h, boxstyle="round,pad=0.0,rounding_size=0.03",
                          linewidth=0, facecolor=RED, zorder=2.5, alpha=0.9)
    ax.add_patch(bar)
    icon_cy = y + h - 0.62
    ax.add_patch(Circle((x + w / 2, icon_cy), 0.4, facecolor=LIGHT_RED, edgecolor=RED, lw=1.4, zorder=3))
    icon(ax, x + w / 2, icon_cy, 0.23, RED)
    ax.text(x + w / 2, y + h - 1.32, title, ha="center", va="center", fontsize=14.3,
            fontweight="bold", color=NAVY, zorder=3)
    ax.text(x + w / 2, y + 0.72, desc, ha="center", va="center", fontsize=10.8, color=GRAY, zorder=3)


def diagram_1_problem_statement():
    fig, ax = new_fig(14.2, 9.8)
    ax.add_patch(Rectangle((0.15, 2.35), 13.9, 4.05, facecolor=LIGHT_RED, edgecolor="none", alpha=0.18, zorder=0))
    ax.text(7.1, 9.35, "The Problem: 6 Investigation Gaps a Dashboard Can't Close", ha="center",
            fontsize=20.7, fontweight="bold", color=RED)
    ax.text(7.1, 8.9, "Hundreds of data products, thousands of pipelines -- these are structural gaps,\n"
                      "not a missing chart on an existing dashboard",
            ha="center", fontsize=12.9, color=GRAY, style="italic")

    cards = [
        ("No Root Cause,\nOnly a Failed Check",
         "A rule fails in dq_stats and shows\nred -- with no explanation of the\nupstream why.", icon_flag),
        ("Signals Live\nin Silos",
         "team_rule, dq_stats, data_profile,\nschema history, and UC lineage sit\nin separate tables and tools.", icon_layers),
        ("Inconsistent\nInvestigation",
         "Every team manually cross-references\nlogs and history its own way --\nanswers vary by who looks.", icon_question),
        ("Fragmented\nProfiling Data",
         "data_profile is genuinely fragmented --\ndifferent teams profile different\ncolumns of the same table.", icon_database),
        ("No Confidence\nor Audit Trail",
         "\"Probably fine\" can't be checked --\nno evidence trail, no stated tier,\nno confidence score.", icon_shield),
        ("Doesn't Scale to\nHundreds of Products",
         "Manual triage collapses across\nhundreds of data products and\nthousands of pipelines.", icon_grid),
    ]
    card_w, card_h, gap_x, gap_y = 4.2, 2.55, 0.35, 0.35
    left = 0.45
    row_y = [5.55, 2.65]
    for idx, (title, desc, ic) in enumerate(cards):
        col = idx % 3
        row = idx // 3
        x = left + col * (card_w + gap_x)
        y = row_y[row]
        problem_card(ax, x, y, card_w, card_h, title, desc, ic)

    box(ax, 0.45, 0.55, 13.3, 1.0,
        "The fix is not another chart -- it's an agent that investigates, cross-references,\nand explains, grounded only in what it actually finds.",
        fc=LIGHT_RED, ec=RED, fontsize=13, fontweight="bold", textcolor=RED, accent=False)

    fig.tight_layout()
    fig.savefig(os.path.join(OUT, "diagram_1_problem_statement.png"), dpi=175)
    plt.close(fig)


# ===========================================================================
# Diagram 2: End-to-end architecture
# ===========================================================================
def diagram_2_architecture():
    # Shorter than v1 -- the native-metadata row (information_schema / Delta history /
    # UC lineage / system.lakeflow) was dropped per user feedback (redundant with
    # diagram_3's per-space source labels and the body text) so every remaining section
    # could be drawn bigger, with more headroom, instead of leaving the freed space blank.
    fig, ax = new_fig(15.4, 11.3)

    for (y0, y1, c) in [
        (9.4, 10.85, "#F7FAFD"), (7.55, 9.4, "#EFF5FC"), (5.7, 7.55, "#FDF1E7"),
        (3.9, 5.7, "#F2EEF7"), (2.1, 3.9, "#EFF7F1"), (0.25, 2.1, "#F4F6F8"),
    ]:
        ax.add_patch(Rectangle((0.1, y0), 15.2, y1 - y0, facecolor=c, edgecolor="none", zorder=0))

    ax.text(7.7, 10.55, "Data Quality AI Agent -- End-to-End Architecture", ha="center",
            fontsize=22.5, fontweight="bold", color=NAVY)

    # ---- Data sources (one row of four, colored by the tier each one feeds) ----
    ax.text(0.35, 10.05, "DATA SOURCES", fontsize=13.6, color=SLATE, fontweight="bold")
    src_boxes = [
        ("team_rule\n(Tier 2 business rules)", LIGHT_GREEN, GREEN),
        ("dq_stats\n(Tier 2 execution history)", LIGHT_GREEN, GREEN),
        ("data_profile\n(Tier 2 profiling)", LIGHT_GREEN, GREEN),
        ("dqx_results\n(Tier 1 DQX output)", LIGHT_ORANGE, ORANGE),
    ]
    bw, bh, gap = 3.5, 1.35, 0.2
    xs = [0.4 + i * (bw + gap) for i in range(4)]
    srcA_bottom = 8.55
    for x, (t, fc, ec) in zip(xs, src_boxes):
        box(ax, x, srcA_bottom, bw, bh, t, fc=fc, ec=ec, fontsize=13.5, fontweight="bold", icon=icon_database)

    # ---- Tier 1 / Tier 2 ----
    # White halo behind this label only: it's the one section title that sits in the same
    # band the source->tier funnel arrows sweep through, so a solid backing guarantees the
    # text stays legible regardless of exactly where a given arrow's diagonal passes.
    ax.text(0.35, 8.25, "TWO-TIER INVESTIGATION MODEL", fontsize=13.6, color=BLUE, fontweight="bold",
            zorder=10, bbox=dict(facecolor="white", edgecolor="none", pad=3, alpha=0.92))
    ty = 6.7
    tier_h = 1.35
    tier1_x, tier1_w = 0.4, 7.15
    tier2_x, tier2_w = 7.85, 7.15
    # Kept short and single-line -- the fuller "writes ONLY to dqx_results" / "preferred
    # whenever present" detail lives in docs/01 and docs/04; the longer wording used to run
    # edge-to-edge in the box at this width, reading as text overlapping the border.
    box(ax, tier1_x, ty, tier1_w, tier_h,
        "TIER 1 -- DQX\nZero onboarding . Read-only . Automated",
        fc=LIGHT_ORANGE, ec=ORANGE, fontsize=12.8, fontweight="bold", icon=icon_gear)
    box(ax, tier2_x, ty, tier2_w, tier_h,
        "TIER 2 -- Human-Curated\nteam_rule . dq_stats . data_profile",
        fc=LIGHT_GREEN, ec=GREEN, fontsize=12.8, fontweight="bold", icon=icon_shield)

    # Each source box is colored to match the tier it feeds (green -> Tier 2, orange ->
    # Tier 1), so these converging, color-matched arrows read as "obviously correct"
    # rather than an arbitrary crossing pattern -- the same diagonal-funnel convention
    # diagram_5 already uses for its read arrows.
    # Arrows stop 0.07 short of the tier boxes' top edge -- landing exactly ON the edge let
    # the arrowhead marker visually poke through the box border (reported as an overlap on
    # the TIER 1 -- DQX box specifically, but it applied to every landing point here).
    tier_gap = 0.07
    tier2_landing = [9.5, 11.4, 13.3]  # team_rule, dq_stats, data_profile -> spread across Tier 2's top
    for x_src, lx in zip(xs[:3], tier2_landing):
        sx = x_src + bw / 2
        arrow(ax, (sx, srcA_bottom), (lx, ty + tier_h + tier_gap), color=GREEN, lw=1.6)
        flow_dots(ax, sx, srcA_bottom, lx, ty + tier_h + tier_gap, GREEN, n=1)
    sx4 = xs[3] + bw / 2
    arrow(ax, (sx4, srcA_bottom), (tier1_x + tier1_w / 2, ty + tier_h + tier_gap), color=ORANGE, lw=1.6)
    flow_dots(ax, sx4, srcA_bottom, tier1_x + tier1_w / 2, ty + tier_h + tier_gap, ORANGE, n=1)

    # ---- 8 Genie spaces (width trimmed to make room for the Lakehouse Monitoring future
    # box to its right -- see docs/05_LAKEHOUSE_MONITORING_ADOPTION.md) ----
    ax.text(0.35, 6.35, "8 GENIE SPACES", fontsize=13.6, color=PURPLE, fontweight="bold")
    gy = 4.85
    gh = 1.4
    gw = 11.35
    box(ax, 0.4, gy, gw, gh,
        "Rule Intelligence . Profiling Intelligence . DQ Execution Analytics . Schema Intelligence\n"
        "Freshness Intelligence . Volume Intelligence . Lineage & Impact Analysis . Governance Intelligence",
        fc=LIGHT_PURPLE, ec=PURPLE, fontsize=12.8, icon=icon_gear)
    arrow(ax, (tier1_x + tier1_w / 2, ty), (tier1_x + tier1_w / 2, gy + gh), color=ORANGE, lw=1.8)
    arrow(ax, (tier2_x + tier2_w / 2, ty), (tier2_x + tier2_w / 2, gy + gh), color=GREEN, lw=1.8)
    flow_dots(ax, tier1_x + tier1_w / 2, ty, tier1_x + tier1_w / 2, gy + gh, ORANGE, n=2)
    flow_dots(ax, tier2_x + tier2_w / 2, ty, tier2_x + tier2_w / 2, gy + gh, GREEN, n=2)

    # Lakehouse Monitoring -- future state, not active today (no Serverless compute in
    # this workspace yet). Dashed border = "not live" convention, matching diagram_6's
    # current-vs-future styling. Per docs/05: it will complement/extend Tier 1's automated
    # profiling once available, becoming Profiling Intelligence's preferred source. The
    # link into Profiling Intelligence specifically (not the Genie layer in general) is
    # made explicit three ways: a bold on-arrow label, a thicker/dotted connector aimed at
    # the box's first text line (where "Profiling Intelligence" sits), and the caption below.
    lhm_x, lhm_w = 0.4 + gw + 0.4, 2.5
    ax.text(lhm_x + lhm_w / 2, gy + gh + 0.22, "FUTURE", ha="center", fontsize=9.5,
            color=GREEN, fontweight="bold")
    box(ax, lhm_x, gy, lhm_w, gh, "Lakehouse\nMonitoring\n(needs Serverless)",
        fc=LIGHT_GREEN, ec=GREEN, fontsize=10.6, fontweight="bold", icon=icon_chart,
        icon_color=GREEN, dashed=True, accent=False)
    link_y = gy + gh * 0.66  # roughly the genie box's first text line, where "Profiling
    # Intelligence" appears, so the connector visibly aims at that phrase, not the box centroid
    arrow(ax, (lhm_x - 0.04, link_y), (0.4 + gw + 0.04, link_y), color=GREEN, lw=2.2,
          style="-|>", connectionstyle="arc3,rad=0.0")
    flow_dots(ax, lhm_x - 0.04, link_y, 0.4 + gw + 0.04, link_y, GREEN, n=2)
    # Centered in the narrow gap between the two boxes (not inside the LHM box itself,
    # which is where this used to land and overlapped its chart icon).
    gap_cx = (0.4 + gw + lhm_x) / 2
    ax.text(gap_cx, link_y + 0.22, "feeds", ha="center", fontsize=9,
            color=GREEN, fontweight="bold", style="italic",
            bbox=dict(facecolor="white", edgecolor="none", pad=1.5, alpha=0.9))
    ax.text(lhm_x + lhm_w / 2, gy - 0.12, "-> becomes Profiling Intelligence's\npreferred source", ha="center",
            va="top", fontsize=8.6, color=GREEN, fontweight="bold", style="italic")

    # ---- Agent ----
    ax.text(0.35, 4.55, "AGENT LAYER", fontsize=13.6, color=NAVY, fontweight="bold")
    ay = 3.15
    ah = 1.2
    box(ax, 3.7, ay, 8.0, ah,
        "DQ Agent -- Databricks-hosted Claude\nDCS Agent Studio . Sequential reasoning",
        fc=NAVY, ec=NAVY, fontsize=15.2, fontweight="bold", textcolor=WHITE, icon=icon_robot,
        icon_color=ORANGE, accent=False)
    # No add_sheen() here: its highlight band sits right where the icon is drawn (near
    # the box top), which read as the icon being visually "cut" -- a solid navy fill with
    # the orange icon and white text already has enough contrast without it.
    arrow(ax, (7.7, gy), (7.7, ay + ah), color=PURPLE, lw=2.0)
    flow_dots(ax, 7.7, gy, 7.7, ay + ah, PURPLE, n=2)

    # ---- Outputs ----
    ax.text(0.35, 2.85, "OUTPUTS", fontsize=13.6, color=BLUE, fontweight="bold")
    oy = 1.35
    oh = 1.35
    out_boxes = [
        ("Root Cause\nExplanation", icon_magnifier, LIGHT_BLUE, BLUE),
        ("Recommendations\n(SQL / YAML, human-review)", icon_screen, LIGHT_AMBER, AMBER),
        ("Data Quality\nScorecard", icon_chart, LIGHT_TEAL, TEAL),
        ("Daily Health\nSummary", icon_clock, LIGHT_GREEN, GREEN),
    ]
    ow = 3.5
    oxs = [0.4 + i * (ow + gap) for i in range(4)]
    # Arrows stop 0.08 short of each box's top edge -- ending exactly ON the edge let the
    # arrowhead marker visually poke into the box border, which read as an overlap.
    for x, (t, ic, fc, ec) in zip(oxs, out_boxes):
        box(ax, x, oy, ow, oh, t, fc=fc, ec=ec, fontsize=13.2, fontweight="bold", icon=ic)
        arrow(ax, (7.7, ay), (x + ow / 2, oy + oh + 0.08), color=NAVY, lw=1.4)

    box(ax, 0.4, 0.25, 14.6, 0.95,
        "Every claim traces to a real query result -- NOT_RUN is never reported as PASS, and nothing is fabricated.",
        fc=LIGHT_RED, ec=RED, fontsize=13.4, fontweight="bold", textcolor=RED, accent=False)

    fig.tight_layout()
    fig.savefig(os.path.join(OUT, "diagram_2_architecture.png"), dpi=175)
    plt.close(fig)


# ===========================================================================
# Diagram 3: Radial map of the 8 Genie spaces
# ===========================================================================
def diagram_3_genie_map():
    fig, ax = new_fig(15.0, 13.6)
    cx, cy = 7.5, 6.9
    ax.add_patch(Circle((cx, cy), 5.95, facecolor="#EEF2F8", edgecolor="none", zorder=0))
    ax.add_patch(Circle((cx, cy), 5.6, facecolor="#F6F8FB", edgecolor="none", zorder=0))
    ax.add_patch(Circle((cx, cy), 2.35, facecolor="#FFFFFF", edgecolor="#E3E7EE", lw=1.0, zorder=0.2))
    ax.text(cx, 13.05, "8 Specialized Genie Workspaces", ha="center", fontsize=23.3, fontweight="bold", color=NAVY)
    ax.text(cx, 12.55, "Each space is narrowly scoped -- a small fixed table list plus explicit guardrails",
            ha="center", fontsize=13.2, color=GRAY, style="italic")

    box(ax, cx - 1.55, cy - 0.62, 3.1, 1.24, "Data Quality\nAI Agent", fc=NAVY, ec=NAVY, fontsize=14.6,
        fontweight="bold", textcolor=WHITE, zorder=3, icon=icon_robot, icon_color=ORANGE, accent=False)

    # Colored by rollout-phase role (see docs/02_QUALITY_DIMENSIONS.md): GREEN = Phase 1
    # primary, ORANGE = Phase 2 (primary or corroborating), TEAL = cross-phase / mixed
    # (plays a role in both phases), PURPLE = cross-cutting governance (not phase-specific).
    # The dimension-mapping line under each name gives the precise per-dimension role;
    # the box color only encodes the coarse 4-category legend below.
    workspaces = [
        ("Rule\nIntelligence", "team_rule", icon_gear, TEAL,
         "Consistency (P2 primary)\nCompl/Valid/Uniq (P1 corrob)"),
        ("Profiling\nIntelligence", "data_profile", icon_chart, GREEN,
         "Compl/Valid/Uniqueness\n-- P1 primary"),
        ("DQ Execution\nAnalytics", "dq_stats + dqx_results", icon_screen, TEAL,
         "All 7 dimensions\n-- cross-phase corroborate"),
        ("Schema\nIntelligence", "information_schema + Delta history", icon_layers, ORANGE,
         "Schema Drift\n-- P2 primary"),
        ("Freshness\nIntelligence", "Delta history + job_run_timeline", icon_clock, ORANGE,
         "Timeliness\n-- P2 primary"),
        ("Volume\nIntelligence", "dq_stats + data_profile", icon_chart, ORANGE,
         "Volume\n-- P2 primary"),
        ("Lineage &\nImpact Analysis", "UC table / column lineage", icon_link, ORANGE,
         "Schema/Consist/Time/Volume\n-- P2 corroborate"),
        ("Governance\nIntelligence", "team_rule + system.access.audit", icon_shield, PURPLE,
         "Cross-cutting\n-- ownership & scorecards"),
    ]

    n = len(workspaces)
    r = 4.6
    w, h = 2.55, 1.15
    fc_map = {BLUE: LIGHT_BLUE, GREEN: LIGHT_GREEN, ORANGE: LIGHT_ORANGE, PURPLE: LIGHT_PURPLE, TEAL: LIGHT_TEAL}
    for i, (name, scope, ic, c, mapping) in enumerate(workspaces):
        angle = math.pi / 2 + 2 * math.pi * i / n
        x = cx + r * math.cos(angle)
        y = cy + r * math.sin(angle) * 0.92
        dx, dy = cx - x, cy - y
        dist = (dx ** 2 + dy ** 2) ** 0.5
        ux, uy = dx / dist, dy / dist
        fc = fc_map[c]
        arrow(ax, (x + ux * (w / 2), y + uy * (h / 2)), (cx - ux * 1.55, cy - uy * 0.62), color=GRAY, lw=1.3)
        flow_dots(ax, x + ux * (w / 2), y + uy * (h / 2), cx - ux * 1.55, cy - uy * 0.62, c, n=2)
        box(ax, x - w / 2, y - h / 2, w, h, name, fc=fc, ec=c, fontsize=12.6, fontweight="bold", icon=ic)
        ax.text(x, y - h / 2 - 0.24, scope, ha="center", va="top", fontsize=10.2, color=GRAY, style="italic")
        ax.text(x, y - h / 2 - 0.46, mapping, ha="center", va="top", fontsize=10, color=c, fontweight="bold")

    # Legend for the 4-category phase-role coloring, in the clear band below the circle.
    legend_items = [
        (GREEN, "Phase 1 primary"),
        (ORANGE, "Phase 2 (primary or corroborating)"),
        (TEAL, "Cross-phase / mixed"),
        (PURPLE, "Cross-cutting governance"),
    ]
    lx = 1.6
    ly = 0.62
    for lc, label in legend_items:
        ax.add_patch(Circle((lx, ly), 0.11, facecolor=lc, edgecolor="none", zorder=4))
        ax.text(lx + 0.24, ly, label, ha="left", va="center", fontsize=11, color="#111827")
        lx += 0.35 + len(label) * 0.093 + 0.5

    ax.text(cx, 0.18, "Primary data source shown beneath each workspace; bold colored line = dimension(s) it maps to",
            ha="center", fontsize=10.8, color=GRAY, style="italic")

    fig.tight_layout()
    fig.savefig(os.path.join(OUT, "diagram_3_genie_map.png"), dpi=175)
    plt.close(fig)


# ===========================================================================
# Diagram 4: Quality dimension coverage matrix
# ===========================================================================
def diagram_4_dimension_matrix():
    # Corroborating-space column added per docs/02_QUALITY_DIMENSIONS.md (5th column) --
    # abbreviated ("Exec Analytics", "Intel") only where a cell needs 3 space names, so
    # everything still wraps to at most 2 lines like the other columns.
    rows = [
        ("Completeness", icon_layers,
         "DQX is_not_null (Tier 1)\n+ team_rule rules (Tier 2)",
         "Profiling Intelligence",
         "DQ Execution Analytics,\nRule Intelligence",
         "Phase 1", 1),
        ("Validity", icon_shield,
         "DQX regex / range (Tier 1)\n+ team_rule rules (Tier 2)",
         "Profiling Intelligence",
         "Rule Intelligence,\nDQ Execution Analytics",
         "Phase 1", 1),
        ("Uniqueness", icon_gear,
         "DQX PK / uniqueness (Tier 1)\n+ team_rule rules (Tier 2)",
         "Profiling Intelligence",
         "DQ Exec Analytics, Rule Intel,\nLineage & Impact Analysis",
         "Phase 1", 1),
        ("Consistency", icon_link,
         "team_rule cross-table rules (Tier 2)\n+ DQX dataset comparison (Tier 1, structural)",
         "Rule Intelligence",
         "Lineage & Impact, Freshness\nIntel, Profiling Intel",
         "Phase 2", 2),
        ("Timeliness", icon_clock,
         "DQX freshness checks (Tier 1)\n+ team_rule SLA rules (Tier 2)",
         "Freshness Intelligence",
         "DQ Exec Analytics, Volume\nIntel, Lineage & Impact",
         "Phase 2", 2),
        ("Volume", icon_chart,
         "dq_stats / data_profile counts\n+ DQX volume checks (Tier 1)",
         "Volume Intelligence",
         "DQ Exec Analytics, Schema\nIntel, Lineage & Impact",
         "Phase 2", 2),
        ("Schema Drift", icon_layers,
         "information_schema + Delta history\n(native) + DQX schema/ODCS (Tier 1)",
         "Schema Intelligence",
         "Lineage & Impact, DQ Exec\nAnalytics, Profiling Intel",
         "Phase 2", 2),
    ]

    fig, ax = new_fig(14.6, 14.5)
    ax.text(7.3, 14.1, "Quality Dimension Coverage Matrix", ha="center", fontsize=23.9, fontweight="bold", color=BLUE)
    ax.text(7.3, 13.65, "7 dimensions x Detection Tier x Primary + Corroborating Genie Space x Rollout Phase",
            ha="center", fontsize=13.5, color=GRAY, style="italic")

    left, top = 0.35, 12.5
    dim_w = 1.9
    col_w = [4.3, 2.6, 1.5, 3.2]
    total_w = dim_w + sum(col_w)
    row_h = 1.45
    divider_h = 0.62
    gap = 0.06

    x = left
    box(ax, x, top, dim_w, 1.0, "Dimension", fc=NAVY, ec=NAVY, textcolor=WHITE, fontweight="bold", fontsize=13.5, accent=False)
    add_sheen(ax, x, top, dim_w, 1.0)
    x += dim_w
    for c, w in zip(["Detection Tier", "Primary Genie\nSpace", "Rollout\nPhase", "Corroborating Genie\nSpace(s)"], col_w):
        box(ax, x, top, w, 1.0, c, fc=NAVY, ec=NAVY, textcolor=WHITE, fontweight="bold", fontsize=12.6, accent=False)
        add_sheen(ax, x, top, w, 1.0)
        x += w

    y_top = top - 0.15
    current_phase = None
    for name, ic, det, space, corrob, phase_label, phase in rows:
        if phase != current_phase:
            d_bottom = y_top - divider_h
            if phase == 1:
                label = "PHASE 1 -- SHIP FIRST   (pure rule-execution + DQX built-ins, no new infrastructure)"
                fc_div, ec_div, tc_div = "#DCEFE2", GREEN, "#1E5C38"
            else:
                label = "PHASE 2 -- NEXT   (cross-table correlation / baselines / schema-history depth)"
                fc_div, ec_div, tc_div = LIGHT_ORANGE, ORANGE, "#7A3B0E"
            box(ax, left, d_bottom, total_w, divider_h, label, fc=fc_div, ec=ec_div, textcolor=tc_div,
                fontweight="bold", fontsize=13, accent=False)
            add_sheen(ax, left, d_bottom, total_w, divider_h)
            y_top = d_bottom - gap
            current_phase = phase

        row_bottom = y_top - row_h
        cell_fc = "#EEF6F0" if phase == 1 else "#FDF3E9"
        dim_fc, dim_ec = (LIGHT_GREEN, GREEN) if phase == 1 else (LIGHT_ORANGE, ORANGE)
        x = left
        box(ax, x, row_bottom, dim_w, row_h - 0.1, name, fc=dim_fc, ec=dim_ec, fontsize=13.2, fontweight="bold", icon=ic)
        x += dim_w
        box(ax, x, row_bottom, col_w[0], row_h - 0.1, det, fc=cell_fc, ec="#C7CDD6", fontsize=11, accent=False)
        x += col_w[0]
        box(ax, x, row_bottom, col_w[1], row_h - 0.1, space, fc=cell_fc, ec="#C7CDD6", fontsize=11.5, accent=False)
        x += col_w[1]
        box(ax, x, row_bottom, col_w[2], row_h - 0.1, phase_label, fc=cell_fc, ec="#C7CDD6", fontsize=12.1,
            fontweight="bold", accent=False)
        x += col_w[2]
        box(ax, x, row_bottom, col_w[3], row_h - 0.1, corrob, fc=cell_fc, ec="#C7CDD6", fontsize=10.6, accent=False)

        y_top = row_bottom - gap

    fig.tight_layout()
    fig.savefig(os.path.join(OUT, "diagram_4_dimension_matrix.png"), dpi=175)
    plt.close(fig)


# ===========================================================================
# Diagram 5: DQX zero-copy integration pattern (the leadership diagram)
# ===========================================================================
def diagram_5_dqx_zero_copy():
    fig, ax = new_fig(15.6, 8.3)
    ax.text(8.3, 7.85, "DQX Zero-Copy, Zero-Pipeline-Change Integration", ha="center",
            fontsize=20.7, fontweight="bold", color=GREEN)
    ax.text(8.3, 7.42, "One central, DQ-owned job reads other teams' existing tables read-only -- it never writes back",
            ha="center", fontsize=13.1, color=GRAY, style="italic")

    # Team tables around the top, arrows pointing DOWN into the central job (read direction)
    teams = ["Sales\norders", "Payments\ntransactions", "Risk\nexposures", "Marketing\ncampaigns", "Finance\nrevenue_by_region"]
    n = len(teams)
    tw, th = 2.15, 0.95
    total_span = 13.6
    # Shifted right (vs. a naive centered layout) to leave a dedicated clear margin on the
    # left for the "NEVER writes back" callout -- the leftmost table's diagonal read-arrow
    # (and its "SELECT-only grant" label) starts at tx_start + tw/2 and only moves further
    # right/down from there, so nothing left of tx_start is ever crossed by that arrow.
    tx_start = 1.5
    txs = [tx_start + i * (total_span - tw) / (n - 1) for i in range(n)]
    ty = 6.05  # bottom of the team-table row
    team_tints = [(LIGHT_GRAY, GRAY), (LIGHT_SLATE, SLATE)]
    for i, (x, t) in enumerate(zip(txs, teams)):
        tfc, tec = team_tints[i % 2]
        box(ax, x, ty, tw, th, t, fc=tfc, ec=tec, fontsize=10.8, icon=icon_database)
        ax.text(x + tw / 2, ty - 0.26, "SELECT-only grant", ha="center", fontsize=10, color=GREEN, style="italic",
                 fontweight="bold")

    # Central job cluster
    jx, jy, jw, jh = 6.4, 3.05, 3.8, 1.55
    box(ax, jx, jy, jw, jh, "Central DQ Job\n(standard job cluster --\nno serverless required)",
        fc=NAVY, ec=NAVY, fontsize=13.2, fontweight="bold", textcolor=WHITE, icon=icon_gear,
        icon_color=ORANGE, accent=False)
    add_sheen(ax, jx, jy, jw, jh)

    # Read arrows: FROM each team table TO the central job (arrowhead at the job = read direction)
    jcx, jcy = jx + jw / 2, jy + jh
    for x in txs:
        arrow(ax, (x + tw / 2, ty), (jcx + (x + tw / 2 - jcx) * 0.12, jcy + 0.02), color=GREEN, lw=1.8)
        flow_dots(ax, x + tw / 2, ty, jcx + (x + tw / 2 - jcx) * 0.12, jcy + 0.02, GREEN, n=2)
    ax.text(jx + jw * 0.32, jcy + 0.28, "READ ONLY --\nno copy made", ha="center",
            fontsize=11, color=GREEN, fontweight="bold")

    # Prohibited reverse arrow (crossed out) — explicit "no write-back", drawn in the dedicated
    # left margin (x < tx_start = 1.5) that no table arrow, table label, or the rule-registry
    # box ever reaches, so it never collides with the "SELECT-only grant" labels above it.
    no_cx, no_cy = 0.7, 5.3
    # Entry point is the circle's upper-right edge (well above the "NEVER writes back to
    # source" caption beneath the circle) with a shallow arc, so the dashed line curves in
    # from above and never crosses the caption text.
    ax.annotate("", xy=(no_cx + 0.4, no_cy + 0.1), xytext=(jx + 0.15, jy + jh * 0.92),
                arrowprops=dict(arrowstyle="-|>", color=RED, lw=1.7, linestyle="--",
                                connectionstyle="arc3,rad=0.22"))
    ax.add_patch(Circle((no_cx, no_cy), 0.4, facecolor="white", edgecolor=RED, lw=2.2, zorder=6))
    icon_cross(ax, no_cx, no_cy, 0.25, RED)
    ax.text(no_cx, no_cy - 0.95, "NEVER writes\nback to source", ha="center", va="top", fontsize=11, color=RED,
            fontweight="bold")

    # Write arrow: central job -> dqx_results (DQ-owned)
    rx, ry, rw, rh = 10.9, 3.05, 3.4, 1.55
    box(ax, rx, ry, rw, rh, "dqx_results\n(DQ-team-owned schema)", fc=LIGHT_ORANGE, ec=ORANGE,
        fontsize=12.4, fontweight="bold", icon=icon_database)
    arrow(ax, (jx + jw, jy + jh / 2), (rx, ry + rh / 2), color=ORANGE, lw=2.3)
    flow_dots(ax, jx + jw, jy + jh / 2, rx, ry + rh / 2, ORANGE, n=2)
    ax.text((jx + jw + rx) / 2, ry + rh + 0.24, "WRITES ONLY HERE", ha="center", fontsize=11.5,
            color=ORANGE, fontweight="bold")

    # Rule registry feeding the job (wildcard run-configs) -- a governed Delta table
    # (dq_catalog.dq_config.dqx_rule_registry, see dqx/rule_registry_ddl.sql), not a config
    # file, so it gets the same database-cylinder icon used for the source tables above.
    reg_x, reg_y, reg_w, reg_h = 1.5, 3.05, 3.6, 1.55
    box(ax, reg_x, reg_y, reg_w, reg_h, "Delta table:\ndqx_rule_registry\n(wildcard run-configs)",
        fc=LIGHT_BLUE, ec=BLUE, fontsize=11.5, icon=icon_database)
    arrow(ax, (reg_x + reg_w, reg_y + reg_h / 2), (jx, jy + jh / 2), color=BLUE, lw=2.0)

    # The unambiguous callout — most important line in the deck
    box(ax, 1.5, 1.05, 13.6, 1.6,
        "NO writes back to source tables    .    NO changes to any other team's pipeline code    .    NO data copy\n\n"
        "Onboarding a new team = one SELECT grant (+ one registry line). Nothing else changes.",
        fc=LIGHT_RED, ec=RED, fontsize=14, fontweight="bold", textcolor=RED, accent=False)

    fig.tight_layout()
    fig.savefig(os.path.join(OUT, "diagram_5_dqx_zero_copy.png"), dpi=175)
    plt.close(fig)


# ===========================================================================
# Diagram 6: Lakehouse Monitoring roadmap — current vs future state
# ===========================================================================
def diagram_6_lhm_roadmap():
    # Taller figure than a naive layout would need -- the card rows below use a bigger box
    # height (1.45 vs. the icon-colliding 0.85 this replaced) so the icon (fixed ~0.3 from
    # the box top) and the 2-line wrapped text (centered at box mid-height) have enough
    # vertical separation. Compare diagram_1_problem_statement's cards, which give the
    # icon circle its own clear band above the title/desc text -- same principle here.
    fig, ax = new_fig(13.8, 11.8)
    ax.add_patch(Rectangle((0.25, 0.3), 6.1, 9.8, facecolor="#F4F5F7", edgecolor="none", zorder=0))
    ax.add_patch(Rectangle((7.15, 0.3), 6.1, 9.8, facecolor="#F1F8F3", edgecolor="none", zorder=0))
    ax.text(6.9, 11.4, "Lakehouse Monitoring: Current State vs. Future State", ha="center",
            fontsize=20.7, fontweight="bold", color=BLUE)
    ax.text(6.9, 10.95, "Deferred for one concrete reason: no Serverless compute available yet -- not a judgment on its value",
            ha="center", fontsize=12.2, color=GRAY, style="italic")

    box(ax, 0.4, 9.85, 5.8, 0.8, "TODAY -- no Serverless compute", fc=SLATE, ec=SLATE, textcolor=WHITE,
        fontweight="bold", fontsize=13, accent=False)
    add_sheen(ax, 0.4, 9.85, 5.8, 0.8)
    cur = [("DQX Tier-1 sweep + custom\ndata_profile / Genie-assisted SQL", icon_database),
           ("No native drift dashboards --\nhand-assembled from data_profile/DQX", icon_chart),
           ("No managed profile-metrics /\ndrift-metrics tables", icon_layers),
           ("Manual refresh jobs owned and\noperated by the DQ platform team", icon_gear)]
    y = 9.25
    for c, ic in cur:
        box(ax, 0.4, y - 1.45, 5.8, 1.45, c, fc=LIGHT_GRAY, ec=GRAY, fontsize=11.5, icon=ic)
        y -= 1.6

    box(ax, 7.3, 9.85, 5.8, 0.8, "FUTURE -- Serverless available", fc=GREEN, ec=GREEN, textcolor=WHITE,
        fontweight="bold", fontsize=13, accent=False)
    add_sheen(ax, 7.3, 9.85, 5.8, 0.8)
    fut = [("CREATE MONITOR per table --\nno custom registry to maintain", icon_database),
           ("Native profile-metrics / drift-metrics\ntables, platform-computed", icon_chart),
           ("Auto-generated drift dashboards,\nstatistical distribution drift", icon_shield),
           ("Managed refresh scheduling --\nbecomes preferred profiling source", icon_clock)]
    y = 9.25
    for c, ic in fut:
        box(ax, 7.3, y - 1.45, 5.8, 1.45, c, fc=LIGHT_GREEN, ec=GREEN, fontsize=11.5, icon=ic)
        y -= 1.6

    # y is now 9.25 - 4*1.6 = 2.85, i.e. the bottom of the last content row is at 3.00,
    # comfortably above the phase-progression box below (top edge at 2.70).
    # Widened to match the disclaimer box below (13.0, same x=0.4) and shortened/reduced in
    # size -- the original single-line text at width 9.2/fontsize 12 was wider than the box
    # itself, so "Phase 1" and "...Source" rendered past the box's left/right border.
    box(ax, 0.4, 1.85, 13.0, 0.85,
        "Phase 1 Now -> Phase 2 Pilot -> Phase 3 Table-by-Table Cutover -> Phase 4 LHM Preferred Source",
        fc=LIGHT_BLUE, ec=BLUE, fontsize=11.5, fontweight="bold")

    box(ax, 0.4, 0.4, 13.0, 0.95,
        "DQX's inline validation/quarantine layer is untouched by this migration -- only the profiling\n"
        "responsibility shifts, table-by-table, once parity is confirmed.",
        fc=LIGHT_ORANGE, ec=ORANGE, fontsize=11.3, textcolor="#7A3B0E", accent=False)

    fig.tight_layout()
    fig.savefig(os.path.join(OUT, "diagram_6_lhm_roadmap.png"), dpi=175)
    plt.close(fig)


# ===========================================================================
# Diagram 7: Mapping the reference design pattern onto this stack
# ===========================================================================
def diagram_7_snapshot_pattern_mapping():
    fig, ax = new_fig(14.4, 11.6)
    ax.text(7.2, 11.15, "Mapping the Reference Design Pattern to This Stack", ha="center",
            fontsize=20.7, fontweight="bold", color=NAVY)
    ax.text(7.2, 10.68, "Same investigative pattern -- collapsed onto native Databricks capabilities instead of custom orchestration",
            ha="center", fontsize=12.6, color=GRAY, style="italic")

    left_x, right_x, col_w = 0.5, 7.4, 6.5
    box(ax, left_x, 9.55, col_w, 0.75, "Reference Article's Pattern", fc=GRAY, ec=GRAY, textcolor=WHITE,
        fontweight="bold", fontsize=14, accent=False)
    add_sheen(ax, left_x, 9.55, col_w, 0.75)
    box(ax, right_x, 9.55, col_w, 0.75, "This Design", fc=NAVY, ec=NAVY, textcolor=WHITE,
        fontweight="bold", fontsize=14, accent=False)
    add_sheen(ax, right_x, 9.55, col_w, 0.75)

    left_items = [
        ("ADLS ingestion layer", icon_database),
        ("Collibra metadata catalog", icon_book),
        ("5 custom rule-generator / aggregator /\ncode-generator agents", icon_robot),
        ("\"Data Fixer Tool\" (auto intrinsic /\nextrinsic fixes)", icon_gear),
        ("Delta tables + dashboards", icon_chart),
    ]
    right_items = [
        ("Unity Catalog Delta tables\n(already the system of record)", icon_database),
        ("information_schema + Delta history\n(native, no external catalog)", icon_book),
        ("1 DQ Agent + 8 Genie spaces\n(one synthesis pass, one precedence rule)", icon_robot),
        ("Recommendation-only remediation --\nSQL/YAML proposal, human-applied", icon_shield),
        ("team_rule / dq_stats / data_profile /\ndqx_results + scorecard", icon_chart),
    ]

    iy = 8.85
    ih, igap = 1.15, 0.15
    for (lt, lic), (rt, ric) in zip(left_items, right_items):
        box(ax, left_x, iy - ih, col_w, ih, lt, fc=LIGHT_GRAY, ec=GRAY, fontsize=11.5, icon=lic)
        box(ax, right_x, iy - ih, col_w, ih, rt, fc=LIGHT_GREEN, ec=GREEN, fontsize=11.5, icon=ric)
        arrow(ax, (left_x + col_w + 0.05, iy - ih / 2), (right_x - 0.05, iy - ih / 2), color=BLUE, lw=1.6)
        iy -= (ih + igap)

    # iy now sits just below the last item row (with one igap of extra clearance already
    # subtracted) -- add a further gap before the verdict box so they never overlap.
    verdict_top = iy - 0.15
    verdict_h = 1.3
    box(ax, 0.5, verdict_top - verdict_h, 13.4, verdict_h,
        "Verdict: the pattern is preserved, not discarded -- multi-stage rule generation, cross-source\n"
        "aggregation, translation into executable checks, and fix suggestion all still happen. They collapse\n"
        "onto native UC/DQX/Genie capabilities instead of 5+ bespoke agents and 2 external systems.",
        fc=LIGHT_BLUE, ec=BLUE, fontsize=12.6, fontweight="bold", textcolor=NAVY, accent=False)

    fig.tight_layout()
    fig.savefig(os.path.join(OUT, "diagram_7_snapshot_pattern_mapping.png"), dpi=175)
    plt.close(fig)


if __name__ == "__main__":
    diagram_1_problem_statement()
    diagram_2_architecture()
    diagram_3_genie_map()
    diagram_4_dimension_matrix()
    diagram_5_dqx_zero_copy()
    diagram_6_lhm_roadmap()
    diagram_7_snapshot_pattern_mapping()
    print("Diagrams written to", OUT)
