"""
Builds DQ_Agent_Enterprise_Leadership_Architecture.docx from the diagrams in
this folder plus narrative content summarizing docs/00-08, CONTEXT_BRIEF.md,
agent_studio/*, and dqx/* in this project (DCS-DataQuality-Agent).
Run after build_diagrams.py. Requires: python-docx.
"""
import os
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "DQ_Agent_Enterprise_Leadership_Architecture.docx")

NAVY = RGBColor(0x1F, 0x35, 0x57)
ORANGE = RGBColor(0xE8, 0x79, 0x2B)
GRAY = RGBColor(0x4B, 0x55, 0x63)
DARK = RGBColor(0x11, 0x18, 0x27)

# Extended palette -- mirrors the phase-color legend used in the diagrams (build_diagrams.py)
# so the document text and the embedded figures read as one visually consistent system:
#   GREEN = Phase 1 / positive-guarantee, ORANGE = Phase 2 / cost-risk, TEAL = cross-phase,
#   PURPLE = governance / cross-cutting, RED = risk / non-negotiable, BLUE = informational.
BLUE = RGBColor(0x2E, 0x6F, 0xB5)
GREEN = RGBColor(0x3E, 0x8E, 0x5A)
TEAL = RGBColor(0x0E, 0x7C, 0x86)
PURPLE = RGBColor(0x6B, 0x4C, 0x93)
RED = RGBColor(0xC0, 0x39, 0x2B)
AMBER = RGBColor(0xB8, 0x86, 0x0B)

# Light fills paired with the accents above, for callouts / shading / cell backgrounds.
LIGHT_NAVY = "DCE3EC"
LIGHT_ORANGE = "FBE6D4"
LIGHT_GRAY = "EDEFF2"
LIGHT_BLUE = "DCE8F5"
LIGHT_GREEN = "DCEFE2"
LIGHT_TEAL = "D9EEF0"
LIGHT_PURPLE = "E9E1F2"
LIGHT_RED = "FBE4E1"
LIGHT_AMBER = "F7ECD1"


def set_cell_shading(cell, hex_color):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hex_color)
    tcPr.append(shd)


def add_title_page(doc):
    doc.add_paragraph().paragraph_format.space_before = Pt(60)

    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(14)
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r0 = p.add_run("Data Quality ")
    r0.font.size = Pt(34)
    r0.font.bold = True
    r0.font.color.rgb = NAVY
    r1 = p.add_run("AI Agent")
    r1.font.size = Pt(34)
    r1.font.bold = True
    r1.font.color.rgb = ORANGE
    r2 = p.add_run(" \U0001F916")
    r2.font.size = Pt(30)

    p2 = doc.add_paragraph()
    p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r2 = p2.add_run("DCS Agent Studio")
    r2.font.size = Pt(18)
    r2.font.color.rgb = ORANGE

    p3 = doc.add_paragraph()
    p3.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p3.paragraph_format.space_before = Pt(20)
    r3 = p3.add_run("Enterprise Leadership Architecture Overview")
    r3.font.size = Pt(13)
    r3.font.italic = True
    r3.font.color.rgb = GRAY

    p4 = doc.add_paragraph()
    p4.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p4.paragraph_format.space_before = Pt(8)
    r4 = p4.add_run(
        "A metadata-driven, two-tier investigative agent for hundreds of data products "
        "and thousands of pipelines on Databricks Lakehouse / Unity Catalog")
    r4.font.size = Pt(10.5)
    r4.font.italic = True
    r4.font.color.rgb = GRAY
    doc.add_page_break()


def _set_paragraph_bottom_border(paragraph, hex_color, sz="18"):
    pPr = paragraph._p.get_or_add_pPr()
    pBdr = OxmlElement("w:pBdr")
    bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single")
    bottom.set(qn("w:sz"), sz)
    bottom.set(qn("w:space"), "4")
    bottom.set(qn("w:color"), hex_color)
    pBdr.append(bottom)
    pPr.append(pBdr)


def _rgb_to_hex(rgb):
    return "%02X%02X%02X" % (rgb[0], rgb[1], rgb[2])


def add_heading(doc, text, level=1, color=NAVY):
    """H1: bold colored text sized up, with a themed colored rule underneath, giving
    each section its own visual identity (e.g. DQX section in green, Governance in
    purple) instead of every heading looking identical. H2: same theme color, smaller,
    with a short colored tick mark so subsections (e.g. each Genie workspace) visually
    inherit the color used for that workspace in diagram_3's legend."""
    h = doc.add_heading("", level=level)
    hex_color = _rgb_to_hex(color)
    if level == 1:
        r = h.add_run(text)
        r.font.size = Pt(20)
        r.font.bold = True
        r.font.color.rgb = color
        _set_paragraph_bottom_border(h, hex_color, sz="20")
        h.paragraph_format.space_after = Pt(10)
    else:
        tick = h.add_run("❙ ")
        tick.font.size = Pt(14)
        tick.font.bold = True
        tick.font.color.rgb = color
        r = h.add_run(text)
        r.font.size = Pt(14)
        r.font.bold = True
        r.font.color.rgb = color
        h.paragraph_format.space_before = Pt(10)
        h.paragraph_format.space_after = Pt(4)
    return h


def add_body(doc, text, size=11, italic=False, bold=False, color=DARK):
    p = doc.add_paragraph()
    r = p.add_run(text)
    r.font.size = Pt(size)
    r.italic = italic
    r.bold = bold
    r.font.color.rgb = color
    return p


def add_bullets(doc, items):
    for item in items:
        p = doc.add_paragraph(style="List Bullet")
        r = p.add_run(item)
        r.font.size = Pt(11)


def add_rich(doc, parts, size=11, space_after=None):
    """Body paragraph built from (text, {bold, italic, color, size}) segments, so a
    single sentence can bold a key term/number or color an aside inline instead of
    every paragraph being one flat run. Example:
        add_rich(doc, [("The agent reasons across ", {}),
                        ("eight", {"bold": True, "color": PURPLE}),
                        (" purpose-scoped Genie spaces.", {})])
    """
    p = doc.add_paragraph()
    if space_after is not None:
        p.paragraph_format.space_after = Pt(space_after)
    for text, kwargs in parts:
        r = p.add_run(text)
        r.font.size = Pt(kwargs.get("size", size))
        r.bold = kwargs.get("bold", False)
        r.italic = kwargs.get("italic", False)
        r.font.color.rgb = kwargs.get("color", DARK)
    return p


def add_stat_row(doc, stats):
    """A row of leadership-skim-read 'stat tiles' -- a big colored number over a small
    gray label, e.g. 8 / Genie Spaces, 20 / Eval Cases. Rendered as a native docx table
    (auto-sized cells, no absolute positioning), so it cannot introduce an overlap.
    stats: list of (number_str, label_str, color) tuples."""
    table = doc.add_table(rows=2, cols=len(stats))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, (num, label, color) in enumerate(stats):
        num_cell = table.rows[0].cells[i]
        set_cell_shading(num_cell, "F7F8FA")
        np_ = num_cell.paragraphs[0]
        np_.alignment = WD_ALIGN_PARAGRAPH.CENTER
        np_.paragraph_format.space_before = Pt(6)
        np_.paragraph_format.space_after = Pt(0)
        nr = np_.add_run(num)
        nr.bold = True
        nr.font.size = Pt(22)
        nr.font.color.rgb = color

        lbl_cell = table.rows[1].cells[i]
        set_cell_shading(lbl_cell, "F7F8FA")
        lp = lbl_cell.paragraphs[0]
        lp.alignment = WD_ALIGN_PARAGRAPH.CENTER
        lp.paragraph_format.space_after = Pt(8)
        lr = lp.add_run(label.upper())
        lr.bold = True
        lr.font.size = Pt(8.5)
        lr.font.color.rgb = GRAY
    doc.add_paragraph()
    return table


def add_image(doc, filename, width_in=6.4, caption=None):
    doc.add_picture(os.path.join(HERE, filename), width=Inches(width_in))
    doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
    if caption:
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = p.add_run(caption)
        r.font.size = Pt(10)
        r.italic = True
        r.font.color.rgb = GRAY


def add_table(doc, headers, rows, col_widths=None, header_fill="1F3557"):
    table = doc.add_table(rows=1, cols=len(headers))
    table.style = "Table Grid"
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    hdr_cells = table.rows[0].cells
    for i, h in enumerate(headers):
        hdr_cells[i].text = ""
        p = hdr_cells[i].paragraphs[0]
        r = p.add_run(h)
        r.bold = True
        r.font.size = Pt(11)
        r.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
        set_cell_shading(hdr_cells[i], header_fill)
    for row_i, row in enumerate(rows):
        cells = table.add_row().cells
        for i, val in enumerate(row):
            cells[i].text = ""
            p = cells[i].paragraphs[0]
            r = p.add_run(str(val))
            r.font.size = Pt(10.3)
            if row_i % 2 == 0:
                set_cell_shading(cells[i], LIGHT_BLUE)
    if col_widths:
        for row in table.rows:
            for i, w in enumerate(col_widths):
                row.cells[i].width = Inches(w)
    doc.add_paragraph()
    return table


def _set_cell_borders(cell, **edges):
    tcPr = cell._tc.get_or_add_tcPr()
    borders = OxmlElement("w:tcBorders")
    for edge, color in edges.items():
        el = OxmlElement(f"w:{edge}")
        el.set(qn("w:val"), "single")
        el.set(qn("w:sz"), "20")
        el.set(qn("w:color"), color)
        borders.append(el)
    tcPr.append(borders)


def add_toc_table(doc, items):
    """items: list of (number_str, title, description, accent_color) tuples. accent_color
    (an RGBColor) mirrors the color that section's own heading uses (add_heading's
    `color=`), so the Contents page previews each section's visual theme."""
    table = doc.add_table(rows=0, cols=2)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    badge_w, text_w = 0.62, 5.98
    for i, (num, title, desc, accent) in enumerate(items):
        accent_hex = _rgb_to_hex(accent)
        row = table.add_row()
        row.height = Inches(0.56)
        badge, text = row.cells
        badge.width = Inches(badge_w)
        text.width = Inches(text_w)

        row_fill = "F4F6FA" if i % 2 == 0 else "FFFFFF"
        set_cell_shading(badge, accent_hex)
        set_cell_shading(text, row_fill)
        _set_cell_borders(text, left=accent_hex)

        badge.vertical_alignment = 1
        bp = badge.paragraphs[0]
        bp.alignment = WD_ALIGN_PARAGRAPH.CENTER
        br = bp.add_run(num)
        br.bold = True
        br.font.size = Pt(12.5)
        br.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)

        text.vertical_alignment = 1
        tp = text.paragraphs[0]
        tp.paragraph_format.space_before = Pt(3)
        tp.paragraph_format.space_after = Pt(0)
        tp.paragraph_format.left_indent = Pt(10)
        tr = tp.add_run(title)
        tr.bold = True
        tr.font.size = Pt(12)
        tr.font.color.rgb = accent
        dp = text.add_paragraph()
        dp.paragraph_format.space_after = Pt(4)
        dp.paragraph_format.left_indent = Pt(10)
        dr = dp.add_run(desc)
        dr.italic = True
        dr.font.size = Pt(9.8)
        dr.font.color.rgb = GRAY
    doc.add_paragraph()
    return table


def add_labeled_line(doc, label, text, label_color=NAVY):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(4)
    r1 = p.add_run(label + "  ")
    r1.bold = True
    r1.font.size = Pt(11)
    r1.font.color.rgb = label_color
    r2 = p.add_run(text)
    r2.font.size = Pt(11)
    r2.font.color.rgb = DARK
    return p


def add_callout_box(doc, label, text, fill="FBE6D4", accent="E8792B", label_color=None, text_color=None):
    """A colored, left-accented callout. Fill/accent/label_color vary by callout type
    across the document (guarantee = green, risk/cost = amber/red, phase = its own
    theme color, cross-cutting = blue) so a reader can tell the category apart at a
    glance instead of every callout using the same orange."""
    label_color = label_color or RGBColor(0xE8, 0x79, 0x2B)
    text_color = text_color or RGBColor(0x4A, 0x3A, 0x20)
    table = doc.add_table(rows=1, cols=1)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = table.rows[0].cells[0]
    set_cell_shading(cell, fill)
    tcPr = cell._tc.get_or_add_tcPr()
    borders = OxmlElement("w:tcBorders")
    for edge in ("left",):
        el = OxmlElement(f"w:{edge}")
        el.set(qn("w:val"), "single")
        el.set(qn("w:sz"), "28")
        el.set(qn("w:color"), accent)
        borders.append(el)
    tcPr.append(borders)
    cell.text = ""
    p = cell.paragraphs[0]
    p.paragraph_format.space_before = Pt(7)
    p.paragraph_format.space_after = Pt(7)
    r = p.add_run(label + "  ")
    r.bold = True
    r.italic = True
    r.font.size = Pt(10)
    r.font.color.rgb = label_color
    r2 = p.add_run(text)
    r2.italic = True
    r2.font.size = Pt(10)
    r2.font.color.rgb = text_color
    doc.add_paragraph().paragraph_format.space_after = Pt(2)
    return table


# ---------------------------------------------------------------------------
# Condensed Genie workspace content (purpose + sources + 2-3 sample questions
# only -- the full instructions/context/guardrails specs live in
# docs/03_GENIE_WORKSPACES.md and are intentionally NOT reproduced here).
# ---------------------------------------------------------------------------
GENIE_WORKSPACES = [
    {
        "name": "Rule Intelligence",
        "purpose": "What a business rule does, why it exists, who owns it, and whether it's currently active -- the rule catalog and its lifecycle. Never answers pass/fail (that's DQ Execution Analytics).",
        "sources": "team_rule (Tier 2) -- the only table in this space.",
        "questions": [
            "What does the customer_email_not_null rule check and why does it exist?",
            "Which rules does the Payments team have registered against prod.payments.transactions?",
            "Is the duplicate-order rule on orders currently active?",
        ],
    },
    {
        "name": "Profiling Intelligence",
        "purpose": "What a column actually looks like -- null rate, distinct count, min/max, distribution shape, cardinality -- as of a specific profiling snapshot. Describes shape, not pass/fail.",
        "sources": "data_profile (Tier 2) -- the only table in this space.",
        "questions": [
            "What's the null rate and distinct count for customer_id as profiled by the Sales team?",
            "Show me the distribution summary for the transaction_amount column.",
            "Which columns of prod.payments.transactions has the Payments team actually profiled?",
        ],
    },
    {
        "name": "DQ Execution Analytics",
        "purpose": "The primary \"why did quality degrade\" surface -- rule pass/fail/no-result outcomes and trends. The one space that presents both tiers together and always labels which tier answered.",
        "sources": "dq_stats (Tier 2) + dqx_results (Tier 1, same column shape).",
        "questions": [
            "Why did data quality drop for prod.sales.orders yesterday?",
            "Did the uniqueness rule on customer_id run today, and what was the result?",
            "What DQX Tier-1 checks exist for prod.marketing.campaigns, and has the team added Tier 2 rules?",
        ],
    },
    {
        "name": "Schema Intelligence",
        "purpose": "What changed in a table's schema, and when -- using Unity Catalog's native metadata and Delta's transaction log. No custom snapshot table exists or is queried.",
        "sources": "information_schema.columns/.tables + DESCRIBE HISTORY / Delta Time Travel.",
        "questions": [
            "Has the schema of prod.sales.orders changed in the last 2 weeks?",
            "When was the discount_pct column added, and who ran the operation?",
            "Did any column go from NOT NULL to nullable recently?",
        ],
    },
    {
        "name": "Freshness Intelligence",
        "purpose": "Is this data late, and how fresh is it -- combining Delta commit history (ground truth for last write) with job-run telemetry (did the producing job run and succeed).",
        "sources": "DESCRIBE HISTORY + system.lakeflow.job_run_timeline.",
        "questions": [
            "When was prod.sales.orders last written to, and by what kind of operation?",
            "Did the job that loads prod.payments.transactions run successfully last night?",
            "How many hours since the last commit to prod.marketing.campaigns?",
        ],
    },
    {
        "name": "Volume Intelligence",
        "purpose": "Did the row count do something unexpected -- volume anomaly detection with explicit seasonality awareness before any anomaly is declared.",
        "sources": "dq_stats.input_record_count + data_profile.row_count_at_profile_time.",
        "questions": [
            "Has the row count for prod.sales.orders dropped compared to the last 4 weeks?",
            "Is the volume dip on prod.marketing.campaigns this Monday normal or unusual?",
            "Show me the input_record_count trend for the last 30 execution days.",
        ],
    },
    {
        "name": "Lineage & Impact Analysis",
        "purpose": "What's upstream/downstream of a table, and the blast radius if it breaks -- cross-referenced against Tier 2 coverage to flag governance gaps on downstream tables.",
        "sources": "system.access.table_lineage / column_lineage + team_rule/dq_stats (read-only cross-reference).",
        "questions": [
            "What tables feed into prod.sales.orders?",
            "If prod.risk.exposures breaks, what downstream tables and columns are affected?",
            "Which downstream consumers of prod.payments.transactions have zero Tier 2 rule coverage?",
        ],
    },
    {
        "name": "Governance Intelligence",
        "purpose": "Who owns this, is coverage complete, how healthy is this domain overall, and who changed what -- ownership, coverage-completeness, scorecards, and audit trail.",
        "sources": "team_rule (ownership/lifecycle fields) + system.access.audit.",
        "questions": [
            "Who owns the DQ rules registered against prod.risk.exposures?",
            "What percentage of tables in prod.sales have at least one active team_rule registered?",
            "Show me the audit trail of grant changes on prod.payments.transactions in the last 30 days.",
        ],
    },
]


doc = Document()

# Page size / margins
section = doc.sections[0]
section.page_width = Inches(8.5)
section.page_height = Inches(11)
section.left_margin = Inches(0.9)
section.right_margin = Inches(0.9)
section.top_margin = Inches(0.8)
section.bottom_margin = Inches(0.8)

# Neutral footer (no company branding confirmed for this project)
footer_p = section.footer.paragraphs[0] if section.footer.paragraphs else section.footer.add_paragraph()
footer_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
footer_r = footer_p.add_run("Internal Use Only — Confidential")
footer_r.font.size = Pt(7)
footer_r.font.italic = True
footer_r.font.color.rgb = RGBColor(0xA8, 0xAD, 0xB5)

# -------------------------------------------------------------------------
add_title_page(doc)

# -------------------------------------------------------------------------
add_heading(doc, "Contents", level=1)
add_toc_table(doc, [
    ("1", "Executive Summary", "The problem, the solution, and the core guarantees in one page", NAVY),
    ("2", "The Problem", "Six investigation gaps a dashboard structurally can't close", RED),
    ("3", "Solution Overview / Architecture", "End-to-end architecture and the two-tier investigation model", BLUE),
    ("4", "Quality Dimension Coverage", "7 dimensions, phased rollout, detection tier and Genie space per dimension", ORANGE),
    ("5", "Eight Specialized Genie Workspaces", "Purpose, sources, and sample questions for each of the 8 spaces", TEAL),
    ("6", "DQX Integration — Zero-Copy, Zero-Pipeline-Change", "The central leadership ask: no data copy, no pipeline changes", GREEN),
    ("7", "Lakehouse Monitoring Roadmap", "Today's workaround and the phased future-state migration", BLUE),
    ("8", "Governance & Trust Guarantees", "Anti-fabrication, AI-assisted not autonomous, human-curated outranks AI", PURPLE),
    ("9", "Rollout Plan & Next Steps", "Phased dimension rollout, DQX pilot, and the go-live eval gate", ORANGE),
])
doc.add_page_break()

# -------------------------------------------------------------------------
add_heading(doc, "1. Executive Summary", level=1, color=NAVY)
add_body(doc,
    "The organization runs hundreds of data products across thousands of pipelines on Databricks / "
    "Unity Catalog. Data quality practice today is fragmented by team, with no single place to ask "
    "\"why did this table's quality drop last Tuesday\" and get a synthesized, evidence-backed answer. "
    "The result is slow root-cause triage, inconsistent quality definitions across teams, no "
    "org-wide scorecard, and a real onboarding cost every time a new team wants basic coverage.")
add_rich(doc, [
    ("The Data Quality AI Agent is an ", {}),
    ("investigative agent, not another dashboard", {"bold": True, "color": NAVY}),
    (". It runs on the Databricks-hosted Claude endpoint inside DCS Agent Studio and reasons across ", {}),
    ("eight purpose-scoped Genie spaces", {"bold": True, "color": TEAL}),
    (" backed by Unity Catalog metadata -- human-authored business rules, execution history, "
     "profiling statistics, and native schema/lineage/lakeflow system tables -- plus ", {}),
    ("DQX", {"bold": True, "color": GREEN}),
    (", a read-only automated check layer that gives every table quality coverage from day one, "
     "with or without team-specific setup.", {}),
])
add_stat_row(doc, [
    ("8", "Genie Spaces", TEAL),
    ("2", "Investigation Tiers", ORANGE),
    ("7", "Quality Dimensions", GREEN),
    ("20", "Eval Cases", PURPLE),
])
add_body(doc, "Two-tier architecture, in brief:", bold=True, size=11)
add_bullets(doc, [
    "Tier 1 — zero onboarding, always on. DQX runs read-only against any Unity Catalog table the "
    "agent has SELECT on. No pipeline changes, no new tables for the team to populate.",
    "Tier 2 — richer, opportunistic. When a team has invested in team_rule / dq_stats / data_profile, "
    "those human-curated signals are preferred and take precedence over Tier 1's AI-inferred findings.",
])
add_body(doc, "Core guarantees:", bold=True, size=11)
add_bullets(doc, [
    "Onboarding a new team = one UC SELECT grant, zero pipeline changes, zero new tables.",
    "Anti-fabrication non-negotiable: NOT_RUN / no-result is never reported as PASS.",
    "AI-assisted rule recommendations only — the agent never writes to team_rule, dq_stats, "
    "data_profile, or any production table.",
    "100% native Databricks: Unity Catalog, information_schema, Delta history, lineage/lakeflow "
    "system tables, Genie, DQX — no external tooling.",
    "Lakehouse Monitoring is architected for a drop-in swap once serverless compute is available.",
])
doc.add_page_break()

# -------------------------------------------------------------------------
add_heading(doc, "2. The Problem", level=1, color=RED)
add_body(doc,
    "DCS already captures rich data-quality signal today: business rules, execution results, and "
    "column-level profiling per team. What's missing is not more data — it's reasoning. Today, when "
    "quality degrades, an analyst manually stitches together rule failures, profiling anomalies, "
    "schema changes, and upstream job status to find a root cause. That is slow, inconsistent across "
    "teams, and does not scale to hundreds of data products and thousands of pipelines.")
add_image(doc, "diagram_1_problem_statement.png", width_in=6.7,
          caption="Figure 1 — Six investigation gaps a dashboard structurally can't close.")
doc.add_page_break()

# -------------------------------------------------------------------------
add_heading(doc, "3. Solution Overview / Architecture", level=1, color=BLUE)
add_body(doc,
    "The Data Quality AI Agent is a single conversational agent on the Databricks-hosted Claude "
    "endpoint inside DCS Agent Studio. It owns no new pipeline or data store beyond the results table "
    "it already gets via DQX; its role is investigation and synthesis across metadata that already "
    "exists in Unity Catalog, plus three shared, multi-tenant Delta tables (team_rule, dq_stats, "
    "data_profile) and a DQX-owned results table (dqx_results). It reasons through eight scoped Genie "
    "spaces rather than issuing raw SQL directly, keeping data access governed, auditable, and "
    "UC-permission-bounded.")
add_image(doc, "diagram_2_architecture.png", width_in=6.7,
          caption="Figure 2 — End-to-end architecture: data sources → two-tier model → 8 Genie spaces → agent → outputs.")
add_body(doc, "The two-tier investigation model", bold=True, size=12, color=NAVY)
add_body(doc,
    "Tier 1 (DQX, zero onboarding, always on): DQX runs read-only against any Unity Catalog table the "
    "agent (via the central DQ job) has SELECT on. It requires no team_rule / dq_stats / data_profile "
    "rows at all -- its own profiler samples the table and its 50+ built-in checks cover completeness, "
    "validity, uniqueness, freshness, and schema from day zero, from a UC grant alone. Results land only "
    "in dqx_results, never in a team's own tables.")
add_body(doc,
    "Tier 2 (human-curated, opportunistic): when a team has already populated team_rule / dq_stats / "
    "data_profile, those rows represent human judgment about what quality means for that table and are "
    "preferred whenever both tiers have an answer for the same table or rule. The agent always states "
    "which tier produced a given answer.")
add_body(doc,
    "Both tiers feed the same eight Genie spaces, which the agent (running as a Sequential reasoning "
    "agent in DCS Agent Studio) queries to classify the question, route to the right space(s), "
    "cross-reference at least one corroborating signal before asserting a root cause, and synthesize a "
    "confidence-scored, tier-labeled answer -- a root-cause explanation, a human-reviewable "
    "recommendation, a scorecard, or a daily health summary.")
doc.add_page_break()

# -------------------------------------------------------------------------
add_heading(doc, "4. Quality Dimension Coverage", level=1, color=ORANGE)
add_body(doc,
    "Seven quality dimensions are in scope: Completeness, Validity, Consistency, Uniqueness, "
    "Timeliness, Volume, and Schema Drift. Rollout is phased by build complexity, not business "
    "importance. Completeness, Validity, and Uniqueness (Phase 1) are pure rule-execution checks "
    "answerable directly from DQX built-ins plus existing team_rule / dq_stats data, with no new "
    "infrastructure — these ship first. Consistency, Timeliness, Volume, and Schema Drift (Phase 2) "
    "each lean on cross-table correlation, an SLA/volume baseline, or Delta history depth, and follow "
    "once Phase 1 is validated in production.")
add_image(doc, "diagram_4_dimension_matrix.png", width_in=6.7,
          caption="Figure 3 — 7 quality dimensions x detection tier x primary + corroborating Genie space(s) x rollout phase.")
add_body(doc,
    "Every dimension is a full investigation loop, not a single static check: several investigation "
    "workflows deliberately query more than one Genie space before concluding a root cause — "
    "Consistency checks Freshness and Completeness, Volume checks Schema Intelligence and Execution "
    "Analytics, Schema Drift checks Volume and Profiling — so the agent avoids attributing a symptom "
    "to the first matching dimension without ruling out neighboring explanations.", italic=True, color=GRAY)
doc.add_page_break()

# -------------------------------------------------------------------------
add_heading(doc, "5. Eight Specialized Genie Workspaces", level=1, color=TEAL)
add_body(doc,
    "One large, do-everything Genie space degrades in accuracy as its table scope and instruction "
    "complexity grow. Instead, each investigative surface gets its own narrowly-scoped workspace with "
    "a small fixed table list and explicit guardrails, including instructions on when to defer to a "
    "sibling workspace rather than guess.")
add_image(doc, "diagram_3_genie_map.png", width_in=6.2,
          caption="Figure 4 — The 8 Genie workspaces around the agent, colored by Phase 1/Phase 2/cross-phase/"
                  "cross-cutting rollout role, with the dimension(s) each one maps to.")
add_table(doc,
    ["Workspace", "Answers"],
    [
        ["Rule Intelligence", "What a rule does, its status, its owner"],
        ["Profiling Intelligence", "Column-level nulls, counts, cardinality, distribution"],
        ["DQ Execution Analytics", "Pass/fail/no-result history, run summaries (both tiers)"],
        ["Schema Intelligence", "Schema drift -- added/dropped/retyped columns"],
        ["Freshness Intelligence", "Is data late, SLA-breach detection"],
        ["Volume Intelligence", "Row-count anomalies vs. baseline and seasonality"],
        ["Lineage & Impact Analysis", "Upstream cause, downstream blast radius"],
        ["Governance Intelligence", "Ownership, coverage gaps, DQ scorecards"],
    ],
    col_widths=[2.3, 4.1])
add_callout_box(doc, "Cross-cutting guardrail (every space):",
    "NOT_RUN, PARTIAL, or a missing row is never reported as PASS or \"no issues.\" Every space labels "
    "which tier (Tier 1 DQX vs. Tier 2 human-curated) answered, and Tier 2 always outranks Tier 1 when "
    "both exist for the same table/rule.",
    fill="DCE8F5", accent="2E6FB5", label_color=RGBColor(0x2E, 0x6F, 0xB5), text_color=DARK)
add_body(doc,
    "Full per-space configuration — complete instructions, context, and guardrail text exactly as "
    "configured in Agent Studio — lives in docs/03_GENIE_WORKSPACES.md and is intentionally not "
    "reproduced in full here. Condensed purpose, sources, and sample questions for each space follow.",
    italic=True, color=GRAY)
doc.add_page_break()

for i, ws in enumerate(GENIE_WORKSPACES, start=1):
    add_heading(doc, f"5.{i}. {ws['name']}", level=2)
    add_body(doc, ws["purpose"])
    add_labeled_line(doc, "Data sources:", ws["sources"])
    add_body(doc, "Sample questions:", bold=True, size=10.5)
    add_bullets(doc, ws["questions"])
    if i < len(GENIE_WORKSPACES):
        doc.add_paragraph()
doc.add_page_break()

# -------------------------------------------------------------------------
add_heading(doc, "6. DQX Integration — Zero-Copy, Zero-Pipeline-Change", level=1, color=GREEN)
add_body(doc,
    "This is the section leadership most needs: can DQX be used without copying another team's data "
    "and without changing any other team's pipeline code? Yes — confirmed feasible, and it is the "
    "single most important design property behind Tier 1.")
add_image(doc, "diagram_5_dqx_zero_copy.png", width_in=6.8,
          caption="Figure 5 — The DQX zero-copy integration pattern: read-only in, results out, nothing else touched.")
add_body(doc, "How it works:", bold=True, size=12, color=NAVY)
add_bullets(doc, [
    "One central job, owned entirely by the DQ team, running on a standard job cluster — "
    "no serverless compute required.",
    "The DQ team is granted SELECT-only Unity Catalog access on each target table. No MODIFY, no "
    "CREATE, no ownership transfer, no data movement into a copy or staging area.",
    "The job reads each table straight out of its existing location into a DataFrame; DQX evaluates "
    "checks against that DataFrame in memory for the duration of the run.",
    "Results — validated rows, quarantined rows, and run metrics — are written only to a schema "
    "the DQ team owns (dqx_results), shaped to mirror dq_stats so DQ Execution Analytics can query "
    "both tiers uniformly. The source table is never written to.",
    "A control master table -- a governed Delta table (dq_catalog.dq_config.dq_control_table, see "
    "dqx/ddl/control_table_ddl.sql), not a YAML/JSON file -- lets the DQX Module (an installable "
    "Python package, dqx/, not a single script) pick up new sources. A team's entire onboarding "
    "action is adding ONE row naming their table, Parquet path, or Avro-schema-described dataset -- "
    "no wildcard pattern or checks array to author. Onboarding a new team = one SELECT grant plus "
    "one control-table INSERT.",
])
add_body(doc, "Cost and governance considerations to flag at sign-off:", bold=True, size=11)
add_bullets(doc, [
    "DQX v0.15.0 enables ML-based anomaly detection by default, which calls Model Serving and incurs "
    "real, metered cost — recommend disabling it for the initial rollout and enabling deliberately, "
    "per table, once a concrete use case and cost agreement exist.",
    "DQX is pre-1.0 with real breaking changes between releases — pin the exact version and review "
    "changelogs before any upgrade.",
    "DQX is a Databricks Labs project: source-available, but explicitly not covered by Databricks "
    "support SLAs. The central DQ team owns operating it; Tier 1 degrades gracefully if the project "
    "stalls, and Tier 2 is unaffected.",
])
doc.add_page_break()

# -------------------------------------------------------------------------
add_heading(doc, "7. Lakehouse Monitoring Roadmap", level=1, color=BLUE)
add_body(doc,
    "Lakehouse Monitoring (LHM) is deferred today for one concrete, environment-specific reason: its "
    "monitor refresh jobs require a managed Serverless SQL warehouse, and no Serverless compute is "
    "available in this workspace yet. This mirrors the DQX Studio deferral — same root cause, same "
    "\"not blocking now\" status, not a judgment on LHM's value.")
add_image(doc, "diagram_6_lhm_roadmap.png", width_in=6.7,
          caption="Figure 6 — Current-state workaround vs. future Lakehouse Monitoring state, with the phased migration path.")
add_body(doc,
    "Migration approach: pilot Lakehouse Monitoring on a small set of tables once serverless is "
    "available, run it in parallel (dual-run) with the existing DQX-profiler / data_profile path for "
    "long enough to see the table's normal variability, then cut over table-by-table once parity is "
    "confirmed — never as a single global switch. DQX's inline validation and quarantine layer is "
    "untouched by this migration; only the routine profiling responsibility shifts, and only for "
    "tables where LHM parity has been signed off by the owning team.")
doc.add_page_break()

# -------------------------------------------------------------------------
add_heading(doc, "8. Governance & Trust Guarantees", level=1, color=PURPLE)
add_body(doc,
    "Trust is the product. These guarantees are enforced at multiple layers — the SQL/view logic, "
    "the agent's system instruction, and a dedicated eval suite — so they hold even as the system "
    "evolves.")
add_callout_box(doc, "Anti-fabrication (non-negotiable):",
    "NOT_RUN and any missing/no-result state are never reported as PASS. A rule absent from today's "
    "dq_stats/dqx_results rows \"did not run,\" full stop. No invented tables, columns, or values; no "
    "lineage claim without an actual lineage-space result.",
    fill="FBE4E1", accent="C0392B", label_color=RGBColor(0xC0, 0x39, 0x2B), text_color=DARK)
add_callout_box(doc, "AI-assisted, not AI-autonomous:",
    "The agent recommends — with SQL/YAML and rationale attached — and never writes to team_rule, "
    "dq_stats, data_profile, or any production table. Every recommendation requires explicit human "
    "review and manual application; there is no auto-deploy path.",
    fill="FBE6D4", accent="E8792B", label_color=RGBColor(0xE8, 0x79, 0x2B), text_color=DARK)
add_callout_box(doc, "Human-curated outranks AI-inferred:",
    "Tier 2 (team_rule / dq_stats / data_profile) findings always take precedence over Tier 1 (DQX) "
    "findings for the same table/rule when both exist. The agent always states which tier answered.",
    fill="DCEFE2", accent="3E8E5A", label_color=RGBColor(0x3E, 0x8E, 0x5A), text_color=DARK)
add_body(doc,
    "Native Databricks first: Unity Catalog, information_schema, Delta history, lineage/lakeflow "
    "system tables, Genie, DQX, and AI Functions are the entire toolset — no external tooling is "
    "introduced without strong justification, and none exists in this design.")
doc.add_page_break()

# -------------------------------------------------------------------------
add_heading(doc, "9. Rollout Plan & Next Steps", level=1)
add_body(doc,
    "The onboarding runbook sequences one-time platform setup (Steps 1–6) followed by a repeatable, "
    "near-zero-effort per-team onboarding path (Step 7).")
add_bullets(doc, [
    "Step 1 — Grant the agent's service principal read-only access to team_rule, dq_stats, "
    "data_profile, dqx_results, information_schema, and the relevant lineage/lakeflow system tables. "
    "No write grants are issued anywhere.",
    "Step 2 — Set table/column comments and declare PK/FK relationships on the four shared tables so "
    "Genie can read intent rather than inferring meaning from names alone.",
    "Step 3 — Create the 8 Genie spaces with their table lists, instructions, context, guardrails, "
    "and certified sample queries.",
    "Step 4 — Deploy the DQX central job against a pilot table set (2-3 teams), version-pinned, on a "
    "standard job cluster, with ML anomaly detection explicitly reviewed before enabling.",
    "Step 5 — Create the agent in DCS Agent Studio from agent_studio/agent_config.md, "
    "system_instruction.md, and tools_manifest.md, with no write-capable tool bound anywhere.",
    "Step 6 — Run the full eval suite (evals/eval_cases.md) before go-live: all 7 zero-tolerance "
    "cases (anti-fabrication, tier-labeling, etc.) must pass with no exceptions; general-coverage "
    "cases are tracked against an agreed pass-rate target.",
    "Step 7 — Onboard each new team: teams already writing to team_rule/dq_stats/data_profile need "
    "nothing further (discovery is automatic, shared tables). Teams with none of these get Tier 1 "
    "coverage the moment SELECT is granted to the DQX job's service principal — no redeployment.",
])
add_body(doc, "Phased dimension rollout:", bold=True, size=11)
add_bullets(doc, [
    "Wave 1 — Completeness, Validity, Uniqueness: pure rule-execution plus DQX built-ins, both tiers "
    "available immediately at go-live.",
    "Wave 2 — Consistency, Timeliness, Volume, Schema Drift: sequenced after Wave 1 is validated in "
    "production, once job_run_timeline correlation, historical baselines, and Delta history retention "
    "are confirmed adequate for the tables in scope.",
])
add_body(doc,
    "This phasing is a rollout sequencing decision, not an architectural one — all 8 Genie spaces and "
    "both tiers are live from Step 3/Step 4; Wave 2 dimensions simply take longer to reach reliable "
    "answer quality because they depend on accumulated history/baseline depth rather than a single "
    "day's execution result.", italic=True, color=GRAY)

doc.save(OUT)
print("Saved", OUT)
