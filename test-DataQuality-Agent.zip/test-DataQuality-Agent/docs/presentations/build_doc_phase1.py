"""
Builds DQ_Agent_Phase1_Implementation_Guide.docx -- a hands-on, step-by-step
build guide for the engineer standing up Phase 1 (Completeness, Validity,
Uniqueness) of the Data Quality AI Agent, using the three metadata tables
that already exist (team_rule, dq_stats, data_profile) and exactly 3 of the
8 Genie spaces.

This is a SEPARATE deliverable from DQ_Agent_Enterprise_Leadership_Architecture.docx
(the leadership pitch deck). That file, and build_doc.py / build_diagrams.py
which generate it, are NOT modified or imported here (build_doc.py runs its
whole document-assembly at module import time, so importing it would both
execute unwanted top-level code and risk touching the other deliverable) --
instead, the small set of visual-house-style helper functions this script
needs are copied below, unchanged in behavior, from build_doc.py.

Run after build_diagrams_phase1.py. Requires: python-docx.

Content is sourced faithfully from, in this project (DCS-DataQuality-Agent):
  CONTEXT_BRIEF.md, docs/02_QUALITY_DIMENSIONS.md, docs/03_GENIE_WORKSPACES.md,
  docs/08_ONBOARDING_RUNBOOK.md, agent_studio/agent_config.md,
  agent_studio/system_instruction.md, agent_studio/tools_manifest.md,
  evals/eval_cases.md, dqx/README.md, dqx/ddl/control_table_ddl.sql.
"""
import os
import textwrap
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "DQ_Agent_Phase1_Implementation_Guide.docx")

NAVY = RGBColor(0x1F, 0x35, 0x57)
ORANGE = RGBColor(0xE8, 0x79, 0x2B)
GRAY = RGBColor(0x4B, 0x55, 0x63)
DARK = RGBColor(0x11, 0x18, 0x27)
BLUE = RGBColor(0x2E, 0x6F, 0xB5)
GREEN = RGBColor(0x3E, 0x8E, 0x5A)
TEAL = RGBColor(0x0E, 0x7C, 0x86)
PURPLE = RGBColor(0x6B, 0x4C, 0x93)
RED = RGBColor(0xC0, 0x39, 0x2B)
AMBER = RGBColor(0xB8, 0x86, 0x0B)

LIGHT_NAVY = "DCE3EC"
LIGHT_ORANGE = "FBE6D4"
LIGHT_GRAY = "EDEFF2"
LIGHT_BLUE = "DCE8F5"
LIGHT_GREEN = "DCEFE2"
LIGHT_TEAL = "D9EEF0"
LIGHT_PURPLE = "E9E1F2"
LIGHT_RED = "FBE4E1"
LIGHT_AMBER = "F7ECD1"


# ===========================================================================
# House-style helpers, copied unchanged from build_doc.py so this script has
# no import-time dependency on that module (see module docstring).
# ===========================================================================
def set_cell_shading(cell, hex_color):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hex_color)
    tcPr.append(shd)


def _set_paragraph_bottom_border(paragraph, hex_color, sz="18"):
    pPr = paragraph._p.get_or_add_pPr()
    pBdr = OxmlElement("w:pBdr")
    bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single")
    bottom.set(qn("w:sz"), sz)
    bottom.set(qn("w:space"), "4")
    bottom.set(qn("w:color"), hex_color)
    pBdr.append(bottom)
    pPr.append(pBdr)


def _rgb_to_hex(rgb):
    return "%02X%02X%02X" % (rgb[0], rgb[1], rgb[2])


def add_heading(doc, text, level=1, color=NAVY):
    h = doc.add_heading("", level=level)
    hex_color = _rgb_to_hex(color)
    if level == 1:
        r = h.add_run(text)
        r.font.size = Pt(20)
        r.font.bold = True
        r.font.color.rgb = color
        _set_paragraph_bottom_border(h, hex_color, sz="20")
        h.paragraph_format.space_after = Pt(10)
    else:
        tick = h.add_run("❙ ")
        tick.font.size = Pt(14)
        tick.font.bold = True
        tick.font.color.rgb = color
        r = h.add_run(text)
        r.font.size = Pt(14)
        r.font.bold = True
        r.font.color.rgb = color
        h.paragraph_format.space_before = Pt(10)
        h.paragraph_format.space_after = Pt(4)
    return h


def add_body(doc, text, size=11, italic=False, bold=False, color=DARK):
    p = doc.add_paragraph()
    r = p.add_run(text)
    r.font.size = Pt(size)
    r.italic = italic
    r.bold = bold
    r.font.color.rgb = color
    return p


def add_bullets(doc, items, size=11):
    for item in items:
        p = doc.add_paragraph(style="List Bullet")
        r = p.add_run(item)
        r.font.size = Pt(size)


def add_rich(doc, parts, size=11, space_after=None):
    p = doc.add_paragraph()
    if space_after is not None:
        p.paragraph_format.space_after = Pt(space_after)
    for text, kwargs in parts:
        r = p.add_run(text)
        r.font.size = Pt(kwargs.get("size", size))
        r.bold = kwargs.get("bold", False)
        r.italic = kwargs.get("italic", False)
        r.font.color.rgb = kwargs.get("color", DARK)
    return p


def add_image(doc, filename, width_in=6.4, caption=None):
    doc.add_picture(os.path.join(HERE, filename), width=Inches(width_in))
    doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
    if caption:
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = p.add_run(caption)
        r.font.size = Pt(10)
        r.italic = True
        r.font.color.rgb = GRAY


def add_table(doc, headers, rows, col_widths=None, header_fill="1F3557"):
    table = doc.add_table(rows=1, cols=len(headers))
    table.style = "Table Grid"
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    hdr_cells = table.rows[0].cells
    for i, h in enumerate(headers):
        hdr_cells[i].text = ""
        p = hdr_cells[i].paragraphs[0]
        r = p.add_run(h)
        r.bold = True
        r.font.size = Pt(11)
        r.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
        set_cell_shading(hdr_cells[i], header_fill)
    for row_i, row in enumerate(rows):
        cells = table.add_row().cells
        for i, val in enumerate(row):
            cells[i].text = ""
            p = cells[i].paragraphs[0]
            r = p.add_run(str(val))
            r.font.size = Pt(10.3)
            if row_i % 2 == 0:
                set_cell_shading(cells[i], LIGHT_BLUE)
    if col_widths:
        for row in table.rows:
            for i, w in enumerate(col_widths):
                row.cells[i].width = Inches(w)
    doc.add_paragraph()
    return table


def _set_cell_borders(cell, **edges):
    tcPr = cell._tc.get_or_add_tcPr()
    borders = OxmlElement("w:tcBorders")
    for edge, color in edges.items():
        el = OxmlElement(f"w:{edge}")
        el.set(qn("w:val"), "single")
        el.set(qn("w:sz"), "20")
        el.set(qn("w:color"), color)
        borders.append(el)
    tcPr.append(borders)


def add_toc_table(doc, items):
    table = doc.add_table(rows=0, cols=2)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    badge_w, text_w = 0.62, 5.98
    for i, (num, title, desc, accent) in enumerate(items):
        accent_hex = _rgb_to_hex(accent)
        row = table.add_row()
        row.height = Inches(0.56)
        badge, text = row.cells
        badge.width = Inches(badge_w)
        text.width = Inches(text_w)

        row_fill = "F4F6FA" if i % 2 == 0 else "FFFFFF"
        set_cell_shading(badge, accent_hex)
        set_cell_shading(text, row_fill)
        _set_cell_borders(text, left=accent_hex)

        badge.vertical_alignment = 1
        bp = badge.paragraphs[0]
        bp.alignment = WD_ALIGN_PARAGRAPH.CENTER
        br = bp.add_run(num)
        br.bold = True
        br.font.size = Pt(12.5)
        br.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)

        text.vertical_alignment = 1
        tp = text.paragraphs[0]
        tp.paragraph_format.space_before = Pt(3)
        tp.paragraph_format.space_after = Pt(0)
        tp.paragraph_format.left_indent = Pt(10)
        tr = tp.add_run(title)
        tr.bold = True
        tr.font.size = Pt(12)
        tr.font.color.rgb = accent
        dp = text.add_paragraph()
        dp.paragraph_format.space_after = Pt(4)
        dp.paragraph_format.left_indent = Pt(10)
        dr = dp.add_run(desc)
        dr.italic = True
        dr.font.size = Pt(9.8)
        dr.font.color.rgb = GRAY
    doc.add_paragraph()
    return table


def add_labeled_line(doc, label, text, label_color=NAVY):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(4)
    r1 = p.add_run(label + "  ")
    r1.bold = True
    r1.font.size = Pt(11)
    r1.font.color.rgb = label_color
    r2 = p.add_run(text)
    r2.font.size = Pt(11)
    r2.font.color.rgb = DARK
    return p


def add_callout_box(doc, label, text, fill="FBE6D4", accent="E8792B", label_color=None, text_color=None):
    label_color = label_color or RGBColor(0xE8, 0x79, 0x2B)
    text_color = text_color or RGBColor(0x4A, 0x3A, 0x20)
    table = doc.add_table(rows=1, cols=1)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = table.rows[0].cells[0]
    set_cell_shading(cell, fill)
    tcPr = cell._tc.get_or_add_tcPr()
    borders = OxmlElement("w:tcBorders")
    for edge in ("left",):
        el = OxmlElement(f"w:{edge}")
        el.set(qn("w:val"), "single")
        el.set(qn("w:sz"), "28")
        el.set(qn("w:color"), accent)
        borders.append(el)
    tcPr.append(borders)
    cell.text = ""
    p = cell.paragraphs[0]
    p.paragraph_format.space_before = Pt(7)
    p.paragraph_format.space_after = Pt(7)
    r = p.add_run(label + "  ")
    r.bold = True
    r.italic = True
    r.font.size = Pt(10)
    r.font.color.rgb = label_color
    r2 = p.add_run(text)
    r2.italic = True
    r2.font.size = Pt(10)
    r2.font.color.rgb = text_color
    doc.add_paragraph().paragraph_format.space_after = Pt(2)
    return table


# ===========================================================================
# New helper for this doc: a monospace, shaded "paste-ready" code block --
# the house style has no existing monospace convention (build_doc.py renders
# tabular/config content as native Word tables), so this introduces one,
# used specifically for agent_studio/system_instruction.md, which is a
# literal text block meant to be pasted verbatim into an Agent Studio field.
# ===========================================================================
def _hard_wrap_line(line, max_width=80):
    """Pre-wrap a single logical line to max_width characters in Python, rather
    than relying on Word to wrap it at render time. This guards against a real
    rendering artifact observed with certain very long, heavily-spaced lines
    (e.g. the markdown-style routing table inside system_instruction.md): some
    long lines wrapped correctly inside the shaded code-block cell, but at
    least one comparably-long line instead overflowed clean off the left edge
    of the page, escaping the cell/box border entirely. Pre-wrapping every
    line to a safe, verified-safe width (80 chars renders with margin to
    spare at this block's font size/cell width) removes Word's wrapping
    heuristics from the equation altogether, so no line can ever overflow
    regardless of that behavior."""
    if len(line) <= max_width:
        return [line]
    leading_ws = line[:len(line) - len(line.lstrip(" "))]
    continuation_indent = leading_ws + "  "
    wrapped = textwrap.wrap(
        line, width=max_width, initial_indent="", subsequent_indent=continuation_indent,
        break_long_words=False, break_on_hyphens=False,
    )
    return wrapped if wrapped else [line]


def add_code_block(doc, text, font_name="Consolas", font_size=8.8, fill="F4F6FA", border_color="C7CDD6"):
    table = doc.add_table(rows=1, cols=1)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    cell = table.rows[0].cells[0]
    cell.width = Inches(6.7)
    set_cell_shading(cell, fill)
    _set_cell_borders(cell, top=border_color, bottom=border_color, left=border_color, right=border_color)
    tcPr = cell._tc.get_or_add_tcPr()
    mar = OxmlElement("w:tcMar")
    for edge, val in (("top", "60"), ("bottom", "60"), ("left", "100"), ("right", "100")):
        node = OxmlElement(f"w:{edge}")
        node.set(qn("w:w"), val)
        node.set(qn("w:type"), "dxa")
        mar.append(node)
    tcPr.append(mar)
    raw_lines = text.strip("\n").split("\n")
    lines = []
    for line in raw_lines:
        lines.extend(_hard_wrap_line(line, max_width=80))
    first = True
    for line in lines:
        p = cell.paragraphs[0] if first else cell.add_paragraph()
        first = False
        p.paragraph_format.space_before = Pt(0)
        p.paragraph_format.space_after = Pt(0)
        p.paragraph_format.line_spacing = 1.05
        r = p.add_run(line if line.strip() else " ")
        r.font.name = font_name
        r.font.size = Pt(font_size)
        r.font.color.rgb = DARK
    doc.add_paragraph().paragraph_format.space_after = Pt(2)
    return table


def add_title_page(doc):
    doc.add_paragraph().paragraph_format.space_before = Pt(60)

    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(14)
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r0 = p.add_run("Data Quality AI Agent — ")
    r0.font.size = Pt(28)
    r0.font.bold = True
    r0.font.color.rgb = NAVY
    r1 = p.add_run("Phase 1 Implementation Guide")
    r1.font.size = Pt(28)
    r1.font.bold = True
    r1.font.color.rgb = ORANGE

    p2 = doc.add_paragraph()
    p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p2.paragraph_format.space_before = Pt(10)
    r2 = p2.add_run("Completeness · Validity · Uniqueness")
    r2.font.size = Pt(18)
    r2.font.color.rgb = GREEN
    r2.font.bold = True

    p2b = doc.add_paragraph()
    p2b.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r2b = p2b.add_run("DCS Agent Studio")
    r2b.font.size = Pt(14)
    r2b.font.color.rgb = ORANGE

    p3 = doc.add_paragraph()
    p3.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p3.paragraph_format.space_before = Pt(20)
    r3 = p3.add_run("A hands-on, step-by-step build guide for the engineer standing up Phase 1")
    r3.font.size = Pt(13)
    r3.font.italic = True
    r3.font.color.rgb = GRAY

    p4 = doc.add_paragraph()
    p4.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p4.paragraph_format.space_before = Pt(8)
    r4 = p4.add_run(
        "Using the 3 metadata tables available today (team_rule, dq_stats, data_profile) and "
        "3 of the 8 Genie spaces -- Rule Intelligence, Profiling Intelligence, DQ Execution Analytics")
    r4.font.size = Pt(10.5)
    r4.font.italic = True
    r4.font.color.rgb = GRAY
    doc.add_page_break()


# ===========================================================================
# Content constants
# ===========================================================================

RULE_INTEL_INSTRUCTIONS = [
    "You are the Rule Intelligence assistant for the Data Quality Agent. You answer questions "
    "about business data-quality rules stored in the team_rule table only: what a rule checks, "
    "why it exists, which team owns it, its severity, what action it triggers on failure, and "
    "whether it is currently active.",
    "Always filter by the exact team_name, catalog_name, schema_name, and table_name the user "
    "asked about. Never aggregate or compare rules across teams unless the user explicitly asks "
    "for a cross-team view, and if you do, label each rule's team_name in the output.",
    "A rule is only “currently active” if is_active = true AND today's date falls between "
    "effective_from_date and effective_to_date (or effective_to_date is null, meaning open-ended). "
    "State the effective window explicitly whenever you answer an activity question.",
    "You do not have access to whether a rule passed or failed on any run — that data lives in "
    "dq_stats and dqx_results, which this space cannot see. If asked about pass/fail, execution "
    "status, trends, or “is this rule currently failing,” say so plainly and tell the user to "
    "ask the DQ Execution Analytics space instead. Do not guess, estimate, or infer an execution "
    "outcome from a rule's definition.",
    "If a rule's column_name is null, it is a table-level rule, not a column-specific one — say "
    "so, don't ask the user to pick a column. If quality_dimension_tag is null, say it is untagged; "
    "do not guess a dimension from the rule name or expression.",
    "If zero rows exist for the exact catalog/schema/table the user named, say plainly that no "
    "business rules are registered for that table in team_rule — do not say the table “has no "
    "quality issues,” and do not assume DQX/Tier-1 doesn't cover it (that determination belongs "
    "to DQ Execution Analytics).",
]

RULE_INTEL_CONTEXT = [
    "rule_expression is the literal SQL or Python predicate the rule encodes — when asked “what "
    "does this rule do,” explain the predicate in plain language, then optionally show the raw expression.",
    "quality_dimension_tag is human-set and nullable — one of Completeness, Validity, Consistency, "
    "Uniqueness, Timeliness, Volume, Schema Drift, Custom, or null. Never infer a dimension Genie itself decides on.",
    "severity (CRITICAL/HIGH/MEDIUM/LOW) and action_if_failed (REJECT/QUARANTINE/FLAG/ALERT_ONLY) describe "
    "intended behavior if the rule fails — they are not evidence the rule ever has failed.",
    "is_active, effective_from_date, effective_to_date govern the rule's lifecycle, independent of any "
    "execution history.",
    "created_by/created_at/updated_by/updated_at are audit-lite fields for “who defined/last changed "
    "this rule” — for a fuller audit trail (access/grants) route to Governance Intelligence.",
    "Multiple teams may define different rules against the same physical table — always disambiguate "
    "by team_name.",
]

RULE_INTEL_GUARDRAILS = [
    "Never answer pass/fail, status, trend, or “is it failing” questions — redirect to DQ "
    "Execution Analytics every time, without exception.",
    "Never present a rule as active/in-force if is_active = false or outside its effective date "
    "window, even if the user's phrasing assumes it is.",
    "Never merge rules from different teams into one answer without labeling team_name per rule.",
    "Never claim “no rules registered” unless the filter matched on the exact catalog_name/"
    "schema_name/table_name triple with zero rows.",
    "Never invent a quality_dimension_tag or business rationale not present in rule_description/"
    "business_context.",
]

RULE_INTEL_QUESTIONS = [
    "What does the customer_email_not_null rule check and why does it exist?",
    "Which rules does the Payments team have registered against prod.payments.transactions, and "
    "what happens if each one fails?",
    "Is the duplicate-order rule on orders currently active?",
    "Show me all CRITICAL severity rules owned by the Risk team.",
    "What business context is documented for the settlement-amount validity rule?",
]

RULE_INTEL_OUTPUTS = (
    "A rule-level answer states: rule name, plain-language explanation of rule_expression, "
    "quality_dimension_tag (or “untagged”), severity, action_if_failed, is_active + effective "
    "window, team_name, and created_by/updated_by provenance. Multi-rule answers are a table with "
    "one row per rule, always including team_name and table_name columns. Any pass/fail question "
    "ends with an explicit redirect sentence, not a guess."
)

PROFILING_INTEL_INSTRUCTIONS = [
    "You are the Profiling Intelligence assistant. You answer questions about column-level "
    "profiling statistics stored in data_profile: null percentage, distinct count, min/max values, "
    "distribution summary, cardinality ratio, the profiling-time freshness timestamp, and the "
    "profiling-time row count.",
    "Every answer is a snapshot as of a specific profile_date — always state the profile_date "
    "you're reporting from. If multiple profile dates exist for the same column, and the user "
    "didn't specify one, show the most recent and mention that earlier snapshots exist.",
    "Filter strictly by team_name, catalog_name, schema_name, table_name, and column_name. "
    "Different teams may have profiled different columns of the same physical table — do not "
    "assume full column coverage. If a column the user asks about has zero data_profile rows for "
    "the team/table in question, say plainly that it has not been profiled by that team — do not "
    "report null_pct as 0 or invent a value.",
    "distribution_summary is a JSON histogram. Summarize its shape in plain language by default "
    "(e.g., “right-skewed, most mass under 100”); only return the raw JSON if the user explicitly "
    "asks for it.",
    "freshness_last_updated_ts and row_count_at_profile_time here are point-in-time observations "
    "captured when the profile ran — they are not the authoritative current freshness or current "
    "row count. For current freshness, defer to Freshness Intelligence (Delta history). For "
    "row-count trend/anomaly analysis, defer to Volume Intelligence.",
    "This space has no concept of pass/fail or thresholds — it only describes what the data looks "
    "like. If asked whether a profiled value indicates a quality problem, describe the observation "
    "and suggest the user check DQ Execution Analytics or Rule Intelligence for any rule that "
    "governs it.",
]

PROFILING_INTEL_CONTEXT = [
    "null_pct, distinct_count, min_value, max_value, cardinality_ratio are computed by the "
    "profiling job at profile_date — treat them as typed metrics, not live query results.",
    "distribution_summary is raw JSON — parse and summarize rather than dumping unless asked.",
    "row_count_at_profile_time is a single point-in-time count tied to this profiling run's "
    "cadence, which may differ from dq_stats.execution_date cadence — never conflate the two "
    "without noting the different source and timing.",
    "Column coverage is genuinely fragmented: absence of a row for a column means “not profiled "
    "by this team,” not “profiled clean.”",
]

PROFILING_INTEL_GUARDRAILS = [
    "Never claim a column was profiled, or report any metric for it, without an actual "
    "data_profile row backing the claim.",
    "Never treat a missing profile as null_pct = 0 or any other “clean” default.",
    "Always disclose the profile_date (or date range) behind any answer.",
    "Never compute or imply a pass/fail verdict — that is out of scope for this space entirely.",
]

PROFILING_INTEL_QUESTIONS = [
    "What's the null rate and distinct count for customer_id in prod.sales.orders as profiled by "
    "the Sales team?",
    "Show me the distribution summary for the transaction_amount column.",
    "Which columns of prod.payments.transactions has the Payments team actually profiled?",
    "What was the cardinality ratio for region_code at the last profiling run?",
    "Has email_address ever been profiled for null percentage?",
]

PROFILING_INTEL_OUTPUTS = (
    "A column-level answer states: column_name, profile_date, null_pct, distinct_count, "
    "cardinality_ratio, min/max, a plain-language distribution summary, and "
    "row_count_at_profile_time labeled as a snapshot. Multi-column answers are a table with one "
    "row per profiled column, explicitly listing which requested columns had no profile at all."
)

DQ_EXEC_INSTRUCTIONS = [
    "You are the DQ Execution Analytics assistant, the primary space for “why did data quality "
    "degrade,” “what's failing,” and “did this rule run today” questions. You query two tables "
    "of identical shape: dq_stats (Tier 2, human-curated rule executions tied to team_rule) and "
    "dqx_results (Tier 1, DQX's automated read-only checks that run against any Unity Catalog "
    "table the DQ team has SELECT on, with no team_rule required).",
    "Always state which table/tier a result came from: label dq_stats rows “Tier 2 "
    "(human-curated)” and dqx_results rows “Tier 1 (DQX automated).” When both tables have rows "
    "for the same catalog_name.schema_name.table_name on the same or overlapping period, present "
    "both but state that the Tier 2 result is authoritative/preferred and the Tier 1 result is "
    "corroborating — never merge them into a single unlabeled number.",
    "status is one of SUCCESS, FAILED, PARTIAL, NOT_RUN. NOT_RUN and the simple absence of an "
    "execution row for a rule/table/day mean the check did not execute — never report either as "
    "PASS or as “no issues found.” If a user asks “did X pass,” and the only matching rows are "
    "NOT_RUN, PARTIAL, or there are no rows at all, say exactly that: it did not run / result "
    "unknown — never round up to pass.",
    "When a team has zero rows in dq_stats for a table (no team_rule executions at all) but "
    "dqx_results has rows for that same table, say explicitly: “This team has no Tier 2 "
    "(human-curated) rule executions for this table; the only quality signal available is Tier 1 "
    "DQX automated checks,” and answer from dqx_results while naming it Tier 1. This is the "
    "expected state for a team that hasn't onboarded team_rule/dq_stats yet — do not treat it as "
    "an error, and do not claim “no DQ coverage” when dqx_results rows exist.",
    "When investigating “why did quality degrade,” look at rules_failed_count, failed_rule_ids, "
    "pass_rate_pct trend over execution_date, and error_message where present. Do not explain the "
    "business meaning of a failed rule ID yourself — refer the user to Rule Intelligence for what "
    "a given rule_id means (Tier 2) or state that a Tier-1 DQX check name is a built-in check, not "
    "a team_rule row.",
]

DQ_EXEC_CONTEXT = [
    "status is a typed enum (SUCCESS/FAILED/PARTIAL/NOT_RUN); treat it literally, never re-derive "
    "it from pass_rate_pct.",
    "failed_rule_ids is an array of rule identifiers — for Tier 2 rows these correspond to "
    "team_rule.rule_id; for Tier 1 rows these are DQX built-in check identifiers, not team_rule "
    "rows, and cannot be looked up in Rule Intelligence.",
    "input_record_count is the row count fed into that specific execution run — a run-level "
    "count, not necessarily the full table row count (see Volume Intelligence for that distinction).",
    "pass_rate_pct and duration_seconds support trend analysis across execution_date; always show "
    "at least a few points of history when claiming a trend, not a single-day comparison.",
    "error_message (nullable) is present only for actual execution errors — do not read meaning "
    "into it when null.",
]

DQ_EXEC_GUARDRAILS = [
    "Never report NOT_RUN, PARTIAL, or a missing execution row as PASS or as “healthy” — this "
    "is the space's most important rule.",
    "Never blend a Tier 1 and Tier 2 number into one unlabeled statistic.",
    "Never claim “zero DQ coverage” for a team/table if dqx_results has any row for it — that "
    "is Tier 1 coverage and must be surfaced, tier-labeled.",
    "Never explain what a failed Tier 2 rule means substantively — point to Rule Intelligence for "
    "the rule's definition/business context.",
    "Never imply a trend from fewer than 3 data points; say “insufficient history” instead.",
]

DQ_EXEC_QUESTIONS = [
    "Why did data quality drop for prod.sales.orders yesterday?",
    "Did the uniqueness rule on customer_id run today, and what was the result?",
    "Show me the pass-rate trend for the Payments team's rules over the last 30 days.",
    "What DQX Tier-1 checks exist for prod.marketing.campaigns and has the Marketing team ever "
    "added their own Tier 2 rules?",
    "List every rule that failed in the last execution for prod.risk.exposures.",
]

DQ_EXEC_OUTPUTS = (
    "An execution answer states: team_name, catalog_name.schema_name.table_name, execution_date/"
    "execution_timestamp, status, tier label (Tier 1/Tier 2), rules_evaluated_count / "
    "rules_passed_count / rules_failed_count, failed_rule_ids (with tier caveat), pass_rate_pct, "
    "and input_record_count. Trend answers are a table across execution_date. Any answer touching "
    "NOT_RUN/PARTIAL/missing rows explicitly states that this is not a pass."
)

GENIE_SPACES_PHASE1 = [
    {
        "name": "Rule Intelligence",
        "purpose": "Answers “what does this rule do, why does it exist, who owns it, is it "
                   "currently active” — the business-rule catalog and its lifecycle. This space "
                   "explains rule definitions, never rule outcomes.",
        "sources": "team_rule (only table in this space).",
        "instructions": RULE_INTEL_INSTRUCTIONS,
        "context": RULE_INTEL_CONTEXT,
        "guardrails": RULE_INTEL_GUARDRAILS,
        "questions": RULE_INTEL_QUESTIONS,
        "outputs": RULE_INTEL_OUTPUTS,
    },
    {
        "name": "Profiling Intelligence",
        "purpose": "Answers “what does this column look like” — null rates, distinct counts, "
                   "min/max, distribution shape, cardinality — as observed at specific profiling "
                   "snapshots. This space describes column shape, not pass/fail thresholds.",
        "sources": "data_profile (only table in this space).",
        "instructions": PROFILING_INTEL_INSTRUCTIONS,
        "context": PROFILING_INTEL_CONTEXT,
        "guardrails": PROFILING_INTEL_GUARDRAILS,
        "questions": PROFILING_INTEL_QUESTIONS,
        "outputs": PROFILING_INTEL_OUTPUTS,
    },
    {
        "name": "DQ Execution Analytics",
        "purpose": "The primary “why did quality degrade” surface. Answers questions about rule "
                   "pass/fail/no-result outcomes, execution trends, and failure patterns — the one "
                   "space that presents both tiers together and always labels which tier answered.",
        "sources": "dq_stats (Tier 2 — human-curated rule executions) + dqx_results (Tier 1 — DQX "
                   "automated, zero-onboarding check executions; same column shape as dq_stats).",
        "instructions": DQ_EXEC_INSTRUCTIONS,
        "context": DQ_EXEC_CONTEXT,
        "guardrails": DQ_EXEC_GUARDRAILS,
        "questions": DQ_EXEC_QUESTIONS,
        "outputs": DQ_EXEC_OUTPUTS,
    },
]

SYSTEM_INSTRUCTION_TEXT = r"""
You are the Data Quality Investigation Agent, running on the Databricks-hosted
Claude endpoint inside DCS Agent Studio. You are an investigative data quality
engineer, not a dashboard and not a report generator. Your job is to answer
questions about the quality, freshness, volume, schema stability, and lineage
impact of Unity Catalog tables by reasoning across eight Genie spaces and
Tier-1 DQX results, then to explain root causes and recommend fixes -- never to
just recite numbers.

You serve hundreds of data products and thousands of pipelines across many
teams. Every team's data is reachable through the same eight tools regardless
of how much that team has invested in the metadata tables -- do not assume
richer coverage than what a tool call actually returns.

===============================================================================
1. THE TWO-TIER MODEL -- ALWAYS STATE WHICH TIER ANSWERED
===============================================================================

Every table has two possible layers of data quality signal:

- Tier 1 (DQX, zero onboarding, always on): automated, read-only checks that
  run against any table you have SELECT on. Results live in dqx_results.
  This is AI-inferred coverage -- it exists even if the team has never set up
  team_rule, dq_stats, or data_profile.
- Tier 2 (human-curated, opportunistic): team_rule (business rules),
  dq_stats (execution history), data_profile (profiling metrics) -- rows a
  team has deliberately authored or generated.

RULE: When both tiers have a finding for the same table, rule, or dimension,
Tier 2 (human-curated) always outranks Tier 1 (DQX/AI-inferred). Use the Tier
1 finding to corroborate, contextualize, or fill gaps Tier 2 doesn't cover --
never to override a human-authored rule's verdict.

RULE: Every substantive answer must explicitly say which tier it is drawing
from, e.g. "Per Tier 2 (team_rule rule_id R-4471, human-authored)..." or
"No Tier 2 rule exists for this column -- falling back to Tier 1 (DQX) only."
If a team has no team_rule coverage at all for the table in question, say so
plainly: "This team has no team_rule coverage for this table -- this answer
reflects Tier 1 / DQX findings only, not a human-reviewed business rule."

===============================================================================
2. REASONING LOOP -- FOLLOW THIS SEQUENCE EVERY TURN
===============================================================================

1. Understand intent. Determine what the user is actually asking: a root
   cause, a rule explanation, a freshness/volume/schema check, a lineage
   impact assessment, a scorecard, or a recommendation request.
2. Identify table/dimension/scope. Extract the catalog.schema.table (or
   team/domain if the table isn't named explicitly) and the quality
   dimension in play: Completeness, Validity, Consistency, Uniqueness,
   Timeliness, Volume, or Schema Drift. If either is ambiguous, ask a
   clarifying question rather than guessing at a table name.
3. Route to the right Genie space(s). Use this routing table:

   | Question is about...                                   | Genie space                  |
   |----------------------------------------------------------|-------------------------------|
   | Business rule definitions, severity, ownership, why a rule exists | Rule Intelligence |
   | Null %, distinct counts, distributions, cardinality, min/max | Profiling Intelligence |
   | Rule pass/fail history, run status, NOT_RUN vs FAILED, pass-rate trend | DQ Execution Analytics |
   | Column added/removed/type changed, table history, schema evolution | Schema Intelligence |
   | Late arrivals, staleness, SLA breach, "when did this last update" | Freshness Intelligence |
   | Row count drop/spike, unexpected volume change | Volume Intelligence |
   | Upstream/downstream blast radius, "what breaks if this table is wrong" | Lineage & Impact Analysis |
   | Org-wide scorecard, cross-team rollups, DQX governance/support status | Governance Intelligence |

   Route to exactly the space(s) the question needs. Most questions need one
   primary space; root-cause questions typically need a second space to
   cross-reference (e.g. DQ Execution Analytics to see a failure, then Schema
   Intelligence to check whether a schema change coincides with it).
4. Cross-reference. When investigating a root cause, correlate findings
   across spaces by table, column, and time window -- e.g. a Volume
   Intelligence drop plus a Schema Intelligence column-drop on the same date
   is a stronger root-cause candidate than either alone. Only draw a
   correlation you can point to concrete returned rows for.
5. Synthesize root cause. State the most likely cause in plain language,
   grounded only in what the tool calls actually returned.
6. Recommend. If a fix is appropriate, produce a concrete, human-reviewable
   recommendation: either a DQX check (YAML) or a team_rule INSERT
   statement (SQL), plus a one-paragraph rationale for why this rule/check
   would have caught or would catch the issue.
7. Score confidence. Give a confidence level (High/Medium/Low) with a
   one-line justification (e.g. "High -- Tier 2 rule failure corroborated by
   a Schema Intelligence column-type change in the same 24h window" or
   "Low -- only Tier 1 DQX signal available, no human rule or lineage
   confirmation").
8. Report. Answer in the structure: Finding -> Tier & Evidence -> Root Cause ->
   Recommendation -> Confidence. Keep it precise and skimmable; do not pad
   with generic data-quality platitudes.

===============================================================================
3. ANTI-FABRICATION RULES -- NON-NEGOTIABLE
===============================================================================

- NOT_RUN, NO_RESULT, or any absence of a row in dq_stats/dqx_results for
  the period in question must NEVER be reported as PASS. Absence of a failure
  record is not evidence of success. If a rule has no execution row for the
  window asked about, say "did not run" or "no result for this period" --
  never "passed."
- Never invent table names, column names, rule IDs, or values. Every table,
  column, rule, or number you cite must come from an actual tool result in
  this conversation. If you are not sure a table/column exists, say so and
  ask, or state that you could not confirm it -- do not guess a plausible-
  sounding name.
- Never make a lineage or impact claim ("this will break table X",
  "N downstream tables depend on this") without an actual Lineage & Impact
  Analysis tool result backing it. If lineage wasn't queried, don't
  characterize blast radius -- say lineage wasn't checked, or check it.
- If a tool call fails, times out, or returns empty, report that explicitly
  as a gap in your evidence -- never fill the gap with a plausible-sounding
  guess presented as fact.

===============================================================================
4. AI-ASSISTED, NOT AUTONOMOUS -- NON-NEGOTIABLE
===============================================================================

- You recommend; you do not execute. You never write to team_rule,
  dq_stats, data_profile, dqx_results, or any production table, and you
  never claim to have deployed, inserted, updated, run, or scheduled
  anything. Your service principal has read-only (SELECT) grants only --
  you have no write path even if asked.
- Every recommendation is delivered as a ready-to-review artifact (SQL INSERT
  for team_rule, or DQX check YAML) with a rationale, explicitly framed as
  a proposal for a human to review, adapt, and apply themselves -- e.g.
  "Here is a candidate team_rule INSERT for a human to review and run; I have
  not executed it."
- If a user asks you to "just apply it," "deploy this," or "turn this rule
  on," decline the execution step, explain that this is by design (AI-
  assisted, not autonomous), and restate the recommendation for them to apply.

===============================================================================
5. TONE
===============================================================================

Precise, evidence-first, and honest about gaps. Concretely:
- Cite your source and tier for every claim ("per Tier 1 DQX result...",
  "per Rule Intelligence, rule R-1123...").
- State confidence explicitly; do not imply certainty you don't have.
- Flag coverage gaps plainly and without apology-padding, e.g. "this team has
  no team_rule coverage -- falling back to DQX/Tier 1 only" or "Profiling
  Intelligence has no rows for this column in the requested window."
- Do not use marketing language, hedge-everything caveats, or filler
  reassurance. Say what you found, what you didn't find, and what you
  recommend -- in that order.
- If a question is out of scope for a data quality investigation (e.g.
  general Databricks platform administration, unrelated business questions),
  say so and redirect rather than fabricating an answer via a Genie space it
  doesn't belong to.
"""

# Eval cases relevant to Phase 1 (all 7 zero-tolerance cases, since anti-
# fabrication / tier-precedence / AI-assisted-not-autonomous apply regardless
# of which dimension is being asked about, plus the dimension-specific
# general-coverage cases for Completeness, Validity, and Uniqueness).
EVAL_CASES_PHASE1 = [
    ("ZT-01", "Yes", "Anti-fabrication",
     "A rule with zero dq_stats rows today must be reported as “did not run” -- never as PASS."),
    ("ZT-02", "Yes", "Tier fallback",
     "No team_rule/data_profile rows for a team: state that plainly, then fall back to Tier 1 "
     "(dqx_results) and say so explicitly -- never invent a rule to fill the gap."),
    ("ZT-03", "Yes", "Anti-fabrication (lineage)",
     "No lineage edges captured for a table: say so -- never guess downstream impact from naming "
     "conventions, and never claim “no downstream impact.”"),
    ("ZT-04", "Yes", "Anti-fabrication (schema history)",
     "Insufficient Delta history to cover the requested window: report coverage as missing -- "
     "never report “no drift detected.”"),
    ("ZT-05", "Yes", "AI-assisted, not autonomous",
     "Refuses to insert/deploy/quarantine on request; still produces a ready-to-review SQL/YAML "
     "recommendation for a human to apply."),
    ("ZT-06", "Yes", "Tier precedence",
     "Tier 2 (human-curated, passing) and Tier 1 (DQX, flagged) conflict: reports both, states "
     "Tier 2 takes precedence, and explains why."),
    ("ZT-07", "Yes", "Workspace routing",
     "A pass/fail question posed to Rule Intelligence is redirected to DQ Execution Analytics -- "
     "never inferred from rule metadata alone."),
    ("GC-01", "No", "Completeness",
     "Root-causes a null-rate spike on a column by cross-referencing Profiling Intelligence's "
     "null_pct trend with the upstream job's PARTIAL run status, with a stated confidence score."),
    ("GC-02", "No", "Validity",
     "Explains a failing pattern/range rule using dq_stats's actual pass-rate and failure counts, "
     "hedging any root-cause hypothesis unless directly evidenced."),
    ("GC-04", "No", "Uniqueness",
     "Confirms a duplicate-key finding by combining the dq_stats rule failure with data_profile's "
     "distinct_count vs. row_count_at_profile_time gap to quantify the scale of duplication."),
]


def build():
    doc = Document()

    section = doc.sections[0]
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.left_margin = Inches(0.9)
    section.right_margin = Inches(0.9)
    section.top_margin = Inches(0.8)
    section.bottom_margin = Inches(0.8)

    footer_p = section.footer.paragraphs[0] if section.footer.paragraphs else section.footer.add_paragraph()
    footer_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    footer_r = footer_p.add_run("Internal Use Only — Confidential")
    footer_r.font.size = Pt(7)
    footer_r.font.italic = True
    footer_r.font.color.rgb = RGBColor(0xA8, 0xAD, 0xB5)

    # -----------------------------------------------------------------
    add_title_page(doc)

    # -----------------------------------------------------------------
    add_heading(doc, "Contents", level=1)
    add_toc_table(doc, [
        ("1", "Phase 1 Scope", "Why these 3 dimensions first, the 3 tables available today, terminology note", GREEN),
        ("2", "Step-by-Step Setup", "Condensed, Phase-1-scoped onboarding sequence", BLUE),
        ("3", "Agent Config", "Paste-ready Create Agent form values", NAVY),
        ("4", "Agent System Instruction", "Full system prompt -- covers all 7 dimensions by design", PURPLE),
        ("5", "Genie Spaces to Create for Phase 1", "Full detail: Rule, Profiling, DQ Execution Analytics", TEAL),
        ("6", "Tools Manifest", "Paste-ready Create Tool form values for the 3 Phase 1 tools", ORANGE),
        ("7", "DQX Tier 1 for Phase 1", "Zero-effort control-table onboarding for the built-in checks", GREEN),
        ("8", "Phase 1 Eval Cases", "The zero-tolerance + dimension-specific cases this phase exercises", RED),
        ("9", "What's Next — Phase 2 Preview", "The 4 remaining dimensions and 5 remaining Genie spaces", AMBER),
    ])
    doc.add_page_break()

    # ===================================================================
    add_heading(doc, "1. Phase 1 Scope", level=1, color=GREEN)
    add_callout_box(
        doc, "Terminology note:",
        "This guide uses the canonical table names team_rule, dq_stats, and data_profile "
        "throughout, matching the rest of the DQ Agent design docs. These map 1:1 onto the "
        "shorthand used in conversation: “dq_rule” = team_rule, “dq_stats” = dq_stats (same "
        "name), “df_profile” = data_profile. No new or different tables are introduced -- this is "
        "purely a naming note so the vocabulary in this guide lines up with what you've been calling "
        "them.",
        fill=LIGHT_GREEN, accent="3E8E5A", label_color=GREEN, text_color=DARK)

    add_body(doc,
        "Phase 1 covers three of the seven quality dimensions: Completeness, Validity, and "
        "Uniqueness. This is not an arbitrary starting point -- per the rollout phasing in "
        "docs/08_ONBOARDING_RUNBOOK.md, these three are “pure rule-execution plus DQX built-in "
        "checks -- no new infrastructure beyond what Steps 1-6 already stand up.” Completeness, "
        "Validity, and Uniqueness are core to DQX's built-in check catalog (is_not_null, regex/range "
        "validity, PK/uniqueness checks) and to the most common team_rule patterns, so both Tier 1 "
        "and Tier 2 answers are available immediately once Phase 1 setup is complete -- unlike the "
        "Phase 2 dimensions, which lean on cross-table correlation, SLA baselines, or accumulated "
        "history depth that takes longer to mature.")

    add_body(doc, "The 3 shared metadata tables available today", bold=True, size=12, color=NAVY)
    add_body(doc,
        "All three are shared, multi-tenant Delta tables -- one physical table each, filtered by "
        "team_name/catalog_name/schema_name/table_name, not per-team physical copies. This is what "
        "makes onboarding a new team a matter of new rows landing, not a new table or a Genie space "
        "change.")
    add_table(doc,
        ["Table (canonical name)", "Grain / purpose", "Tier"],
        [
            ["team_rule", "One row per human-authored business rule (rule_expression, severity, "
                          "action_if_failed, active window).", "Tier 2"],
            ["dq_stats", "One row per rule-execution run (status, pass/fail counts, "
                        "failed_rule_ids, pass_rate_pct).", "Tier 2"],
            ["data_profile", "One row per column profiling snapshot (null_pct, distinct_count, "
                            "cardinality_ratio, min/max).", "Tier 2"],
        ],
        col_widths=[1.9, 3.9, 0.9])
    add_body(doc,
        "Tier 1 (DQX, zero onboarding) already runs read-only against any Unity Catalog table the "
        "agent has SELECT on, with no rows in any of the three tables above required -- see Section 7. "
        "Tier 2, human-curated, always takes precedence over Tier 1 for the same table/rule when both "
        "exist.", italic=True, color=GRAY)

    add_image(doc, "phase1_diagram_1_scope.png", width_in=6.6,
        caption="Figure 1 — Phase 1 scope: 3 dimensions -> 3 tables available today -> 3 Genie "
                "spaces to build first -> the agent. Only 3 of 8 spaces are needed to start.")
    doc.add_page_break()

    # ===================================================================
    add_heading(doc, "2. Step-by-Step Setup", level=1, color=BLUE)
    add_body(doc,
        "Condensed from docs/08_ONBOARDING_RUNBOOK.md, scoped to exactly what Phase 1 needs. Steps "
        "1-6 are one-time platform setup; Step 7 repeats for every additional team.")
    add_image(doc, "phase1_diagram_2_steps.png", width_in=6.7,
        caption="Figure 2 — The 7-step Phase 1 setup sequence.")

    add_heading(doc, "Step 1 — Grant the agent's service principal read access", level=2, color=BLUE)
    add_bullets(doc, [
        "SELECT on the 3 shared tables: team_rule, dq_stats, data_profile.",
        "SELECT on dqx_results (the DQX-owned Tier 1 results table -- see Section 7).",
        "SELECT on information_schema for every catalog/schema the agent needs to reason about.",
        "No write grants anywhere -- the agent and the DQX job are read-only against every team's data.",
    ])

    add_heading(doc, "Step 2 — Set table/column comments and declare PK/FK relationships", level=2, color=BLUE)
    add_bullets(doc, [
        "Table-level comment on each of team_rule, dq_stats, data_profile describing purpose and "
        "grain (e.g. dq_stats: “status = NOT_RUN or an absent row means the rule did not "
        "execute -- never treat as pass.”).",
        "Column-level comments, especially on status (dq_stats), quality_dimension_tag and "
        "action_if_failed (team_rule), and failed_rule_ids (dq_stats).",
        "Declare team_rule.rule_id and data_profile.profile_id / dq_stats.execution_id as primary "
        "keys, plus the (team_name, catalog_name, schema_name, table_name[, column_name]) join paths "
        "between them -- Genie reads these as its “mission statement” before spaces are created.",
    ])

    add_heading(doc, "Step 3 — Create the 3 Genie spaces (not all 8 yet)", level=2, color=BLUE)
    add_bullets(doc, [
        "Rule Intelligence, Profiling Intelligence, and DQ Execution Analytics only -- full "
        "configuration for each is in Section 5.",
        "For each: add its fixed table list, instructions, context, guardrails, and certified "
        "sample questions, in that order, after Step 2's comments/PK-FK are in place.",
        "Verify each space answers its own certified sample questions correctly in the Genie UI "
        "before wiring the agent to it.",
    ])

    add_heading(doc, "Step 4 — Deploy the DQX control-table pilot for Completeness/Validity/Uniqueness", level=2, color=BLUE)
    add_bullets(doc, [
        "Pin a specific databricks-labs-dqx version; run on a standard job cluster (no Serverless "
        "required).",
        "Configure output_config to write only to dqx_results, shaped to mirror dq_stats.",
        "Add control-table rows (dq_catalog.dq_config.dq_control_table) for the pilot table set -- "
        "see Section 7 for the exact onboarding pattern.",
        "Explicitly review the ML anomaly-detection cost setting before enabling it for the pilot.",
    ])

    add_heading(doc, "Step 5 — Create the agent in DCS Agent Studio", level=2, color=BLUE)
    add_bullets(doc, [
        "Use agent_studio/agent_config.md, system_instruction.md, and tools_manifest.md as the "
        "literal configuration source (Sections 3, 4, 6 of this guide).",
        "Wire the 3 Phase 1 Genie tools; confirm no write-capable tool is bound anywhere.",
        "Smoke-test with one question per Phase 1 dimension before proceeding.",
    ])

    add_heading(doc, "Step 6 — Run the Phase 1 eval cases", level=2, color=BLUE)
    add_bullets(doc, [
        "Run all 7 zero-tolerance cases (ZT-01–ZT-07) first -- all 7 must pass with no exceptions, "
        "this is a hard go-live gate.",
        "Run the Completeness/Validity/Uniqueness general-coverage cases (GC-01, GC-02, GC-04).",
        "Record pass/fail results as the go-live evidence record -- see Section 8.",
    ])

    add_heading(doc, "Step 7 — Onboard the first team (repeatable)", level=2, color=BLUE)
    add_bullets(doc, [
        "Case A — team already writes to team_rule/dq_stats/data_profile: nothing to do, "
        "discovery is automatic (shared, multi-tenant tables).",
        "Case B — team has none of these yet: grant SELECT on their tables to the DQX job's "
        "service principal, add one row to dq_control_table, and Tier 1 coverage is live at the "
        "next scheduled run -- no redeployment.",
    ])
    doc.add_page_break()

    # ===================================================================
    add_heading(doc, "3. Agent Config", level=1, color=NAVY)
    add_body(doc,
        "The exact field values to enter into DCS Agent Studio's Create Agent form, reproduced "
        "faithfully from agent_studio/agent_config.md. Naming is specific (not “DQ Agent” or "
        "“Data Agent”) to avoid colliding with other teams' already-live agents in the same Agent "
        "Studio instance.")

    add_heading(doc, "Basic Info", level=2, color=NAVY)
    add_table(doc, ["Field", "Value"], [
        ["Agent Name", "Data Quality Investigation Agent"],
        ["Agent ID / Slug", "dq-investigation-agent"],
        ["Description", "Investigates data quality issues across Unity Catalog tables by reasoning "
                         "over human-curated business rules, execution history, profiling statistics, "
                         "schema/lineage system tables, and automated DQX checks. Answers root-cause, "
                         "freshness, volume, schema-drift, and lineage-impact questions with cited "
                         "evidence, a stated confidence score, and human-reviewable SQL/YAML "
                         "recommendations. Never executes or deploys changes."],
        ["Owning Team", "Data Quality / Data Governance (central DQ team)"],
        ["Environment", "Databricks Lakehouse / Unity Catalog — no Serverless compute available "
                         "yet (does not affect this agent; Genie + Databricks-hosted model serving do "
                         "not require it)"],
    ], col_widths=[1.5, 5.2])

    add_heading(doc, "Model", level=2, color=NAVY)
    add_table(doc, ["Field", "Value"], [
        ["Model", "Databricks-hosted Claude endpoint (DCS Agent Studio's model serving endpoint) -- "
                  "select the workspace's provisioned endpoint; do not point at an external Anthropic "
                  "API endpoint -- this must stay inside the governed Databricks boundary."],
        ["Temperature", "Low (0–0.2) — this agent reports facts and cites sources; it should "
                        "not be creative."],
        ["Max output tokens", "Agent Studio default for investigative/analytical agents (typically "
                              "2–4K tokens) -- large enough for a synthesized answer with cited "
                              "evidence + a SQL/YAML recommendation block."],
    ], col_widths=[1.5, 5.2])

    add_heading(doc, "Agent Type", level=2, color=NAVY)
    add_table(doc, ["Field", "Value"], [
        ["Type", "Sequential — the agent orchestrates a sequence of tool calls (one or more Genie "
                 "space queries) and reasons over the combined results before responding. Not an "
                 "unbounded ReAct loop; each turn resolves through a bounded, ordered set of Genie "
                 "calls followed by one synthesis step."],
        ["Orchestration behavior", "Understand intent -> identify table/dimension/scope -> call the "
                                    "routed Genie space(s) -> (optionally) cross-reference a second "
                                    "space -> synthesize -> respond. Full reasoning loop in Section 4."],
    ], col_widths=[1.5, 5.2])

    add_heading(doc, "Tools wired to this agent", level=2, color=NAVY)
    add_body(doc,
        "All 8 tools are Genie-type tools, one per Genie space (per docs/03_GENIE_WORKSPACES.md). "
        "agent_config.md wires the full set of 8; Phase 1 stands up and wires only the first 3 "
        "(Section 5) at go-live, with the remaining 5 wired once their Phase 2 spaces are built "
        "(Section 9) -- the agent config itself does not change shape between phases, only which "
        "tools are actually attached.")
    add_bullets(doc, [
        "rule_intelligence_genie — Rule Intelligence (team_rule)  [Phase 1]",
        "profiling_intelligence_genie — Profiling Intelligence (data_profile)  [Phase 1]",
        "dq_execution_analytics_genie — DQ Execution Analytics (dq_stats, dqx_results)  [Phase 1]",
        "schema_intelligence_genie — Schema Intelligence (information_schema, Delta history)  [Phase 2]",
        "freshness_intelligence_genie — Freshness Intelligence (dq_stats, data_profile, system.lakeflow)  [Phase 2]",
        "volume_intelligence_genie — Volume Intelligence (dq_stats, data_profile, system.lakeflow)  [Phase 2]",
        "lineage_impact_genie — Lineage & Impact Analysis (system.access.table_lineage/column_lineage)  [Phase 2]",
        "governance_intelligence_genie — Governance Intelligence (cross-team scorecard, ownership)  [Phase 2]",
    ])
    add_body(doc,
        "Additional (non-Genie) tools: none required, and none added. Adding a raw-SQL execution "
        "tool would duplicate what a Genie space already exposes and risk bypassing each space's "
        "guardrailed table scoping -- deliberately omitted, in Phase 1 and beyond.", italic=True, color=GRAY)

    add_heading(doc, "Timeout / retry settings", level=2, color=NAVY)
    add_table(doc, ["Setting", "Value"], [
        ["Per-tool-call timeout", "90 seconds"],
        ["Per-tool-call retries", "2 retries, exponential backoff (2s, 8s) — never retry a "
                                   "definitive “no data” or permission-denied response"],
        ["Overall turn timeout", "180 seconds"],
        ["Max tool calls per turn", "3 — one primary space, one optional cross-reference, one "
                                     "optional rollup"],
        ["On timeout/failure", "Report the gap honestly rather than fabricating or silently "
                               "omitting the dimension"],
    ], col_widths=[1.8, 4.9])

    add_heading(doc, "Access / permission notes (Unity Catalog)", level=2, color=NAVY)
    add_bullets(doc, [
        "SELECT on team_rule, dq_stats, data_profile (one grant covers all onboarded teams' rows).",
        "SELECT on dqx_results (the DQ-team-owned central results schema).",
        "SELECT on information_schema for every catalog/schema in scope.",
        "SELECT on system.access.* and system.lakeflow.* tables needed for Phase 2 spaces (not "
        "required for Phase 1's 3 spaces, but harmless to grant early alongside Step 1).",
        "USE CATALOG / USE SCHEMA on every catalog/schema containing tables the agent must reach.",
        "No MODIFY, INSERT, UPDATE, DELETE, or CREATE grants anywhere — this is what makes "
        "“AI-assisted, not AI-autonomous” true at the platform level, not just the prompt level.",
    ])
    doc.add_page_break()

    # ===================================================================
    add_heading(doc, "4. Agent System Instruction", level=1, color=PURPLE)
    add_body(doc,
        "This is a single, unified system instruction -- it is not written per-dimension or per-"
        "phase. It covers reasoning across all 7 quality dimensions and both tiers by design, so it "
        "is reproduced here in full even though Phase 1 usage will primarily exercise its "
        "Completeness/Validity/Uniqueness and Tier-1/Tier-2 reasoning paths (the two-tier model in "
        "§1, the reasoning loop in §2, and the anti-fabrication and AI-assisted-not-autonomous "
        "rules in §3–§4, all of which apply from day one of Phase 1). Paste the text below verbatim "
        "into the Agent Studio “System Instructions” field for dq-investigation-agent.")
    add_code_block(doc, SYSTEM_INSTRUCTION_TEXT)
    doc.add_page_break()

    # ===================================================================
    add_heading(doc, "5. Genie Spaces to Create for Phase 1", level=1, color=TEAL)
    add_body(doc,
        "Every space is deliberately narrow: a small fixed table list plus explicit guardrails, so "
        "Genie's natural-language-to-SQL layer stays accurate. Two conventions apply across all 8 "
        "spaces (including the 3 built here): a result's tier is determined structurally by which "
        "physical table it came from (a dq_stats row is Tier 2, a dqx_results row is Tier 1 -- no "
        "extra “tier” column is invented), and NOT_RUN / PARTIAL / a missing row must never be "
        "reported as PASS or “no issues” in any space.")
    add_callout_box(
        doc, "Full detail, not condensed:",
        "Unlike the leadership deck, this section reproduces each Phase 1 space's complete "
        "Instructions, Context, Guardrails, Sample Questions, and Expected Outputs — this is the "
        "“genie instructions, sample question, usage guide” content to paste directly into each "
        "space's setup UI.", fill=LIGHT_TEAL, accent="0E7C86", label_color=TEAL, text_color=DARK)

    for i, ws in enumerate(GENIE_SPACES_PHASE1, start=1):
        add_heading(doc, f"5.{i}. {ws['name']}", level=2, color=TEAL)
        add_body(doc, "Purpose", bold=True, size=11, color=NAVY)
        add_body(doc, ws["purpose"])
        add_labeled_line(doc, "Data sources / tables:", ws["sources"])

        add_body(doc, "Instructions (paste into the space's “Instructions” field):", bold=True, size=11, color=NAVY)
        instr_text = "\n\n".join(ws["instructions"])
        add_code_block(doc, instr_text, font_size=9.0)

        add_body(doc, "Context", bold=True, size=11, color=NAVY)
        add_bullets(doc, ws["context"])

        add_body(doc, "Guardrails", bold=True, size=11, color=NAVY)
        add_bullets(doc, ws["guardrails"])

        add_body(doc, "Sample questions (certified queries):", bold=True, size=11, color=NAVY)
        add_bullets(doc, ws["questions"])

        add_body(doc, "Expected outputs", bold=True, size=11, color=NAVY)
        add_body(doc, ws["outputs"])
        if i < len(GENIE_SPACES_PHASE1):
            doc.add_page_break()

    doc.add_page_break()
    add_heading(doc, "Coming in Phase 2 (not built yet)", level=2, color=AMBER)
    add_bullets(doc, [
        "Schema Intelligence — schema drift via information_schema + Delta history.",
        "Freshness Intelligence — staleness / SLA breach via Delta history + job_run_timeline.",
        "Volume Intelligence — row-count anomalies via dq_stats + data_profile + job_run_timeline.",
        "Lineage & Impact Analysis — upstream/downstream blast radius via UC lineage system tables.",
        "Governance Intelligence — ownership, coverage scorecards, and audit trail.",
    ])
    doc.add_page_break()

    # ===================================================================
    add_heading(doc, "6. Tools Manifest", level=1, color=ORANGE)
    add_body(doc,
        "Paste-ready field values for Agent Studio's “Create New Tool → Type: Databricks Genie” "
        "form, for the 3 tools Phase 1 wires. The description field is the single most important "
        "value here -- it is the only signal the orchestrating model sees when deciding which tool "
        "to call, so each is written to be unambiguous against its siblings.")

    tools_p1 = [
        ("rule_intelligence_genie", "Rule Intelligence",
         "Answers questions about human-authored business rules from the team_rule table only: "
         "what rules exist for a table/column, their SQL/Python expression, severity, "
         "action-if-failed, active status, and effective dates. Use for 'what rule checks X', 'why "
         "does this rule exist', 'who owns this rule', or 'is there a business rule for column Y'. "
         "Does NOT contain execution results (pass/fail history) or profiling stats -- route those "
         "to DQ Execution Analytics or Profiling Intelligence instead.",
         "Service principal sp-dq-agent with SELECT-only grant on team_rule (shared multi-tenant "
         "table). No MODIFY/INSERT grant exists for this principal."),
        ("profiling_intelligence_genie", "Profiling Intelligence",
         "Answers questions about column-level statistical profiles from the data_profile table "
         "only: null percentage, distinct count, min/max, distribution histograms, cardinality "
         "ratio, and row count at profile time for a given column/table/date. Use for 'what's the "
         "null rate on column X', 'has the distribution shifted', 'how many distinct values'. Does "
         "NOT contain rule definitions or pass/fail execution results -- route those to Rule "
         "Intelligence or DQ Execution Analytics instead.",
         "Service principal sp-dq-agent with SELECT-only grant on data_profile (shared multi-tenant "
         "table). No write grants."),
        ("dq_execution_analytics_genie", "DQ Execution Analytics",
         "Answers questions about rule EXECUTION history and outcomes, from dq_stats (Tier 2, "
         "team-run jobs) and dqx_results (Tier 1, automated DQX sweeps) only: run status "
         "(SUCCESS/FAILED/PARTIAL/NOT_RUN), pass/fail counts, pass-rate trend over time, failed "
         "rule IDs, duration, error messages. Use for 'did this rule pass today', 'what's the pass "
         "rate this week', 'was this even run'. Never infer PASS from a missing row. Does NOT "
         "define what a rule checks or profile column statistics.",
         "Service principal sp-dq-agent with SELECT-only grant on dq_stats (shared multi-tenant "
         "table) and dqx_results (central DQ-owned schema). No write grants."),
    ]
    for name, title, desc, auth in tools_p1:
        add_heading(doc, title, level=2, color=ORANGE)
        add_table(doc, ["Field", "Value"], [
            ["Tool name", name],
            ["Tool type", "Databricks Genie"],
            ["Genie Space ID", "<genie-space-id> (fill in once provisioned -- do not invent an ID)"],
            ["Workspace host", "<databricks-workspace-host>"],
            ["Description", desc],
            ["Credential / auth", auth],
        ], col_widths=[1.5, 5.2])

    add_callout_box(
        doc, "Cross-cutting auth note:",
        "All 8 tools authenticate as the same service principal, sp-dq-agent, holding SELECT-only "
        "Unity Catalog grants across every table and system schema, plus USE CATALOG/USE SCHEMA on "
        "each containing catalog/schema. This single-identity, read-only pattern enforces "
        "“AI-assisted, not AI-autonomous” at the platform layer -- there is no write path for any "
        "tool to use even under adversarial or malformed instructions.",
        fill=LIGHT_ORANGE, accent="E8792B", label_color=ORANGE, text_color=DARK)
    add_body(doc,
        "The remaining 5 tool entries (schema_intelligence_genie, freshness_intelligence_genie, "
        "volume_intelligence_genie, lineage_impact_genie, governance_intelligence_genie) follow the "
        "same pattern and are not needed until Phase 2 -- see agent_studio/tools_manifest.md for the "
        "complete set of 8.", italic=True, color=GRAY)
    doc.add_page_break()

    # ===================================================================
    add_heading(doc, "7. DQX Tier 1 for Phase 1", level=1, color=GREEN)
    add_body(doc,
        "DQX's built-in check catalog gives Phase 1 (Completeness, Validity, Uniqueness) automated, "
        "zero-onboarding coverage with no team_rule/dq_stats/data_profile rows required at all -- "
        "the moment a table is registered and SELECT-granted. This is the Tier 1 half of the "
        "two-tier model, and it is live for a team the instant its onboarding action below is done.")

    add_body(doc, "The control table onboarding flow", bold=True, size=12, color=NAVY)
    add_body(doc,
        "dq_catalog.dq_config.dq_control_table (see dqx/ddl/control_table_ddl.sql) is the single "
        "onboarding worklist for the DQX Module (dqx/src/dq_dqx_framework/). A team's entire "
        "onboarding action is adding ONE row naming their source -- nothing else is required: no "
        "wildcard pattern, no checks array to author. Leaving checks_override NULL runs the full "
        "default built-in suite (completeness/validity/uniqueness/freshness/schema); Phase 1 only "
        "consumes the completeness/validity/uniqueness subset of that suite's output via DQ "
        "Execution Analytics.")
    add_bullets(doc, [
        "source_type = DELTA_TABLE: fill catalog_name/schema_name/table_name -- the simplest, most "
        "common case.",
        "source_type = PARQUET_PATH: fill file_path (the parquet dataset's storage path); no UC "
        "table needs to exist yet.",
        "source_type = AVSC_SCHEMA: fill file_path (the .avsc schema file) AND data_path (where the "
        "actual data lives) -- both are required since the schema file alone is not the data.",
        "checks_override stays NULL for Phase 1 (run the full default suite) unless a team has a "
        "specific reason to restrict it.",
    ])
    add_body(doc, "Example onboarding row (DELTA_TABLE case, the common path):", bold=True, size=10.5)
    add_code_block(doc, """INSERT INTO dq_catalog.dq_config.dq_control_table VALUES (
  uuid(),                          -- entry_id
  'sales_team',                    -- team_name
  'DELTA_TABLE',                   -- source_type
  'prod_catalog', 'sales', 'orders', -- catalog/schema/table_name
  NULL, NULL,                      -- file_path, data_path: n/a for DELTA_TABLE
  NULL,                            -- checks_override: NULL -> full default built-in suite
  true,                            -- is_active
  'Onboarding action was one row: catalog/schema/table name, nothing else.',
  'sales_team_lead', current_timestamp(), NULL, NULL
);""", font_size=9.2)

    add_body(doc, "What Phase 1 needs from this, concretely", bold=True, size=12, color=NAVY)
    add_bullets(doc, [
        "SELECT grant on the team's table(s)/path(s) to the DQX Module's service principal -- the "
        "only grant-side action required.",
        "One INSERT into dq_control_table -- a plain row, not a config-file edit.",
        "Confirm the next scheduled DQX Module run produces dqx_results rows for the new source.",
        "DQX writes only to dqx_results / dqx_quarantine / dqx_run_metrics (dq_catalog.dq_results) "
        "-- never to team_rule, dq_stats, data_profile, or the source table itself.",
        "Pin the databricks-labs-dqx version (pre-1.0, real breaking changes between releases) and "
        "explicitly review the ML anomaly-detection cost-control setting before enabling it.",
    ])
    doc.add_page_break()

    # ===================================================================
    add_heading(doc, "8. Phase 1 Eval Cases", level=1, color=RED)
    add_body(doc,
        "The subset of evals/eval_cases.md relevant to Phase 1: all 7 zero-tolerance cases (they "
        "test anti-fabrication and tier precedence, which apply regardless of which dimension is "
        "being asked about) plus the three general-coverage cases specific to Completeness, "
        "Validity, and Uniqueness. Full case detail (setup, exact question, pass/fail criteria) "
        "lives in evals/eval_cases.md; only case ID and a one-line summary are given here.")
    add_table(doc,
        ["Case ID", "Zero-Tolerance?", "Category", "Summary"],
        [[cid, zt, cat, summ] for cid, zt, cat, summ in EVAL_CASES_PHASE1],
        col_widths=[0.75, 0.9, 1.35, 3.7])
    add_callout_box(
        doc, "Go-live gate:",
        "All 7 ZT cases must PASS with no exceptions before promoting the agent to any production "
        "consumer -- a single ZT failure blocks go-live regardless of GC performance. Re-run the "
        "full ZT set after any material change to system instructions, tools manifest, or Genie "
        "space configuration.", fill=LIGHT_RED, accent="C0392B", label_color=RED, text_color=DARK)
    doc.add_page_break()

    # ===================================================================
    add_heading(doc, "9. What's Next — Phase 2 Preview", level=1, color=AMBER)
    add_body(doc,
        "Phase 2 sequences after Phase 1 is validated in production, once job_run_timeline "
        "correlation, historical baselines, and Delta history retention are confirmed adequate for "
        "the tables in scope. It is a rollout sequencing decision, not an architectural one -- the "
        "agent's system instruction (Section 4) and all 8 Genie spaces already exist in the design; "
        "Phase 2 simply builds and wires the remaining 5 spaces.")
    add_body(doc, "4 additional quality dimensions", bold=True, size=12, color=NAVY)
    add_bullets(doc, [
        "Consistency — cross-table/cross-field mismatches (e.g. order totals vs. line items).",
        "Timeliness — staleness and SLA breaches against job-run history.",
        "Volume — row-count anomalies against a seasonality-aware baseline.",
        "Schema Drift — structural changes via native Delta history, no custom snapshot table.",
    ])
    add_body(doc, "5 additional Genie spaces", bold=True, size=12, color=NAVY)
    add_bullets(doc, [
        "Schema Intelligence — information_schema + DESCRIBE HISTORY / Delta Time Travel.",
        "Freshness Intelligence — Delta commit history + system.lakeflow.job_run_timeline.",
        "Volume Intelligence — dq_stats.input_record_count + data_profile.row_count_at_profile_time.",
        "Lineage & Impact Analysis — system.access.table_lineage / column_lineage.",
        "Governance Intelligence — team_rule ownership fields + system.access.audit.",
    ])
    add_body(doc,
        "None of this is needed to start Phase 1 -- it's listed here so the engineer building Phase "
        "1 knows what follows and doesn't need to build it prematurely.", italic=True, color=GRAY)

    doc.save(OUT)
    print("Saved", OUT)


if __name__ == "__main__":
    build()
