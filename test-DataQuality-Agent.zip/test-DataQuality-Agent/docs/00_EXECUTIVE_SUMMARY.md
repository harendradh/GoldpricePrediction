# Executive Summary — Data Quality AI Agent

## The Problem

The organization runs hundreds of data products across thousands of pipelines
on Databricks/Unity Catalog. Data quality practice today is fragmented by
team: some teams write their own rule checks, some run ad hoc profiling
notebooks, some rely on downstream consumers to notice a problem first. There
is no single place to ask "why did this table's data quality drop last
Tuesday?" and get a synthesized, evidence-backed answer. The result is slow
root-cause triage (hours to days of manual cross-referencing across job logs,
table history, and tribal knowledge), inconsistent quality definitions across
teams, no organization-wide quality scorecard, and a real onboarding cost
every time a new team wants basic data quality coverage — historically that
has meant standing up new tables, new pipelines, and new dashboards per team
before any value is delivered.

This does not scale to hundreds of data products and thousands of pipelines.
Point dashboards and per-team scripts multiply linearly with every
onboarding; an investigative agent does not.

## The Solution

The Data Quality AI Agent is an **investigative agent**, not another
dashboard. It sits on the Databricks-hosted Claude endpoint inside DCS Agent
Studio and reasons across eight purpose-scoped Genie spaces backed by Unity
Catalog metadata — human-authored business rules, execution history,
profiling statistics, native schema/lineage/lakeflow system tables — plus
DQX, a read-only automated check layer that gives every table quality
coverage from day one, with or without team-specific setup. When someone asks
"why is `orders.total_amount` failing validity checks this week," the agent
identifies the table and dimension in question, queries the relevant Genie
space(s), cross-references execution history against lineage and schema
history, synthesizes a root-cause explanation grounded in what it actually
found (never fabricated), assigns a confidence score, and recommends a
concrete, human-reviewable fix — a DQX check or a `team_rule` SQL insert.
Nothing is auto-deployed; every recommendation is AI-assisted, human-approved.

## Two-Tier Architecture, in Brief

- **Tier 1 — zero onboarding, always on.** DQX runs read-only against any
  Unity Catalog table the agent has `SELECT` on. No pipeline changes, no new
  tables for the team to populate. A team gets completeness, validity,
  uniqueness, freshness, and schema coverage from the moment they grant
  access — nothing else required.
- **Tier 2 — richer, opportunistic.** When a team has already invested in
  `team_rule` (business rules), `dq_stats` (execution history), and
  `data_profile` (profiling metrics), those human-curated signals are
  preferred and take precedence over Tier 1's AI-inferred findings whenever
  both exist for the same table or rule.

The agent always states which tier answered a question, so users know
whether they're seeing a human-authored rule result or an automated
Tier-1 inference.

## Why This Fits This Environment

The design is deliberately native to the current Databricks estate and its
present constraints, not a generic reference architecture:

- **No Serverless compute available yet** — DQX's core engine runs on
  standard job clusters; the serverless-only pieces (DQX Studio, Lakehouse
  Monitoring) are explicitly deferred, not blocking.
- **Native-Databricks-only** — Unity Catalog, `information_schema`, Delta
  history/Time Travel, `system.access.table_lineage`/`column_lineage`,
  `system.lakeflow.job_run_timeline`, and Genie are used as-is; no external
  ingestion layer, no third-party governance tool is introduced.
- **AI-assisted, not autonomous** — the agent explains and recommends; it
  never writes to `team_rule`, `dq_stats`, `data_profile`, or any production
  table. A human reviews and applies every change.
- **Multi-tenant by construction** — `team_rule`, `dq_stats`, and
  `data_profile` are each one shared physical table filtered by team/catalog/
  schema/table, so onboarding a new team costs a UC grant, not a new table or
  a new Genie space.

## Expected Business Outcomes

- **Faster root cause** — minutes instead of hours/days, because the agent
  cross-references rule definitions, execution history, profiling drift,
  schema changes, and lineage impact in one pass instead of a human doing it
  manually across five different places.
- **Reduced manual triage load** — first-line investigation is handled by
  the agent; engineers step in for confirmed, prioritized issues instead of
  initial discovery.
- **Governance and scorecard visibility** — a consistent, org-wide data
  quality scorecard and daily health summary across all teams, on the same
  seven quality dimensions, regardless of how much each team has invested in
  Tier 2 tooling.
- **Near-zero onboarding cost per new team** — Tier 1 gives immediate
  coverage with a UC grant alone; teams graduate to Tier 2 by adding rows to
  the existing shared tables, never by requesting new infrastructure.
