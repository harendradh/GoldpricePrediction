# Lakehouse Monitoring Adoption Roadmap

## Purpose

This document is a forward-looking adoption plan for Databricks Lakehouse
Monitoring (LHM) in this environment. LHM is **not part of the current
build** — it is deferred for one concrete, environment-specific reason (no
Serverless compute), not because it lacks value. This doc records why it's
deferred, exactly what it would change once available, and a phased path to
adopt it without a disruptive cutover or a period of blind trust in a new
system.

Read this alongside `docs/03_GENIE_WORKSPACES.md` (Profiling Intelligence and
Schema Intelligence spaces) and `docs/04_DQX_INTEGRATION.md` (DQX profiler and
inline validation) — LHM's eventual role sits at the intersection of those
two, and this doc is explicit about where it overlaps and where it does not.

## 1. Current-State Gap

**Why Lakehouse Monitoring cannot be adopted today:** LHM's monitor refresh
jobs execute on a managed Serverless SQL warehouse — this is not an optional
configuration, it is how the feature is built. This workspace has **no
Serverless compute available**. That single constraint is the entire reason
LHM is out of scope for the current build, not a judgment about its
usefulness. This mirrors the DQX Studio deferral (`docs/04`) — same root
cause, same "not blocking now" status, different feature.

**What capability gap this leaves, concretely:**

- **No native drift dashboards.** LHM auto-generates a dashboard per
  monitored table showing distribution drift, null-rate trends, and
  numeric-summary drift over time. Without it, drift visibility depends on
  whatever the agent and Genie spaces can synthesize from `data_profile` rows
  and DQX profiler output — useful, but hand-assembled rather than a
  managed, auto-refreshing dashboard artifact.
- **No managed profiling metrics tables.** LHM writes two system-managed
  Delta tables per monitored asset (a profile-metrics table and a
  drift-metrics table) with a stable, documented schema, computed and
  maintained by the platform. Today, the equivalent numbers exist only in
  the team-populated `data_profile` table (Tier 2, opportunistic, team's own
  choice of which columns to profile) and in DQX profiler runs (Tier 1,
  read-only sweep) — neither is a platform-managed, uniformly-scheduled
  metrics table across every asset.
- **No built-in monitor refresh scheduling.** LHM manages its own refresh
  cadence per monitor (time-series, snapshot, or inference-profile mode)
  through the Serverless warehouse. Without it, "refresh" for profiling data
  means a regular job — a scheduled notebook/workflow running DQX's profiler
  or team-authored aggregate SQL — that the DQ platform team owns and
  operates by hand, including its own retry/failure handling.

None of this blocks the agent from being useful today — it means the
profiling and drift-detection story is currently powered by DQX plus
Genie-assisted SQL rather than a managed monitoring service, and that story
is explicitly reactive and job-driven rather than continuously maintained by
the platform.

## 2. What LHM Would Replace or Enhance Once Available

LHM's scope overlaps with two existing pieces of this design. Being precise
about the overlap here matters — LHM is not a general DQ replacement, and
overclaiming its scope would misdirect the roadmap.

### 2.1 Overlap with Profiling Intelligence (Genie space, `docs/03`)

This is the primary overlap. The Profiling Intelligence Genie space today
answers questions like "how has null rate on `orders.customer_id` trended
over the last 30 days" by querying `data_profile` (Tier 2, team-authored) and
DQX profiler output (Tier 1). LHM's profile-metrics table is designed to
answer exactly this class of question, computed automatically rather than
depending on a team having populated `data_profile` or a scheduled DQX
profiler run having executed. Once available, LHM becomes an **additional,
eventually preferred, source** for the Profiling Intelligence space — see
Phase 4 below.

### 2.2 Overlap with Schema Intelligence (Genie space, `docs/03`)

Partial overlap. Schema Intelligence already uses native Unity Catalog
mechanisms — `DESCRIBE HISTORY`, Delta Time Travel, `information_schema` —
per this project's explicit decision not to build a custom schema-snapshot
table (§2 of `CONTEXT_BRIEF.md`). LHM's drift-metrics table adds
statistical distribution drift on top of that (e.g., a categorical column's
value distribution shifting even without a schema change), which is a
complementary signal, not a replacement for the native schema-history
mechanisms already in place. Schema Intelligence keeps `DESCRIBE
HISTORY`/`information_schema` as its source of truth for structural changes
regardless of LHM adoption; LHM would add distribution-level drift on top.

### 2.3 Overlap with DQX's profiler (`docs/04`)

Partial overlap, and this is the distinction to be explicit and honest
about: **LHM does not replace DQX's inline validation or quarantine path.**
DQX's profiler is one part of DQX (used to sample data and auto-suggest
candidate checks); DQX's core value — row/column/dataset-level checks
enforced before or at write time, with quarantine routing — is a proactive,
in-pipeline concern that has no LHM equivalent. LHM is purely reactive: it
profiles data that has already landed, on its own schedule, after the fact.
Adopting LHM narrows what DQX's *profiler* needs to be scheduled for
separately (since LHM would cover routine profiling metrics), but it does
not reduce DQX's role as the inline validation/quarantine layer described in
`docs/04`. Both stay in the architecture; they answer different questions
("is this row good enough to write" vs. "how has this table's distribution
drifted over the last N days").

## 3. Migration Approach — Phased Plan

### Phase 1 — Now (no Serverless available)

DQX plus custom `data_profile`/Genie-generated aggregate SQL cover profiling
reactively, run on standard job clusters via scheduled jobs:

- DQX's profiler runs as part of the Tier-1 zero-onboarding sweep
  (`docs/04`), sampling tables and surfacing candidate checks and basic
  profiling stats.
- Teams that have adopted Tier 2 populate `data_profile` themselves, on
  their own pipeline schedule, for the columns they choose to profile.
- The Profiling Intelligence Genie space synthesizes across both sources,
  always stating which tier a given answer came from (per the
  anti-fabrication non-negotiable in `CONTEXT_BRIEF.md` §8).
- No LHM-specific work happens in this phase. This is the current, shippable
  state of the agent.

### Phase 2 — Serverless becomes available: pilot, dual-run

Once a Serverless SQL warehouse is provisioned in this workspace:

- Stand up Lakehouse Monitoring on a **small pilot set of tables** — a
  handful of production tables already well-covered by DQX profiler output
  and/or `data_profile`, chosen so outputs can be directly compared.
- Configure monitors in the mode appropriate to each table (snapshot,
  time-series, or inference-profile) per its update pattern.
- Run LHM **in parallel** with the existing DQX-profiler/`data_profile`
  path — do not disable or reduce the existing profiling jobs for these
  tables yet. This is a dual-run period, not a cutover.
- Compare LHM's profile-metrics/drift-metrics output against the existing
  DQX/`data_profile` numbers for the same tables and time windows. Look
  specifically for: differing null-rate or cardinality calculations,
  differing sampling behavior (DQX samples ~30%/1000 rows by default;
  LHM typically scans full data), timing/latency differences in when
  numbers become available, and monitor-configuration edge cases (e.g.
  columns LHM can't profile the way the existing path did, or refresh
  cadence mismatches).
- No Genie space or agent-facing answer changes in this phase — this phase
  is validation only, run by the platform team, not yet surfaced to agent
  users.

### Phase 3 — Cut over profiling-heavy tables to LHM-managed monitors

Once Phase 2 comparison shows LHM parity (or an understood, acceptable
delta) for the pilot set:

- Expand LHM monitor coverage to the broader set of profiling-heavy tables
  (tables whose primary DQ need is drift/profiling rather than inline
  validation).
- **Keep DQX for inline validation/quarantine** — this is a distinct job
  from profiling and is not touched by this cutover. DQX continues to run
  its rule checks (completeness, validity, uniqueness, freshness, schema,
  custom checks) exactly as described in `docs/04`; only the *profiling*
  responsibility shifts.
- Retire the redundant parts of the custom profiling SQL path — specifically,
  the scheduled jobs whose only job was computing profiling metrics now
  covered by LHM — for tables where LHM parity has been confirmed. Do this
  table-by-table, not as a single global switch.
- `data_profile` itself is not deprecated as a table in this phase — Tier 2
  teams may still choose to write their own curated profiling rows there;
  what's retired is the *redundant scheduled computation* that duplicates
  what LHM now computes for tables under LHM coverage.

### Phase 4 — Wire LHM into Profiling Intelligence as a preferred source

- Extend the Profiling Intelligence Genie space's table list to include
  LHM's generated profile-metrics and drift-metrics tables for
  LHM-monitored assets.
- For tables under LHM coverage, treat LHM's tables as the **preferred**
  profiling source (analogous to how Tier 2 `team_rule`/`dq_stats` outrank
  Tier 1 DQX findings per `CONTEXT_BRIEF.md` §8) — LHM's numbers are
  platform-computed and continuously refreshed, so they take precedence
  over ad hoc `data_profile` rows for the same table once both exist,
  while `data_profile` and DQX profiler output remain the answer for any
  table not yet under LHM coverage.
- The agent continues to state which source answered a profiling question
  (LHM / `data_profile` / DQX profiler) — the anti-fabrication and
  tier-attribution discipline from `CONTEXT_BRIEF.md` §8 extends to this
  three-way source distinction, it does not get relaxed just because LHM is
  a managed platform feature.

## 4. Operational Benefits Once Adopted

- **Managed metric computation** — null rates, distinct counts, min/max,
  distribution summaries computed and refreshed by the platform; no
  hand-maintained profiling SQL or notebook logic to keep correct as schemas
  evolve.
- **Built-in drift-detection dashboards** — a generated dashboard per
  monitored table, available immediately, instead of the agent/Genie having
  to assemble drift visibility from raw `data_profile`/DQX rows on demand.
  This does not replace agent-driven investigation — it gives the agent (and
  humans) a ready-made visual reference to point to.
- **Automatic monitor refresh scheduling** — the platform manages refresh
  cadence per monitor; the DQ platform team stops owning bespoke job
  scheduling and failure handling for routine profiling refreshes.
  Note this shifts, rather than eliminates, an operational dependency: LHM
  monitors depend on Serverless SQL warehouse availability, so any future
  gap in Serverless capacity becomes a new failure mode to watch for that
  didn't exist under job-cluster-based profiling.
- **Tighter Unity Catalog-native integration** — monitors are UC-native
  objects (attached to a table, governed by UC permissions), consistent with
  this project's "native Databricks first" principle (`CONTEXT_BRIEF.md`
  §8) — no external monitoring tool, no separate access model to reconcile.
- **Lower long-term maintenance burden** — versus a hand-rolled profiling
  SQL/notebook path per team, LHM centralizes the computation once, for
  every table it monitors, maintained by the platform rather than by
  whichever team wrote the original profiling query.

## 5. Risk / Rollback Note

- **Keep the dual-run period (Phase 2) long enough** to catch
  monitor-configuration edge cases — differing sampling assumptions, columns
  LHM handles differently, refresh-timing mismatches — before retiring any
  custom SQL. A short dual-run window that only spans a few refresh cycles
  is not sufficient evidence of parity; span enough cycles to see the
  table's normal volume/schema variability at least once.
- **Do not delete the interim profiling path (DQX profiler scheduling /
  custom `data_profile` population jobs) until LHM parity is signed off by
  the owning team** for that specific table. Sign-off is per-table, not a
  single global go/no-go — a table with unusual profiling requirements may
  need to stay on the interim path even after most tables have cut over.
- If a cut-over table shows a regression after Phase 3 (e.g., LHM's monitor
  configuration turns out not to capture something the custom SQL did), the
  rollback is to re-enable the retired scheduled job for that table's
  profiling metrics and resume dual-run investigation — the custom SQL path
  should not be deleted outright, only deprioritized, until this kind of
  rollback risk is judged acceptably low by the owning team.
- DQX's inline validation/quarantine jobs are never part of this rollback
  question — they are a separate system from profiling and are unaffected by
  any LHM adoption or rollback decision.
