# Snapshot Pattern Mapping — "Building a Data Quality Agent: From Idea to End-to-End Architecture"

## What the Article's Pattern Actually Is

The referenced infographic describes a data-quality architecture built around
an ADLS ingestion layer feeding a Collibra-defined schema/metadata catalog,
followed by a chain of purpose-built LLM agents: a schema-based rule
generator agent (infers checks from column types/constraints), a
description-based rule generator agent (infers checks from business/column
descriptions), a chief rule aggregator agent that reconciles and deduplicates
the outputs of the two generators, an LLM/NLP rule synthesis step that turns
natural-language rule intent into structured rule definitions, a rule-based
code generator agent and a separate Python function generator that turn
structured rules into executable checks, a chief function-rule matcher agent
that pairs generated functions back to the rules they implement, a "Data
Fixer Tool" that proposes intrinsic fixes (in-place corrections, e.g.
trimming, casting, standardizing) and extrinsic fixes (external
lookups/enrichment), and a persistence/reporting layer of Delta tables plus
dashboards. This is a legitimate, coherent pattern — it is what you build when
your metadata catalog (Collibra), your ingestion layer (ADLS), and your rule
execution engine are all separate, un-integrated systems that need custom
agents glued between them to move information from one to the next. Every
stage in the chain exists to bridge a gap between tools that don't natively
talk to each other.

## Side-by-Side Mapping

| Article's Component | This Project's Equivalent | Why the Equivalent Is Simpler/Native Here |
|---|---|---|
| ADLS ingestion layer | Unity Catalog tables (Delta Lake), already the system of record | No separate ingestion/landing layer needed — the agent and DQX read UC tables directly via `SELECT`; there is no "get the data into the metadata system" step because Databricks already is the metadata system (`information_schema`, Delta transaction log). |
| Collibra schema/metadata definitions | `information_schema`, Delta table history (`DESCRIBE HISTORY`), and Unity Catalog column/table metadata | Schema metadata is already first-class in UC — no external catalog to sync or reconcile against; Schema Intelligence (Genie space 4) queries it live, so there is no drift between "what Collibra says the schema is" and "what the table actually is." |
| Schema-based rule generator agent | DQX's built-in data profiler + candidate-check generation, sampling tables (default 30%/1000 rows) to auto-propose checks | This is a shipped DQX capability, not custom code to build or maintain — one library call against a UC table produces the same class of schema-inferred candidate rules the article's bespoke agent was built to produce. |
| Description-based rule generator agent | The DQ agent's own reasoning over `team_rule.rule_description`, `business_context`, and `data_profile` content inside the relevant Genie space(s) | The agent already has read access to human-authored rule descriptions and business context in `team_rule`; synthesizing candidate rules from that text is a reasoning step the single agent performs in-line, not a separate agent with its own orchestration and hand-off contract. |
| Chief rule aggregator agent | The DQ agent's own system-instruction-level synthesis step, reconciling DQX (Tier 1) findings against `team_rule`/`data_profile` (Tier 2) | Aggregation across sources is one synthesis pass by the single agent, governed by one fixed precedence rule (human-curated Tier 2 always outranks AI-inferred Tier 1) — no inter-agent hand-off protocol, no separate aggregator to keep in sync with the generators it aggregates. |
| LLM/NLP rule synthesis | Same reasoning step, folded into Rule Discovery & Explanation and Rule Recommendation capabilities | Natural-language rule intent is interpreted directly against the shared schemas already defined in `team_rule`/`dq_stats`/`data_profile` — no separate synthesis stage with its own output format to reconcile with downstream code generation. |
| Rule-based code generator agent | DQX check YAML/JSON/Python DataFrame API (already the native rule-expression formats) | DQX already expresses checks as SQL/Python/YAML — there is no gap between "a rule was decided" and "a rule is expressed as executable code" that needs a bespoke generator; the agent's recommendation output is already valid DQX check syntax. |
| Python function generator | Same DQX check expressions (Python predicate or `rule_expression` in `team_rule`) | `team_rule.rule_expression` already accepts a SQL or Python predicate directly — no separate function-generation stage producing artifacts that then need matching back to a rule. |
| Chief function-rule matcher agent | Not needed — DQX checks and `team_rule` rows carry their own identity (`rule_id`, check name) end to end | Because code generation and rule definition are the same artifact here (not two artifacts produced by two agents), there is nothing to "match" — the matching problem only exists because the article's architecture generates rules and functions in separate stages. |
| "Data Fixer Tool" (intrinsic/extrinsic fixes) | Recommendation-only remediation output: a proposed SQL snippet or DQX quarantine-routing config, always human-applied | Deliberately reduced in scope, not a missing capability — see verdict below. |
| Delta tables + dashboards | `team_rule`, `dq_stats`, `data_profile`, `dqx_results`, plus a scorecard view/dashboard (Data Quality Scorecard, Daily Health Summary capabilities) | Already the native persistence and BI layer for this stack — no additional reporting tier to stand up. |

## Verdict: Can It Be Used Here?

The underlying **pattern** — multi-stage rule generation, aggregation across
sources, translation into executable checks, automated fix suggestion, and
dashboarding — is directly applicable, and this design already implements it.
Every stage of the article's chain maps onto a native Databricks capability or
a single reasoning step inside one agent, as shown above.

The article's **literal architecture** — five or more separate custom agents,
an ADLS ingestion layer, and a Collibra metadata catalog — should **not** be
replicated in this environment. Doing so would mean building and maintaining
custom orchestration to solve integration problems (moving metadata from
Collibra to a rule generator, moving generated rules to a function generator,
matching functions back to rules) that simply do not exist when Unity
Catalog, DQX, and Genie already share one metadata surface and one rule
expression format. Replicating the five-agent chain here would add
maintenance surface — more agents to prompt-engineer, more hand-off contracts
to keep in sync, more failure points — for zero net new capability. This is a
recommendation, not a hedge: build the one-agent-plus-8-Genie-spaces-plus-DQX
design described in this project, not the article's multi-agent chain.

## Rule Generation and the "Data Fixer Tool" — Already Covered, Deliberately Scoped

The article's entire rule-generator-agent chain (schema-based generator +
description-based generator + chief aggregator + LLM/NLP synthesis) exists to
produce candidate rules from two sources: table structure and business
description. This design's **Rule Discovery & Explanation** and **Rule
Recommendation** capabilities already deliver both of those inputs — DQX's
profiler supplies the schema-based signal, and the agent's reasoning over
`team_rule.rule_description`/`business_context` supplies the description-based
signal — synthesized by one agent instead of four. Nothing in the article's
rule-generation chain represents a capability gap in this design.

The "Data Fixer Tool" concept (intrinsic fixes like trimming/casting/
standardizing, and extrinsic fixes like external lookups/enrichment) is
intentionally reduced here to **recommendation-only** output: the agent
proposes a remediation SQL snippet or a DQX quarantine-routing config, and a
human reviews and runs it. The agent never writes to `team_rule`, `dq_stats`,
`data_profile`, `dqx_results`, or any production table. This is a deliberate
scope choice driven by this design's **AI-assisted, not AI-autonomous**
non-negotiable, not a gap relative to the article: an agent that
autonomously applies intrinsic/extrinsic fixes to production data is exactly
the failure mode this design is built to avoid, given hundreds of data
products and thousands of pipelines where an incorrect automated fix would be
far more costly than a slower, human-approved one. The value of the article's
Data Fixer Tool — proposing what the fix should be — is fully retained; only
the auto-apply step is withheld, and it is withheld on purpose.
