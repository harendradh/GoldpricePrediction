# Agent Capabilities Reference

This document is a capability-by-capability reference for the Data Quality AI
Agent, not an architecture narrative (see `01_ARCHITECTURE.md` for that). Each
capability below states what it does, which Genie space(s) and/or tier it
draws on, and a short realistic example of the agent's output. Tier 1 =
DQX zero-onboarding sweep (AI-inferred). Tier 2 = `team_rule`/`dq_stats`/
`data_profile` (human-curated, always takes precedence over Tier 1 when both
exist for the same table/rule). The 8 Genie spaces are: Rule Intelligence,
Profiling Intelligence, DQ Execution Analytics, Schema Intelligence,
Freshness Intelligence, Volume Intelligence, Lineage & Impact Analysis, and
Governance Intelligence.

## Root Cause Analysis

Cross-references execution history, rule definitions, profiling drift,
schema changes, and lineage impact in a single pass to explain *why* a
quality metric moved, not just that it moved. Draws on DQ Execution
Analytics, Profiling Intelligence, Schema Intelligence, and Lineage & Impact
Analysis together; sources from both Tier 1 and Tier 2 depending on what
exists for the table. Every explanation is grounded in what was actually
found — never fabricated.

> "`orders.total_amount` validity failures jumped from 0.2% to 4.8% starting
> 2026-07-14. Cause: an upstream schema change on `raw_orders.currency_code`
> (VARCHAR(3) → VARCHAR(10), committed 2026-07-13 per Delta history)
> introduced non-ISO currency codes that fail the existing range check.
> Confidence: High (Tier 2 rule + confirmed schema commit)."

## Intelligent Investigation

Runs a multi-step, agent-driven investigation across multiple Genie spaces
in response to an open-ended question, deciding which spaces to query and
in what order rather than requiring the user to specify a dimension or
table up front. Spans all 8 Genie spaces as needed; tier is stated per
finding. This is the general-purpose reasoning loop the more specific
capabilities below plug into.

> "You asked about `customer_360` health this week. Checked DQ Execution
> Analytics (2 rule failures, both LOW severity), Freshness Intelligence (no
> delay), and Volume Intelligence (normal). No action needed — table is
> healthy."

## Rule Discovery & Explanation

Surfaces which rules exist for a table/column (Tier 2, `team_rule`) and/or
which DQX checks would apply (Tier 1), and explains each rule's intent in
plain language using `rule_description`/`business_context`. Draws on Rule
Intelligence (Tier 2) and DQX check metadata (Tier 1).

> "3 active rules on `payments.amount` (Tier 2): CRITICAL not-null check,
> HIGH range check (0–1,000,000), MEDIUM currency-code validity check. Tier
> 1 DQX also flags 2 additional candidate checks (uniqueness on
> `payment_id`, freshness) not yet promoted to `team_rule`."

## Rule Recommendation (AI-assisted, never auto-deployed)

Proposes new or adjusted rules — as ready-to-review DQX check YAML or a
`team_rule` INSERT statement — based on DQX profiler output and/or observed
failure patterns. Always includes rationale and confidence. Draws on Rule
Intelligence and Profiling Intelligence. Never writes to `team_rule` or any
production table; a human must review and apply.

> "Recommend adding a completeness check on `shipments.tracking_number`
> (null_pct rose from 1% to 12% over 14 days per profiling data). Suggested
> `team_rule` INSERT provided below — human review required before
> insertion."

## Profiling Analysis

Reports column-level statistics — null rate, distinct count, min/max,
distribution, cardinality — for a table/column, and flags values that look
anomalous relative to prior profiling runs. Draws on Profiling Intelligence
(Tier 2 `data_profile` when populated, Tier 1 DQX profiler otherwise).

> "`users.email` (Tier 1, DQX profiler): null_pct 0.3%, distinct_count
> 482,110, cardinality_ratio 0.99 — consistent with prior 30-day baseline,
> no anomaly."

## Historical Trend Analysis

Plots or narrates how a metric (pass rate, null rate, row count, rule
failures) has moved over a date range, distinguishing a one-off blip from a
sustained trend. Draws on DQ Execution Analytics and Profiling Intelligence,
querying `dq_stats`/`data_profile` history or `dqx_results` history.

> "`inventory.on_hand_qty` pass rate: 99.1% (Jun), 98.7% (early Jul), 91.2%
> (last 7 days) — a sustained decline, not a one-day spike. Recommend
> prioritizing root cause analysis."

## Data Freshness Analysis

Checks whether a table's latest data is as recent as expected, using
`freshness_last_updated_ts` (Tier 2) and/or DQX temporal/freshness checks
and `system.lakeflow.job_run_timeline` (Tier 1). Draws on Freshness
Intelligence.

> "`daily_sales_summary` last updated 2026-07-15 06:02 UTC; expected daily
> by 05:00 UTC. 22-hour delay detected — upstream job
> `sales_ingest_daily` shows a FAILED run at 2026-07-16 04:58 UTC
> (Tier 1, DQX + lakeflow system table)."

## Volume Anomaly Detection

Compares current row counts / ingestion volume against historical baselines
to flag unexpected spikes or drops. Draws on Volume Intelligence, using
`dq_stats.input_record_count` (Tier 2) or DQX volume checks (Tier 1).

> "`clickstream_events` row count today: 1.2M vs. 14-day average of 8.4M — a
> 86% drop. Flagged as a volume anomaly, severity HIGH pending root cause."

## Duplicate Detection

Identifies duplicate or near-duplicate rows based on uniqueness rules
(Tier 2 `team_rule` with `quality_dimension_tag = Uniqueness`) or DQX's
built-in uniqueness/foreign-key checks (Tier 1). Draws on Rule Intelligence
and DQ Execution Analytics.

> "`customer_master` uniqueness check on `customer_id` (Tier 2, CRITICAL):
> 47 duplicate `customer_id` values found in yesterday's run, up from 2 the
> day before."

## Missing Data Investigation

Investigates elevated null rates or absent expected records, distinguishing
a genuine data quality issue from an expected pattern (e.g. a nullable
column by design). Draws on Profiling Intelligence and Rule Intelligence.

> "`orders.discount_code` null_pct is 68% — checked `team_rule`: no
> completeness rule exists for this column, and `rule_description` on a
> related rule notes discounts are optional. Likely expected, not a defect."

## Schema Drift Detection

Detects column additions, removals, type changes, and other schema changes
using native Delta/UC history (`DESCRIBE HISTORY`, Delta Time Travel,
`information_schema`) — no custom schema-snapshot table. Draws on Schema
Intelligence.

> "`raw_orders` schema change detected: `currency_code` widened from
> VARCHAR(3) to VARCHAR(10) on 2026-07-13, commit version 482 (Delta
> history). No column additions/removals in the last 30 days."

## Lineage & Impact Analysis

Traces upstream/downstream table and column dependencies using
`system.access.table_lineage`/`column_lineage` to answer "what breaks if
this table's quality drops" or "where did this bad value come from." Draws
on Lineage & Impact Analysis. Never asserts a lineage relationship without
an actual lineage-space result.

> "`orders.total_amount` feeds 3 downstream tables: `finance.daily_revenue`,
> `analytics.customer_ltv`, `reporting.exec_dashboard_summary` (per
> `system.access.table_lineage`). A quality drop here has confirmed
> downstream impact on all three."

## SQL-Based Recommendations

Produces literal, runnable SQL — a `team_rule` INSERT, a diagnostic SELECT,
or a DQX YAML check — as part of a recommendation, so a human can review and
apply it directly rather than translate the agent's prose into code. Draws
on Rule Intelligence and DQX check metadata; output is always
human-reviewed, never auto-executed.

> "Suggested diagnostic query to confirm the duplicate `customer_id` finding:
> `SELECT customer_id, COUNT(*) FROM customer_master GROUP BY customer_id
> HAVING COUNT(*) > 1;` — run and review before any remediation."

## Daily Health Summary

Produces a daily, org-wide narrative summary of quality status across
monitored tables — new failures, resolved issues, freshness delays, volume
anomalies — stating which tier answered each item. Draws on all 8 Genie
spaces, primarily DQ Execution Analytics and Governance Intelligence.

> "Daily Health Summary, 2026-07-16: 214 tables monitored (Tier 1: 189,
> Tier 2: 25). 3 new CRITICAL failures (all Tier 2), 1 freshness delay
> (Tier 1), 0 unresolved volume anomalies from yesterday."

## Data Quality Scorecard

Presents a consistent, org-wide quality score across all monitored tables
on the same seven quality dimensions (Completeness, Validity, Consistency,
Uniqueness, Timeliness, Volume, Schema Drift), regardless of each team's
Tier 2 investment. Draws on Governance Intelligence, aggregating `dq_stats`/
`dqx_results` across all teams.

> "`finance` domain scorecard: Completeness 98.2%, Validity 96.7%,
> Uniqueness 99.9%, Timeliness 94.1%, Volume 99.0%, Schema Drift stable
> (0 unreviewed changes in 30 days). Overall: Healthy."

## Confidence Scoring

Attaches a confidence level (e.g. High/Medium/Low) to every finding,
root-cause explanation, and recommendation, based on tier (Tier 2
human-curated outranks Tier 1 AI-inferred), corroboration across Genie
spaces, and data completeness (e.g. `NOT_RUN` never counted as evidence).
Applies to every capability above, not a separate Genie space.

> "Confidence: Medium — Tier 1 DQX flags a validity drop, but no
> corroborating Tier 2 rule exists for this column and lineage data is
> incomplete for the relevant upstream table."

## Explainability

Every agent response states its reasoning path explicitly: which Genie
space(s) were queried, which tier answered, what evidence was found (or not
found), and why a conclusion follows from that evidence — so a user can
verify the answer rather than take it on faith. Applies across all
capabilities; this is a response-shape guarantee, not a separate space.

> "Answer based on: DQ Execution Analytics (Tier 2, `dq_stats` rows for
> 2026-07-14 to 2026-07-16) + Schema Intelligence (Delta history commit
> version 482). No lineage query was needed for this question, so no
> lineage claim is made."
