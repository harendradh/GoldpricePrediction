# Context Brief — Ground Truth for This Build

This is the single source of truth for every doc in this project. Every writing
task must stay consistent with what's below — do not invent table names,
column names, or architectural decisions that contradict this file.

## 0. What this project is

A metadata-driven, modular, reusable Data Quality AI Agent for **DCS Agent
Studio**, onboarding alongside other teams' already-live agents. Target scale:
hundreds of data products, thousands of pipelines, multi-team from day one.
Platform: Databricks Lakehouse, Unity Catalog, Delta Lake, Genie, SQL
Warehouses — **no Serverless compute available yet**. Agent runs on the
Databricks-hosted Claude endpoint inside DCS Agent Studio.

This is a **fresh, standalone deliverable** — not a continuation of any prior
repo. Design it to be portable/reusable across engagements: illustrative
generic schemas below, not hard-coded to one team's exact production naming.

## 1. The three metadata tables (as given by the user — use these exact names/columns)

All three are **shared, multi-tenant tables** — one physical table each,
filtered by `team_name`/`catalog_name`/`schema_name`/`table_name`, NOT
per-team physical copies. This is deliberate: it's what makes the design
metadata-driven and horizontally scalable to hundreds of teams without a new
table per onboarding.

### 1.1 `team_rule` — business rules (human-authored, per-team)
Multiple teams can define different business rules against the *same*
physical table. These are business rules only — not generic completeness/
validity checks (those come from Tier 1 / DQX, see §3).

Illustrative columns:
`rule_id, team_name, catalog_name, schema_name, table_name, column_name
(nullable), rule_name, rule_description, business_context, rule_expression
(SQL or Python predicate), quality_dimension_tag (Completeness/Validity/
Consistency/Uniqueness/Timeliness/Volume/SchemaDrift/Custom — human-set,
nullable), severity (CRITICAL/HIGH/MEDIUM/LOW), action_if_failed (REJECT/
QUARANTINE/FLAG/ALERT_ONLY), is_active, effective_from_date,
effective_to_date, created_by, created_at, updated_by, updated_at`

### 1.2 `dq_stats` — execution metadata
One row per rule-execution run. Columns: `execution_id, job_name,
pipeline_name, workflow_run_id, team_name, catalog_name, schema_name,
table_name, execution_timestamp, execution_date, status (SUCCESS/FAILED/
PARTIAL/NOT_RUN), input_record_count, rules_evaluated_count,
rules_passed_count, rules_failed_count, failed_rule_ids (array<string>),
pass_rate_pct, duration_seconds, error_message (nullable)`.

**Anti-fabrication non-negotiable (carry into every doc that touches
execution results):** `NOT_RUN` and any missing/no-result state must never be
reported as `PASS`. A rule absent from today's `dq_stats` rows is "did not
run," never "passed."

### 1.3 `data_profile` — profiling metrics
Different teams may profile different columns of the same physical table
(genuinely fragmented by team choice, not just by table). Columns:
`profile_id, team_name, catalog_name, schema_name, table_name, column_name,
profile_date, null_pct, distinct_count, min_value, max_value,
distribution_summary (JSON histogram), cardinality_ratio,
freshness_last_updated_ts, row_count_at_profile_time`.

### 1.4 Cold start — a team without these tables yet
**Decision:** do NOT force every team onto a bootstrap-and-insert workflow
before the agent is useful. Two tiers, always both available:

- **Tier 1 (zero onboarding, always on):** DQX (see §3) runs read-only
  against ANY Unity Catalog table the agent has SELECT on — no `team_rule`/
  `dq_stats`/`data_profile` rows required at all. DQX's own profiler +
  built-in checks (completeness, validity, uniqueness, freshness, schema)
  cover a team from day zero with only a UC grant, no pipeline changes, no
  new tables for that team to populate. DQX writes its own results to a
  DQ-team-owned central results table (`dqx_results` — see §3), never into
  the team's `team_rule`/`dq_stats`.
- **Tier 2 (richer, opportunistic):** when a team already has rows in
  `team_rule`/`dq_stats`/`data_profile`, those are preferred and corroborate
  or override Tier 1 findings (human-curated always outranks AI-inferred).

The agent must always state which tier answered a question. This directly
answers the brief's "if a team doesn't have these tables yet" — the answer is
DQX, not a new custom onboarding table (the one exception being
`dq_control_table` itself — see §3 — which is a one-row-per-source
onboarding switch, not a bootstrap-and-insert workflow like `team_rule`/
`dq_stats`/`data_profile`).

## 2. Genie workspace decision: 8 spaces (user's explicit choice)

The user was told a 4-space, domain-grouped design is also valid (a Genie
space supports ~30 tables and reaches beyond its list via UC permissions), and
explicitly chose to keep **8 dimension-named spaces** instead, matching their
original ask exactly:

1. Rule Intelligence
2. Profiling Intelligence
3. DQ Execution Analytics
4. Schema Intelligence
5. Freshness Intelligence
6. Volume Intelligence
7. Lineage & Impact Analysis
8. Governance Intelligence

Each space is still scoped narrowly (small fixed table list + guardrails) —
that discipline doesn't depend on the space count. Use native Unity Catalog
history for schema drift (`DESCRIBE HISTORY`, Delta Time Travel,
`information_schema`) — do **not** invent a custom `dq_schema_snapshot` table;
Delta's transaction log already stores a full schema snapshot at every
commit, so no custom snapshot table is needed for Schema Intelligence.

## 3. DQX — verified findings (from live 2026 research, cite these, don't re-derive)

- **What it is:** `databricks-labs-dqx`, a Python library (pip/Databricks
  Labs CLI install) with a `DQEngine` API you call from your own notebooks/
  jobs/DLT pipelines. Not a hosted service. Also has a no-code path (YAML/JSON
  + CLI) and an optional serverless-only web UI, **DQX Studio** (skip
  initially — avoids the serverless requirement).
- **License:** source-available under a proprietary Databricks Labs license
  (not OSI open source), and explicitly **not officially supported** — an
  exploration/labs project, no SLA. Flag this as a governance/support
  consideration, not a blocker.
- **Minimal-copy, read-only pattern — CONFIRMED FEASIBLE.** DQX reads a
  source table into a DataFrame, runs checks, and writes results only to
  separately configured `output_config`/`quarantine_config`/`metrics_config`
  destinations. It never writes back to the source table. A central DQ-owned
  job only needs SELECT on other teams' UC tables plus write access to its
  own results schema — **no other team's pipeline code changes at all.**
  Wildcard/parameterized run-configs let one shared job iterate over many
  teams' tables.
- **Serverless — NOT required for the core engine.** Runs on standard job
  clusters (Spark ≥3.5.0, DBR ≥15.4 recommended). Only DQX Studio (the
  no-code UI) requires serverless — deliberately deferred, same as Lakehouse
  Monitoring (§5).
- **Core capabilities:** 50+ built-in checks (nullability/completeness,
  range/pattern/regex validity, uniqueness, foreign-key, PII detection,
  temporal/freshness, dataset comparison, schema checks incl. ODCS data
  contracts), custom SQL/Python expression checks, rules as Python DataFrame
  API or YAML/JSON (local, Workspace, UC Volume, or table rows), a data
  profiler that samples tables (default 30%/1000 rows) to auto-generate
  candidate rules, row/column/dataset-level pre-commit and post-factum
  validation. v0.15.0 (current) adds ML anomaly detection with SHAP/LLM
  explanations — **enabled by default, incurs Model Serving cost** — flag as
  a cost-control setting to disable/gate explicitly in the adoption doc.
- **Relationship to Lakehouse Monitoring:** complementary, not competing. DQX
  = proactive inline validation/quarantine before/at write time (custom Spark
  jobs) or via DLT Expectations (DLT pipelines). Lakehouse Monitoring =
  reactive periodic drift/profiling on already-persisted tables. Recommended
  layering: DLT Expectations for DLT pipelines, DQX for custom Spark jobs
  and for the Tier-1 zero-onboarding sweep, Lakehouse Monitoring later for
  periodic reactive profiling once serverless is available.
- **Adoption pattern to document:** a shared job-cluster workflow, packaged
  as an installable Python framework (`dq-dqx-framework` under `dqx/`),
  owned by the central DQ team; SELECT grants on target teams' UC tables/
  paths/schema files; a central **control master table**,
  `dq_catalog.dq_config.dq_control_table`, where a team's entire onboarding
  action is adding **one row** naming their source (`source_type`:
  `DELTA_TABLE` / `PARQUET_PATH` / `AVSC_SCHEMA`) — no wildcard pattern or
  checks array to author; `checks_override` stays `NULL` to run the DQX
  Module's full default built-in suite. Writes only to three DQ-owned,
  explicitly-schema'd tables in `dq_catalog.dq_results`
  (`dqx_results`/`dqx_quarantine`/`dqx_run_metrics` — see
  `dqx/ddl/dqx_metadata_tables_ddl.sql`); `dqx_results` mirrors `dq_stats`
  shape so the Execution Analytics Genie space can query both uniformly.
  Pin the DQX version; this is pre-1.0 with real breaking changes between
  releases (e.g. v0.15.0 changed anomaly-detection defaults and the
  `_dq_info` schema) — review changelogs before upgrading.
- Sources: github.com/databrickslabs/dqx (README, LICENSE),
  databrickslabs.github.io/dqx (Motivation, Installation, User Guide, Apply
  Quality Checks, DQX Studio), github.com/databrickslabs/dqx/releases
  (v0.15.0), pypi.org/project/databricks-labs-dqx.

## 4. The snapshot article — pattern to extract, not tools to copy

The user attached an infographic ("Building a Data Quality Agent: From Idea
to End-to-End Architecture") built on ADLS + Collibra + a multi-agent
rule-generation chain (schema-based rule generator agent, description-based
rule generator agent, chief rule aggregator, LLM/NLP rule synthesis,
rule-based code generator agent, Python function generator, chief
function-rule matcher agent, a "Data Fixer Tool," Delta tables + dashboards).

**Decision (user-confirmed):** extract the *pattern*, not the tools. This
environment is Unity-Catalog-native — no ADLS ingestion layer, no Collibra.
Map the article's useful ideas onto the real stack:
- "Rule Generator Agents" (schema-based / description-based) → this is what
  DQX's **profiler + candidate-check generation** already does natively,
  plus the agent's own reasoning over `information_schema` +
  `team_rule`/`data_profile` content — no separate bespoke rule-generator
  agent needed.
- "Chief Rule Aggregator Agent" → the DQ agent's own system-instruction-level
  synthesis step across the 8 Genie spaces + DQX results — not a separate
  agent/tool.
- "Rule-Based Code Generator" / "Python-Based Function Generator" → DQX
  already expresses checks as SQL/Python/YAML; the agent's recommendation
  output includes ready-to-review DQX check YAML or `team_rule` INSERT SQL,
  always human-reviewed, never auto-deployed (AI-assisted, not
  AI-autonomous — non-negotiable, matches the "Rule Recommendation" capability
  in §Agent Capabilities).
- "Data Fixer Tool" (intrinsic/extrinsic fixes) → represented as a
  **recommendation-only** capability: the agent proposes a remediation SQL
  snippet or DQX quarantine-routing config; a human runs it. The agent never
  writes to production tables.
- "Delta Tables + Dashboards" → already native (`team_rule`, `dq_stats`,
  `data_profile`, `dqx_results` + a scorecard view/dashboard).

Net effect: the snapshot's five-agent chain collapses to **one agent + 8
Genie spaces + DQX**, because Genie/DQX/UC already provide natively what that
generic pattern built by hand. State this explicitly in
`docs/06_SNAPSHOT_PATTERN_MAPPING.md` as a side-by-side comparison table.

## 5. Lakehouse Monitoring

Deferred today — **no Serverless compute in this workspace**, and Lakehouse
Monitoring requires it. Document: current-state gap, what LHM would replace
once available (much of the Tier-1 profiling/drift sweep), a migration
approach (parallel-run, then cutover), and operational benefits (native
drift dashboards, less custom profiling SQL, tighter UC integration). This
mirrors the DQX Studio deferral — same root cause, same "not blocking now."

## 6. Quality dimensions (7, use these exact 7 — not 13)

Completeness, Validity, Consistency, Uniqueness, Timeliness, Volume, Schema
Drift. Every dimension doc/section must include: business problem, detection
approach, investigation workflow, root cause strategy, AI reasoning,
recommendation, example user questions.

## 7. Agent capabilities to cover (used by docs/07 and agent_studio/*)

Root Cause Analysis, Intelligent Investigation, Rule Discovery & Explanation,
Rule Recommendation (AI-assisted, never auto-deployed), Profiling Analysis,
Historical Trend Analysis, Data Freshness Analysis, Volume Anomaly Detection,
Duplicate Detection, Missing Data Investigation, Schema Drift Detection,
Lineage & Impact Analysis, SQL-Based Recommendations, Daily Health Summary,
Data Quality Scorecard, Confidence Scoring, Explainability.

## 8. Non-negotiables (repeat in every relevant doc)

- Anti-fabrication: NOT_RUN/NO_RESULT ≠ PASS, no invented tables/columns/
  values, no lineage claim without an actual lineage-space result.
- AI-assisted, not AI-autonomous: recommends with SQL/YAML + rationale; never
  writes to `team_rule`, `dq_stats`, `data_profile`, or any production table.
- Native Databricks first: Unity Catalog, information_schema, Delta history,
  lineage system tables, Genie, DQX, AI Functions — no external tooling
  unless strongly justified (none is, in this design).
- Human-curated (Tier 2) always outranks AI-inferred (Tier 1/DQX) when both
  exist for the same table/rule.

## 9. Project layout (write into these exact paths)

```
docs/00_EXECUTIVE_SUMMARY.md
docs/01_ARCHITECTURE.md
docs/02_QUALITY_DIMENSIONS.md
docs/03_GENIE_WORKSPACES.md
docs/04_DQX_INTEGRATION.md
docs/05_LAKEHOUSE_MONITORING_ADOPTION.md
docs/06_SNAPSHOT_PATTERN_MAPPING.md
docs/07_AGENT_CAPABILITIES.md
docs/08_ONBOARDING_RUNBOOK.md
docs/presentations/   (diagrams + Word doc, built separately)
agent_studio/agent_config.md
agent_studio/system_instruction.md
agent_studio/tools_manifest.md
rag/business_glossary.md
rag/dimension_playbooks.md
rag/historical_incident_patterns.md
rag/dqx_reference.md
dqx/ (sample YAML check configs + a central job notebook template — illustrative code, not deployed)
evals/eval_cases.md
README.md
```
