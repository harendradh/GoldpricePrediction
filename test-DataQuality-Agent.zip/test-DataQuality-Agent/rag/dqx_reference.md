# DQX Reference (RAG-Optimized)

Condensed retrieval reference for `databricks-labs-dqx`, distilled from
`CONTEXT_BRIEF.md` §3 (which is the verified source — see it for full
citations). Written as short, self-contained bullet chunks so each point can
be retrieved independently without needing surrounding paragraphs.

---

## What DQX is

- DQX (`databricks-labs-dqx`) is a Python library, installed via pip or the
  Databricks Labs CLI — it is not a hosted service.
- It exposes a `DQEngine` API called from your own notebooks, jobs, or DLT
  pipelines.
- It also supports a no-code path: rules defined in YAML/JSON, run via CLI.
- An optional web UI, **DQX Studio**, exists but requires serverless
  compute — deferred in this environment since no serverless is available
  yet (same reason Lakehouse Monitoring is deferred).
- License: source-available under a proprietary Databricks Labs license
  (not OSI open source).
- Governance status: explicitly **not officially supported** by
  Databricks — it is an exploration/labs project with no SLA. Treat this as
  a governance/support consideration to flag, not a reason to avoid it.
- It powers **Tier 1** coverage: zero-onboarding, read-only checks against
  any Unity Catalog table the agent has SELECT on, with no `team_rule` /
  `dq_stats` / `data_profile` rows required.

---

## Built-in check categories (50+ checks total)

- Nullability / completeness checks.
- Range, pattern, and regex validity checks.
- Uniqueness checks.
- Foreign-key checks.
- PII detection checks.
- Temporal / freshness checks.
- Dataset comparison checks (compare one dataset/snapshot to another).
- Schema checks, including support for ODCS data contracts.
- Custom checks expressible as SQL or Python expressions when a built-in
  check doesn't cover a specific business need.
- Checks can be authored as a Python DataFrame API, or as YAML/JSON stored
  locally, in a Workspace, in a UC Volume, or as rows in a table.

---

## How the profiler generates candidate rules

- DQX includes a data profiler that samples a table — default sampling is
  30% of rows or 1,000 rows (whichever applies per its sampling logic).
- From that sample, the profiler automatically generates **candidate
  checks** (proposed rules) based on observed patterns in the data — this
  is what replaces a bespoke "rule generator agent" in this design (see
  `CONTEXT_BRIEF.md` §4).
- v0.15.0 (current as of the verified research) adds ML-based anomaly
  detection with SHAP/LLM-generated explanations for flagged anomalies.
- Candidate rules from the profiler are inputs to a human review step —
  consistent with the "AI-assisted, not AI-autonomous" non-negotiable, they
  are never auto-deployed into `team_rule` without review.

---

## Zero-copy, read-only integration pattern

- DQX reads a source table into a DataFrame, runs its checks, and writes
  results **only** to separately configured destinations:
  `output_config`, `quarantine_config`, and `metrics_config`.
- It never writes back to the source table — this is what makes the
  pattern "minimal-copy, read-only" and CONFIRMED FEASIBLE per the brief.
- A central DQ-owned job needs only SELECT grants on other teams' UC
  tables, plus write access to its own results schema.
- No other team's pipeline code needs to change at all for Tier 1 coverage
  to apply to their tables.
- A shared control master table (one row per onboarded source) lets one
  shared job iterate over many teams' tables/files without a separate job
  per team, and without a team needing to author anything beyond that one
  row.
- Results land in a DQ-team-owned central table, `dqx_results`, which
  mirrors the shape of `dq_stats` so the DQ Execution Analytics Genie space
  can query Tier 1 and Tier 2 results uniformly.
- Runs on standard job clusters (Spark ≥3.5.0, DBR ≥15.4 recommended) — the
  core engine does **not** require serverless compute. Only DQX Studio (the
  no-code UI) requires serverless.

---

## Cost, governance, and version-stability gotchas

- **ML anomaly detection cost:** v0.15.0's ML-based anomaly detection is
  **enabled by default** and incurs Model Serving cost. This should be
  flagged explicitly as a cost-control setting to disable or gate in any
  adoption/rollout documentation — don't let it run silently and rack up
  Model Serving charges.
- **Not officially supported:** DQX is a Databricks Labs project, not a
  fully supported product — no SLA, source-available (not OSI) license.
  Flag as a governance/support risk to accept knowingly, not a reason to
  block adoption.
- **Pre-1.0 API churn:** DQX is pre-1.0 with real breaking changes between
  releases — for example, v0.15.0 changed both the anomaly-detection
  defaults and the `_dq_info` schema. Pin the DQX version in use, and
  review changelogs before any upgrade rather than auto-upgrading.
- **Relationship to Lakehouse Monitoring:** complementary, not competing.
  DQX = proactive inline validation/quarantine at or before write time
  (custom Spark jobs, or via DLT Expectations for DLT pipelines).
  Lakehouse Monitoring = reactive periodic drift/profiling on already
  persisted tables. Recommended layering: DLT Expectations for DLT
  pipelines, DQX for custom Spark jobs and the Tier-1 zero-onboarding
  sweep, Lakehouse Monitoring later (once serverless is available) for
  periodic reactive profiling.
- **Adoption pattern:** a shared job-cluster workflow (the `dq-dqx-framework`
  package under `dqx/`) owned by the central DQ team; SELECT grants on
  target teams' sources; a central **Delta table** control master table
  (`dq_catalog.dq_config.dq_control_table`, not a YAML/JSON file, and not a
  wildcard-pattern registry) where a team onboards by adding **one row**
  naming their source (`source_type`: `DELTA_TABLE` / `PARQUET_PATH` /
  `AVSC_SCHEMA`); writes only to the DQ-owned `dqx_results` schema. A Delta
  table is preferred over a file: UC-governed grants, queryable/joinable
  alongside `information_schema` and `dqx_results`, Delta history for free
  on every row change, and onboarding is a plain `INSERT` rather than a file
  edit + redeploy. See `dqx/README.md` and `docs/04_DQX_INTEGRATION.md` §2.5
  for the full onboarding model.
