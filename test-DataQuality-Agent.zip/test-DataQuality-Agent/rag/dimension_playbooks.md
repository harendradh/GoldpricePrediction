# Dimension Remediation Playbooks

Purpose: this is the content the DQ Agent retrieves when it needs to turn a
detected quality finding into a concrete recommendation. Each of the 7
quality dimensions (per `CONTEXT_BRIEF.md` §6) has a playbook below with:
common root causes (ranked by observed frequency), standard remediation
steps, who typically needs to be looped in, and rough time-to-resolve
expectations by severity. These are general patterns intended to guide
reasoning, not a substitute for investigation — the agent should always
state its findings came from Tier 1 (DQX) or Tier 2 (team_rule/dq_stats)
before recommending a fix, per the anti-fabrication non-negotiable.

---

## Completeness

**Common root causes (most to least frequent):**
1. Upstream source system started allowing an optional field to be left
   blank, or a form/UI validation was relaxed.
2. An upstream job failed partway through and only partially wrote a batch
   (silent partial failure).
3. A join or lookup upstream is failing to match some records, leaving
   enrichment columns null.
4. A new source (new region, new product line, new partner) was
   onboarded without mapping all fields the pipeline expects.
5. A schema change dropped or renamed a column, and the pipeline is
   populating the old expected name with nulls instead of erroring.

**Standard remediation steps:**
1. Confirm the null/missing pattern is new (compare against `data_profile`
   history) rather than a long-standing, accepted characteristic of the
   data.
2. Identify whether the gap is uniform (every record affected) or
   segment-specific (one region, one source system, one time window) —
   segment-specific gaps point to a single upstream cause and are faster to
   root-cause.
3. Trace the affected column back through lineage to its source table/job.
4. Check upstream job logs / `dq_stats` `status` and `error_message` for
   PARTIAL or FAILED runs around the time the gap began.
5. If the cause is a genuine upstream data gap (not a pipeline bug),
   coordinate a backfill; if it's a pipeline bug, fix the transformation
   and reprocess the affected window.
6. Recommend a completeness rule (or tighten an existing one) in
   `team_rule` if none existed, so the same gap is caught earlier next time.

**Who to loop in:** Data engineering (pipeline logs, reprocessing) first;
upstream source-system team if the cause traces past the pipeline boundary;
business owner only if a backfill decision or customer-facing impact
assessment is needed.

**Time-to-resolve expectations:**
- CRITICAL: same business day (contain via quarantine/reject immediately,
  root cause within 24 hours)
- HIGH: 1–2 business days
- MEDIUM: within the current sprint / work cycle
- LOW: tracked, addressed opportunistically

---

## Validity

**Common root causes (most to least frequent):**
1. Upstream system changed a field's allowed value set or format (new
   status code, new locale format) without notifying downstream consumers.
2. A source system upgrade or migration changed how a value is encoded
   (e.g., date format, currency representation, unit of measure).
3. Manual data entry error at the source, not caught by source-side
   validation.
4. A validity rule itself is stale — the business definition of "valid"
   changed (new country added, new product category) and the rule wasn't
   updated.
5. A type-coercion bug in an upstream transformation (e.g., a numeric field
   silently truncated or a string field misencoded).

**Standard remediation steps:**
1. Pull a sample of the failing records and inspect the actual invalid
   values — don't assume the failure mode, look at it.
2. Check whether the invalid pattern correlates with a specific source
   system, region, or a specific point in time (points to an upstream
   change) versus scattered randomly (points to entry error or transform
   bug).
3. Cross-reference recent upstream release notes / schema history
   (`DESCRIBE HISTORY`) if a step-change is visible in when failures began.
4. Distinguish "the data is wrong" from "our rule is outdated" — validate
   the rule's definition against current business requirements before
   assuming the data is at fault.
5. If the rule is outdated, update it in `team_rule` (human review
   required, never auto-applied). If the data is genuinely invalid,
   coordinate correction or quarantine with the source team.

**Who to loop in:** Upstream source team first (most validity issues
originate there); data engineering for transform-layer bugs; business
owner to confirm/update the rule definition when the "valid" definition
itself may have changed.

**Time-to-resolve expectations:**
- CRITICAL: same business day
- HIGH: 1–2 business days
- MEDIUM: within the current sprint
- LOW: opportunistic, often batched with a rule-definition review

---

## Consistency

**Common root causes (most to least frequent):**
1. Two systems that should agree were updated on different schedules
   (timing mismatch, not a real data error).
2. A business logic change was implemented in one system/pipeline but not
   propagated to a related one (e.g., a status-transition rule updated in
   the source app but not in a downstream derived table).
3. A cross-field dependency broke because one of the two fields is now
   populated by a different, out-of-sync process.
4. Referential integrity drift — a foreign key points to an entity that
   was deleted, merged, or renumbered upstream (common after a source
   system migration).
5. Rounding, unit, or aggregation-level mismatches between systems that
   are nominally reporting "the same" number.

**Standard remediation steps:**
1. Establish which side is authoritative for the field(s) in question —
   consistency issues are meaningless to fix without a clear source of
   truth.
2. Check whether the mismatch is transient (timing/refresh-cycle lag) by
   re-checking after the next scheduled refresh before treating it as a
   defect.
3. If persistent, trace both sides' lineage back to see where the logic or
   timing diverged.
4. Coordinate with both owning teams (if two systems are involved) to
   agree on which one adopts the corrected logic, or how the two are
   reconciled going forward.
5. Add or tighten a cross-field/cross-system `team_rule` to catch
   recurrence, and document the agreed authoritative source.

**Who to loop in:** Business owner early (to establish source of truth);
data engineering and the second system's owning team (frequently a
cross-team coordination problem, not a single-team fix).

**Time-to-resolve expectations:**
- CRITICAL: same business day for containment; full reconciliation may
  take longer given cross-team coordination — communicate a target within
  24–48 hours
- HIGH: 2–3 business days
- MEDIUM: within the current sprint
- LOW: opportunistic

---

## Uniqueness

**Common root causes (most to least frequent):**
1. A retried or re-run job re-inserted records that already succeeded
   (no idempotency key / lack of upsert logic), producing duplicates.
2. A merge/dedup step upstream was skipped, misconfigured, or its logic
   changed.
3. The same real-world entity legitimately exists in two source systems
   (e.g., post-merger or multi-source scenarios) without a cross-system
   matching/dedup step.
4. A change in an entity's natural key (e.g., a customer ID format change)
   caused the same entity to appear as "new" instead of matching existing
   records.
5. A scheduling overlap caused the same batch window to be processed twice.

**Standard remediation steps:**
1. Confirm true duplication (identical or near-identical records) versus a
   legitimate one-to-many relationship being miscounted.
2. Check `dq_stats`/job run history for retries, overlapping runs, or
   back-to-back executions around the time duplicates appeared — this is
   the fastest and most common culprit.
3. Identify the natural/business key that should be unique and confirm
   whether the pipeline enforces it (upsert/merge vs. plain append).
4. Coordinate removal of the duplicate records (via a corrective backfill)
   and fix the pipeline to use idempotent writes (merge on key, not
   append) going forward.
5. Add a uniqueness rule/check if one didn't already exist to catch
   recurrence immediately.

**Who to loop in:** Data engineering (job idempotency is almost always the
fix); upstream source team only if the duplication originates from
multiple source systems representing the same entity.

**Time-to-resolve expectations:**
- CRITICAL: same business day (duplicates affecting financial or
  customer-facing counts should be contained immediately)
- HIGH: 1–2 business days
- MEDIUM: within the current sprint
- LOW: opportunistic

---

## Timeliness

**Common root causes (most to least frequent):**
1. An upstream source job ran late (source-side scheduling delay, resource
   contention, or an upstream dependency that itself ran late).
2. A pipeline failure caused a retry, pushing the effective delivery time
   past the expected SLA window.
3. A scheduling/cron misconfiguration (wrong timezone, wrong trigger
   window) causes a job to run later than intended.
4. Increased data volume caused a job to run past its usual completion
   time (a volume problem manifesting as a timeliness problem).
5. A downstream dependency chain has a single slow link that delays every
   pipeline behind it.

**Standard remediation steps:**
1. Check `dq_stats` `execution_timestamp` and `duration_seconds` trend to
   see if this is a one-off delay or a creeping trend.
2. Identify where in the dependency chain the delay originates (source
   system, ingestion job, transformation job) — timeliness issues are
   almost always inherited from somewhere upstream in the chain.
3. If it's a one-off, confirm the cause (an incident, a retry) and confirm
   the data eventually arrived complete and correct.
4. If it's a trend, escalate for a capacity/scheduling review before it
   becomes a recurring SLA miss.
5. Update freshness expectations/alerts in `team_rule` if the legitimate
   business SLA has changed, rather than continuing to alert on a moved
   goalpost.

**Who to loop in:** Data engineering first (job scheduling/performance);
upstream source team if the delay originates before ingestion; business
owner if the SLA itself needs renegotiation.

**Time-to-resolve expectations:**
- CRITICAL: same-day investigation; immediate stakeholder notification
  that data is late so downstream decisions aren't made on stale data
- HIGH: within the day / next business cycle
- MEDIUM: within the current sprint
- LOW: monitored for trend, no immediate action

---

## Volume

**Common root causes (most to least frequent):**
1. An upstream source feed failed to send a file/batch (silent upstream
   failure — the pipeline ran "successfully" on zero or partial input).
2. A retried job re-processed and re-loaded a batch, inflating volume
   (overlaps with Uniqueness root cause #1).
3. A genuine, legitimate business event (promotion, seasonal peak, new
   market launch) causing a real volume shift that isn't a data problem
   at all.
4. An upstream filter/query changed and now excludes or includes a
   different population than before.
5. A source system migration changed extraction logic, altering the
   population captured.

**Standard remediation steps:**
1. Compare against the same period in prior weeks/cycles and against
   `data_profile` `row_count_at_profile_time` history, not just yesterday
   — a single day-over-day comparison is the most common source of false
   alarms.
2. Check for known business events (promotions, launches, holidays) before
   treating a spike as an anomaly — rule out seasonality first.
3. If a drop, check whether the upstream job actually ran and how many
   records it read at the source (source-side count vs. what landed).
4. If a spike, check for duplicate/retried loads first (fastest, most
   common cause) before assuming a genuine business surge.
5. Once root cause is confirmed, either accept and document the new
   normal (adjust volume thresholds) or trigger a reload/fix.

**Who to loop in:** Data engineering first (job execution, retries);
upstream source team if the feed itself under- or over-delivered; business
owner to confirm whether a volume shift reflects a real, known business
event.

**Time-to-resolve expectations:**
- CRITICAL: same business day (volume swings affecting financial or
  operational reporting need same-day triage)
- HIGH: 1 business day
- MEDIUM: within the current sprint
- LOW: monitored, often resolved as "expected seasonality" with no action

---

## Schema Drift

**Common root causes (most to least frequent):**
1. An upstream source system added, removed, or renamed a column without
   coordinating with downstream consumers.
2. A source system migration or platform upgrade changed underlying data
   types (e.g., an integer becoming a decimal, a string length changing).
3. A well-intentioned upstream "cleanup" restructured a nested/JSON
   field's internal shape.
4. An automated schema-evolution setting (e.g., auto-merge-schema) allowed
   a drift to pass through silently instead of failing loudly.
5. A new source system version deprecated a field and replaced it with a
   differently-named equivalent.

**Standard remediation steps:**
1. Use Delta history / `DESCRIBE HISTORY` and `information_schema` to
   pinpoint exactly when and what changed — the transaction log gives an
   exact commit-level answer, so this should never be guessed at.
2. Assess blast radius: which downstream tables, views, dashboards, and
   pipelines reference the changed column (lineage lookup).
3. Contact the upstream/source team to confirm whether the change was
   intentional and whether more changes are coming.
4. Decide on a short-term compatibility shim (alias, cast, default value)
   to keep downstream consumers working while a longer-term fix is
   coordinated, versus a full downstream update if the change is
   permanent and well-communicated.
5. Update the data contract / schema expectations once the new shape is
   confirmed stable, and add a schema-drift check if the table wasn't
   already covered.

**Who to loop in:** Upstream source team always (schema drift originates
there by definition); data engineering for downstream compatibility fixes
and lineage assessment; business owner if the change affects
customer-facing reports or contractual data-sharing agreements.

**Time-to-resolve expectations:**
- CRITICAL: same business day for containment/communication; full
  downstream fix may take 1–3 days depending on blast radius
- HIGH: 1–2 business days
- MEDIUM: within the current sprint
- LOW: tracked and addressed with the next planned schema review
