# Business Glossary — Data Quality AI Agent

**Audience:** business data stewards, data product owners, and analysts who
interact with the DQ Agent — not an engineering reference. For technical
schema/column definitions, see `CONTEXT_BRIEF.md`. This glossary is retrieval
content: the agent pulls definitions from here when explaining a term to a
user in plain language.

---

## The 7 Quality Dimensions

### Completeness
Completeness asks: *is the data we expect to be there actually there?* It
covers missing values in fields that matter to the business — a customer
record with no email address, an order with no ship date, a required field
that silently went blank. When completeness fails, downstream reports and
decisions are working with gaps, which can understate volumes, break
customer-facing processes, or cause a report to look "wrong" without anyone
knowing why. Business stakeholders should care about completeness because it
directly determines whether a number they're looking at is the whole picture
or a partial one.

### Validity
Validity asks: *does the data conform to the rules that define a legitimate
value?* This includes format rules (a phone number that isn't a phone
number), range rules (a discount percentage of 150%), and category rules (a
status code that isn't one of the agreed values). Validity failures are
often the earliest sign of an upstream system change or a data-entry defect,
and they matter because invalid values can silently corrupt calculations,
break joins, or produce nonsensical business metrics that look plausible at
a glance.

### Consistency
Consistency asks: *does this data agree with itself and with other related
data?* This covers cross-field logic (an order marked "delivered" with no
delivery date), cross-system agreement (the same customer having different
statuses in two systems that should match), and referential relationships
(a transaction pointing to a product that doesn't exist). Consistency issues
matter to the business because they erode trust between teams — when
Finance and Operations get different answers to the same question, both
start to distrust the data.

### Uniqueness
Uniqueness asks: *is each real-world entity or event represented exactly
once?* Duplicate customer records, duplicate transactions, or duplicate
shipments inflate counts, distort totals, and can cause customers to be
billed or contacted more than once. Uniqueness matters because it is one of
the most visible quality failures to end users — duplicates are the kind of
error that gets escalated quickly and damages confidence in the whole data
product.

### Timeliness
Timeliness asks: *did the data arrive when it was supposed to?* This
dimension covers late-arriving files, delayed pipeline runs, and data that
is technically present but too stale to be useful for a same-day decision.
Timeliness matters to the business because even perfectly accurate data is
low-value if it shows up after the decision it was meant to inform has
already been made — a dashboard refreshed a day late can lead to acting on
yesterday's picture of the business.

### Volume
Volume asks: *did we receive roughly the amount of data we expected?* A
sudden drop in row counts can mean an upstream feed silently failed; a
sudden spike can mean a duplicate load or a runaway process. Volume is often
the fastest, simplest signal that something is wrong upstream — long before
anyone notices a business-level symptom, an unexpected swing in record
counts is usually the first alarm bell.

### Schema Drift
Schema Drift asks: *has the shape of the data changed underneath us?* This
covers columns being added, removed, renamed, or having their data type
changed by an upstream source system without notice. Schema drift matters
to the business because it can silently break reports (a renamed column
returns nulls instead of an error) or, worse, get partially fixed in one
place and not another — creating quiet inconsistency across the
organization until someone investigates.

---

## Key Terms

**team_rule** — The table where a team's own data stewards and analysts
write down the specific business rules that matter for their data (for
example, "order total must never be negative" or "region code must be one
of our five approved regions"). These are rules a person defined based on
business knowledge, not generic technical checks — they capture context a
machine cannot infer on its own.

**dq_stats** — The record of what happened each time those business rules
were actually run against the data: how many rules were checked, how many
passed, how many failed, and whether the run itself completed successfully.
This is the agent's source of truth for "what has and hasn't been verified
recently" — if a rule doesn't appear here for a given day, it was not
checked that day, full stop.

**data_profile** — A statistical fingerprint of a column or table over time:
how many values are missing, how many distinct values exist, what the
minimum/maximum look like, and when the data was last refreshed. Profiling
tells the story of how a dataset's shape is drifting over time, even before
any explicit rule has been written to catch it.

**dqx_results** — A central table, owned by the DQ team, where automated
findings from DQX (see below) are recorded for any table across the
organization — including tables belonging to teams who have not yet written
a single business rule of their own. This is what makes "day one" coverage
possible without waiting on any team to onboard.

**Tier 1** — The baseline, zero-effort layer of coverage. As soon as the DQ
Agent has read access to a table, DQX automatically profiles it and runs a
standard set of built-in checks — no rules to write, no new tables to
populate, no pipeline changes. Tier 1 findings are AI-inferred: useful, but
generic, since they don't yet reflect anything a human on that team has
explicitly decided matters.

**Tier 2** — The richer layer that kicks in once a team has started
populating `team_rule`, `dq_stats`, and/or `data_profile` themselves.
Because these rules and results were authored or reviewed by people who
understand the business context, Tier 2 findings are treated as more
authoritative than Tier 1 — when both exist for the same question, Tier 2
wins.

**DQX** — Short for "Data Quality X," an automated checking engine
(`databricks-labs-dqx`) that the DQ team runs centrally against tables
across the organization. Think of it as a tireless, generic inspector: it
reads a table (without ever modifying it), evaluates a standard battery of
completeness/validity/uniqueness/freshness/schema checks, and writes its
findings to `dqx_results`. It is what powers Tier 1 coverage.

**Genie space** — A curated, natural-language query interface scoped to a
small, deliberately narrow set of tables and guardrails. The DQ Agent draws
on eight of these, each focused on one area (for example, "Freshness
Intelligence" or "Governance Intelligence"), so that questions get answered
against a well-understood, bounded set of data rather than an
unconstrained search across everything.

**Data product** — A dataset (or family of related tables) that a team
owns, publishes, and is accountable for the quality of — the unit the DQ
Agent organizes its coverage and reporting around.

**Data contract** — An explicit, agreed-upon definition of what a data
product promises to deliver: its schema, its refresh cadence, its
acceptable value ranges, and the quality guarantees a consuming team can
rely on. Schema-related contract checks are one of the things DQX can
validate automatically.

---

## Severity Levels

**CRITICAL** — A failure serious enough to threaten trust in the data
product or cause direct business harm if left unaddressed (for example,
duplicate financial transactions, or a schema change that silently zeroes
out a required field). CRITICAL findings should be escalated immediately —
same-day awareness to both the data engineering team and the accountable
business owner is expected, and the issue should be tracked until resolved,
not just logged.

**HIGH** — A significant problem that is very likely to affect downstream
consumers or reports but is not yet an emergency (for example, a
meaningfully elevated null rate in an important-but-not-critical field).
HIGH findings should be escalated promptly — typically within the same
business day or the next morning stand-up — and tracked to resolution on a
short timeline.

**MEDIUM** — A real quality issue worth fixing, but with limited or
contained business impact (for example, a formatting inconsistency in a
rarely-used field). MEDIUM findings are typically triaged into a normal
work queue rather than escalated urgently — they should be visible on a
health summary but don't need to interrupt anyone's day.

**LOW** — A minor or cosmetic issue, or a deviation that is expected and
low-risk (for example, a slightly wider-than-usual value distribution).
LOW findings are mostly informational — worth recording so the trend is
visible over time, but not worth active escalation unless they persist or
compound.

---

## `action_if_failed` Values

**REJECT** — The offending record(s) are not allowed to proceed at all;
the data is blocked from loading into the target table. Operationally,
this is the strictest response — appropriate when bad data would actively
corrupt downstream calculations or violate a hard business constraint.
Expect an immediate pipeline-level signal (a failed job, an alert) rather
than a quiet log entry.

**QUARANTINE** — The offending record(s) are set aside into a separate
holding location instead of being loaded or dropped outright, so the rest
of the (clean) data can still flow through on schedule. Operationally, this
is the "contain but don't block everything" response — someone needs to
review the quarantined records and decide whether to fix and reload them or
discard them, but the rest of the business isn't held hostage waiting for
that decision.

**FLAG** — The record is allowed to proceed into the target table as-is,
but it is marked or tagged so downstream consumers and stewards can see
that a quality concern was noted against it. Operationally, this is used
when blocking the data would cause more harm than letting a marked,
imperfect record through — the business gets the data on time, with a
visible caveat.

**ALERT_ONLY** — The record proceeds completely untouched, but a
notification is generated so a human is aware the condition occurred.
Operationally, this is the lightest-touch response, typically used for
lower-severity or exploratory rules where the team wants visibility and
trend-tracking without yet committing to blocking or marking data.
