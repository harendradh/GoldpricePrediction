# Historical Incident Patterns

> **These are illustrative example patterns for RAG grounding — replace with
> real incident history during onboarding.** Every incident in this file is
> a fabricated, representative scenario used to teach the DQ Agent what a
> well-formed incident write-up looks like and what kinds of root causes are
> plausible for each quality dimension. None of these describe a real past
> event, a real team, or a real system. Per the anti-fabrication
> non-negotiable in `CONTEXT_BRIEF.md`, the agent must never present any
> pattern from this file as a real, dated incident that actually occurred —
> it may use these only to reason about plausible root causes and
> remediation shapes, and must say so if asked.

---

## Incident 1 (illustrative example) — Upstream schema change silently nulled a required field

- **Symptom:** Completeness alerts fired on a `customer_region` column that
  had been reliably 100% populated for months; null rate jumped to ~40%
  overnight.
- **Root cause found:** The upstream CRM system renamed the source field
  from `region_code` to `region_cd` during a routine release; the ingestion
  pipeline's column mapping still referenced the old name, so the new
  column silently mapped to null instead of erroring.
- **Dimension:** Completeness (surfaced), Schema Drift (true cause).
- **How long it took to detect:** ~18 hours — caught by the next scheduled
  completeness check run, not in real time.
- **How it was fixed:** Ingestion mapping updated to the new source column
  name; affected day's partition backfilled from the CRM's retained export.
- **Prevention rule added afterward:** A schema-drift check comparing
  upstream source schema to the pipeline's expected column list before each
  run, configured to fail loudly (REJECT) rather than silently pass through
  a renamed/missing column as null.

---

## Incident 2 (illustrative example) — Late-arriving source job breached the freshness SLA

- **Symptom:** A downstream daily revenue dashboard was showing yesterday's
  numbers as of 9am, past the promised 6am refresh SLA.
- **Root cause found:** The upstream point-of-sale extract job was queued
  behind an unrelated, much larger batch job on a shared cluster that had
  grown over several weeks; the extract consistently finished later and
  later each week until it crossed the SLA threshold.
- **Dimension:** Timeliness.
- **How long it took to detect:** Same day — a freshness check flagged the
  breach within minutes of the missed SLA window, but the underlying
  capacity trend had been building for roughly 3 weeks before anyone
  noticed.
- **How it was fixed:** The extract job was moved to a dedicated cluster
  with reserved capacity and rescheduled earlier in the queue order.
- **Prevention rule added afterward:** A trend-based freshness check that
  alerts on a creeping increase in job duration/completion time, not just a
  hard SLA breach — so gradual degradation is caught before it becomes an
  outage.

---

## Incident 3 (illustrative example) — Silent null-injection bug in a currency conversion step

- **Symptom:** A validity check on `amount_usd` began failing intermittently
  — roughly 5% of records had a null converted amount even though the
  source `amount_local` and `currency_code` fields were both populated.
- **Root cause found:** A new currency was added to the source system (a
  regional expansion) but the exchange-rate lookup table used by the
  conversion job had not been updated with a rate for that currency; the
  lookup join silently returned null instead of failing the job.
- **Dimension:** Completeness (symptom in `amount_usd`), Validity (root
  cause is an invalid/unmapped currency code).
- **How long it took to detect:** ~5 days — the failure rate was low enough
  early on that it stayed under the alert threshold until the new region's
  volume ramped up.
- **How it was fixed:** Exchange-rate table backfilled with the missing
  currency; affected records reprocessed; conversion job changed to fail
  loudly on an unmapped currency rather than nulling the result.
- **Prevention rule added afterward:** A completeness rule specifically on
  the post-conversion `amount_usd` field, plus a validity check that the
  exchange-rate lookup table covers every `currency_code` present in the
  source data before a run is allowed to proceed.

---

## Incident 4 (illustrative example) — Duplicate ingestion from a retried job

- **Symptom:** A volume check flagged an unusual ~2x spike in daily
  transaction row counts, and a downstream finance reconciliation showed
  transaction totals roughly double the expected amount.
- **Root cause found:** The ingestion job failed partway through due to a
  transient network timeout; the orchestrator's automatic retry re-ran the
  full job without first checking whether the prior attempt had already
  committed data, and the pipeline used append-only writes rather than an
  idempotent merge — so the successfully-loaded rows from the first attempt
  were loaded a second time.
- **Dimension:** Volume (symptom), Uniqueness (true cause).
- **How long it took to detect:** Same day — the volume spike check caught
  it within the first run after the retry.
- **How it was fixed:** Duplicate rows identified by natural key and
  removed; pipeline changed from append to merge-on-key (upsert) so retries
  are naturally idempotent going forward.
- **Prevention rule added afterward:** A uniqueness rule on the transaction
  natural key added to `team_rule`, plus a job-level idempotency
  requirement documented for any pipeline with automatic retries enabled.

---

## Incident 5 (illustrative example) — Business logic drift after a source system migration

- **Symptom:** A consistency check comparing "order status" between the
  order-management system and the downstream fulfillment reporting table
  began failing for a subset of orders — statuses that should have been
  mutually exclusive were appearing together.
- **Root cause found:** The order-management system was migrated to a new
  platform, and the new platform introduced an additional intermediate
  status in its state machine ("partially fulfilled") that the downstream
  reporting logic — written for the old system's simpler status set — did
  not know how to interpret, so it mapped the new status incorrectly.
- **Dimension:** Consistency.
- **How long it took to detect:** ~10 days — the new status was rare
  enough at first that only a handful of orders were affected before volume
  in that status increased.
- **How it was fixed:** Downstream mapping logic updated to handle the new
  status explicitly; historical affected orders reprocessed with corrected
  status mapping.
- **Prevention rule added afterward:** A consistency check that flags any
  status value appearing in the source system that isn't in the downstream
  mapping's known set, failing loudly instead of defaulting to a guessed
  mapping.

---

## Incident 6 (illustrative example) — Seasonality misclassified as a volume anomaly

- **Symptom:** A volume anomaly alert fired for a retail transactions table
  showing a ~3x spike in daily order volume, initially treated as a
  potential duplicate-load incident.
- **Root cause found:** The spike coincided with a recurring annual
  promotional event; the underlying anomaly-detection baseline had been
  trained on a rolling recent window that did not include the prior year's
  same event, so it had no basis to recognize the pattern as expected
  seasonality.
- **Dimension:** Volume.
- **How long it took to detect:** Root cause identified within a few hours
  once the business calendar was checked — the initial alert itself fired
  immediately, but the investigation to rule out a real defect took longer
  than the eventual explanation warranted.
- **How it was fixed:** No data fix was needed — the finding was
  reclassified from "anomaly" to "expected seasonal pattern" after business
  confirmation.
- **Prevention rule added afterward:** The volume baseline was updated to
  incorporate a longer historical window (covering at least one full prior
  cycle of the recurring event) and a business calendar of known
  promotional/seasonal dates was added as context the anomaly detector
  checks before alerting.

---

## Incident 7 (illustrative example) — Referential integrity drift after a customer ID re-numbering

- **Symptom:** A consistency/referential check began flagging a growing
  number of transaction records whose `customer_id` had no matching record
  in the customer dimension table.
- **Root cause found:** The upstream CRM ran a one-time customer ID
  re-numbering project to resolve historical duplicate customer records;
  the transactions pipeline was not included in the migration's downstream
  notification list, so it continued referencing the old ID scheme for
  new incoming transactions while the customer dimension had already moved
  to the new IDs.
- **Dimension:** Consistency.
- **How long it took to detect:** ~2 days — the referential check ran
  daily and caught the mismatch on the first run after the re-numbering,
  but it took additional time to trace back to the CRM project as the
  cause since it wasn't initially on the investigation list.
- **How it was fixed:** An ID crosswalk table was created mapping old to
  new customer IDs; the transactions pipeline was updated to translate
  incoming IDs through the crosswalk until the source system fully cut
  over.
- **Prevention rule added afterward:** The DQ team requested to be added to
  the notification list for any upstream key-structure or ID-scheme change
  project, and a referential-integrity check was added to run more
  frequently (from daily to hourly) during any known migration window.

---

## Incident 8 (illustrative example) — Duplicate customer records from a multi-source merge

- **Symptom:** A uniqueness check on the customer dimension table showed a
  slowly climbing duplicate rate — the same customer, identifiable by
  email and phone, appearing as two or three separate customer records.
- **Root cause found:** Following a business acquisition, customer records
  from the acquired company's system were loaded into the shared customer
  table using the acquired system's own customer ID as the natural key,
  with no cross-system identity-matching step — so any customer who existed
  in both the original and acquired systems appeared twice.
- **Dimension:** Uniqueness.
- **How long it took to detect:** ~3 weeks — the duplicate rate rose
  gradually as more of the acquired company's customer base was loaded, so
  it stayed below the alert threshold for some time before crossing it.
- **How it was fixed:** A one-time identity-resolution/matching pass was
  run (matching on normalized email and phone) to merge duplicate customer
  records and establish a single golden record per real customer.
- **Prevention rule added afterward:** A recurring cross-source duplicate
  check comparing normalized email/phone across all customer source
  systems, run on a schedule rather than only at the time of the original
  merge, so future multi-source onboarding events are caught automatically.

---

## Incident 9 (illustrative example) — Schema drift from an automated schema-evolution setting

- **Symptom:** A downstream report started showing an unexpected new
  column with a generic auto-generated name, and an existing decimal
  column's values appeared to have been rounded differently than before.
- **Root cause found:** The ingestion pipeline had schema-auto-merge
  enabled, and an upstream source added a new nested field inside what had
  been a simple JSON blob; auto-merge silently accepted the new nested
  structure and, in doing so, changed how an existing numeric field was
  extracted and typed, altering its precision.
- **Dimension:** Schema Drift.
- **How long it took to detect:** ~4 days — the change didn't cause any
  job failures (auto-merge succeeded by design), so it was only caught when
  a business user noticed the report numbers looked slightly different
  than expected and raised it.
- **How it was fixed:** The extraction logic was updated to explicitly
  handle the new nested structure with the correct precision; auto-merge
  was disabled for this pipeline in favor of an explicit, reviewed schema
  evolution step.
- **Prevention rule added afterward:** Schema-evolution auto-merge disabled
  by default for pipelines feeding business-critical reports; any schema
  change now requires an explicit review step using Delta history, and a
  precision/type-drift check was added to the affected numeric columns.
