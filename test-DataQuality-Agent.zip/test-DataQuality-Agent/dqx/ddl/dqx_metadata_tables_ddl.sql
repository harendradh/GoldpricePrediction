-- Explicit DDL for the three tables the DQX Module writes its generated
-- metadata to. Previously these were referenced only as path strings in
-- central_dq_job.py's OUTPUT_CONFIG/QUARANTINE_CONFIG/METRICS_CONFIG, with no
-- column schema defined anywhere in the project -- this file fills that gap.
--
-- All three live in dq_catalog.dq_results and are DQX-owned (Tier 1). They
-- are written to ONLY by the central DQX Module job -- never by any team's
-- own pipeline. This is the same zero-copy/zero-pipeline-change guarantee
-- documented in docs/04_DQX_INTEGRATION.md section 2: a team's existing job
-- keeps running exactly as before, untouched; only the DQX Module reads that
-- team's source and writes to these three tables.

-- ---------------------------------------------------------------------------
-- dqx_results -- check-level grain: one row per check per run per table.
-- Mirrors dq_stats's shape (CONTEXT_BRIEF.md section 1.2 / docs/01) so the
-- DQ Execution Analytics Genie space can query Tier 1 (dqx_results) and
-- Tier 2 (dq_stats) results uniformly, per docs/04_DQX_INTEGRATION.md
-- section 2.4.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS dq_catalog.dq_results.dqx_results (
  execution_id       STRING      NOT NULL COMMENT 'Unique id for one DQX Module run against one source',
  entry_id            STRING      NOT NULL COMMENT 'FK to dq_catalog.dq_config.dq_control_table.entry_id',
  team_name           STRING      NOT NULL,
  source_type         STRING      NOT NULL COMMENT 'DELTA_TABLE | PARQUET_PATH | AVSC_SCHEMA',
  catalog_name        STRING      COMMENT 'Populated when source_type = DELTA_TABLE',
  schema_name         STRING      COMMENT 'Populated when source_type = DELTA_TABLE',
  table_name          STRING      COMMENT 'Populated when source_type = DELTA_TABLE',
  file_path           STRING      COMMENT 'Populated when source_type = PARQUET_PATH or AVSC_SCHEMA',
  check_name          STRING      NOT NULL COMMENT 'DQX check identifier, e.g. is_not_null, is_unique, is_recent',
  check_column         STRING      COMMENT 'Column the check evaluated, NULL for dataset-level checks',
  criticality          STRING      NOT NULL COMMENT 'error | warn',
  check_status         STRING      NOT NULL COMMENT 'PASS | FAIL',
  failed_row_count      BIGINT      COMMENT 'Rows that failed this specific check',
  input_record_count    BIGINT      COMMENT 'Total rows evaluated in this run',
  run_ts               TIMESTAMP   NOT NULL,
  run_date              DATE        NOT NULL
)
USING DELTA
COMMENT 'DQX Module (Tier 1) check-level results -- one row per check per run per table/file. DQX-owned: written only by the central DQX Module job, never by any team''s own pipeline. Mirrors dq_stats grain concepts so DQ Execution Analytics can query both tiers uniformly. See dqx/README.md and docs/04_DQX_INTEGRATION.md.';

-- ---------------------------------------------------------------------------
-- dqx_quarantine -- one row per quarantined (failed-check) record.
-- quarantined_row is JSON-serialized because the source schema varies per
-- table/file and cannot be strongly typed in a single shared table.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS dq_catalog.dq_results.dqx_quarantine (
  execution_id     STRING    NOT NULL COMMENT 'FK to dqx_results.execution_id / dqx_run_metrics.execution_id',
  entry_id         STRING    NOT NULL COMMENT 'FK to dq_catalog.dq_config.dq_control_table.entry_id',
  team_name        STRING    NOT NULL,
  table_name       STRING    COMMENT 'Populated when source_type = DELTA_TABLE',
  file_path        STRING    COMMENT 'Populated when source_type = PARQUET_PATH or AVSC_SCHEMA',
  run_ts           TIMESTAMP NOT NULL,
  quarantined_row  STRING    NOT NULL COMMENT 'JSON-serialized copy of the failing row -- schema varies per source table/file, so this cannot be strongly typed here',
  failed_checks    ARRAY<STRING> NOT NULL COMMENT 'Names of every check this row failed'
)
USING DELTA
COMMENT 'DQX Module (Tier 1) quarantined rows -- one row per record that failed at least one check. DQX-owned: written only by the central DQX Module job, never by any team''s own pipeline. Source table/file is read-only; nothing is deleted or modified there.';

-- ---------------------------------------------------------------------------
-- dqx_run_metrics -- one row per DQX Module run against one source
-- (table/path), i.e. run-level grain (coarser than dqx_results).
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS dq_catalog.dq_results.dqx_run_metrics (
  execution_id         STRING    NOT NULL COMMENT 'FK to dqx_results.execution_id / dqx_quarantine.execution_id',
  entry_id             STRING    NOT NULL COMMENT 'FK to dq_catalog.dq_config.dq_control_table.entry_id',
  team_name            STRING    NOT NULL,
  table_name           STRING    COMMENT 'Populated when source_type = DELTA_TABLE',
  file_path            STRING    COMMENT 'Populated when source_type = PARQUET_PATH or AVSC_SCHEMA',
  input_record_count   BIGINT    NOT NULL,
  valid_count          BIGINT    NOT NULL,
  quarantined_count    BIGINT    NOT NULL,
  duration_seconds     DOUBLE    NOT NULL,
  run_ts               TIMESTAMP NOT NULL,
  run_date             DATE      NOT NULL
)
USING DELTA
COMMENT 'DQX Module (Tier 1) run-level metrics -- one row per run per table/file (rows scanned, valid/quarantined counts, duration). DQX-owned: written only by the central DQX Module job, never by any team''s own pipeline.';
