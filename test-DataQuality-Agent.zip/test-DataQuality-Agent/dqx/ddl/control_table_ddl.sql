-- Control master table for Tier-1 DQX onboarding.
--
-- Replaces the old wildcard-pattern `dqx_rule_registry` (dq_catalog.dq_config
-- .dqx_rule_registry) as the PRIMARY onboarding path. That model required a
-- team to reason about a table_pattern wildcard and a checks array before
-- anything ran for them -- too much ceremony for the common case. This
-- table's whole design intent is:
--
--     A TEAM'S ONBOARDING ACTION IS "ADD ONE ROW NAMING YOUR TABLE."
--     NOTHING ELSE IS REQUIRED.
--
-- Concretely: a team picks their source_type, fills in the handful of
-- identifying columns for that source_type, leaves checks_override NULL
-- (meaning "run the DQX Module's full default built-in suite --
-- completeness/validity/uniqueness/freshness/schema"), and is done. The DQX
-- Module (see ../src/dq_dqx_framework/) reads this table each run, filters to
-- is_active = true, and dispatches on source_type to pick up the right table/
-- file/schema -- Delta table, Parquet dataset, or a .avsc-described dataset --
-- with no other config file, YAML, or job edit required.
--
-- Extension point (not implemented by this table, documented for later): if
-- wildcard/pattern-based bulk registration for "every table in a schema" is
-- ever worth reintroducing as a SECONDARY, opt-in capability alongside this
-- one-row-per-table model, it should live as its own table (e.g. a revived
-- dqx_bulk_registry keyed by catalog/schema/table_pattern) that expands into
-- rows here, or into ad hoc targets resolved at run time -- it should not be
-- collapsed back into this table's schema, which is deliberately kept to
-- exactly one row per onboarded source.

CREATE TABLE IF NOT EXISTS dq_catalog.dq_config.dq_control_table (
  entry_id        STRING NOT NULL COMMENT 'Primary key, e.g. uuid()',
  team_name       STRING NOT NULL,
  source_type     STRING NOT NULL COMMENT 'One of: DELTA_TABLE | PARQUET_PATH | AVSC_SCHEMA',
  catalog_name    STRING COMMENT 'Populated when source_type = DELTA_TABLE',
  schema_name     STRING COMMENT 'Populated when source_type = DELTA_TABLE',
  table_name      STRING COMMENT 'Populated when source_type = DELTA_TABLE -- the literal "just add your table name" field a team fills in to onboard',
  file_path       STRING COMMENT 'Populated when source_type = PARQUET_PATH (the parquet dataset''s storage path) or AVSC_SCHEMA (path to the .avsc schema file)',
  data_path       STRING COMMENT 'Only for source_type = AVSC_SCHEMA: where the actual data described by the .avsc lives. The .avsc file alone is schema, not data -- this column is required so the DQX Module knows what to read.',
  checks_override ARRAY<STRING> COMMENT 'Nullable. NULL means "run the DQX Module''s full default built-in suite" (completeness/validity/uniqueness/freshness/schema). A team only sets this to restrict the run to a subset of that default suite.',
  is_active       BOOLEAN NOT NULL DEFAULT true,
  notes           STRING COMMENT 'Free-text context, e.g. why checks_override is scoped narrower than the default suite',
  registered_by   STRING NOT NULL,
  registered_at   TIMESTAMP NOT NULL,
  updated_by      STRING,
  updated_at      TIMESTAMP
)
USING DELTA
COMMENT 'Control master table for Tier-1 DQX onboarding. A team onboards by adding ONE row naming their table (or parquet path, or .avsc schema + data path) -- that is the entire onboarding flow. No checks to write, no wildcard pattern to reason about; checks_override stays NULL for the default full built-in suite. The DQX Module (dqx/src/dq_dqx_framework) reads is_active=true rows each run and dispatches on source_type. Supersedes dq_catalog.dq_config.dqx_rule_registry (deleted) as the primary onboarding path.';

-- ---------------------------------------------------------------------------
-- Seed rows -- illustrative, one per source_type, replace with real
-- onboarding entries. This is deliberately concrete, not abstract: it shows
-- exactly what a team fills in for each source_type.
-- ---------------------------------------------------------------------------

-- DELTA_TABLE: the simplest, most common case. A team names their table and
-- is done -- no other column beyond the standard identifying/audit fields.
INSERT INTO dq_catalog.dq_config.dq_control_table VALUES (
  'a1b2c3d4-0001-4a11-8b11-000000000001',
  'sales_team',
  'DELTA_TABLE',
  'prod_catalog', 'sales', 'orders',
  NULL,   -- file_path: n/a for DELTA_TABLE
  NULL,   -- data_path: n/a for DELTA_TABLE
  NULL,   -- checks_override: NULL -> full default built-in suite
  true,
  'Onboarding action was literally one row: catalog/schema/table name, nothing else.',
  'sales_team_lead', current_timestamp(), NULL, NULL
);

-- PARQUET_PATH: no Unity Catalog table exists yet (or the data lives as raw
-- parquet outside UC) -- the team points the DQX Module at the storage path
-- instead of a catalog.schema.table triple.
INSERT INTO dq_catalog.dq_config.dq_control_table VALUES (
  'a1b2c3d4-0002-4a11-8b11-000000000002',
  'finance_team',
  'PARQUET_PATH',
  NULL, NULL, NULL,   -- catalog/schema/table_name: n/a for PARQUET_PATH
  'abfss://landing@financelake.dfs.core.windows.net/invoices/parquet/',
  NULL,   -- data_path: n/a for PARQUET_PATH (file_path already points at the data)
  array('completeness', 'validity'),   -- restricted subset of the default suite
  true,
  'Restricted to completeness/validity only -- uniqueness is already covered by a Tier-2 team_rule on this dataset.',
  'finance_platform_eng', current_timestamp(), NULL, NULL
);

-- AVSC_SCHEMA: the dataset's schema is described by an Avro (.avsc) file
-- separate from where the data itself lives -- both file_path (the .avsc)
-- and data_path (the actual data) must be populated, since the schema file
-- alone is not the data.
INSERT INTO dq_catalog.dq_config.dq_control_table VALUES (
  'a1b2c3d4-0003-4a11-8b11-000000000003',
  'iot_platform_team',
  'AVSC_SCHEMA',
  NULL, NULL, NULL,   -- catalog/schema/table_name: n/a for AVSC_SCHEMA
  'abfss://schemas@iotplatform.dfs.core.windows.net/device_telemetry/device_telemetry.avsc',
  'abfss://landing@iotplatform.dfs.core.windows.net/device_telemetry/data/',
  NULL,   -- checks_override: NULL -> full default built-in suite
  true,
  'Schema (.avsc) and data live in different locations -- both file_path and data_path are required for this source_type.',
  'iot_platform_eng', current_timestamp(), NULL, NULL
);

-- Onboarding a new team, in full = one INSERT like the above. No wildcard
-- pattern, no checks array to author, no new table, no new job, no change to
-- any other team's pipeline or code.
