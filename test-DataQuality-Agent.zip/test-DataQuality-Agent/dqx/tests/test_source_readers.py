"""Unit tests for the source_type dispatch logic in source_readers.py.

These stub out the Spark session entirely with a minimal fake that just
records which read method was called with which argument -- no live Spark
session or Databricks cluster is used or required to run these. Full
integration testing (actually reading a Delta table / parquet path / Avro
dataset) needs a Databricks cluster or a local pyspark install
(`pip install -e ".[local-dev]"`) and is out of scope for these stubs.
"""

from __future__ import annotations

import pytest

from dq_dqx_framework.control_table import ControlEntry
from dq_dqx_framework.source_readers import read_source


class _FakeReader:
    def __init__(self):
        self.calls: list[tuple[str, str]] = []

    def table(self, fqtn: str):
        self.calls.append(("table", fqtn))
        return f"DataFrame(table={fqtn})"

    def parquet(self, path: str):
        self.calls.append(("parquet", path))
        return f"DataFrame(parquet={path})"


class _FakeSpark:
    def __init__(self):
        self.read = _FakeReader()


def _entry(**overrides) -> ControlEntry:
    base = dict(
        entry_id="e1", team_name="sales_team", source_type="DELTA_TABLE",
        catalog_name="prod_catalog", schema_name="sales", table_name="orders",
        file_path=None, data_path=None, checks_override=None, is_active=True,
    )
    base.update(overrides)
    return ControlEntry(**base)


def test_delta_table_dispatches_to_spark_read_table():
    spark = _FakeSpark()
    entry = _entry(source_type="DELTA_TABLE")

    result = read_source(spark, entry)

    assert spark.read.calls == [("table", "prod_catalog.sales.orders")]
    assert result == "DataFrame(table=prod_catalog.sales.orders)"


def test_delta_table_missing_identifiers_raises():
    spark = _FakeSpark()
    entry = _entry(source_type="DELTA_TABLE", catalog_name=None, schema_name=None, table_name=None)

    with pytest.raises(ValueError, match="missing catalog_name"):
        read_source(spark, entry)


def test_parquet_path_dispatches_to_spark_read_parquet():
    spark = _FakeSpark()
    entry = _entry(
        source_type="PARQUET_PATH", catalog_name=None, schema_name=None, table_name=None,
        file_path="abfss://landing/invoices/parquet/",
    )

    result = read_source(spark, entry)

    assert spark.read.calls == [("parquet", "abfss://landing/invoices/parquet/")]
    assert result == "DataFrame(parquet=abfss://landing/invoices/parquet/)"


def test_parquet_path_missing_file_path_raises():
    spark = _FakeSpark()
    entry = _entry(source_type="PARQUET_PATH", catalog_name=None, schema_name=None, table_name=None, file_path=None)

    with pytest.raises(ValueError, match="missing file_path"):
        read_source(spark, entry)


def test_avsc_schema_missing_data_path_raises_before_touching_spark():
    spark = _FakeSpark()
    entry = _entry(
        source_type="AVSC_SCHEMA", catalog_name=None, schema_name=None, table_name=None,
        file_path="abfss://schemas/device.avsc", data_path=None,
    )

    with pytest.raises(ValueError, match="both file_path"):
        read_source(spark, entry)
    assert spark.read.calls == []


def test_unsupported_source_type_raises():
    spark = _FakeSpark()
    entry = _entry(source_type="XML_BLOB")

    with pytest.raises(ValueError, match="Unsupported source_type"):
        read_source(spark, entry)


def test_avsc_schema_without_fastavro_installed_raises_actionable_error(monkeypatch):
    """When fastavro isn't installed, the AVSC_SCHEMA path should fail with a
    clear instruction rather than a bare ImportError -- see the `avro` extra
    in pyproject.toml. This test only asserts on the reachable branch that
    doesn't require Avro-to-Spark schema translation (NotImplementedError is
    covered separately; that translation is an illustrative stub, not a real
    implementation, per source_readers._avsc_to_spark_schema's docstring)."""
    spark = _FakeSpark()
    entry = _entry(
        source_type="AVSC_SCHEMA", catalog_name=None, schema_name=None, table_name=None,
        file_path="abfss://schemas/device.avsc", data_path="abfss://landing/device/data/",
    )

    import builtins

    real_import = builtins.__import__

    def _blocked_import(name, *args, **kwargs):
        if name == "fastavro":
            raise ImportError("no module named fastavro")
        return real_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", _blocked_import)

    with pytest.raises(ImportError, match="fastavro"):
        read_source(spark, entry)
