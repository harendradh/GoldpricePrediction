"""Unit tests for control-table row parsing/filtering.

These are stubs that exercise the pure-Python parts of control_table.py
(ControlEntry, filter_valid_entries) against plain dict fixtures -- no live
Spark session or Databricks cluster is used or required to run these.

Full integration testing (actually querying dq_control_table via Spark SQL,
i.e. load_active_entries()) needs a real Databricks cluster/Spark session
and is out of scope for these stubs -- that function is a thin SQL-read +
_row_to_entry() mapping, deliberately kept thin so nearly all of the
interesting logic lives in the parts tested here.
"""

from __future__ import annotations

from dq_dqx_framework.control_table import ControlEntry, _row_to_entry, filter_valid_entries


def _delta_row(**overrides) -> dict:
    row = {
        "entry_id": "e1",
        "team_name": "sales_team",
        "source_type": "DELTA_TABLE",
        "catalog_name": "prod_catalog",
        "schema_name": "sales",
        "table_name": "orders",
        "file_path": None,
        "data_path": None,
        "checks_override": None,
        "is_active": True,
    }
    row.update(overrides)
    return row


def test_row_to_entry_defaults_checks_override_to_none():
    entry = _row_to_entry(_delta_row())
    assert entry.checks_override is None
    assert entry.checks == ["completeness", "validity", "uniqueness", "freshness", "schema"]


def test_checks_override_restricts_default_suite():
    entry = _row_to_entry(_delta_row(checks_override=["completeness", "validity"]))
    assert entry.checks == ["completeness", "validity"]


def test_fq_table_name_for_delta_table():
    entry = _row_to_entry(_delta_row())
    assert entry.fq_table_name == "prod_catalog.sales.orders"


def test_fq_table_name_none_for_non_delta_source():
    entry = _row_to_entry(
        _delta_row(source_type="PARQUET_PATH", catalog_name=None, schema_name=None, table_name=None,
                    file_path="abfss://landing/invoices/")
    )
    assert entry.fq_table_name is None
    assert entry.display_name() == "abfss://landing/invoices/"


def test_filter_valid_entries_accepts_well_formed_delta_entry():
    entry = _row_to_entry(_delta_row())
    valid, problems = filter_valid_entries([entry])
    assert valid == [entry]
    assert problems == []


def test_filter_valid_entries_rejects_delta_entry_missing_table_name():
    entry = _row_to_entry(_delta_row(table_name=None))
    valid, problems = filter_valid_entries([entry])
    assert valid == []
    assert len(problems) == 1
    assert "DELTA_TABLE entry missing" in problems[0]


def test_filter_valid_entries_rejects_parquet_entry_missing_file_path():
    entry = _row_to_entry(
        _delta_row(source_type="PARQUET_PATH", catalog_name=None, schema_name=None, table_name=None, file_path=None)
    )
    valid, problems = filter_valid_entries([entry])
    assert valid == []
    assert "PARQUET_PATH entry missing file_path" in problems[0]


def test_filter_valid_entries_rejects_avsc_entry_missing_data_path():
    entry = _row_to_entry(
        _delta_row(
            source_type="AVSC_SCHEMA", catalog_name=None, schema_name=None, table_name=None,
            file_path="abfss://schemas/device.avsc", data_path=None,
        )
    )
    valid, problems = filter_valid_entries([entry])
    assert valid == []
    assert "AVSC_SCHEMA entry missing" in problems[0]


def test_filter_valid_entries_accepts_well_formed_avsc_entry():
    entry = _row_to_entry(
        _delta_row(
            source_type="AVSC_SCHEMA", catalog_name=None, schema_name=None, table_name=None,
            file_path="abfss://schemas/device.avsc", data_path="abfss://landing/device/data/",
        )
    )
    valid, problems = filter_valid_entries([entry])
    assert valid == [entry]
    assert problems == []


def test_filter_valid_entries_rejects_unknown_source_type():
    entry = _row_to_entry(_delta_row(source_type="XML_BLOB"))
    valid, problems = filter_valid_entries([entry])
    assert valid == []
    assert "unknown source_type" in problems[0]


def test_control_entry_is_a_frozen_dataclass():
    entry = ControlEntry(
        entry_id="e1", team_name="t", source_type="DELTA_TABLE",
        catalog_name="c", schema_name="s", table_name="t1",
        file_path=None, data_path=None, checks_override=None, is_active=True,
    )
    assert entry.fq_table_name == "c.s.t1"
