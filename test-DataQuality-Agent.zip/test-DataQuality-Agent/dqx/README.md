# dq-dqx-framework

The Tier-1 DQX Module for the **DCS Data Quality AI Agent** project (see the
repo root [`../CONTEXT_BRIEF.md`](../CONTEXT_BRIEF.md) and
[`../docs/04_DQX_INTEGRATION.md`](../docs/04_DQX_INTEGRATION.md) for full
grounding). This is a real, installable Python package/framework — not a
single flat script — that wraps `databricks-labs-dqx` and runs its checks
against whatever a team has registered in the control master table.

**Illustrative reference implementation, not deployed as-is.** Adapt catalog/
schema names, cluster policy, and scheduling to your workspace. It is written
to show the shape of a real framework (package layout, config module, unit
tests) rather than to be dropped unmodified into a production job.

## How this relates to the rest of `DCS-DataQuality-Agent`

- This package **is** the automated engine behind **Tier 1** of the two-tier
  model described in `CONTEXT_BRIEF.md` §1.4: zero-onboarding, read-only
  checks (completeness/validity/uniqueness/freshness/schema) against any
  source a team has registered — no `team_rule`/`dq_stats`/`data_profile`
  rows required.
- It reads its worklist from `dq_catalog.dq_config.dq_control_table`
  (`ddl/control_table_ddl.sql`) — a team onboards by adding **one row**
  naming their table (or parquet path, or `.avsc` schema + data path).
  See §1 of `docs/04_DQX_INTEGRATION.md` for the full onboarding model.
- It writes results **only** to the three DQX-owned metadata tables defined
  in `ddl/dqx_metadata_tables_ddl.sql` (`dqx_results`, `dqx_quarantine`,
  `dqx_run_metrics`) — never back to any team's source table, and never into
  `team_rule`/`dq_stats`/`data_profile`. This is the same zero-copy/
  zero-pipeline-change guarantee documented in `docs/04_DQX_INTEGRATION.md`
  §2.
- `dqx_results` is shaped to mirror `dq_stats`'s grain so the **DQ Execution
  Analytics** Genie space (`docs/03_GENIE_WORKSPACES.md`) can query Tier 1
  and Tier 2 results uniformly.

## Project layout

```
dqx/
  pyproject.toml               Package metadata, pinned databricks-labs-dqx==0.15.0
  README.md                    This file
  ddl/
    control_table_ddl.sql       dq_control_table -- the onboarding worklist
    dqx_metadata_tables_ddl.sql dqx_results / dqx_quarantine / dqx_run_metrics
  src/dq_dqx_framework/
    __init__.py
    config.py                  Constants: catalogs/schemas, output/quarantine/
                                metrics config, anomaly-detection cost-control flag
    control_table.py           load_active_entries() -- reads dq_control_table
    source_readers.py          read_source(entry) -- dispatches on source_type
    checks.py                  built_in_checks_for() / profile_and_generate_checks()
    runner.py                  has_prior_dqx_run() / run_target() -- per-entry execution
    __main__.py                Entrypoint a Databricks Job points at
  tests/
    test_control_table.py      Unit tests for control-table filtering logic
    test_source_readers.py     Unit tests for the source_type dispatch logic
```

## Install

From inside `dqx/`:

```bash
pip install -e .
# AVSC_SCHEMA source support needs fastavro:
pip install -e ".[avro]"
# Local dev/testing outside a Databricks cluster needs a local pyspark:
pip install -e ".[local-dev,dev]"
```

On Databricks, `pyspark` is provided by the job/cluster runtime — do not
install it there; only `databricks-labs-dqx` (and `fastavro` if any control
table row uses `AVSC_SCHEMA`) need to be added as cluster/job libraries,
pinned to the versions in `pyproject.toml`.

## Run

As a Databricks Job (or notebook `%run`), point the job task at the
`dq-dqx-run` console-script entrypoint, or run the module directly:

```bash
python -m dq_dqx_framework
```

This calls `control_table.load_active_entries()` to read every `is_active =
true` row from `dq_catalog.dq_config.dq_control_table`, then calls
`runner.run_target(entry)` once per entry. Requires:

- `SELECT` on every table/path/schema-file registered in the control table.
- `USE CATALOG` / `CREATE TABLE` on `dq_catalog.dq_results` (this job's own
  results schema).

No other team's pipeline, job, or table is modified by running this package.

## Tests

```bash
pip install -e ".[dev]"
pytest tests/
```

The included tests are **unit-test stubs** for the control-table filtering
and source-dispatch logic only — they use plain dict fixtures / mocks, not a
live Spark session. Full integration testing (actually reading a Delta
table, writing to `dqx_results`, etc.) needs a Databricks cluster or a local
Spark session and is out of scope for these stubs; see the comment at the
top of each test file.

## Design decisions carried forward from the original `central_dq_job.py`

These rationale points predate this package restructuring and still hold;
see the relevant module docstring for where each now lives:

- **Version pinning + changelog-review caveat** (`pyproject.toml`,
  `config.py`): DQX is pre-1.0 with real breaking changes between releases
  (v0.15.0 itself changed the anomaly-detection defaults and the `_dq_info`
  schema) — never let this auto-upgrade silently.
- **Cost control: ML anomaly detection off by default** (`config.py`
  `ANOMALY_DETECTION_CONFIG`): DQX v0.15.0 enables ML-based anomaly detection
  by default, which calls Model Serving — real, metered cost. Disabled here
  explicitly; re-enable per table only once a team has a concrete use case
  and has accepted the cost.
- **Cold-start profiler fallback** (`runner.py` / `checks.py`): a
  never-before-seen source gets profiled (DQX default 30%/1000-row sample)
  to auto-generate candidate checks on its first run; subsequent runs use the
  established check set instead of re-profiling every time.
- **Read-only / no-write-back guarantee** (`source_readers.py` / `runner.py`):
  every source is read via `spark.read.table(...)` / `spark.read.parquet(...)`
  / an Avro-schema-driven read — never written to. Results land only in the
  three DQX-owned metadata tables.
- **Standard job cluster, no Serverless required** (this README, `config.py`):
  the core DQX engine runs on a standard job cluster (Spark ≥3.5.0, DBR
  ≥15.4 recommended). Only the optional DQX Studio no-code UI needs
  Serverless, and that is out of scope here.
