"""Dispatch a control-table entry to the right Spark read, by source_type.

Read-only, always: every branch below reads into a DataFrame and never
writes anywhere -- this is the only touch this module makes on a team's
source. No write, no schema change, no side effect on the owning team's data.
See runner.py for where the resulting DataFrame is checked and where results
are written (to the DQX-owned tables only, never back to the source).
"""

from __future__ import annotations

from dq_dqx_framework.control_table import ControlEntry


def read_source(spark, entry: ControlEntry):
    """Return a DataFrame for `entry`, dispatching on entry.source_type.

    DELTA_TABLE   -> spark.read.table(fqtn)
    PARQUET_PATH  -> spark.read.parquet(path)
    AVSC_SCHEMA   -> read the .avsc to get an explicit schema, then apply it
                     reading data_path (the .avsc alone is schema, not data)
    """
    if entry.source_type == "DELTA_TABLE":
        return _read_delta_table(spark, entry)
    if entry.source_type == "PARQUET_PATH":
        return _read_parquet_path(spark, entry)
    if entry.source_type == "AVSC_SCHEMA":
        return _read_avsc_schema(spark, entry)
    raise ValueError(f"Unsupported source_type '{entry.source_type}' for entry {entry.entry_id}")


def _read_delta_table(spark, entry: ControlEntry):
    fqtn = entry.fq_table_name
    if not fqtn:
        raise ValueError(f"DELTA_TABLE entry {entry.entry_id} is missing catalog_name/schema_name/table_name")
    # Read-only: this is the only touch this module makes on the source
    # table. No write, no schema change, no side effect on the owning
    # team's data.
    return spark.read.table(fqtn)


def _read_parquet_path(spark, entry: ControlEntry):
    if not entry.file_path:
        raise ValueError(f"PARQUET_PATH entry {entry.entry_id} is missing file_path")
    return spark.read.parquet(entry.file_path)


def _read_avsc_schema(spark, entry: ControlEntry):
    """Illustrative AVSC_SCHEMA path.

    A real implementation needs an Avro schema library available on the
    cluster -- fastavro (declared as the optional `avro` extra in
    pyproject.toml) to parse the .avsc into a schema object, translated into
    a Spark schema (StructType) before reading data_path. The spark-avro
    reader (`spark.read.format("avro")`) is an alternative if data_path
    itself is Avro-encoded rather than Parquet/CSV/JSON described by an
    external .avsc -- pick whichever matches how the team's data is actually
    encoded on disk; this function shows the fastavro-schema-then-generic-
    read shape since that's the more common "schema file separate from data
    files" case this source_type exists for.
    """
    if not (entry.file_path and entry.data_path):
        raise ValueError(
            f"AVSC_SCHEMA entry {entry.entry_id} needs both file_path (the .avsc) "
            "and data_path (where the actual data lives) -- the .avsc alone "
            "is schema, not data"
        )

    try:
        import fastavro  # noqa: F401  -- optional dependency, see pyproject.toml "avro" extra
    except ImportError as exc:  # pragma: no cover - illustrative guidance only
        raise ImportError(
            "Reading AVSC_SCHEMA entries requires fastavro. Install with "
            "`pip install -e '.[avro]'` (see dqx/pyproject.toml)."
        ) from exc

    spark_schema = _avsc_to_spark_schema(entry.file_path)
    # Illustrative: assumes data_path holds files in a format spark.read can
    # apply an explicit schema to (e.g. CSV/JSON/Parquet-without-embedded-
    # schema). If data_path is itself Avro-encoded, prefer
    # spark.read.format("avro").load(entry.data_path) instead, which reads
    # the embedded Avro schema natively and does not need this translation
    # step at all.
    return spark.read.schema(spark_schema).parquet(entry.data_path)


def _avsc_to_spark_schema(avsc_path: str):
    """Parse a .avsc file (via fastavro) and translate it to a Spark
    StructType. Illustrative stub -- a real implementation needs a full
    Avro-type-to-Spark-type mapping (record/array/map/union/logical types,
    nullability from Avro unions with "null"); left unimplemented here since
    it's a non-trivial amount of mapping code orthogonal to this framework's
    control-flow, not something to fake with a shortcut.
    """
    raise NotImplementedError(
        "Avro-schema-to-Spark-schema translation is illustrative only in this "
        "reference implementation -- implement using fastavro.schema.load_schema() "
        f"against '{avsc_path}' plus an Avro-type -> Spark-type mapping before "
        "using AVSC_SCHEMA entries in a real run."
    )
