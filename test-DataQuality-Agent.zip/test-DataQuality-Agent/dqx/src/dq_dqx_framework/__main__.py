# Databricks notebook source / job entrypoint
# MAGIC %md
# MAGIC # DQX Module -- Tier-1 Sweep Entrypoint
# MAGIC
# MAGIC **Illustrative reference implementation -- not deployed as-is.** Adapt
# MAGIC catalog/schema names, cluster policy, and scheduling to your workspace
# MAGIC before running.
# MAGIC
# MAGIC Owned and operated exclusively by the central Data Quality team. Runs
# MAGIC on a standard job cluster (no serverless requirement for the DQX core
# MAGIC engine). Requires only:
# MAGIC   - SELECT on every table/path/schema-file registered in
# MAGIC     dq_catalog.dq_config.dq_control_table
# MAGIC   - USE CATALOG / CREATE TABLE on the DQ team's own results schema
# MAGIC     (dq_catalog.dq_results)
# MAGIC
# MAGIC No other team's pipeline, job, or table is modified by this entrypoint.
# MAGIC See docs/04_DQX_INTEGRATION.md section 2 for the full design rationale,
# MAGIC and dqx/README.md for how this package is installed and run.

"""Entrypoint a Databricks Job points at.

Flow: control_table.load_active_entries() -> runner.run_target() once per
entry. Replaces the old central_dq_job.py flow of load_run_configs() +
expand_table_pattern() (wildcard registry resolution) -- the control table
is already one row per source, so there is no pattern-expansion step here.
"""

from __future__ import annotations

from dq_dqx_framework.config import CONTROL_TABLE
from dq_dqx_framework.control_table import filter_valid_entries, load_active_entries
from dq_dqx_framework.runner import build_engine, run_target


def main() -> None:
    spark = globals().get("spark")  # provided by the Databricks notebook/job runtime
    if spark is None:
        raise RuntimeError(
            "No SparkSession found. Run this entrypoint on a Databricks job "
            "cluster/notebook, or pass a SparkSession explicitly when calling "
            "run() directly for local testing."
        )
    run(spark)


def run(spark) -> None:
    engine = build_engine()

    entries = load_active_entries(spark, CONTROL_TABLE)
    valid_entries, problems = filter_valid_entries(entries)

    for problem in problems:
        # Illustrative: a real job should log these to the job's own
        # logging/alerting rather than print(), and should not silently
        # skip a malformed control-table row without surfacing it somewhere
        # a human will see (e.g. a Slack/email alert to the DQ platform team).
        print(f"[dq-dqx-framework] skipping invalid control-table row: {problem}")

    for entry in valid_entries:
        run_target(spark, engine, entry)


if __name__ == "__main__":
    main()
