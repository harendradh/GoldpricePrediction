"""Load the DQX Module's onboarding worklist from the control master table.

Replaces the old load_run_configs() YAML/wildcard-registry logic from the
flat central_dq_job.py script. Onboarding is now "one row per source" instead
of a wildcard table_pattern expanded against information_schema -- see
../ddl/control_table_ddl.sql for the schema and rationale, and
docs/04_DQX_INTEGRATION.md section 2.5 (post-restructure) for the design
narrative.
"""

from __future__ import annotations

from dataclasses import dataclass

from dq_dqx_framework.config import CONTROL_TABLE, DEFAULT_CHECK_SUITE, VALID_SOURCE_TYPES


@dataclass(frozen=True)
class ControlEntry:
    """One row of dq_control_table -- one onboarded source."""

    entry_id: str
    team_name: str
    source_type: str
    catalog_name: str | None
    schema_name: str | None
    table_name: str | None
    file_path: str | None
    data_path: str | None
    checks_override: list[str] | None
    is_active: bool

    @property
    def checks(self) -> list[str]:
        """Effective check list: checks_override if a team narrowed it,
        otherwise the DQX Module's full default built-in suite."""
        return list(self.checks_override) if self.checks_override else list(DEFAULT_CHECK_SUITE)

    @property
    def fq_table_name(self) -> str | None:
        """catalog.schema.table for DELTA_TABLE entries, else None."""
        if self.source_type != "DELTA_TABLE":
            return None
        if not (self.catalog_name and self.schema_name and self.table_name):
            return None
        return f"{self.catalog_name}.{self.schema_name}.{self.table_name}"

    def display_name(self) -> str:
        """Human-readable identifier for logs/metrics rows, whatever the
        source_type -- a Delta fqtn, or a file_path."""
        return self.fq_table_name or self.file_path or self.entry_id


def _row_to_entry(row: dict) -> ControlEntry:
    return ControlEntry(
        entry_id=row["entry_id"],
        team_name=row["team_name"],
        source_type=row["source_type"],
        catalog_name=row.get("catalog_name"),
        schema_name=row.get("schema_name"),
        table_name=row.get("table_name"),
        file_path=row.get("file_path"),
        data_path=row.get("data_path"),
        checks_override=row.get("checks_override"),
        is_active=bool(row.get("is_active", True)),
    )


def load_active_entries(spark, control_table: str = CONTROL_TABLE) -> list[ControlEntry]:
    """Read every is_active = true row from dq_control_table.

    `spark` is a SparkSession, provided by the Databricks notebook/job
    runtime (kept as a parameter, not a module-level global, so this
    function is trivially unit-testable with a stub -- see
    tests/test_control_table.py).
    """
    rows = (
        spark.sql(
            f"""
            SELECT entry_id, team_name, source_type, catalog_name, schema_name,
                   table_name, file_path, data_path, checks_override, is_active
            FROM {control_table}
            WHERE is_active = true
            """
        )
        .collect()
    )
    return [_row_to_entry(r.asDict()) for r in rows]


def filter_valid_entries(entries: list[ControlEntry]) -> tuple[list[ControlEntry], list[str]]:
    """Split entries into (valid, problem-descriptions-for-invalid).

    A row is invalid if its source_type isn't recognized, or if the columns
    required for its declared source_type are missing (e.g. an AVSC_SCHEMA
    row without a data_path -- the .avsc alone is schema, not data).
    Pulled out as a pure function (no Spark dependency) precisely so it can
    be unit tested against plain fixtures -- see
    tests/test_control_table.py.
    """
    valid: list[ControlEntry] = []
    problems: list[str] = []

    for e in entries:
        if e.source_type not in VALID_SOURCE_TYPES:
            problems.append(f"{e.entry_id}: unknown source_type '{e.source_type}'")
            continue

        if e.source_type == "DELTA_TABLE" and not e.fq_table_name:
            problems.append(f"{e.entry_id}: DELTA_TABLE entry missing catalog_name/schema_name/table_name")
            continue

        if e.source_type == "PARQUET_PATH" and not e.file_path:
            problems.append(f"{e.entry_id}: PARQUET_PATH entry missing file_path")
            continue

        if e.source_type == "AVSC_SCHEMA" and not (e.file_path and e.data_path):
            problems.append(
                f"{e.entry_id}: AVSC_SCHEMA entry missing file_path (the .avsc) and/or "
                "data_path (where the actual data lives)"
            )
            continue

        valid.append(e)

    return valid, problems
