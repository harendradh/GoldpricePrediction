"""Per-entry execution: cold-start detection, running DQX checks, and
writing results to the three DQX-owned metadata tables.

Ported from the flat central_dq_job.py's has_prior_dqx_run()/run_target(),
adapted to entry-based config (ControlEntry) instead of the old
table_pattern/wildcard-resolved target dict, and to the explicit column
schemas now defined in ../ddl/dqx_metadata_tables_ddl.sql (previously these
tables were referenced only as path strings with no column schema anywhere
in the project).
"""

from __future__ import annotations

import time
from datetime import datetime, timezone

from databricks.labs.dqx.engine import DQEngine
from databricks.sdk import WorkspaceClient

from dq_dqx_framework.checks import checks_for_entry, profile_and_generate_checks
from dq_dqx_framework.config import METRICS_CONFIG, OUTPUT_CONFIG, QUARANTINE_CONFIG, ANOMALY_DETECTION_CONFIG
from dq_dqx_framework.control_table import ControlEntry
from dq_dqx_framework.source_readers import read_source


def has_prior_dqx_run(spark, entry: ControlEntry) -> bool:
    """Tier-1 cold-start detection: has this source ever been profiled/
    checked by this module before? If not, the caller should run the
    profiler first to auto-generate candidate checks -- this is what gives a
    brand-new team's source completeness/validity/uniqueness/freshness
    coverage on day one with zero team_rule/data_profile rows (brief section
    1.4).

    Looks up dqx_run_metrics by entry_id rather than dqx_results, since
    dqx_run_metrics is the run-level (one row per run) table -- a cheaper
    existence check than scanning check-level dqx_results rows.
    """
    existing = spark.sql(
        f"""
        SELECT 1 FROM {METRICS_CONFIG['location']}
        WHERE entry_id = '{entry.entry_id}' LIMIT 1
        """
    )
    return existing.limit(1).count() > 0


def run_target(spark, engine: DQEngine, entry: ControlEntry) -> None:
    """Run the DQX Module against one control-table entry, writing results
    only to the three DQX-owned metadata tables -- never back to the
    source. This is the only per-entry execution path; __main__.py calls
    this once per active control-table row.
    """
    start = time.monotonic()

    # Read-only: this is the only touch this module makes on the source.
    # No write, no schema change, no side effect on the owning team's data.
    df = read_source(spark, entry)

    if has_prior_dqx_run(spark, entry):
        checks = checks_for_entry(entry)
    else:
        checks = profile_and_generate_checks(engine, df)  # cold-start path

    valid_df, quarantine_df = engine.apply_checks_by_metadata_and_split(
        df,
        checks,
        # ML anomaly detection stays explicitly off unless a table opts in --
        # see config.ANOMALY_DETECTION_CONFIG.
        extra_params={"anomaly_detection": ANOMALY_DETECTION_CONFIG},
    )

    now = datetime.now(timezone.utc)
    execution_id = f"{entry.entry_id}_{now.isoformat()}"
    input_count = df.count()
    valid_count = valid_df.count()
    quarantined_count = quarantine_df.count()
    duration_seconds = time.monotonic() - start

    _write_results(spark, entry, execution_id, checks, valid_df, quarantine_df, now)
    _write_quarantine(spark, entry, execution_id, quarantine_df, now)
    _write_run_metrics(
        spark, entry, execution_id, input_count, valid_count, quarantined_count, duration_seconds, now
    )


def _write_results(spark, entry: ControlEntry, execution_id: str, checks: list[dict], valid_df, quarantine_df, now) -> None:
    """Write check-level rows to dqx_results (see
    ../ddl/dqx_metadata_tables_ddl.sql for the column schema). One row per
    check per run -- built from the check specs actually evaluated, plus
    pass/fail counts derived from the valid/quarantine split, rather than an
    ad hoc inferred-DataFrame write.
    """
    rows = []
    for check in checks:
        check_name = check.get("check", {}).get("function", "unknown")
        criticality = check.get("criticality", "warn")
        # Illustrative: apply_checks_by_metadata_and_split does not itself
        # return a per-check pass/fail breakdown in this simplified sketch;
        # a real implementation should use DQEngine's per-check result API
        # (e.g. the _errors/_warnings columns or a checks-summary call) to
        # populate check_status/failed_row_count per check exactly, rather
        # than approximating from the overall quarantine_df count.
        rows.append(
            (
                execution_id,
                entry.entry_id,
                entry.team_name,
                entry.source_type,
                entry.catalog_name,
                entry.schema_name,
                entry.table_name,
                entry.file_path,
                check_name,
                None,  # check_column -- populate from the check spec's column ref if present
                criticality,
                "FAIL" if quarantine_df.count() > 0 else "PASS",
                quarantine_df.count(),
                valid_df.count() + quarantine_df.count(),
                now,
                now.date(),
            )
        )

    columns = [
        "execution_id", "entry_id", "team_name", "source_type", "catalog_name",
        "schema_name", "table_name", "file_path", "check_name", "check_column",
        "criticality", "check_status", "failed_row_count", "input_record_count",
        "run_ts", "run_date",
    ]
    spark.createDataFrame(rows, columns).write.mode(OUTPUT_CONFIG["mode"]).saveAsTable(OUTPUT_CONFIG["location"])


def _write_quarantine(spark, entry: ControlEntry, execution_id: str, quarantine_df, now) -> None:
    """Write quarantined rows to dqx_quarantine, JSON-serializing each
    failing row since the source schema varies per table/file and cannot be
    strongly typed in this shared table (see
    ../ddl/dqx_metadata_tables_ddl.sql).
    """
    import json

    from pyspark.sql.functions import lit, to_json, struct

    if quarantine_df.rdd.isEmpty():
        return

    (
        quarantine_df
        .select(to_json(struct([c for c in quarantine_df.columns])).alias("quarantined_row"))
        .withColumn("execution_id", lit(execution_id))
        .withColumn("entry_id", lit(entry.entry_id))
        .withColumn("team_name", lit(entry.team_name))
        .withColumn("table_name", lit(entry.table_name))
        .withColumn("file_path", lit(entry.file_path))
        .withColumn("run_ts", lit(now))
        # Illustrative: a real implementation should carry the actual list of
        # failed check names per row from DQEngine's split output rather than
        # a placeholder -- left as a follow-up since DQEngine's exact
        # per-row failed-checks column name varies by version (see the
        # _dq_info schema-change caveat in config.py / docs/04).
        .withColumn("failed_checks", lit(json.dumps([])))
        .select("execution_id", "entry_id", "team_name", "table_name", "file_path", "run_ts", "quarantined_row", "failed_checks")
        .write.mode(QUARANTINE_CONFIG["mode"]).saveAsTable(QUARANTINE_CONFIG["location"])
    )


def _write_run_metrics(
    spark, entry: ControlEntry, execution_id: str, input_count: int, valid_count: int,
    quarantined_count: int, duration_seconds: float, now,
) -> None:
    """Write one run-level row to dqx_run_metrics (see
    ../ddl/dqx_metadata_tables_ddl.sql for the column schema)."""
    row = [
        (
            execution_id,
            entry.entry_id,
            entry.team_name,
            entry.table_name,
            entry.file_path,
            input_count,
            valid_count,
            quarantined_count,
            duration_seconds,
            now,
            now.date(),
        )
    ]
    columns = [
        "execution_id", "entry_id", "team_name", "table_name", "file_path",
        "input_record_count", "valid_count", "quarantined_count",
        "duration_seconds", "run_ts", "run_date",
    ]
    spark.createDataFrame(row, columns).write.mode(METRICS_CONFIG["mode"]).saveAsTable(METRICS_CONFIG["location"])


def build_engine() -> DQEngine:
    """Construct the DQEngine used across a run. Split out so tests/tooling
    can substitute a stub instead of a real WorkspaceClient."""
    return DQEngine(WorkspaceClient())
