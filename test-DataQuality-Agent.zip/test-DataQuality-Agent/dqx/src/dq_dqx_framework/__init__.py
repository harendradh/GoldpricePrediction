"""dq_dqx_framework -- the Tier-1 DQX Module for the DCS Data Quality AI Agent.

Illustrative reference implementation, not deployed as-is. See ../README.md
and ../../docs/04_DQX_INTEGRATION.md for full design context.
"""

__version__ = "0.1.0"
