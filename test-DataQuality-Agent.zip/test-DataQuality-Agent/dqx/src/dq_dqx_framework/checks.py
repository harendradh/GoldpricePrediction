"""Check-set resolution: built-in check mapping and cold-start profiling.

Ported from the flat central_dq_job.py, adapted to entry-based config
(ControlEntry from control_table.py) instead of the old run_config dict
produced by the wildcard rule registry.
"""

from __future__ import annotations

from pyspark.sql import DataFrame

from dq_dqx_framework.control_table import ControlEntry

# Illustrative subset -- DQX ships 50+ built-ins; see
# databrickslabs.github.io/dqx (Apply Quality Checks) for the full catalog.
# "schema" is included here because it is part of the DQX Module's default
# full built-in suite (see config.DEFAULT_CHECK_SUITE); schema checks are
# DQX's own is_schema/ODCS-contract-style checks, not a bespoke addition.
_BUILT_IN_CHECK_CATALOG = {
    "completeness": {"check": {"function": "is_not_null"}, "criticality": "error"},
    "validity": {"check": {"function": "regex_match"}, "criticality": "warn"},
    "uniqueness": {"check": {"function": "is_unique"}, "criticality": "error"},
    "freshness": {"check": {"function": "is_recent"}, "criticality": "warn"},
    "schema": {"check": {"function": "is_schema"}, "criticality": "warn"},
}


def built_in_checks_for(check_names: list[str]) -> list[dict]:
    """Map control-table-declared check categories (entry.checks, i.e.
    checks_override or the default full suite) to DQX built-in check specs."""
    return [_BUILT_IN_CHECK_CATALOG[name] for name in check_names if name in _BUILT_IN_CHECK_CATALOG]


def checks_for_entry(entry: ControlEntry) -> list[dict]:
    """Resolve the effective check list for one control-table entry."""
    return built_in_checks_for(entry.checks)


def profile_and_generate_checks(engine, df: DataFrame) -> list[dict]:
    """Sample the source (DQX default: 30% / 1000 rows) and auto-generate
    candidate checks. Used only for sources with no prior DQX run -- once a
    source has an established check set (built-in or promoted to a
    human-authored team_rule), routine runs use the fixed check set instead
    of re-profiling every time.

    This is the cold-start fallback referenced in CONTEXT_BRIEF.md section
    1.4 / docs/04_DQX_INTEGRATION.md section 3: it is what gives a
    brand-new team's table completeness/validity/uniqueness/freshness
    coverage on day one with zero team_rule/data_profile rows, adapting per
    table instead of relying only on the fixed built_in_checks_for() list.

    `engine` is a databricks.labs.dqx.engine.DQEngine instance, passed in
    (not imported/constructed here) so this function stays unit-testable
    with a stub/mock -- see runner.py for where the real DQEngine is built.
    """
    from databricks.labs.dqx.profiler.profiler import DQProfiler
    from databricks.labs.dqx.profiler.generator import DQGenerator

    profiler = DQProfiler(engine.ws)
    _summary_stats, profiles = profiler.profile(df)
    generator = DQGenerator(engine.ws)
    return generator.generate_dq_rules(profiles)
