"""Central configuration for the DQX Module.

Owned and operated exclusively by the central Data Quality team. Nothing in
this module grants write access to any other team's table -- it only names
where THIS module's own control table and results tables live.
"""

# ----------------------------------------------------------------------------
# Where this module reads its onboarding worklist from.
# See ../ddl/control_table_ddl.sql -- a team onboards by adding one row here.
# ----------------------------------------------------------------------------
CONTROL_CATALOG = "dq_catalog"
CONTROL_SCHEMA = "dq_config"
CONTROL_TABLE = f"{CONTROL_CATALOG}.{CONTROL_SCHEMA}.dq_control_table"

# ----------------------------------------------------------------------------
# Where results land. This schema is owned by the DQ team ONLY. DQX never
# writes back to a source table -- these are the only three destinations any
# check result, quarantined row, or metric is written to. See
# ../ddl/dqx_metadata_tables_ddl.sql for the column schema of each.
# ----------------------------------------------------------------------------
RESULTS_CATALOG = "dq_catalog"
RESULTS_SCHEMA = "dq_results"

OUTPUT_CONFIG = {
    "location": f"{RESULTS_CATALOG}.{RESULTS_SCHEMA}.dqx_results",
    "mode": "append",
}
QUARANTINE_CONFIG = {
    "location": f"{RESULTS_CATALOG}.{RESULTS_SCHEMA}.dqx_quarantine",
    "mode": "append",
}
METRICS_CONFIG = {
    "location": f"{RESULTS_CATALOG}.{RESULTS_SCHEMA}.dqx_run_metrics",
    "mode": "append",
}

# ----------------------------------------------------------------------------
# Cost control: ML anomaly detection is enabled BY DEFAULT in DQX v0.15.0 and
# calls Model Serving on every run -- that is real, metered cost, not a free
# static check. Disable explicitly for the initial rollout; re-enable per
# table only once a team has a concrete use case and has accepted the Model
# Serving cost. Do not rely on the library default here.
#
# See docs/04_DQX_INTEGRATION.md section 6 for the full cost/governance
# rationale, and dqx/README.md for the carried-forward design-decision list.
# ----------------------------------------------------------------------------
ANOMALY_DETECTION_CONFIG = {
    "enabled": False,  # cost control -- see docs/04_DQX_INTEGRATION.md section 6
}

# ----------------------------------------------------------------------------
# Pin the exact DQX version (mirrored in pyproject.toml's dependency pin).
# DQX is pre-1.0 with real breaking changes between releases -- v0.15.0
# itself changed the anomaly-detection defaults and the _dq_info result
# schema. Review the changelog at github.com/databrickslabs/dqx/releases
# before ever bumping this pin, and update pyproject.toml in the same change.
# ----------------------------------------------------------------------------
PINNED_DQX_VERSION = "0.15.0"

# Default Tier-1 built-in check suite. checks_override in the control table
# is NULL by default, meaning "run this full suite" -- a team only sets
# checks_override to restrict to a subset of these.
DEFAULT_CHECK_SUITE = ["completeness", "validity", "uniqueness", "freshness", "schema"]

# source_type values accepted in dq_control_table -- see
# ../ddl/control_table_ddl.sql.
SOURCE_TYPE_DELTA_TABLE = "DELTA_TABLE"
SOURCE_TYPE_PARQUET_PATH = "PARQUET_PATH"
SOURCE_TYPE_AVSC_SCHEMA = "AVSC_SCHEMA"
VALID_SOURCE_TYPES = (SOURCE_TYPE_DELTA_TABLE, SOURCE_TYPE_PARQUET_PATH, SOURCE_TYPE_AVSC_SCHEMA)
