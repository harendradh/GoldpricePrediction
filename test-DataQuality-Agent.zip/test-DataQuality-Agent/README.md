# Data Quality AI Agent — DCS Agent Studio

An investigative Data Quality AI Agent for the DCS platform: it explains
**why** quality degraded, finds **root cause** across business rules,
profiling, execution history, lineage, and schema — instead of another
dashboard. Metadata-driven, multi-team, and built to scale to hundreds of
data products and thousands of pipelines without new infrastructure per team.

Runs on the Databricks-hosted Claude endpoint inside **DCS Agent Studio**,
alongside the other teams' agents already onboarded there.

> Fresh, standalone project — not a continuation of any prior repo. See
> [`CONTEXT_BRIEF.md`](CONTEXT_BRIEF.md) for the single source of truth this
> entire project was built against (schema, architecture decisions, DQX
> research findings) — read it first if you're extending this project.

## Two-tier architecture, in brief

- **Tier 1 — zero onboarding, always on.** [DQX](docs/04_DQX_INTEGRATION.md)
  runs read-only against any Unity Catalog table the agent has `SELECT` on —
  no data copy, no changes to a team's own pipeline code, no serverless
  compute required. A team gets completeness/validity/uniqueness/freshness/
  schema coverage from the moment access is granted.
- **Tier 2 — richer, opportunistic.** When a team already writes to the three
  shared metadata tables — `team_rule` (business rules), `dq_stats`
  (execution history), `data_profile` (profiling metrics) — those
  human-curated signals are preferred and take precedence over Tier 1's
  AI-inferred findings.

The agent always states which tier answered a question.

## Project layout

```
CONTEXT_BRIEF.md                              Ground truth for schema/decisions — read first
docs/00_EXECUTIVE_SUMMARY.md                  Leadership-facing 1-2 page summary
docs/01_ARCHITECTURE.md                       Full end-to-end component architecture
docs/02_QUALITY_DIMENSIONS.md                 7 dimensions — detection, investigation, root cause, AI reasoning
docs/03_GENIE_WORKSPACES.md                   Full specs for all 8 Genie spaces (paste-ready)
docs/04_DQX_INTEGRATION.md                    DQX zero-copy/zero-pipeline-change design + phased rollout
docs/05_LAKEHOUSE_MONITORING_ADOPTION.md      Current-state gap, migration approach, operational benefits
docs/06_SNAPSHOT_PATTERN_MAPPING.md           Evaluates the reference article's pattern against this stack
docs/07_AGENT_CAPABILITIES.md                 All 17 capabilities, one subsection each
docs/08_ONBOARDING_RUNBOOK.md                 Step-by-step deployment + new-team onboarding
docs/presentations/                           Leadership Word doc + diagrams (build scripts included)
agent_studio/                                 Agent Studio Create Agent / system instruction / tool manifest
genie/                                        (Genie space specs live in docs/03; folder reserved for exports)
rag/                                          4 RAG source collections (glossary, playbooks, incidents, DQX reference)
dqx/                                          Installable dq-dqx-framework Python package (Tier-1 DQX Module)
evals/eval_cases.md                           20 eval cases, 7 zero-tolerance/release-blocking
```

## Quickstart

1. Read [`docs/00_EXECUTIVE_SUMMARY.md`](docs/00_EXECUTIVE_SUMMARY.md) for
   the one-page pitch, then [`docs/01_ARCHITECTURE.md`](docs/01_ARCHITECTURE.md)
   for the full component architecture.
2. Follow [`docs/08_ONBOARDING_RUNBOOK.md`](docs/08_ONBOARDING_RUNBOOK.md)
   step-by-step to grant access, create the 8 Genie spaces, deploy the DQX
   pilot job, and create the agent in DCS Agent Studio.
3. Run every case in [`evals/eval_cases.md`](evals/eval_cases.md) — the 7
   zero-tolerance cases (ZT-01–ZT-07) are release-blocking.
4. For a leadership walkthrough, present
   [`docs/presentations/DQ_Agent_Enterprise_Leadership_Architecture.docx`](docs/presentations/DQ_Agent_Enterprise_Leadership_Architecture.docx).

## The 8 Genie workspaces

Rule Intelligence · Profiling Intelligence · DQ Execution Analytics · Schema
Intelligence · Freshness Intelligence · Volume Intelligence · Lineage &
Impact Analysis · Governance Intelligence — full specs in
[`docs/03_GENIE_WORKSPACES.md`](docs/03_GENIE_WORKSPACES.md).

## The 7 quality dimensions

Completeness, Validity, Consistency, Uniqueness, Timeliness, Volume, Schema
Drift — each with a full investigation workflow, root-cause strategy, and
remediation playbook in
[`docs/02_QUALITY_DIMENSIONS.md`](docs/02_QUALITY_DIMENSIONS.md) and
[`rag/dimension_playbooks.md`](rag/dimension_playbooks.md).

Rollout is phased: **Completeness, Validity, and Uniqueness ship first**
(pure rule-execution + DQX built-in checks, no new infrastructure);
Consistency, Timeliness, Volume, and Schema Drift follow once Phase 1 is
live and validated.

## DQX — the answer to "what if a team has none of these tables yet"

[`docs/04_DQX_INTEGRATION.md`](docs/04_DQX_INTEGRATION.md) confirms, from
current (2026) Databricks Labs DQX documentation: a central, DQ-team-owned
job can run DQX checks read-only against **any other team's Unity Catalog
table, Parquet path, or Avro-schema-described dataset** with only a `SELECT`
grant — no data copied, no changes to that team's pipeline code, no
serverless compute needed for the core engine. Results land in three
DQX-owned tables. This is Tier 1, implemented as an installable Python
framework — [`dqx/`](dqx/) (package `dq-dqx-framework`, see
[`dqx/README.md`](dqx/README.md)):

- Onboarding worklist: [`dqx/ddl/control_table_ddl.sql`](dqx/ddl/control_table_ddl.sql)
  defines `dq_catalog.dq_config.dq_control_table` — a **Delta table**, not a
  YAML file or wildcard-pattern registry, where a team onboards by adding
  **one row** naming their table/path/schema-file. `INSERT`-only, UC-governed
  like everything else in this design.
- Generated metadata: [`dqx/ddl/dqx_metadata_tables_ddl.sql`](dqx/ddl/dqx_metadata_tables_ddl.sql)
  defines the three DQX-owned result tables (`dqx_results`,
  `dqx_quarantine`, `dqx_run_metrics`) in `dq_catalog.dq_results`.
- Module code: [`dqx/src/dq_dqx_framework/`](dqx/src/dq_dqx_framework/) —
  `control_table.py`, `source_readers.py`, `checks.py`, `runner.py`, and the
  `__main__.py` entrypoint a Databricks Job points at.

An illustrative implementation — see `dqx/README.md` for install/run
instructions and every design decision (version pinning, cost control,
cold-start profiler fallback, read-only guarantee) carried forward into it.

## Design non-negotiables

- **Anti-fabrication.** `NOT_RUN` / `NO_RESULT` are never reported as `PASS`.
  Enforced in every Genie space's guardrails and eval cases ZT-01/ZT-03/ZT-04.
- **AI-assisted, not AI-autonomous.** The agent recommends rule/threshold
  changes and DQX check configs with rationale — it never has write access to
  `team_rule`, `dq_stats`, `data_profile`, or any production table, and never
  claims to have deployed anything (eval case ZT-05).
- **Human-curated (Tier 2) always outranks AI-inferred (Tier 1/DQX)** when
  both exist for the same table (eval case ZT-06).
- **Native Databricks first.** Unity Catalog, `information_schema`, Delta
  history/Time Travel, lineage system tables, Genie, DQX. No external tooling.

## Lakehouse Monitoring

Deferred today — no Serverless compute in this workspace — but DQX already
covers the same ground on standard job clusters in the interim. Full phased
migration approach in
[`docs/05_LAKEHOUSE_MONITORING_ADOPTION.md`](docs/05_LAKEHOUSE_MONITORING_ADOPTION.md).

## The reference "snapshot" design pattern

The attached article's pattern (ADLS + Collibra + a 5-stage rule-generator/
code-generator agent chain + a Data Fixer Tool) is evaluated component-by-
component in
[`docs/06_SNAPSHOT_PATTERN_MAPPING.md`](docs/06_SNAPSHOT_PATTERN_MAPPING.md):
the underlying pattern is sound and largely already implemented here, but its
literal 5-agent/ADLS/Collibra architecture is not recommended for this
environment — DQX + Genie + Unity Catalog already provide the same
capability natively, with far less to build and maintain.
