# Databricks notebook source
# MAGIC %md
# MAGIC # Secret Scan — Databricks Workspace Notebooks
# MAGIC Scans all notebooks under the configured workspace path for hardcoded secrets.

# COMMAND ----------

import sys
sys.path.insert(0, "/Workspace/Repos/<your-repo>/databricks-vscode-utility/src")

import json
from src.utils.notebook_scanner import NotebookScanner

# COMMAND ----------

dbutils.widgets.text("workspace_path", "/Shared", "Workspace path to scan")
dbutils.widgets.text("output_table", "main.governance.secret_scan_results", "Output Delta table")
dbutils.widgets.dropdown("fail_on_critical", "false", ["true", "false"], "Fail on critical findings")

workspace_path = dbutils.widgets.get("workspace_path")
output_table   = dbutils.widgets.get("output_table")
fail_on_critical = dbutils.widgets.get("fail_on_critical") == "true"

# COMMAND ----------

scanner = NotebookScanner(workspace_path=workspace_path)
results = scanner.scan_workspace()
report  = scanner.to_report(results)

print(f"Notebooks scanned  : {report['total_notebooks_scanned']}")
print(f"With secrets       : {report['notebooks_with_secrets']}")
print(f"Critical findings  : {report['critical_findings']}")
print(f"Total findings     : {report['total_findings']}")

# COMMAND ----------

if report["findings"]:
    findings_df = spark.createDataFrame(report["findings"])
    findings_df.write.format("delta").mode("overwrite").saveAsTable(output_table)
    print(f"Results saved to {output_table}")
    display(findings_df)
else:
    print("No secrets found.")

# COMMAND ----------

if fail_on_critical and report["critical_findings"] > 0:
    raise Exception(
        f"CRITICAL secrets found in {report['notebooks_with_secrets']} notebook(s). "
        f"Review {output_table} and remediate immediately."
    )
