# Databricks notebook source
# MAGIC %md
# MAGIC # PR Code Review Agent
# MAGIC Runs the GitHub Copilot review agent against open PRs and posts findings as comments.

# COMMAND ----------

import sys
sys.path.insert(0, "/Workspace/Repos/<your-repo>/databricks-vscode-utility/src")

from src.agent.copilot_review_agent import CopilotReviewAgent
from src.utils.git_utils import GitHubClient

# COMMAND ----------

dbutils.widgets.text("pr_numbers", "", "PR numbers (comma-separated, blank = open PRs)")
dbutils.widgets.dropdown("review_type", "all", ["all", "pyspark", "spark-java", "sql", "pr"], "Review type")
dbutils.widgets.dropdown("post_comment", "true", ["true", "false"], "Post review to GitHub")

pr_input    = dbutils.widgets.get("pr_numbers")
review_type = dbutils.widgets.get("review_type")
post_comment = dbutils.widgets.get("post_comment") == "true"

# COMMAND ----------

gh    = GitHubClient()
agent = CopilotReviewAgent()

if pr_input.strip():
    pr_numbers = [int(n.strip()) for n in pr_input.split(",") if n.strip()]
else:
    import requests, os
    resp = requests.get(
        f"https://api.github.com/repos/{os.environ['GITHUB_REPO']}/pulls?state=open&per_page=10",
        headers={"Authorization": f"Bearer {dbutils.secrets.get('github', 'token')}"},
    )
    pr_numbers = [pr["number"] for pr in resp.json()]
    print(f"Found {len(pr_numbers)} open PRs: {pr_numbers}")

# COMMAND ----------

for pr_number in pr_numbers:
    print(f"\n{'='*60}")
    print(f"Reviewing PR #{pr_number} ...")
    pr = gh.get_pr(pr_number)
    review = agent.review_pr(pr.number, pr.title, pr.body, pr.diff)
    print(review)
    if post_comment:
        gh.post_review_comment(pr_number, review)
        print(f"Review posted to PR #{pr_number}")
