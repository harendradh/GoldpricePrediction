# Databricks notebook source
# MAGIC %md
# MAGIC # DLT Pipeline — Code Review Results
# MAGIC This notebook is used as a DLT pipeline source to surface code review findings
# MAGIC as a managed Delta Live Tables table for dashboarding.

# COMMAND ----------

import dlt
from pyspark.sql import functions as F
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, TimestampType

# COMMAND ----------

FINDINGS_TABLE = spark.conf.get("findings_table", "main.governance.secret_scan_results")

# COMMAND ----------

@dlt.table(
    name="code_review_findings",
    comment="Aggregated code review and secret scan findings from automated PR reviews",
    table_properties={"pipelines.autoOptimize.managed": "true"},
)
@dlt.expect_or_drop("valid_severity", "severity IN ('CRITICAL', 'HIGH', 'MEDIUM', 'INFO')")
@dlt.expect("non_null_notebook", "notebook IS NOT NULL")
def code_review_findings():
    return (
        spark.readStream
        .format("delta")
        .table(FINDINGS_TABLE)
        .withColumn("reviewed_at", F.current_timestamp())
        .withColumn("day", F.to_date("reviewed_at"))
    )

# COMMAND ----------

@dlt.table(
    name="critical_findings_summary",
    comment="Daily summary of CRITICAL severity findings — used for alerting",
)
def critical_findings_summary():
    return (
        dlt.read("code_review_findings")
        .filter(F.col("severity") == "CRITICAL")
        .groupBy("day", "pattern", "severity")
        .agg(
            F.count("*").alias("finding_count"),
            F.collect_list("notebook").alias("affected_notebooks"),
        )
        .orderBy(F.col("finding_count").desc())
    )
