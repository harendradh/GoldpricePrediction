# Databricks VS Code Utility

Automated code review, secret scanning, and productivity skills for Databricks/Spark development.

## Stack
- **Databricks Asset Bundles** — infrastructure as code
- **uv** — Python package management
- **Databricks Connect** — local PySpark development against a remote cluster
- **GitHub Copilot Chat API** — powers the code review agent
- **32 Claude Code skills** — slash commands for daily Databricks tasks

## Quick start

### 1. Prerequisites
```powershell
# Install uv
irm https://astral.sh/uv/install.ps1 | iex

# Install Databricks CLI
winget install Databricks.DatabricksCLI
```

### 2. Install dependencies
```powershell
uv sync
```

### 3. Configure environment
```powershell
copy .env.example .env
# Edit .env and fill in:
#   DATABRICKS_HOST, DATABRICKS_TOKEN, DATABRICKS_CLUSTER_ID
#   GITHUB_TOKEN, GITHUB_REPO
#   COPILOT_TOKEN
```

### 4. Validate the bundle
```powershell
databricks bundle validate
```

### 5. Open in VS Code
```powershell
code .
# Accept recommended extensions when prompted
```

## Daily usage

### Review a pull request
```powershell
# Review all file types and post comment to GitHub
uv run python scripts/review_pr.py --pr 123 --type all --post

# Review PySpark files only
uv run python scripts/review_pr.py --pr 123 --type pyspark
```

### Scan for secrets
```powershell
# Scan Databricks workspace notebooks
uv run python scripts/scan_notebooks.py --path /Shared

# Scan local git repo
uv run python scripts/scan_git_secrets.py --all

# Scan only staged changes before committing
uv run python scripts/scan_git_secrets.py --staged --fail-on-critical
```

### Deploy
```powershell
# Deploy to dev
databricks bundle deploy --target dev

# Run the daily review job manually
databricks bundle run code_review_daily --target dev

# Deploy to prod
databricks bundle deploy --target prod
```

### Run tests
```powershell
uv run pytest tests/ -v
```

## Claude Code skills

Open this folder in Claude Code and use `/skill-name` to run any skill:

| Category | Skills |
|----------|--------|
| Code Review | `/pyspark-review`, `/spark-java-review`, `/sql-review`, `/pr-review`, `/dlt-review`, `/spark-streaming-review`, `/autoloader-review`, `/airflow-dag-review` |
| SQL & Data | `/sql-optimize`, `/sql-migration`, `/sql-to-pyspark`, `/merge-cdc`, `/delta-optimize` |
| Security | `/databricks-secret-scan`, `/github-secret-scan`, `/unity-catalog-scan` |
| Generation | `/drawio-generator`, `/data-lineage`, `/medallion-design`, `/javadocs`, `/notebook-docs`, `/cicd-generator`, `/api-to-databricks` |
| Refactoring | `/pyspark-refactor`, `/spark-java-refactor`, `/pyspark-unit-test`, `/schema-validator`, `/data-quality-check`, `/notebook-to-python`, `/spark-performance-audit` |
| Infrastructure | `/dab-validate`, `/cluster-cost-optimizer` |

## GitHub Copilot agent

The `.github/copilot-instructions.md` file configures Copilot with full PySpark, Spark Java, SQL, and security standards. Copilot will automatically apply these rules in VS Code suggestions and chat.

## CI/CD workflows

| Workflow | Trigger | What it does |
|----------|---------|-------------|
| `pr-code-review.yml` | PR opened/updated | Reviews PySpark, SQL, Spark Java files via agent |
| `secret-scan.yml` | Every push + daily | GitLeaks, TruffleHog, detect-secrets, notebook scan |

## Project structure

```
.claude/commands/       32 Claude Code skills (slash commands)
.github/
  copilot-instructions.md   Copilot coding agent instructions
  workflows/                CI/CD pipelines
src/
  agent/                GitHub Copilot review agent + prompt templates
  utils/                Databricks Connect, notebook scanner, secret patterns, GitHub API
scripts/                CLI entry points
bundles/notebooks/      Databricks notebook stubs for DAB jobs
tests/                  Pytest suite (local Spark, no cluster needed)
databricks.yml          Databricks Asset Bundle config
pyproject.toml          uv project + dependencies
```
