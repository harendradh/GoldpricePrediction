#!/usr/bin/env python
"""Review a GitHub PR using the Copilot review agent."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from dotenv import load_dotenv
from rich.console import Console
from rich.markdown import Markdown

from src.agent.copilot_review_agent import CopilotReviewAgent, ReviewType
from src.utils.git_utils import GitHubClient

load_dotenv()
console = Console()


def main() -> None:
    parser = argparse.ArgumentParser(description="Review a GitHub PR")
    parser.add_argument("--pr", type=int, required=True, help="PR number")
    parser.add_argument(
        "--type",
        choices=["pyspark", "spark-java", "sql", "pr", "all"],
        default="pr",
        help="Review type",
    )
    parser.add_argument("--post", action="store_true", help="Post review as PR comment on GitHub")
    args = parser.parse_args()

    gh = GitHubClient()
    agent = CopilotReviewAgent()

    with console.status(f"Fetching PR #{args.pr} ..."):
        pr = gh.get_pr(args.pr)

    console.print(f"\n[bold]PR #{pr.number}:[/bold] {pr.title}\n")

    if args.type in ("pr", "all"):
        with console.status("Running PR review ..."):
            review = agent.review_pr(pr.number, pr.title, pr.body, pr.diff)
        console.print(Markdown(review))
        if args.post:
            gh.post_review_comment(pr.number, review)
            console.print("[green]Review posted to GitHub.[/green]")

    if args.type in ("pyspark", "all"):
        py_files = [f for f in pr.files if f.endswith(".py")]
        for fname in py_files:
            try:
                code = gh.get_file_content(fname, ref=f"refs/pull/{pr.number}/head")
                diff_ctx = "\n".join(
                    l for l in pr.diff.splitlines() if fname in l or l.startswith(("+", "-"))
                )[:3000]
                with console.status(f"PySpark review: {fname} ..."):
                    review = agent.review_pyspark(fname, code, diff_ctx)
                console.print(Markdown(review))
            except Exception as exc:
                console.print(f"[yellow]Skipped {fname}: {exc}[/yellow]")

    if args.type in ("spark-java", "all"):
        java_files = [f for f in pr.files if f.endswith(".java")]
        for fname in java_files:
            try:
                code = gh.get_file_content(fname, ref=f"refs/pull/{pr.number}/head")
                with console.status(f"Spark Java review: {fname} ..."):
                    review = agent.review_spark_java(fname, code)
                console.print(Markdown(review))
            except Exception as exc:
                console.print(f"[yellow]Skipped {fname}: {exc}[/yellow]")

    if args.type in ("sql", "all"):
        sql_files = [f for f in pr.files if f.endswith(".sql")]
        for fname in sql_files:
            try:
                code = gh.get_file_content(fname, ref=f"refs/pull/{pr.number}/head")
                with console.status(f"SQL review: {fname} ..."):
                    review = agent.review_sql(fname, code)
                console.print(Markdown(review))
            except Exception as exc:
                console.print(f"[yellow]Skipped {fname}: {exc}[/yellow]")


if __name__ == "__main__":
    main()
