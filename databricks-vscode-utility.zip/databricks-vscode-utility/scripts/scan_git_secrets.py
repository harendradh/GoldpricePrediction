#!/usr/bin/env python
"""Scan git history and staged files for hardcoded secrets."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from rich.console import Console
from rich.table import Table

from src.utils.secret_patterns import scan_text, SecretMatch

console = Console()


def get_staged_diff() -> str:
    result = subprocess.run(["git", "diff", "--cached"], capture_output=True, text=True)
    return result.stdout


def get_recent_commits_diff(n: int = 10) -> str:
    result = subprocess.run(
        ["git", "log", f"-{n}", "--patch", "--unified=0"],
        capture_output=True, text=True,
    )
    return result.stdout


def scan_working_tree() -> dict[str, list[SecretMatch]]:
    """Scan all tracked files in the working tree."""
    result = subprocess.run(["git", "ls-files"], capture_output=True, text=True)
    files = result.stdout.splitlines()
    findings: dict[str, list[SecretMatch]] = {}
    for fpath in files:
        p = Path(fpath)
        if not p.exists() or p.stat().st_size > 1_000_000:
            continue
        try:
            text = p.read_text(encoding="utf-8", errors="ignore")
            matches = scan_text(text, fpath)
            if matches:
                findings[fpath] = matches
        except Exception:
            pass
    return findings


def main() -> None:
    import argparse
    parser = argparse.ArgumentParser(description="Scan git repo for secrets")
    parser.add_argument("--staged", action="store_true", help="Scan only staged changes")
    parser.add_argument("--history", action="store_true", help="Scan recent commit history")
    parser.add_argument("--all", action="store_true", help="Scan all tracked files (default)")
    parser.add_argument("--fail-on-critical", action="store_true", help="Exit 1 on CRITICAL findings")
    args = parser.parse_args()

    all_findings: dict[str, list[SecretMatch]] = {}

    if args.staged:
        diff = get_staged_diff()
        matches = scan_text(diff, "staged-diff")
        if matches:
            all_findings["staged-diff"] = matches

    if args.history:
        diff = get_recent_commits_diff()
        matches = scan_text(diff, "git-history")
        if matches:
            all_findings["git-history"] = matches

    if not args.staged and not args.history:
        all_findings = scan_working_tree()

    if not all_findings:
        console.print("[green]No secrets found.[/green]")
        return

    table = Table(title="Git Secret Scan Results", show_lines=True)
    table.add_column("Severity", style="bold")
    table.add_column("File")
    table.add_column("Line")
    table.add_column("Pattern")
    table.add_column("Snippet")

    critical_count = 0
    for fpath, matches in all_findings.items():
        for m in matches:
            color = {"CRITICAL": "red", "HIGH": "orange3", "MEDIUM": "yellow", "INFO": "blue"}.get(m.severity, "white")
            table.add_row(
                f"[{color}]{m.severity}[/{color}]",
                fpath,
                str(m.line_number),
                m.pattern_name,
                m.line[:80],
            )
            if m.severity == "CRITICAL":
                critical_count += 1

    console.print(table)
    console.print(f"\nTotal files with findings: {len(all_findings)}")

    if args.fail_on_critical and critical_count > 0:
        console.print(f"[red]{critical_count} CRITICAL secrets found — failing.[/red]")
        sys.exit(1)


if __name__ == "__main__":
    main()
