#!/usr/bin/env python
"""Scan Databricks workspace notebooks for hardcoded secrets."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from dotenv import load_dotenv
from rich.console import Console
from rich.table import Table

from src.utils.notebook_scanner import NotebookScanner

load_dotenv()
console = Console()


def main() -> None:
    parser = argparse.ArgumentParser(description="Scan Databricks notebooks for secrets")
    parser.add_argument("--workspace", action="store_true", help="Scan full workspace (slow)")
    parser.add_argument("--path", default="/Shared", help="Workspace path to scan")
    parser.add_argument("--output", default="reports/notebook_secret_scan.json")
    parser.add_argument("--fail-on-found", action="store_true", help="Exit 1 if secrets found")
    args = parser.parse_args()

    scanner = NotebookScanner(workspace_path=args.path if args.workspace else args.path)
    results = scanner.scan_workspace()
    report = scanner.to_report(results)

    scanner.save_report(results, args.output)

    table = Table(title="Notebook Secret Scan Results", show_lines=True)
    table.add_column("Severity", style="bold")
    table.add_column("Pattern")
    table.add_column("Notebook")
    table.add_column("Line")
    table.add_column("Snippet")

    for finding in report["findings"]:
        sev = finding["severity"]
        color = {"CRITICAL": "red", "HIGH": "orange3", "MEDIUM": "yellow", "INFO": "blue"}.get(sev, "white")
        table.add_row(
            f"[{color}]{sev}[/{color}]",
            finding["pattern"],
            finding["notebook"],
            str(finding["line"]),
            finding["snippet"][:80],
        )

    console.print(table)
    console.print(f"\nTotal findings: [bold]{report['total_findings']}[/bold]  "
                  f"Critical: [red]{report['critical_findings']}[/red]")

    if args.fail_on_found and report["critical_findings"] > 0:
        console.print("[red]CRITICAL secrets found — failing build.[/red]")
        sys.exit(1)


if __name__ == "__main__":
    main()
