# Databricks VS Code Utility — Claude Code Project Guide

## Project overview
Databricks Asset Bundle project for automating daily engineering tasks:
- **Code review agent** (GitHub Copilot Chat API) for PySpark, Spark Java, SQL, and PRs
- **Secret scanning** for Databricks notebooks and git history
- **20+ Claude Code skills** (slash commands) for common Databricks/Spark tasks

## Setup

```powershell
# 1. Install uv
irm https://astral.sh/uv/install.ps1 | iex

# 2. Install dependencies
uv sync

# 3. Copy env template
copy .env.example .env
# Fill in DATABRICKS_HOST, DATABRICKS_TOKEN, DATABRICKS_CLUSTER_ID, GITHUB_TOKEN, COPILOT_TOKEN

# 4. Install Databricks CLI
winget install Databricks.DatabricksCLI

# 5. Validate the bundle
databricks bundle validate
```

## Common commands

```powershell
# Review a PR
uv run python scripts/review_pr.py --pr 123 --type all --post

# Scan notebooks for secrets
uv run python scripts/scan_notebooks.py --path /Shared

# Scan git for secrets
uv run python scripts/scan_git_secrets.py --all

# Deploy to dev
databricks bundle deploy --target dev

# Run a job
databricks bundle run code_review_daily --target dev

# Run tests
uv run pytest tests/ -v
```

## Python standards
- Python 3.11+, PySpark 3.5, type hints on all public functions
- Formatter: Ruff (`uv run ruff format .`)
- Linter: Ruff (`uv run ruff check .`)
- No `collect()` in loops, no hardcoded secrets, explicit schemas for external reads

## Available Claude Code skills (`/skill-name`)

### Code Review
| Skill | Description |
|-------|-------------|
| `/pyspark-review` | PySpark code review |
| `/spark-java-review` | Spark Java code review |
| `/sql-review` | SQL / Spark SQL review |
| `/pr-review` | Full PR review (all file types) |
| `/dlt-review` | Delta Live Tables review |
| `/spark-streaming-review` | Structured Streaming review |
| `/autoloader-review` | Auto Loader config review |
| `/airflow-dag-review` | Airflow DAG review |

### SQL & Data
| Skill | Description |
|-------|-------------|
| `/sql-optimize` | Rewrite SQL for performance |
| `/sql-migration` | Migrate SQL from T-SQL/Oracle/Snowflake/PostgreSQL to Databricks SQL |
| `/sql-to-pyspark` | Convert SQL to PySpark DataFrame API |
| `/merge-cdc` | Generate MERGE INTO / CDC patterns |
| `/delta-optimize` | Delta table OPTIMIZE/ZORDER/VACUUM plan |

### Security & Compliance
| Skill | Description |
|-------|-------------|
| `/databricks-secret-scan` | Scan notebooks and files for hardcoded secrets |
| `/github-secret-scan` | Scan git history before pushing to GitHub |
| `/unity-catalog-scan` | Audit Unity Catalog for governance issues |

### Generation & Design
| Skill | Description |
|-------|-------------|
| `/drawio-generator` | Generate Draw.io architecture diagrams |
| `/data-lineage` | Generate data lineage diagrams |
| `/medallion-design` | Design Bronze/Silver/Gold architecture |
| `/javadocs` | Generate Javadoc comments for Spark Java |
| `/notebook-docs` | Generate documentation for Databricks notebooks |
| `/cicd-generator` | Generate GitHub Actions CI/CD pipeline |
| `/api-to-databricks` | Generate REST API ingestion pipeline |

### Refactoring & Quality
| Skill | Description |
|-------|-------------|
| `/pyspark-refactor` | Refactor PySpark to production-quality code |
| `/spark-java-refactor` | Modernize Spark Java code |
| `/pyspark-unit-test` | Generate pytest unit tests for PySpark |
| `/schema-validator` | Validate StructType schemas and diff breaking changes |
| `/data-quality-check` | Generate DQ check suite for Delta tables |
| `/notebook-to-python` | Convert notebook to production Python module |
| `/spark-performance-audit` | Audit Spark job for performance bottlenecks |

### Infrastructure
| Skill | Description |
|-------|-------------|
| `/dab-validate` | Validate databricks.yml configuration |
| `/cluster-cost-optimizer` | Cluster right-sizing and cost recommendations |

## File structure
```
src/agent/          — GitHub Copilot review agent + prompt templates
src/utils/          — Databricks Connect, notebook scanner, secret patterns, GitHub API
scripts/            — CLI entry points (review_pr, scan_notebooks, scan_git_secrets)
bundles/            — Databricks Asset Bundle jobs and notebooks
.claude/commands/   — All Claude Code skills (slash commands)
.github/workflows/  — CI/CD: PR review, secret scanning, deployment
```
