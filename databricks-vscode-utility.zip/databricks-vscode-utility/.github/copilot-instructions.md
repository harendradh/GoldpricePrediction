# GitHub Copilot Coding Agent — Databricks Utility Project

## Project context
This is a Databricks utility project using:
- **Databricks Asset Bundles (DAB)** for infrastructure-as-code
- **uv** for Python dependency management (`uv sync` to install, `uv run` to execute)
- **Databricks Connect** for local PySpark development against a remote cluster
- **Python 3.11+** with PySpark 3.5, Databricks SDK 0.28+

## Coding standards

### PySpark
- Always prefer DataFrame API over RDD unless unavoidable
- Use `spark.read.format("delta")` — never use raw Parquet/CSV in production paths
- Partition pruning: always filter before join, not after
- Use `broadcast()` hint for dimension tables under 200 MB
- Prefer `selectExpr` / `withColumnRenamed` over raw `select(col("...").alias(...))`  chains
- Avoid `collect()` in loops — use `toPandas()` once at the boundary
- Cache (`cache()` / `persist()`) only DataFrames reused 3+ times in the same job
- Schema enforcement: always define explicit `StructType` for external sources

### Spark Java
- Use `SparkSession.builder().getOrCreate()` — never create multiple sessions
- Strongly type Datasets (`Dataset<Row>`) where possible; avoid raw RDD<Object>
- Encoders: use `Encoders.bean()` for POJOs, `Encoders.kryo()` only for non-serializable types
- Close resources in `finally` blocks; register `SparkContext.addSparkListener` for cleanup
- JavaDocs: every public class and method must have complete `@param`, `@return`, `@throws`

### SQL (Databricks SQL / Spark SQL)
- Use CTEs (`WITH`) instead of nested subqueries
- Qualify all column references with table alias in multi-table queries
- No `SELECT *` in production — list columns explicitly
- Always include `OPTIMIZE` + `ZORDER BY` hints in review comments for large Delta tables
- Prefer `MERGE INTO` over `DELETE + INSERT` patterns

### Secrets & Security
- **Zero tolerance for hardcoded credentials** — use Databricks Secrets API or `.env` (gitignored)
- Reference secrets as `dbutils.secrets.get(scope="...", key="...")`
- No plain passwords, tokens, or connection strings in notebooks or source files

### Databricks Notebooks
- Notebooks are in `bundles/notebooks/` — keep business logic in `src/` Python modules
- Use `%run` only for shared utilities; prefer importing from installed packages
- Magic commands (`%sql`, `%md`) are acceptable but not in automated test paths

## Review checklist (use for every PR review)
- [ ] No hardcoded secrets or connection strings
- [ ] Schema defined explicitly for all external reads
- [ ] Joins have appropriate broadcast hints or partition alignment
- [ ] Delta table writes use `mergeSchema` or explicit schema only
- [ ] Unit tests exist for all transformation functions
- [ ] JavaDocs / docstrings present on all public APIs
- [ ] `databricks.yml` changes reviewed for target/mode correctness
- [ ] `uv.lock` updated if `pyproject.toml` changed

## Agent behavior
- When asked to review code: apply the checklist above, output findings as numbered items with severity (🔴 Critical / 🟠 High / 🟡 Medium / 🔵 Info)
- When asked to optimize SQL: rewrite the query with CTE structure and add inline comments explaining each optimization
- When asked to generate JavaDocs: produce complete Javadoc blocks, do not omit `@throws`
- When asked to scan for secrets: look for patterns matching API keys, passwords, tokens, connection strings, base64-encoded credentials
