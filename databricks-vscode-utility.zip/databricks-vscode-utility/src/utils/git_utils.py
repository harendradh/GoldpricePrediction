"""GitHub API helpers for PR review and secret scanning."""

from __future__ import annotations

import os
from dataclasses import dataclass

import requests


@dataclass
class PullRequest:
    number: int
    title: str
    body: str
    diff: str
    files: list[str]


class GitHubClient:
    def __init__(self) -> None:
        self.token = os.environ["GITHUB_TOKEN"]
        self.repo = os.environ["GITHUB_REPO"]   # format: "org/repo"
        self.base = "https://api.github.com"
        self.session = requests.Session()
        self.session.headers.update(
            {
                "Authorization": f"Bearer {self.token}",
                "Accept": "application/vnd.github+json",
                "X-GitHub-Api-Version": "2022-11-28",
            }
        )

    def _get(self, path: str, accept: str | None = None) -> requests.Response:
        headers = {"Accept": accept} if accept else {}
        resp = self.session.get(f"{self.base}/repos/{self.repo}{path}", headers=headers, timeout=30)
        resp.raise_for_status()
        return resp

    def get_pr(self, pr_number: int) -> PullRequest:
        pr = self._get(f"/pulls/{pr_number}").json()
        diff = self._get(f"/pulls/{pr_number}", accept="application/vnd.github.v3.diff").text
        files_resp = self._get(f"/pulls/{pr_number}/files").json()
        files = [f["filename"] for f in files_resp]
        return PullRequest(
            number=pr_number,
            title=pr["title"],
            body=pr.get("body") or "",
            diff=diff,
            files=files,
        )

    def post_review_comment(self, pr_number: int, body: str) -> None:
        self.session.post(
            f"{self.base}/repos/{self.repo}/pulls/{pr_number}/reviews",
            json={"body": body, "event": "COMMENT"},
            timeout=30,
        ).raise_for_status()

    def get_file_content(self, path: str, ref: str = "HEAD") -> str:
        import base64
        resp = self._get(f"/contents/{path}?ref={ref}").json()
        return base64.b64decode(resp["content"]).decode("utf-8")
