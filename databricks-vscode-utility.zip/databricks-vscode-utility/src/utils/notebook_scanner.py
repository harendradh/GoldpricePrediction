"""Scan Databricks workspace notebooks for hardcoded secrets."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field

from databricks.sdk import WorkspaceClient
from databricks.sdk.service.workspace import ExportFormat, ObjectType

from src.utils.secret_patterns import SecretMatch, scan_text


@dataclass
class NotebookScanResult:
    path: str
    findings: list[SecretMatch] = field(default_factory=list)

    @property
    def has_secrets(self) -> bool:
        return bool(self.findings)

    @property
    def critical_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == "CRITICAL")


class NotebookScanner:
    def __init__(self, workspace_path: str = "/") -> None:
        self.client = WorkspaceClient(
            host=os.environ["DATABRICKS_HOST"],
            token=os.environ["DATABRICKS_TOKEN"],
        )
        self.workspace_path = workspace_path

    def _list_notebooks(self, path: str) -> list[str]:
        notebooks: list[str] = []
        try:
            for obj in self.client.workspace.list(path=path, recursive=True):
                if obj.object_type == ObjectType.NOTEBOOK:
                    notebooks.append(obj.path)
        except Exception as exc:
            print(f"[WARN] Cannot list {path}: {exc}")
        return notebooks

    def _export_notebook(self, path: str) -> str:
        export = self.client.workspace.export(path=path, format=ExportFormat.SOURCE)
        return export.content or ""

    def scan_notebook(self, path: str) -> NotebookScanResult:
        try:
            content = self._export_notebook(path)
            findings = scan_text(content, filename=path)
            return NotebookScanResult(path=path, findings=findings)
        except Exception as exc:
            print(f"[ERROR] Failed to scan {path}: {exc}")
            return NotebookScanResult(path=path)

    def scan_workspace(self) -> list[NotebookScanResult]:
        notebooks = self._list_notebooks(self.workspace_path)
        print(f"Scanning {len(notebooks)} notebooks under {self.workspace_path} ...")
        results = [self.scan_notebook(nb) for nb in notebooks]
        return results

    def to_report(self, results: list[NotebookScanResult]) -> dict:
        findings_list = [
            {
                "notebook": r.path,
                "severity": f.severity,
                "pattern": f.pattern_name,
                "line": f.line_number,
                "snippet": f.line[:120],
            }
            for r in results
            for f in r.findings
        ]
        return {
            "total_notebooks_scanned": len(results),
            "notebooks_with_secrets": sum(1 for r in results if r.has_secrets),
            "total_findings": len(findings_list),
            "critical_findings": sum(1 for r in results for f in r.findings if f.severity == "CRITICAL"),
            "findings": findings_list,
        }

    def save_report(self, results: list[NotebookScanResult], output_path: str) -> None:
        report = self.to_report(results)
        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
        with open(output_path, "w") as f:
            json.dump(report, f, indent=2)
        print(f"Report saved to {output_path}")
        print(f"  Notebooks scanned : {report['total_notebooks_scanned']}")
        print(f"  With secrets      : {report['notebooks_with_secrets']}")
        print(f"  Critical findings : {report['critical_findings']}")
