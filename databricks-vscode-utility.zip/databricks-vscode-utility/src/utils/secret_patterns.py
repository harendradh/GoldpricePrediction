"""Regex patterns for detecting plaintext secrets in source files and notebooks."""

import re
from dataclasses import dataclass

@dataclass
class SecretMatch:
    pattern_name: str
    line_number: int
    line: str
    severity: str  # CRITICAL | HIGH | MEDIUM


SECRET_PATTERNS: list[tuple[str, str, str]] = [
    # (name, regex, severity)
    ("Databricks PAT",          r"dapi[a-f0-9]{32}",                                        "CRITICAL"),
    ("Azure SAS Token",         r"sig=[A-Za-z0-9%+/]{40,}",                                 "CRITICAL"),
    ("Azure Storage Key",       r"AccountKey=[A-Za-z0-9+/]{60,}==",                         "CRITICAL"),
    ("AWS Access Key",          r"AKIA[0-9A-Z]{16}",                                         "CRITICAL"),
    ("AWS Secret Key",          r"(?i)aws.{0,20}secret.{0,20}['\"][0-9a-zA-Z/+]{40}['\"]", "CRITICAL"),
    ("Generic API Key",         r"(?i)(api[_-]?key|apikey)\s*[=:]\s*['\"][A-Za-z0-9]{20,}['\"]", "HIGH"),
    ("Generic Password",        r"(?i)(password|passwd|pwd)\s*[=:]\s*['\"][^'\"]{6,}['\"]", "HIGH"),
    ("Generic Secret",          r"(?i)(secret|token)\s*[=:]\s*['\"][A-Za-z0-9+/=_\-]{16,}['\"]", "HIGH"),
    ("Bearer Token",            r"(?i)bearer\s+[A-Za-z0-9\-._~+/]+=*",                      "HIGH"),
    ("Basic Auth Header",       r"Authorization:\s*Basic\s+[A-Za-z0-9+/]+=*",               "HIGH"),
    ("JDBC Connection String",  r"jdbc:[a-z]+://[^;]+;[Pp]assword=[^;\"'\s]+",              "CRITICAL"),
    ("Connection String",       r"(?i)(connection.?string|connstr)\s*[=:]\s*['\"][^'\"]+['\"]", "HIGH"),
    ("Private Key Block",       r"-----BEGIN (RSA |EC |OPENSSH |PGP )?PRIVATE KEY-----",    "CRITICAL"),
    ("GitHub Token",            r"gh[pousr]_[A-Za-z0-9]{36}",                               "CRITICAL"),
    ("Slack Token",             r"xox[baprs]-[A-Za-z0-9\-]+",                               "CRITICAL"),
    ("SendGrid Key",            r"SG\.[A-Za-z0-9\-._]{22}\.[A-Za-z0-9\-._]{43}",           "HIGH"),
    ("dbutils.secrets bypass",  r"dbutils\.secrets\.get\s*\(\s*scope\s*=\s*['\"][^'\"]+['\"],\s*key\s*=\s*['\"][^'\"]+['\"]", "INFO"),
    ("Hardcoded dbutils bypass", r"(?i)spark\.conf\.set\s*\([^)]*password[^)]*\)",          "HIGH"),
]

_COMPILED = [(name, re.compile(pattern), sev) for name, pattern, sev in SECRET_PATTERNS]


def scan_text(text: str, filename: str = "") -> list[SecretMatch]:
    findings: list[SecretMatch] = []
    for i, line in enumerate(text.splitlines(), start=1):
        for name, pattern, severity in _COMPILED:
            if pattern.search(line):
                findings.append(SecretMatch(
                    pattern_name=name,
                    line_number=i,
                    line=line.rstrip(),
                    severity=severity,
                ))
    return findings
