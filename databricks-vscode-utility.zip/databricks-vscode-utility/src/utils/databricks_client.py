"""Databricks Connect local SparkSession factory + SDK helpers."""

from __future__ import annotations

import os

from databricks.connect import DatabricksSession
from databricks.sdk import WorkspaceClient
from dotenv import load_dotenv

load_dotenv()


def get_spark():
    """Return a Databricks Connect SparkSession for local development."""
    return (
        DatabricksSession.builder
        .remote(
            host=os.environ["DATABRICKS_HOST"],
            token=os.environ["DATABRICKS_TOKEN"],
            cluster_id=os.environ["DATABRICKS_CLUSTER_ID"],
        )
        .getOrCreate()
    )


def get_workspace_client() -> WorkspaceClient:
    return WorkspaceClient(
        host=os.environ["DATABRICKS_HOST"],
        token=os.environ["DATABRICKS_TOKEN"],
    )


def list_clusters() -> list[dict]:
    w = get_workspace_client()
    return [
        {"id": c.cluster_id, "name": c.cluster_name, "state": c.state.value}
        for c in w.clusters.list()
    ]


def get_secret(scope: str, key: str) -> str:
    """Retrieve a secret from Databricks Secrets API."""
    w = get_workspace_client()
    return w.secrets.get_secret(scope=scope, key=key).value or ""
