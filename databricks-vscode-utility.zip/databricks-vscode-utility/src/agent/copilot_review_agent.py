"""GitHub Copilot Chat API — code review agent."""

from __future__ import annotations

import os
import time
from typing import Literal

import requests
from dotenv import load_dotenv

from src.agent.prompts.pyspark_prompts import PYSPARK_REVIEW_SYSTEM, PYSPARK_REVIEW_USER
from src.agent.prompts.spark_java_prompts import SPARK_JAVA_REVIEW_SYSTEM, SPARK_JAVA_REVIEW_USER, JAVADOC_SYSTEM, JAVADOC_USER
from src.agent.prompts.sql_prompts import SQL_REVIEW_SYSTEM, SQL_REVIEW_USER, SQL_OPTIMIZE_SYSTEM, SQL_OPTIMIZE_USER
from src.agent.prompts.pr_review_prompts import PR_REVIEW_SYSTEM, PR_REVIEW_USER

load_dotenv()

ReviewType = Literal["pyspark", "spark-java", "sql", "pr"]


class CopilotReviewAgent:
    """Thin wrapper around the GitHub Copilot Chat completions API."""

    API_BASE = os.getenv("COPILOT_API_BASE", "https://api.githubcopilot.com")
    MODEL = "gpt-4o"

    def __init__(self) -> None:
        self.token = os.environ["COPILOT_TOKEN"]
        self.session = requests.Session()
        self.session.headers.update(
            {
                "Authorization": f"Bearer {self.token}",
                "Content-Type": "application/json",
                "Copilot-Integration-Id": "vscode-chat",
                "Editor-Version": "vscode/1.89.0",
            }
        )

    def _chat(self, system: str, user: str, *, max_tokens: int = 4096) -> str:
        payload = {
            "model": self.MODEL,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "max_tokens": max_tokens,
            "temperature": 0.2,
        }
        for attempt in range(3):
            resp = self.session.post(f"{self.API_BASE}/chat/completions", json=payload, timeout=120)
            if resp.status_code == 429:
                time.sleep(2 ** attempt * 5)
                continue
            resp.raise_for_status()
            return resp.json()["choices"][0]["message"]["content"]
        raise RuntimeError("Copilot API rate-limit exceeded after retries")

    def review_pyspark(self, filename: str, code: str, diff_context: str = "") -> str:
        return self._chat(
            PYSPARK_REVIEW_SYSTEM,
            PYSPARK_REVIEW_USER.format(filename=filename, code=code, diff_context=diff_context),
        )

    def review_spark_java(self, filename: str, code: str, diff_context: str = "") -> str:
        return self._chat(
            SPARK_JAVA_REVIEW_SYSTEM,
            SPARK_JAVA_REVIEW_USER.format(filename=filename, code=code, diff_context=diff_context),
        )

    def review_sql(self, filename: str, code: str) -> str:
        return self._chat(
            SQL_REVIEW_SYSTEM,
            SQL_REVIEW_USER.format(filename=filename, code=code),
        )

    def optimize_sql(self, filename: str, code: str, table_context: str = "unknown") -> str:
        return self._chat(
            SQL_OPTIMIZE_SYSTEM,
            SQL_OPTIMIZE_USER.format(filename=filename, code=code, table_context=table_context),
        )

    def generate_javadocs(self, filename: str, code: str) -> str:
        return self._chat(
            JAVADOC_SYSTEM,
            JAVADOC_USER.format(filename=filename, code=code),
            max_tokens=8192,
        )

    def review_pr(self, pr_number: int, pr_title: str, pr_body: str, diff: str) -> str:
        return self._chat(
            PR_REVIEW_SYSTEM,
            PR_REVIEW_USER.format(
                pr_number=pr_number,
                pr_title=pr_title,
                pr_body=pr_body,
                diff=diff[:12000],  # truncate very large diffs
            ),
            max_tokens=6000,
        )
