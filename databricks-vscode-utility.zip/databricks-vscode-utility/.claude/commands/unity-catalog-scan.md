---
description: Audit Unity Catalog for governance issues — missing owners, public grants, PII columns without masking, stale tables
allowed-tools: Bash, Read
---

Audit Unity Catalog governance for `$ARGUMENTS` (catalog.schema or just catalog name).

Run these Databricks SQL audit queries (execute via `uv run python -c "from src.utils.databricks_client import get_spark; ..."`):

**1. Tables without owners**
```sql
SELECT catalog_name, schema_name, table_name
FROM system.information_schema.tables
WHERE table_catalog = '<catalog>'
  AND table_owner IS NULL OR table_owner = '';
```

**2. Overly permissive grants (PUBLIC or ALL PRIVILEGES)**
```sql
SELECT grantor, grantee, privilege_type, table_catalog, table_schema, table_name
FROM system.information_schema.table_privileges
WHERE table_catalog = '<catalog>'
  AND grantee = 'PUBLIC'
  OR privilege_type = 'ALL PRIVILEGES';
```

**3. PII columns without row/column masking**
```sql
-- Find columns matching PII naming patterns without a masking policy
SELECT table_catalog, table_schema, table_name, column_name, data_type
FROM system.information_schema.columns
WHERE table_catalog = '<catalog>'
  AND LOWER(column_name) REGEXP '(email|phone|ssn|dob|birth|address|passport|credit.?card|salary)'
  AND column_name NOT IN (
    SELECT column_name FROM system.information_schema.column_masks
    WHERE table_catalog = '<catalog>'
  );
```

**4. Stale tables (not updated in 30+ days)**
```sql
SELECT table_catalog, table_schema, table_name, last_altered
FROM system.information_schema.tables
WHERE table_catalog = '<catalog>'
  AND last_altered < CURRENT_TIMESTAMP - INTERVAL 30 DAYS
ORDER BY last_altered;
```

**5. Tables with no comments**
```sql
SELECT table_catalog, table_schema, table_name
FROM system.information_schema.tables
WHERE table_catalog = '<catalog>'
  AND comment IS NULL;
```

**Output**: Produce a prioritized remediation plan with:
- 🔴 Critical: PUBLIC grants, unmasked PII columns
- 🟠 High: Missing owners, overly broad ALL PRIVILEGES
- 🟡 Medium: Stale tables, missing comments
