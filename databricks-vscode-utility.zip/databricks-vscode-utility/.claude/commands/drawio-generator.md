---
description: Generate a Draw.io XML diagram from a text description — data pipelines, architecture, ERD, data flow
allowed-tools: Write, Read
---

Generate a Draw.io diagram from the description in `$ARGUMENTS`.

**Supported diagram types** (auto-detect from description):
- **Data Pipeline**: source → transform → sink with Databricks/Delta icons
- **Architecture**: microservices, Lambda/Kappa, Medallion (Bronze/Silver/Gold)
- **ERD**: entity-relationship diagram for database schemas
- **Data Flow**: end-to-end data movement diagram
- **Spark Job DAG**: Spark stage/task dependency graph

**Steps**:
1. Parse the description and identify: nodes, edges, layers/swimlanes
2. Map to Draw.io XML using these style conventions:
   - **Bronze layer**: `fillColor=#d79b00;fontColor=#ffffff` (orange)
   - **Silver layer**: `fillColor=#647687;fontColor=#ffffff` (steel blue)
   - **Gold layer**: `fillColor=#d6b656` (gold)
   - **Databricks cluster**: use rounded rectangle, `fillColor=#ff3621;fontColor=#ffffff`
   - **Delta table**: cylinder shape `shape=cylinder3`
   - **Kafka/Event Hub**: use `shape=mxgraph.aws4.resourceIcon` or similar
   - **Arrow labels**: write the transformation/operation name on edge labels
3. Output the complete `.drawio` XML in a fenced code block
4. Save to `resources/drawio/<diagram-name>.drawio` if a filename is given

**Output format**:
```
## Diagram: <name>

### Nodes identified
- ...

### Draw.io XML
```xml
<?xml version="1.0" encoding="UTF-8"?>
<mxfile ...>
  ...
</mxfile>
```

### Usage
1. Open VS Code → install "Draw.io Integration" extension (hediet.vscode-drawio)
2. Save the XML as `<name>.drawio` and open in VS Code
3. To export: right-click → Export as PNG/SVG
```
