---
description: Design a Medallion architecture (Bronze/Silver/Gold) for a given data domain or use case
allowed-tools: Write, Read
---

Design a Medallion architecture for `$ARGUMENTS` (describe the data domain, sources, and consumer use cases).

**Output a complete design document covering**:

## 1. Bronze Layer (Raw Ingest)
- Source systems and ingestion method (Auto Loader, COPY INTO, Kafka, REST API)
- Storage format: Delta with `delta.enableChangeDataFeed = true`
- Schema: raw as-received, no transformations
- Partition strategy: `year/month/day` or `ingestion_date`
- Retention policy: how long to keep raw data
- Auto Loader config:
```python
spark.readStream
  .format("cloudFiles")
  .option("cloudFiles.format", "json")
  .option("cloudFiles.schemaLocation", "/mnt/checkpoints/bronze/<table>/_schema")
  .load("/mnt/raw/<source>/")
```

## 2. Silver Layer (Cleansed & Conformed)
- Transformations applied (dedup, null handling, type casting, standardization)
- DQ expectations (list the `@dlt.expect_or_drop` rules)
- CDC pattern: `APPLY CHANGES INTO` for SCD Type 1 / Type 2
- Schema enforcement: explicit StructType
- ZORDER columns (based on expected query patterns)

## 3. Gold Layer (Business Aggregates)
- Aggregate tables / views for each consumer use case
- Fact and dimension tables (if star schema)
- Delta Sharing or Unity Catalog share for external consumers
- `OPTIMIZE + ZORDER` schedule
- Recommended cluster type (SQL Warehouse for BI, job cluster for batch)

## 4. Draw.io Diagram
Generate a Bronze → Silver → Gold data flow diagram XML (same format as `/drawio-generator`).

## 5. databricks.yml skeleton
Provide a DAB pipeline resource block for the full Medallion pipeline using DLT.

## 6. Cost estimate
Rough DBU estimate based on data volume (ask user for GB/day if not given).
