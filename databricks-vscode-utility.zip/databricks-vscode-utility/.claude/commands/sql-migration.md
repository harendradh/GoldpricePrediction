---
description: Migrate SQL from one dialect to Databricks SQL / Spark SQL — supports Hive, T-SQL, Oracle, PostgreSQL, Redshift, Snowflake
allowed-tools: Read, Write
---

Migrate the SQL in `$ARGUMENTS` to Databricks SQL / Spark SQL.

Specify source dialect in the first line: `-- source: tsql|oracle|postgresql|hive|redshift|snowflake`
If not specified, auto-detect from syntax.

---

**T-SQL → Databricks SQL**:
| T-SQL | Databricks SQL |
|-------|---------------|
| `TOP N` | `LIMIT N` |
| `ISNULL(x, y)` | `COALESCE(x, y)` |
| `GETDATE()` | `current_timestamp()` |
| `CONVERT(DATE, col)` | `CAST(col AS DATE)` |
| `DATEDIFF(day, a, b)` | `DATEDIFF(b, a)` ← args reversed |
| `STRING_AGG(col, ',')` | `array_join(collect_list(col), ',')` |
| `ROW_NUMBER() OVER (...)` | identical |
| `PIVOT` | use `CASE WHEN` + `GROUP BY` |
| `#temp_table` | `CREATE OR REPLACE TEMP VIEW` |
| `@@ROWCOUNT` | `spark.lastInsertId()` — not equivalent, use `count()` |
| `PRINT 'msg'` | remove (use `display()` in notebooks) |

**Oracle → Databricks SQL**:
| Oracle | Databricks SQL |
|--------|---------------|
| `SYSDATE` | `current_timestamp()` |
| `NVL(x, y)` | `COALESCE(x, y)` |
| `DECODE(col, v1, r1, v2, r2, def)` | `CASE WHEN col=v1 THEN r1 WHEN col=v2 THEN r2 ELSE def END` |
| `ROWNUM <= N` | `LIMIT N` |
| `(+)` outer join syntax | `LEFT JOIN` |
| `CONNECT BY` | recursive CTE: `WITH RECURSIVE` |
| `MINUS` | `EXCEPT` |
| `VARCHAR2` | `STRING` |
| `NUMBER(p,s)` | `DECIMAL(p,s)` |
| `TO_DATE('2024-01-01', 'YYYY-MM-DD')` | `DATE '2024-01-01'` |
| Sequences / `NEXTVAL` | `GENERATED ALWAYS AS IDENTITY` |

**Snowflake → Databricks SQL**:
| Snowflake | Databricks SQL |
|-----------|---------------|
| `QUALIFY ROW_NUMBER() OVER (...) = 1` | Wrap in subquery: `SELECT * FROM (SELECT *, ROW_NUMBER() OVER (...) AS rn) WHERE rn = 1` |
| `IFF(cond, a, b)` | `IF(cond, a, b)` or `CASE WHEN` |
| `ZEROIFNULL(x)` | `COALESCE(x, 0)` |
| `LISTAGG(col, ',')` | `array_join(collect_list(col), ',')` |
| `FLATTEN(arr)` | `EXPLODE(arr)` |
| `$1, $2` column aliases | use explicit names |
| `COPY INTO` (Snowflake) | `COPY INTO` (Delta — different syntax!) |

**Output**:
1. Migrated SQL with inline comments marking each conversion
2. List of patterns that need manual review (no direct equivalent)
3. Databricks-specific optimizations added (CTEs, partition hints)
4. Test query to validate output matches source (row count + sample rows)
