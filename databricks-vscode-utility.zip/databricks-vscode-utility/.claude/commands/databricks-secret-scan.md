---
description: Scan Databricks workspace notebooks and local source files for plaintext passwords, API keys, and tokens
allowed-tools: Bash, Read, Glob, Grep
---

Scan for hardcoded secrets. Usage: `/databricks-secret-scan [path]`

Default path: current directory. Pass a workspace path like `/Shared/MyProject` to scan notebooks.

**Step 1 — Local file scan**
Search the codebase under `$ARGUMENTS` (default `.`) for these patterns:

| Severity | Pattern |
|----------|---------|
| 🔴 CRITICAL | Databricks PAT: `dapi[a-f0-9]{32}` |
| 🔴 CRITICAL | Azure Storage Key: `AccountKey=[A-Za-z0-9+/]{60,}==` |
| 🔴 CRITICAL | AWS Access Key: `AKIA[0-9A-Z]{16}` |
| 🔴 CRITICAL | JDBC URL with password: `jdbc:.*[Pp]assword=` |
| 🔴 CRITICAL | Private key block: `-----BEGIN.*PRIVATE KEY-----` |
| 🔴 CRITICAL | GitHub Token: `gh[pousr]_[A-Za-z0-9]{36}` |
| 🟠 HIGH | Generic password: `(?i)password\s*[=:]\s*['"][^'"]{6,}['"]` |
| 🟠 HIGH | Generic API key: `(?i)api.?key\s*[=:]\s*['"][A-Za-z0-9]{20,}['"]` |
| 🟠 HIGH | Bearer token in code: `(?i)bearer\s+[A-Za-z0-9\-._~+/]+=*` |
| 🟠 HIGH | Connection string: `(?i)connection.?string\s*[=:]\s*['"][^'"]+['"]` |

**Step 2 — Databricks notebook scan (if DATABRICKS_HOST is set)**
Run: `uv run python scripts/scan_notebooks.py --path $ARGUMENTS`

**Step 3 — Report**
List every finding with:
- File path and line number
- Severity emoji
- Pattern matched
- Masked snippet (show first 4 + last 4 chars of secret)
- Recommended fix (use `dbutils.secrets.get()` or env var)

**Step 4 — Remediation guidance**
For each CRITICAL finding, provide the exact `dbutils.secrets.put` command to migrate the secret to Databricks Secrets API.
