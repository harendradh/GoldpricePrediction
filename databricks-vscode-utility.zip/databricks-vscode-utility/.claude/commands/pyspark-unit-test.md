---
description: Generate pytest unit tests for PySpark transformation functions using in-memory DataFrames
allowed-tools: Read, Write, Glob
---

Generate pytest unit tests for the PySpark file at `$ARGUMENTS`.

**Rules**:
1. One test file per source file: `tests/test_<module>.py`
2. Shared `SparkSession` fixture in `tests/conftest.py` (session-scoped — one Spark per test run)
3. One test function per public transformation function
4. Use small in-memory DataFrames — never connect to real Databricks cluster in unit tests
5. Test both happy path AND edge cases: nulls, empty DataFrame, duplicate keys, schema mismatches

**conftest.py template** (create if not exists):
```python
import pytest
from pyspark.sql import SparkSession

@pytest.fixture(scope="session")
def spark():
    return (
        SparkSession.builder
        .master("local[2]")
        .appName("unit-tests")
        .config("spark.sql.shuffle.partitions", "2")
        .getOrCreate()
    )
```

**Test template per function**:
```python
def test_<function_name>_happy_path(spark):
    input_df = spark.createDataFrame([...], schema=StructType([...]))
    result = <function_name>(input_df)
    assert result.count() == <expected>
    assert result.schema == expected_schema
    row = result.collect()[0]
    assert row["<col>"] == <expected_value>

def test_<function_name>_empty_input(spark):
    empty_df = spark.createDataFrame([], schema=input_schema)
    result = <function_name>(empty_df)
    assert result.count() == 0

def test_<function_name>_nulls(spark):
    # test null handling
```

**Generate tests for**:
- Every `def` that accepts a `DataFrame` parameter
- Every `def` that calls `spark.read` or `spark.table`
- EXCLUDE: `main()`, `get_spark()`, logging setup

After generating:
- List any functions that are untestable without mocking (e.g., `dbutils`, external writes) with a `# TODO: mock` comment
- Show test coverage estimate based on what was generated
