---
description: Generate a Great Expectations / custom PySpark data quality check suite for a Delta table or DataFrame
allowed-tools: Read, Write, Bash
---

Generate a data quality check suite for `$ARGUMENTS` (table name, schema description, or paste a sample schema).

**Step 1 — Infer or read schema**
If given a table name, run:
```python
spark.table("<table>").printSchema()
spark.table("<table>").describe().show()
```
If given a file, read the schema from the StructType definition.

**Step 2 — Generate PySpark DQ checks**
Create a `src/dq/check_<table>.py` with:

```python
from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from dataclasses import dataclass

@dataclass
class DQResult:
    check_name: str
    passed: bool
    failing_rows: int
    details: str

def run_checks(df: DataFrame) -> list[DQResult]:
    results = []
    
    # Null checks for NOT NULL columns
    # Uniqueness checks for primary keys
    # Range checks for numeric columns
    # Referential integrity checks for FK columns
    # Format checks for date/email/phone columns
    # Freshness check: max(updated_at) < NOW() - INTERVAL 1 DAY
    
    return results
```

**Step 3 — Generate Great Expectations suite** (if GE is available)
```python
import great_expectations as gx
context = gx.get_context()
suite = context.add_expectation_suite("<table>_suite")
# Add expectations for each column
```

**Step 4 — DAB job snippet**
Provide a `databricks.yml` task snippet to run DQ checks as a pre-step before any Gold layer writes.

**Step 5 — Alert on failure**
Show how to send a Databricks alert or webhook notification when DQ fails.
