---
description: Generate GitHub Actions CI/CD pipeline for a Databricks Asset Bundle project with testing, linting, and deployment stages
allowed-tools: Read, Write, Glob
---

Generate a complete GitHub Actions CI/CD pipeline for `$ARGUMENTS` (project name or `databricks.yml` path).

**Output `.github/workflows/ci-cd.yml`**:

### Stages to generate:

**1. Lint & Format** (every push)
```yaml
- name: Lint Python
  run: uv run ruff check src/ scripts/ tests/
- name: Format check
  run: uv run ruff format --check src/
- name: Type check
  run: uv run mypy src/
- name: SQL lint
  run: uv run sqlfluff lint **/*.sql --dialect sparksql
```

**2. Unit Tests** (every push, no Databricks connection needed)
```yaml
- name: Run unit tests
  run: uv run pytest tests/ -v --tb=short -m "not integration"
```

**3. Secret scan** (every push, block on CRITICAL)
```yaml
- name: Scan for secrets
  run: uv run python scripts/scan_git_secrets.py --staged --fail-on-critical
```

**4. DAB Validate** (on PR to main)
```yaml
- name: Validate bundle
  run: databricks bundle validate
  env:
    DATABRICKS_HOST: ${{ secrets.DATABRICKS_HOST }}
    DATABRICKS_TOKEN: ${{ secrets.DATABRICKS_TOKEN }}
```

**5. Deploy to DEV** (on PR open/sync)
```yaml
- name: Deploy to dev
  run: databricks bundle deploy --target dev
```

**6. Integration Tests** (after dev deploy)
```yaml
- name: Run integration tests
  run: uv run pytest tests/ -v -m "integration" --timeout=300
```

**7. Deploy to PROD** (on merge to main, with environment protection)
```yaml
environment: production   # requires manual approval in GitHub
- name: Deploy to prod
  run: databricks bundle deploy --target prod
- name: Run prod job
  run: databricks bundle run <job-name> --target prod
```

**Security requirements in workflow**:
- All secrets via `${{ secrets.* }}` — never hardcoded
- `permissions: contents: read` minimum (add write only where needed)
- No `pull_request_target` trigger without explicit authorization check
- Pinned action versions with SHA: `actions/checkout@abc123` not `@main`

Also generate `.github/environments/production.json` with required reviewers list.
