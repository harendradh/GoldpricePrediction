---
description: Review Delta Live Tables (DLT) pipeline code for correctness, expectations, and performance
allowed-tools: Read, Glob, Grep
---

Review the Delta Live Tables pipeline file at `$ARGUMENTS`.

**Checklist**:

**1. Pipeline structure**
- All tables decorated with `@dlt.table` or `@dlt.view`
- Every `@dlt.table` has `name=`, `comment=`, and `table_properties=`
- Source tables use `dlt.read()` / `dlt.read_stream()` — not `spark.table()` or `spark.read`
- Bronze → Silver → Gold dependency chain is explicit and documented

**2. Data Quality Expectations**
- Every Silver+ table has at least one `@dlt.expect` or `@dlt.expect_or_drop`
- Expectations use `expect_or_drop` for critical constraints (not just `expect` which only warns)
- Expectations named descriptively: `"non_null_customer_id"`, not `"check1"`
- `expect_all` used for column groups rather than repeating individual expects

```python
# Good:
@dlt.expect_or_drop("valid_amount", "amount > 0 AND amount IS NOT NULL")
@dlt.expect("non_null_id", "id IS NOT NULL")

# Bad: expect() on a column that should block bad records
@dlt.expect("amount_positive", "amount > 0")  # only warns!
```

**3. Streaming vs Batch**
- Streaming sources use `dlt.read_stream()` not `dlt.read()`
- `APPLY CHANGES INTO` used for CDC (not manual MERGE in DLT)
- Trigger interval appropriate for SLA (continuous vs triggered)

**4. Schema enforcement**
- `schema=` specified on all external source reads
- `spark.readStream.schema(...)` before `dlt.read_stream()`

**5. Performance**
- No `collect()` or `toPandas()` inside DLT functions
- Large lookups use broadcast joins
- `pipelines.autoOptimize.managed = true` in table properties for Gold tables

**6. Security**
- No hardcoded credentials — use `dbutils.secrets.get()`
- Pipeline cluster `data_security_mode` is `SINGLE_USER`

Output findings with severity 🔴🟠🟡🔵 and corrected code snippets.
