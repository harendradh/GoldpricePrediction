---
description: Refactor PySpark code — eliminate anti-patterns, apply functional style, add type hints and docstrings
allowed-tools: Read, Edit, Write
---

Refactor the PySpark file at `$ARGUMENTS` without changing business logic.

**Refactoring rules** (apply all that are relevant):

**1. Function decomposition**
- Break notebook-style sequential code into named functions: `extract()`, `transform_*()`, `load()`
- Each function: single responsibility, max 30 lines
- Pure functions preferred: no side effects (no `cache()`, no `write()` inside transform functions)

**2. Type hints**
```python
# Before:
def process(df, start_date, config):

# After:
from pyspark.sql import DataFrame, SparkSession
from datetime import date

def process(df: DataFrame, start_date: date, config: dict[str, str]) -> DataFrame:
```

**3. Eliminate magic values**
```python
# Before:
df.filter(col("status") == 3)

# After:
STATUS_COMPLETE = 3
df.filter(col("status") == STATUS_COMPLETE)
```

**4. Replace RDD with DataFrame API**
```python
# Before (RDD):
rdd.map(lambda x: (x[0], x[1] * 2)).filter(lambda x: x[1] > 0)

# After (DataFrame):
df.select(col("id"), (col("value") * 2).alias("value")).filter(col("value") > 0)
```

**5. Replace Python UDFs with built-in functions**
```python
# Before:
@udf(returnType=StringType())
def clean_email(email): return email.strip().lower()

# After:
from pyspark.sql.functions import lower, trim
df.withColumn("email", lower(trim(col("email"))))
```

**6. Docstrings** (Google style on every public function)
```python
def calculate_revenue(df: DataFrame, date_col: str) -> DataFrame:
    """Calculate daily revenue per region.

    Args:
        df: Orders DataFrame with amount, region, and date_col columns.
        date_col: Name of the timestamp column to group by date.

    Returns:
        DataFrame with columns: region, date, total_revenue.
    """
```

**7. Constants at top of file**, imports grouped (stdlib → pyspark → local)

**Output**: Show the refactored file as a complete replacement, then a summary of every change made.
