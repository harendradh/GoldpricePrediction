---
description: Analyze Databricks cluster configuration and recommend cost optimizations — right-sizing, spot instances, Photon, serverless
allowed-tools: Read, Glob, Bash
---

Analyze the cluster configuration in `$ARGUMENTS` (paste cluster JSON, `databricks.yml` snippet, or cluster name).

**Cost optimization analysis**:

### 1. Right-sizing
- Compare `num_workers` vs actual Spark UI metrics (CPU/memory utilization)
- Recommend minimum workers for the job's data volume
- Flag clusters with `num_workers` > 10 for jobs that run < 30 minutes (startup cost > value)

### 2. Instance type selection
| Workload | Recommended | Avoid |
|----------|------------|-------|
| Memory-heavy (joins, caching) | Memory-optimized (Standard_E series / r5) | Compute-optimized |
| CPU-heavy (ML training) | Compute-optimized (Standard_F series / c5) | Memory-optimized |
| SQL/BI dashboards | SQL Warehouse (serverless) | All-purpose cluster |
| Streaming | Fixed workers (no autoscale) | Spot with no fallback |

### 3. Spot / Preemptible instances
- Batch jobs tolerant of retries → use Spot (60–80% savings)
- Streaming jobs → on-demand driver, Spot workers with `spark.task.maxFailures = 8`
- Never use Spot for: interactive clusters, streaming checkpointing driver

### 4. Photon
- Enable Photon for: SQL queries, Delta reads/writes, scan-heavy workloads
- Skip Photon for: pure Python UDF-heavy jobs (no SQL engine benefit)

### 5. Autoscaling
```json
"autoscale": { "min_workers": 2, "max_workers": 10 }
```
- Enable for variable workloads
- Set `min_workers ≥ 1` (never 0 — cold start is slow)
- For Structured Streaming: disable autoscaling (causes re-partition storms)

### 6. Serverless (Databricks Serverless Compute)
- Jobs < 10 min with infrequent runs → serverless saves idle cluster cost
- DBU rate is higher but no idle time billed

### 7. Schedule optimization
- Avoid always-on all-purpose clusters for scheduled jobs → use job clusters
- Terminate interactive clusters after 30 min idle: `"autotermination_minutes": 30`

**Output**: Estimated monthly DBU savings, corrected cluster JSON, and priority action list.
