---
description: Review PySpark / Databricks Python code for performance, correctness, and security
allowed-tools: Read, Glob, Grep
---

Review the PySpark file at `$ARGUMENTS` (or paste code after the command).

Apply the full Databricks PySpark checklist:

**🔴 Critical** | **🟠 High** | **🟡 Medium** | **🔵 Info**

Criteria:
1. **Security**: Hardcoded PATs (`dapi...`), passwords, storage keys, JDBC connection strings
2. **Correctness**:
   - Cartesian products (missing join condition)
   - Non-deterministic UDFs in Structured Streaming
   - Incorrect window frame (`rowsBetween` vs `rangeBetween`)
   - Closure capturing non-serializable objects
3. **Performance**:
   - `collect()` or `toPandas()` inside loops or before filters
   - Missing `broadcast()` hint for joins with tables < 200 MB
   - Filtering after join instead of before (partition pruning missed)
   - DataFrame reused 3+ times without `cache()` / `persist()`
   - `explode()` without subsequent filter (cardinality explosion)
   - High-cardinality `groupBy` without `repartition`
4. **Delta / Lakehouse**:
   - Raw Parquet/CSV writes instead of Delta
   - Missing explicit `StructType` schema for external reads
   - `overwrite` mode that breaks Delta history
   - Missing `mergeSchema` or schema enforcement
5. **Testing**: Transformation functions without unit tests
6. **Style**: Non-descriptive variable names, missing docstrings on public functions

Output:
```
## PySpark Review — <filename>

### Summary
### Findings
1. 🔴 Critical — Security — line 23
   - Issue: ...
   - Impact: ...
   - Fix: (code snippet)

### Verdict: Approved ✅ / Changes Requested 🔄
```
