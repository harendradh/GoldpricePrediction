---
description: Generate complete Javadoc comments for all public classes and methods in a Spark Java file
allowed-tools: Read, Glob, Edit
---

Generate complete Javadoc for the Java file at `$ARGUMENTS`.

Rules:
1. **Class-level Javadoc**: purpose, thread safety, usage example, `@author`, `@since`
2. **Method Javadoc**: every public/protected method must have:
   - Description (explain WHY/WHEN, not what the name already says)
   - `@param name description` for every parameter
   - `@return description` for non-void methods
   - `@throws ExceptionType condition` for every checked exception
   - `@throws RuntimeException` if unchecked exceptions are thrown intentionally
3. **Constructor Javadoc**: treat like method, describe what state it initializes
4. **Field Javadoc**: one-line `/** ... */` for all public/protected fields
5. **Inline code**: use `{@code expression}` for code references
6. **Cross-references**: use `{@link ClassName#method}` for related types/methods
7. **Spark-specific**: document whether methods trigger Spark actions (eager evaluation), mention partition count if relevant
8. **Do not** repeat what the method name says — explain the contract, edge cases, thread safety

After generating Javadocs:
- Show a diff of what was added
- Flag any methods where the behavior was ambiguous (you had to guess the contract)
- List any `TODO` Javadoc items that need the developer's input (e.g., exception conditions you couldn't infer)
