---
description: Validate a databricks.yml Databricks Asset Bundle configuration for correctness, security, and best practices
allowed-tools: Read, Glob, Bash
---

Validate the Databricks Asset Bundle configuration at `$ARGUMENTS` (default: `databricks.yml`).

**Step 1 — Schema validation**
```bash
databricks bundle validate
```
Report any schema errors.

**Step 2 — Security checks**
- No hardcoded `DATABRICKS_TOKEN` values in the YAML
- `mode: production` targets do not have `development: true`
- Cluster `data_security_mode` is `SINGLE_USER` or `USER_ISOLATION` (not `NONE`)
- No `num_workers: 0` in production (serverless is fine, explicit 0 is not)

**Step 3 — Best practice checks**
- Every job has a `schedule` or is triggered by another job (not orphaned)
- All clusters reference a `spark_version` ending in `.x` (latest patch)
- `node_type_id` uses Photon-enabled instances for SQL-heavy workloads
- `email_notifications` or `webhook_notifications` configured on production jobs
- All tasks have `timeout_seconds` set
- `max_retries` ≤ 3 for production (fail fast)

**Step 4 — Variable completeness**
- All `${var.*}` references have a `default:` value or are set per target
- No `${bundle.target}` in resource names without a sanitized prefix

**Step 5 — Target consistency**
- `dev` target has `mode: development`
- `prod` target has `mode: production`
- No `dev` cluster configs bleeding into `prod` targets

**Output**: Findings table + corrected YAML snippets for each issue.
