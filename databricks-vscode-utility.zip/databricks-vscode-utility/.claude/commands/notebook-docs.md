---
description: Generate structured documentation for a Databricks notebook — purpose, inputs, outputs, dependencies, usage
allowed-tools: Read, Write, Bash
---

Generate documentation for the Databricks notebook at `$ARGUMENTS`.

**Output a Markdown documentation file** `docs/<notebook-name>.md` with:

## Notebook: `<name>`

### Purpose
One paragraph describing what this notebook does and the business problem it solves.

### Inputs
| Name | Type | Source | Description |
|------|------|--------|-------------|
| `param_name` | Widget / Env Var | Caller / Airflow | Description |
| `table_name` | Delta Table | `catalog.schema.table` | Description |

(Extract from `dbutils.widgets.get(...)`, `spark.table(...)`, `spark.read.*`)

### Outputs
| Name | Type | Destination | Description |
|------|------|-------------|-------------|
| `result_table` | Delta Table | `catalog.schema.table` | Description |

(Extract from `df.write.*`, `MERGE INTO`, `INSERT INTO`)

### Dependencies
- Libraries: (from `%pip install` or `pyproject.toml`)
- Other notebooks: (from `%run ./path`)
- Databricks Secrets scopes: (from `dbutils.secrets.get(scope=...)`)

### Transformations
Step-by-step description of the data transformations in logical order.

### Usage
```python
# Run from another notebook:
%run ./path/to/this/notebook

# Run via Databricks Jobs:
databricks runs submit --json '{...}'

# Run via DAB:
databricks bundle run <job-name>
```

### Known Limitations / TODOs
- List any `# TODO` comments found in the notebook
- Flag any hardcoded values that should be parameterized

### Change Log
| Date | Author | Change |
|------|--------|--------|
| (from git log for this file) | | |

Save to `docs/<notebook-name>.md`.
