---
description: Full code review of a GitHub Pull Request — PySpark, Spark Java, SQL, DAB config
allowed-tools: Bash, Read, Glob, Grep
---

Review the GitHub Pull Request. Usage: `/pr-review <PR-number>`

Steps:
1. Run `git fetch origin pull/$ARGUMENTS/head:pr-$ARGUMENTS && git diff main...pr-$ARGUMENTS` to get the diff
2. Identify changed file types: `.py` (PySpark), `.java` (Spark Java), `.sql`, `databricks.yml`, `.github/workflows`
3. Apply the appropriate review criteria per file type (use the checklists from `/pyspark-review`, `/spark-java-review`, `/sql-review`)
4. Also check:
   - `databricks.yml` target/mode correctness (dev vs prod)
   - `pyproject.toml` / `uv.lock` changes for unwanted dependency upgrades
   - `.github/workflows` for security (no `pull_request_target` without authorization check)
   - `DATABRICKS_TOKEN` or secrets never hardcoded in workflow env vars
5. Post the review as structured Markdown

Output format:
```
## PR Review: #<number> — <title>

### Overall Assessment
<2-3 sentences>

### Changed Files
- file1.py — PySpark ✅ / 🔄
- file2.java — Spark Java ✅ / 🔄
- query.sql — SQL ✅ / 🔄

### Findings
1. 🔴 Critical — Security — src/job.py:45
   - Issue: ...
   - Fix: ...

### Verdict
- Approved ✅ / Approved with suggestions 🟡 / Changes Requested 🔄
```
