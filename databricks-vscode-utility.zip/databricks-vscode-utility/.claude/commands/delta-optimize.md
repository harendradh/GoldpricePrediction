---
description: Analyze a Delta table and generate OPTIMIZE, ZORDER, VACUUM, and partition strategy recommendations
allowed-tools: Bash, Read
---

Analyze the Delta table described in `$ARGUMENTS` (table name, path, or describe the query workload).

Generate a complete Delta Lake maintenance plan:

**1. OPTIMIZE + ZORDER**
Recommend ZORDER columns based on:
- Most frequent filter predicates in SELECT/WHERE clauses
- JOIN keys (high selectivity columns)
- Partition columns should NOT be ZORDERed

```sql
OPTIMIZE <catalog>.<schema>.<table>
ZORDER BY (<col1>, <col2>);
```

**2. VACUUM**
```sql
-- Default 7-day retention (do not go below unless time travel is disabled)
VACUUM <table> RETAIN 168 HOURS;

-- Check what will be deleted first:
VACUUM <table> RETAIN 168 HOURS DRY RUN;
```

**3. Partitioning strategy**
- Recommend partition columns (high-cardinality time columns: year, month)
- Warn if current partitioning causes small file problem (< 128 MB per file)
- Warn if too many partitions (> 10,000 partition directories)

**4. Statistics + Auto-optimization**
```sql
ANALYZE TABLE <table> COMPUTE STATISTICS FOR ALL COLUMNS;

ALTER TABLE <table> SET TBLPROPERTIES (
  'delta.autoOptimize.optimizeWrite' = 'true',
  'delta.autoOptimize.autoCompact' = 'true'
);
```

**5. Small file diagnosis**
```sql
DESCRIBE DETAIL <table>;
-- Check: numFiles, sizeInBytes, averageFileSize
-- Target: files between 128 MB – 1 GB
```

**6. Schedule**
Provide a recommended `databricks.yml` job snippet for running OPTIMIZE nightly.
