---
description: Review Apache Airflow DAGs that orchestrate Databricks jobs — operators, retry logic, secret handling, dependency chains
allowed-tools: Read, Glob, Grep
---

Review the Airflow DAG at `$ARGUMENTS` for Databricks orchestration best practices.

**🔴 Critical | 🟠 High | 🟡 Medium | 🔵 Info**

**1. Operator selection**
| Use case | Correct operator | Wrong operator |
|----------|-----------------|----------------|
| Run a Databricks job | `DatabricksRunNowOperator` | `BashOperator` with `databricks runs submit` |
| Submit one-off run | `DatabricksSubmitRunOperator` | `PythonOperator` calling REST API manually |
| Wait for job | `DatabricksRunSensorOperator` | `PythonSensor` polling REST |
| DLT pipeline | `DatabricksPipelineRunStatusSensor` | none |

**2. Connection & secrets**
- Databricks connection via `conn_id="databricks_default"` (Airflow Connection) — not hardcoded host/token
- No `DATABRICKS_TOKEN` in DAG file or environment variable passed directly to task
- Use Airflow Variables or Secrets Backend (HashiCorp Vault, AWS Secrets Manager) for any config

**3. Retry & failure handling**
```python
# Good:
default_args = {
    "retries": 2,
    "retry_delay": timedelta(minutes=5),
    "retry_exponential_backoff": True,
    "email_on_failure": True,
    "email": ["alerts@company.com"],
}

# Bad: no retries on network-flaky Databricks API calls
```
- `retries >= 1` on all Databricks operators (transient API failures)
- `execution_timeout` set — never let a stuck job hang indefinitely
- `on_failure_callback` defined for critical DAGs

**4. Dependency chains**
- No circular dependencies (Airflow will deadlock)
- `trigger_rule="all_done"` used intentionally (not accidentally — it bypasses failure propagation)
- Downstream tasks don't start if upstream Databricks job failed

**5. Idempotency**
- DAG is safe to re-run (Databricks jobs are idempotent for the same logical date)
- `catchup=False` unless historical backfill is intentional
- `max_active_runs=1` for sequential pipelines

**6. Performance**
- `DatabricksRunNowOperator` preferred over `DatabricksSubmitRunOperator` (reuses existing job config)
- Polling interval `polling_period_seconds >= 30` (don't hammer the API)

**7. XCom usage**
- `xcom_pull` from Databricks operator returns `run_id` — document what is being pulled
- Don't pass large DataFrames via XCom (use Delta table path instead)

Output findings with corrected DAG code snippets.
