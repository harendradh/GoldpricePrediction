---
description: Generate a complete Databricks ingestion pipeline from a REST API source — Auto Loader, Bronze table, error handling, scheduling
allowed-tools: Write, Read
---

Generate a complete REST API → Databricks ingestion pipeline for `$ARGUMENTS` (describe the API: endpoint, auth type, response schema, ingestion frequency).

**Output the following files**:

### 1. `src/ingest/api_<name>.py` — API ingestion module
```python
import requests
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.types import StructType
from databricks.sdk import WorkspaceClient

def fetch_page(url: str, token: str, page: int) -> list[dict]:
    """Fetch one page from the API. Handles rate limiting with exponential backoff."""

def ingest_to_bronze(spark: SparkSession, output_path: str) -> int:
    """Fetch all pages and write raw JSON to Bronze Delta table.
    
    Returns:
        Number of records ingested.
    """
```

Features to include:
- Pagination handling (cursor-based or page-number)
- Rate limit handling: retry on 429 with `Retry-After` header respect
- Credentials from `dbutils.secrets.get()` — never hardcoded
- Raw response saved as JSON string column `_raw` + `_ingested_at` + `_source_url`
- Exactly-once: check max `updated_at` in Bronze before fetching (incremental)
- Error rows written to `_error` table (don't fail entire batch for one bad record)

### 2. `bundles/notebooks/ingest_<name>.py` — Databricks notebook wrapper
- Widget for `start_date`, `end_date`, `full_refresh` parameters
- Calls `ingest_to_bronze()` from module
- Prints summary: records fetched, records written, error count

### 3. `databricks.yml` job snippet
```yaml
tasks:
  - task_key: ingest_<name>
    notebook_task:
      notebook_path: ./bundles/notebooks/ingest_<name>.py
      base_parameters:
        full_refresh: "false"
    schedule: "0 0 * * *"
```

### 4. Secret setup commands
```bash
databricks secrets create-scope --scope api-secrets
databricks secrets put --scope api-secrets --key <name>-token
```

### 5. Bronze table DDL
```sql
CREATE TABLE IF NOT EXISTS bronze.<name>_raw (
  _raw STRING,
  _ingested_at TIMESTAMP,
  _source_url STRING,
  -- parsed columns from schema
) USING DELTA
PARTITIONED BY (DATE(_ingested_at))
TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true');
```
