---
description: Review Databricks Auto Loader (cloudFiles) configuration for correctness, schema evolution, and performance
allowed-tools: Read, Glob, Grep
---

Review the Auto Loader (cloudFiles) configuration in `$ARGUMENTS`.

**🔴 Critical | 🟠 High | 🟡 Medium | 🔵 Info**

**1. Required options**
```python
# Every Auto Loader stream must have:
.option("cloudFiles.format", "json|csv|parquet|avro|orc|text|binaryFile")
.option("cloudFiles.schemaLocation", "/mnt/checkpoints/<stream>/_schema")  # REQUIRED
.option("checkpointLocation", "/mnt/checkpoints/<stream>")                  # REQUIRED
```
- 🔴 Missing `schemaLocation` → schema inferred on every restart (expensive)
- 🔴 Missing `checkpointLocation` → no fault tolerance, reprocesses all files on restart
- 🔴 Both locations must be on durable storage (ADLS/S3/GCS) — not `/tmp`

**2. Schema handling**
```python
# Good — explicit schema for known formats:
.schema(my_schema)

# Good — schema evolution with rescue:
.option("cloudFiles.schemaEvolutionMode", "addNewColumns")
.option("cloudFiles.inferColumnTypes", "true")

# Bad — no schema and no schemaLocation:
.load("/mnt/raw/")  # re-infers schema every run = full scan cost
```
- `_rescued_data` column: should be monitored in Silver DQ checks

**3. File notification mode vs directory listing**
```python
# Good (Event-driven, low latency, low cost):
.option("cloudFiles.useNotifications", "true")
.option("cloudFiles.subscriptionId", "...")   # Azure
# OR
.option("cloudFiles.region", "us-east-1")     # AWS SQS

# Acceptable for small directories (< 100K files):
.option("cloudFiles.useNotifications", "false")  # directory listing mode
```
- 🟠 Directory listing on millions of files = slow and expensive

**4. Performance options**
```python
.option("cloudFiles.maxFilesPerTrigger", "1000")   # cap micro-batch size
.option("cloudFiles.maxBytesPerTrigger", "10g")    # or cap by size
```

**5. File format-specific**
- JSON: `.option("multiLine", "true")` only if JSON spans multiple lines
- CSV: always set `header`, `delimiter`, `quote`, `escape` explicitly
- Avro/Parquet: schema from `cloudFiles.schemaHints` for partial override

**6. Permissions**
- Storage credential in Unity Catalog external location — not SAS token in code
- SAS token in options = 🔴 secret exposure

Output findings with corrected code snippets.
