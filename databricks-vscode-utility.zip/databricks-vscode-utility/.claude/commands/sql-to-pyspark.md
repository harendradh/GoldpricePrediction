---
description: Convert a SQL query to idiomatic PySpark DataFrame API code with type hints and performance hints
allowed-tools: Read, Write
---

Convert the SQL in `$ARGUMENTS` to idiomatic PySpark DataFrame API code.

**Conversion rules**:

| SQL | PySpark DataFrame API |
|-----|-----------------------|
| `SELECT a, b` | `.select("a", "b")` or `selectExpr("a", "b")` |
| `SELECT a AS alias` | `.select(col("a").alias("alias"))` |
| `WHERE condition` | `.filter(condition)` or `.where(condition)` |
| `JOIN t ON a.id = b.id` | `.join(t, "id", "inner")` |
| `LEFT JOIN` | `.join(t, "id", "left")` |
| `GROUP BY a` | `.groupBy("a")` |
| `COUNT(*)` | `.count()` or `agg(count("*"))` |
| `SUM(x)` | `agg(sum("x"))` |
| `HAVING count > 5` | `.filter(count("*") > 5)` |
| `ORDER BY a DESC` | `.orderBy(col("a").desc())` |
| `LIMIT 10` | `.limit(10)` |
| `DISTINCT` | `.distinct()` |
| `UNION ALL` | `.unionAll(df2)` |
| `UNION` | `.union(df2).distinct()` |
| `CASE WHEN ... END` | `when(cond, val).when(...).otherwise(val)` |
| `COALESCE(a, b)` | `coalesce(col("a"), col("b"))` |
| `DATE_TRUNC('month', ts)` | `date_trunc("month", col("ts"))` |
| `ROW_NUMBER() OVER (...)` | `row_number().over(Window.partitionBy(...).orderBy(...))` |
| `WITH cte AS (...)` | `cte = ...` (assign to variable) |

**Performance annotations** — add as comments:
```python
# BROADCAST: dim_table is small (< 200 MB) — broadcast hint applied
result = fact_df.join(broadcast(dim_df), "id", "left")

# CACHE: this DataFrame is reused 3 times below
df_clean.cache()
```

**Output format**:
```python
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql.window import Window

def transform(spark: SparkSession) -> DataFrame:
    """<describe what this query computes>."""
    
    # Load sources
    orders = spark.table("catalog.silver.orders")
    customers = spark.table("catalog.silver.customers")
    
    # <converted DataFrame chain>
    result = (
        orders
        .filter(...)
        .join(...)
        .groupBy(...)
        .agg(...)
        .orderBy(...)
    )
    
    return result
```

Then show the original SQL and converted PySpark side-by-side as a diff.
