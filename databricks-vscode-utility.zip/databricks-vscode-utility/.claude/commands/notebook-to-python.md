---
description: Convert a Databricks notebook (Python/SQL) into a production-ready Python module with proper structure
allowed-tools: Read, Write, Bash
---

Convert the Databricks notebook at `$ARGUMENTS` into a production Python module.

**Transformation rules**:

1. **Magic commands**:
   - `%sql <query>` → `spark.sql("""<query>""")`
   - `%run ./util` → `from src.utils.util import *` (flag for manual review)
   - `%md ...` → docstring or remove
   - `%pip install` → add to `pyproject.toml` dependencies

2. **Structure**: wrap all logic into functions:
   ```python
   def extract(spark: SparkSession) -> DataFrame: ...
   def transform(df: DataFrame) -> DataFrame: ...
   def load(df: DataFrame, output_path: str) -> None: ...
   
   def main() -> None:
       spark = get_spark()
       df = extract(spark)
       df = transform(df)
       load(df, OUTPUT_PATH)
   
   if __name__ == "__main__":
       main()
   ```

3. **dbutils references**:
   - `dbutils.widgets.get("param")` → `typer` CLI argument
   - `dbutils.secrets.get(scope, key)` → keep as-is (correct pattern)
   - `dbutils.fs.*` → `databricks.sdk.service.files` or `spark` equivalent

4. **Hardcoded paths**: extract to constants at top of file, add `TODO` comment for env var

5. **Type hints**: add type hints to all function signatures

6. **Docstrings**: add Google-style docstrings to every function

7. **Tests**: generate a skeleton `tests/test_<module>.py` with one test per transformation function using a small in-memory DataFrame fixture

**Output**:
- `src/<module_name>.py` — production Python module
- `tests/test_<module_name>.py` — test skeleton
- List of manual review items flagged with `# TODO`
