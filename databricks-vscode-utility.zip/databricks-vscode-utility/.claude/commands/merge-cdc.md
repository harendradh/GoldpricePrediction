---
description: Generate a MERGE INTO / APPLY CHANGES INTO CDC pattern for a given source and target Delta table
allowed-tools: Read, Write
---

Generate a CDC (Change Data Capture) merge strategy for `$ARGUMENTS` (describe source table, target table, change columns, and CDC type: SCD1, SCD2, or delete+insert).

**Detect CDC type from description**:
- **SCD Type 1** (overwrite): use `MERGE INTO` with `WHEN MATCHED UPDATE`
- **SCD Type 2** (history): use `MERGE INTO` with soft-delete + new row insert
- **Delete+Insert**: use `APPLY CHANGES INTO` (DLT) or `MERGE` with `WHEN MATCHED DELETE`

---

### SCD Type 1 — MERGE INTO template:
```sql
MERGE INTO target t
USING (
  SELECT * FROM source
  QUALIFY ROW_NUMBER() OVER (PARTITION BY <pk> ORDER BY <updated_at> DESC) = 1
) s
ON t.<pk> = s.<pk>
WHEN MATCHED AND s.<updated_at> > t.<updated_at> THEN
  UPDATE SET *
WHEN NOT MATCHED THEN
  INSERT *
WHEN NOT MATCHED BY SOURCE AND <soft_delete_flag> THEN
  UPDATE SET t.is_deleted = true, t.deleted_at = current_timestamp();
```

### SCD Type 2 — MERGE INTO template:
```sql
MERGE INTO target t
USING (SELECT *, true AS is_new FROM source) s
ON t.<pk> = s.<pk> AND t.is_current = true
WHEN MATCHED AND (t.<col1> <> s.<col1> OR t.<col2> <> s.<col2>) THEN
  UPDATE SET t.is_current = false, t.end_date = current_date()
WHEN NOT MATCHED THEN
  INSERT (<pk>, <cols>, effective_date, end_date, is_current)
  VALUES (s.<pk>, s.<cols>, current_date(), NULL, true);
-- Then insert new version for changed rows (two-step MERGE pattern)
```

### DLT APPLY CHANGES INTO (recommended for streaming CDC):
```python
dlt.apply_changes(
  target = "silver_customers",
  source = "bronze_customers_cdc",
  keys = ["customer_id"],
  sequence_by = col("updated_at"),
  apply_as_deletes = expr("op = 'DELETE'"),
  apply_as_truncates = expr("op = 'TRUNCATE'"),
  column_list = ["name", "email", "address"],
  except_column_list = ["_rescued_data"],
)
```

**Output**:
1. Chosen CDC pattern with justification
2. Complete SQL/Python code with your table's actual column names substituted in
3. OPTIMIZE + ZORDER recommendation for the target table
4. Idempotency guarantee explanation (safe to re-run?)
5. Monitoring query to detect merge conflicts or duplicates
