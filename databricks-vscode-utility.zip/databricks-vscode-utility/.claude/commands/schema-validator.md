---
description: Validate a PySpark StructType schema definition or compare two schemas for compatibility and breaking changes
allowed-tools: Read, Glob, Grep, Bash
---

Validate the schema in `$ARGUMENTS` (file path, or paste a StructType / DDL string after the command).

**Mode auto-detection**:
- If one schema given → validate completeness and correctness
- If two schemas given (separated by `---`) → diff them for breaking changes

---

### Single schema validation:
1. **Completeness**: every field has a `name`, `dataType`, and explicit `nullable` (not defaulting to True accidentally)
2. **Type choices**:
   - `StringType()` for codes/IDs that never need arithmetic
   - `LongType()` not `IntegerType()` for IDs > 2 billion
   - `DecimalType(18,4)` not `DoubleType()` for monetary amounts (floating-point imprecision)
   - `TimestampType()` not `StringType()` for timestamps
   - `DateType()` not `StringType()` for dates
3. **Nested structs**: `StructField("address", StructType([...]), nullable=True)` — deeply nested nullable check
4. **Arrays**: `ArrayType(elementType, containsNull=True/False)` — containsNull should be explicit
5. **Nullable consistency**: primary keys and partition columns should be `nullable=False`

### Schema diff (breaking changes):
```
BREAKING (🔴):
  - Column removed: customer_id
  - Type changed: amount LongType → StringType (widening not allowed)
  - Nullable changed: True → False (existing nulls will fail)

NON-BREAKING (🟢):
  - Column added: new_col StringType nullable=True
  - Type widened: IntegerType → LongType

WARNING (🟡):
  - Column renamed (new name not found, old name missing)
  - Nullable False → True (loosens constraint, may hide data quality issues)
```

### Output:
- Validation findings with severity
- Corrected StructType definition
- Delta `ALTER TABLE` statements to apply schema changes safely
- `mergeSchema` flag recommendation if changes are additive only
