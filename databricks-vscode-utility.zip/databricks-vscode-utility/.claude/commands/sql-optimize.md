---
description: Rewrite a SQL / Spark SQL query for maximum performance on Databricks Delta Lake
allowed-tools: Read, Glob
---

Optimize the SQL query in `$ARGUMENTS` (or paste the query after the command).

Apply ALL of the following transformations where applicable:

1. **CTEs** — replace all nested subqueries with named CTEs (`WITH` clause)
2. **Early filters** — push `WHERE` / `HAVING` predicates before JOINs, not after
3. **Window functions** — replace correlated subqueries with `ROW_NUMBER()`, `RANK()`, `LAG()`, `LEAD()`
4. **Broadcast hint** — add `/*+ BROADCAST(dim_table) */` for dimension tables under 200 MB
5. **Explicit columns** — replace `SELECT *` with explicit column list
6. **Join order** — largest fact table first in Spark SQL
7. **NULL safety** — add `COALESCE` / `IS NULL` guards where needed
8. **Inline comments** — add a comment above each CTE and major JOIN explaining the optimization

Then provide:
- **Changes Made** — bullet list of every transformation
- **Optimized Query** — the rewritten SQL in a fenced code block
- **Additional Recommendations**:
  - `OPTIMIZE <table> ZORDER BY (<columns>)` — which columns and why
  - `ANALYZE TABLE` suggestions
  - Caching suggestions if query is run frequently
  - Partitioning suggestions if table is > 1 TB
