---
description: Review SQL / Spark SQL script for correctness, performance, and Delta best practices
allowed-tools: Read, Glob, Grep
---

Review the SQL script at `$ARGUMENTS` (or the current file if no path given).

Apply these criteria and report findings with severity levels:

**🔴 Critical** — data loss, security, correctness bugs  
**🟠 High** — performance on large Delta tables  
**🟡 Medium** — best practices, maintainability  
**🔵 Info** — style, naming

Checklist:
1. **Security**: Hardcoded passwords, tokens, or connection strings inside SQL
2. **Correctness**: Implicit cross joins, missing NULL guards, non-deterministic ORDER BY, DISTINCT masking bad joins
3. **Performance**:
   - `SELECT *` in production
   - Missing partition filter on large Delta tables
   - Correlated subqueries (rewrite with window functions)
   - Nested subqueries (rewrite as CTEs)
   - JOIN order (large fact table left-most in Spark SQL)
   - Missing `ANALYZE TABLE` before complex joins
4. **Delta-specific**: `VACUUM` without retention check, `INSERT OVERWRITE` vs `MERGE INTO` for CDC, missing `OPTIMIZE`/`ZORDER` hints
5. **Style**: Unqualified column refs in multi-table queries, lowercase keywords, magic numbers

Output format:
```
## SQL Review — <filename>

### Summary
<2-3 sentence overall assessment>

### Findings
1. 🔴 Critical — Security — line 12
   - Issue: Hardcoded password in JDBC URL
   - Fix: Use dbutils.secrets.get(scope="...", key="...")

### Verdict: Approved ✅ / Changes Requested 🔄
```
