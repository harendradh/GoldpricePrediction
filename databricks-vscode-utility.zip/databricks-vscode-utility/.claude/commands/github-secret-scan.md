---
description: Scan git history, staged changes, and working tree for secrets before they reach GitHub
allowed-tools: Bash, Glob, Grep
---

Scan git repository for secrets before pushing to GitHub.

**Step 1 — Staged changes** (always run before every commit)
```bash
git diff --cached
```
Scan the diff output for all secret patterns.

**Step 2 — Working tree scan**
```bash
uv run python scripts/scan_git_secrets.py --all
```

**Step 3 — Recent commit history** (last 20 commits)
```bash
uv run python scripts/scan_git_secrets.py --history
git log --oneline -20
```

**Step 4 — GitLeaks scan** (if installed)
```bash
gitleaks detect --source . --verbose
```

**Step 5 — TruffleHog scan** (if installed)
```bash
trufflehog git file://. --since-commit HEAD~20 --only-verified
```

**Step 6 — Check .gitignore**
Verify these are in `.gitignore`:
- `.env`
- `.env.local`
- `*.pem`, `*.key`, `*.p12`, `*.pfx`
- `secrets/`, `credentials/`
- `.secrets.baseline`

**Step 7 — Report & Remediation**
For every finding:
- File / commit SHA / line number
- Severity and pattern matched
- Whether the secret is in git history (requires `git filter-repo` to purge)
- Exact steps to rotate the exposed credential

**If secrets found in git history:**
1. Rotate the exposed credential immediately
2. Run `git filter-repo --path <file> --invert-paths` to purge history
3. Force-push all branches (coordinate with team)
4. Add the file to `.gitignore`
5. Enable GitHub Secret Scanning on the repo (Settings → Security → Secret scanning)
