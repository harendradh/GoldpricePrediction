---
description: Review Spark Java code for correctness, performance, resource management, and Javadoc completeness
allowed-tools: Read, Glob, Grep
---

Review the Spark Java file at `$ARGUMENTS`.

**🔴 Critical** | **🟠 High** | **🟡 Medium** | **🔵 Info**

Criteria:
1. **Security**: Hardcoded credentials, tokens, passwords in source code
2. **Correctness**:
   - Multiple `SparkSession` instances in the same JVM
   - Closures capturing non-serializable objects (causes `NotSerializableException`)
   - Shared mutable state accessed inside transformations
   - Missing null checks on `Row.getAs()` calls
   - Missing `@SuppressWarnings` justification on unchecked casts
3. **Performance**:
   - RDD API used where Dataset/DataFrame suffices
   - `collect()` before filters; large `.collect()` on driver heap
   - Missing broadcast joins for small dimension datasets
   - Kryo encoder misuse or missing class registration
   - UDF registered in a loop (re-registration overhead)
4. **Resource Management**:
   - `SparkContext` / `SparkSession` not closed in `finally` block
   - Unclosed JDBC connections or streams inside `foreachPartition`
   - Missing `unpersist()` after cached RDD/Dataset is no longer needed
5. **Javadoc**:
   - Missing `@param`, `@return`, `@throws` on public methods
   - Missing class-level Javadoc description
   - `@throws` must list checked exceptions
6. **Testing**: Public transformation methods without JUnit 5 tests
7. **Style**: Raw types (`Dataset` without generics), magic numbers, deep nesting > 4 levels

Output:
```
## Spark Java Review — <filename>

### Summary
### Findings
1. 🔴 Critical — Resource Management — ClassName.java:87
   - Issue: SparkSession not closed in finally block
   - Fix: (code snippet)

### Verdict: Approved ✅ / Changes Requested 🔄
```
