---
description: Review Spark Structured Streaming code for correctness, fault tolerance, and Kafka/Event Hub integration
allowed-tools: Read, Glob, Grep
---

Review Spark Structured Streaming code at `$ARGUMENTS`.

**🔴 Critical | 🟠 High | 🟡 Medium | 🔵 Info**

**1. Fault Tolerance**
- Checkpoint location set: `option("checkpointLocation", "/mnt/checkpoints/<job>")`
- Checkpoint path unique per streaming query — never shared between two streams
- Checkpoint on durable storage (DBFS, ADLS, S3) — never local filesystem
- `outputMode` correct for operation: `append` for stateless, `update`/`complete` for aggregations

**2. Trigger settings**
```python
# Good — fixed interval:
.trigger(processingTime="5 minutes")

# Good — once / available-now (batch):
.trigger(availableNow=True)

# Bad — no trigger = continuous micro-batch (overloads cluster):
.writeStream.start()  # missing .trigger(...)
```

**3. Kafka / Event Hubs**
- `startingOffsets` explicitly set: `"earliest"` for initial load, `"latest"` for live
- `failOnDataLoss` set to `false` for long-running streams with Kafka compaction
- Kafka SASL credentials from Databricks Secrets, not hardcoded
- `maxOffsetsPerTrigger` set to cap micro-batch size and avoid OOM
- Schema explicitly defined — never infer schema from Kafka value bytes

**4. Stateful operations (aggregations, joins)**
- Watermark defined before any stateful operation: `.withWatermark("event_time", "10 minutes")`
- Stream-stream joins: both sides have watermarks
- `mapGroupsWithState` / `flatMapGroupsWithState` have timeout set
- State store backend: `RocksDB` recommended for large state

**5. Error handling**
- `foreachBatch` used for complex multi-table writes (not raw `foreach`)
- Dead letter queue pattern for malformed records
- `StreamingQueryListener` attached for monitoring query progress

**6. Performance**
- `spark.sql.shuffle.partitions` tuned to 2–3× cluster cores (not default 200)
- `spark.databricks.delta.optimizeWrite.enabled = true` for Delta sinks
- Avoid `dropDuplicates()` on unbounded stream without watermark (causes state explosion)

Output findings with severity and corrected code snippets.
