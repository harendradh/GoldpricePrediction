---
description: Generate a data lineage diagram showing how data flows from sources through transformations to outputs
allowed-tools: Read, Glob, Grep, Write
---

Generate a data lineage diagram for `$ARGUMENTS` (file path, directory, or table name).

**Step 1 — Parse lineage from code**
Scan the provided file(s) for:
- `spark.read` / `spark.table` / `dlt.read` → source nodes
- `df.write` / `dlt.table` / `MERGE INTO` → sink nodes
- `.join()`, `.withColumn()`, `.groupBy()`, `.agg()` → transformation nodes
- Column-level: which input columns produce which output columns

**Step 2 — Build lineage graph**
```
[Source: raw_orders (Bronze)]
       ↓ filter(status='complete')
[Silver: clean_orders]
       ↓ join(customers on customer_id)
       ↓ agg(revenue by region, month)
[Gold: revenue_summary]
       ↓
[BI Dashboard / SQL Warehouse]
```

**Step 3 — Column-level lineage** (if derivable from code)
```
gold.revenue_summary.total_revenue
  ← SUM(silver.clean_orders.amount)
  ← bronze.raw_orders.order_amount (after CAST to DECIMAL)
  ← source: Kafka topic orders-v2
```

**Step 4 — Generate Draw.io XML**
Produce a layered Draw.io diagram:
- Swim lanes: Source Systems | Bronze | Silver | Gold | Consumers
- Arrows labeled with transformation type
- Color coding: Bronze=orange, Silver=steel-blue, Gold=gold, Source=grey, Consumer=green

**Step 5 — Generate Mermaid diagram** (for README embedding)
```mermaid
flowchart LR
    kafka[Kafka: orders-v2] --> bronze[Bronze: raw_orders]
    bronze --> silver[Silver: clean_orders]
    customers[MySQL: customers] --> silver
    silver --> gold[Gold: revenue_summary]
    gold --> dashboard[BI Dashboard]
```

**Step 6 — Unity Catalog lineage query** (if Unity Catalog is used)
```sql
SELECT * FROM system.access.table_lineage
WHERE target_table_full_name = '<catalog>.<schema>.<table>'
ORDER BY event_time DESC LIMIT 100;
```

Save the Draw.io XML to `resources/drawio/lineage_<name>.drawio`.
