---
description: Refactor Spark Java code — modernize to Dataset API, add Javadocs, fix resource management, apply builder patterns
allowed-tools: Read, Edit, Write
---

Refactor the Spark Java file at `$ARGUMENTS` without changing business logic.

**Refactoring rules**:

**1. RDD → Dataset/DataFrame API**
```java
// Before (RDD):
JavaRDD<String> lines = sc.textFile("data.txt");
JavaRDD<String> words = lines.flatMap(s -> Arrays.asList(s.split(" ")).iterator());

// After (Dataset):
Dataset<Row> words = spark.read().text("data.txt")
    .select(explode(split(col("value"), " ")).alias("word"));
```

**2. Resource management — try-with-resources**
```java
// Before:
SparkSession spark = SparkSession.builder().getOrCreate();
// ... (no close)

// After:
try (SparkSession spark = SparkSession.builder().getOrCreate()) {
    // logic
}
```

**3. Typed Datasets over raw Row**
```java
// Before:
Dataset<Row> result = df.select("name", "age");

// After:
Encoder<Person> encoder = Encoders.bean(Person.class);
Dataset<Person> result = df.as(encoder);
```

**4. Builder pattern for configuration**
```java
// Before:
SparkConf conf = new SparkConf();
conf.set("spark.serializer", "...");
conf.set("spark.sql.shuffle.partitions", "200");

// After:
SparkSession spark = SparkSession.builder()
    .config("spark.serializer", KryoSerializer.class.getName())
    .config("spark.sql.shuffle.partitions", String.valueOf(numPartitions))
    .config("spark.sql.adaptive.enabled", "true")
    .getOrCreate();
```

**5. Lambda → method reference where cleaner**
```java
// Before:
df.foreach(row -> System.out.println(row.getString(0)));

// After:
df.foreach(row -> logger.info(row.getString(0)));  // never println in prod
```

**6. Logging — use SLF4J not System.out**
```java
private static final Logger logger = LoggerFactory.getLogger(MyJob.class);
logger.info("Processing {} records", count);  // not System.out.println
```

**7. Constants and configuration**
- Extract magic strings to `static final` constants
- Load config from environment variables: `System.getenv("DATABRICKS_HOST")`

**8. Javadoc completion** — add on every refactored class/method

**Output**: Complete refactored file + summary of every change.
