---
description: Audit a PySpark or Spark Java job for performance bottlenecks using Spark UI metrics and code analysis
allowed-tools: Read, Glob, Grep, Bash
---

Audit Spark job performance for `$ARGUMENTS` (file path or job name).

**Phase 1 — Code-level analysis**
Scan the code for these anti-patterns ranked by impact:

| Impact | Anti-pattern | Fix |
|--------|-------------|-----|
| 🔴 High | `collect()` on large dataset | Use `write()` or `show(n)` |
| 🔴 High | Shuffle join without broadcast | Add `broadcast()` hint |
| 🔴 High | `groupByKey` on RDD | Use `reduceByKey` or DataFrame |
| 🟠 Med | Re-reading same DataFrame 3+ times | `cache()` / `persist(MEMORY_AND_DISK)` |
| 🟠 Med | UDF instead of built-in function | Replace with `functions.*` equivalent |
| 🟠 Med | `explode()` without filter | Filter before explode |
| 🟠 Med | Skewed join (one key >> others) | Use salting or `skewHint` |
| 🟡 Low | Too many small files read | Coalesce input, use `spark.sql.files.maxPartitionBytes` |
| 🟡 Low | Default parallelism (200 shuffles) | Tune `spark.sql.shuffle.partitions` |

**Phase 2 — Configuration recommendations**
Based on the job type, recommend:
```python
spark.conf.set("spark.sql.shuffle.partitions", "<N>")      # = 2-3x cluster cores
spark.conf.set("spark.sql.files.maxPartitionBytes", "134217728")  # 128 MB
spark.conf.set("spark.sql.adaptive.enabled", "true")        # AQE
spark.conf.set("spark.sql.adaptive.coalescePartitions.enabled", "true")
spark.conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
```

**Phase 3 — Spark UI guidance**
List which Spark UI tabs to check:
- Stages tab → look for long GC time, spill (memory/disk)
- SQL tab → look for HashAggregate vs SortAggregate, exchange size
- Environment tab → verify AQE is enabled

**Phase 4 — Optimized code rewrite**
Rewrite the most impactful anti-patterns found with side-by-side before/after.
