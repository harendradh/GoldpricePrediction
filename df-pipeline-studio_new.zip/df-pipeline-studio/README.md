# DCS Data Factory Pipeline Studio

> **Spec-driven · Multi-agent · Databricks-native pipeline lifecycle.**
> **Five phase agents + one master orchestrator** · one console · Bronze → Gold → Documented → Lineage-traced.

```
📥 data_ingest  →  🔬 data_forge  →  ⚙️ data_prep  →  📋 data_doc
   ingest          analyze (EDA)     standardize       document
                                                       🗺 data_lineage (cross-cutting)
```

Onboard, govern, and document pipelines end-to-end by filling a form on the
Spec Console. The console writes the spec + bootstrap JSONs, copies the chat
invocation, and auto-launches VS Code with Copilot Chat ready to refine.

📘 **New here?** → `docs/QUICKSTART.md` (5-minute walkthrough) · `docs/data-factory-pipeline-architecture.html` (architecture slide · open in browser) · `CHANGELOG.md` (v1.0 release notes)

---

## Two ways to drive the agents

**A) Spec Console (form-driven, recommended)**

Open `tools/data-factory-pipeline-studio.html` in Chrome or Edge. **Six tabs**, mapped to agents + workflows:

| # | Tab | Drives | Writes to |
|---|-----|--------|-----------|
| 🏠 | Portfolio (Home Dashboard) | Live ops view: KPI cards · pipeline-health table · activity feed · governance widget · quick-lineage shortcut | reads `output/` (no writes) |
| 1 | 📥 Ingestion Pipeline | `agents/data_ingest.md` | `specs/ingestion/<name>/spec.md` + `output/ingestion/<name>/configs/<subdomain_slug>/{bronze_load,profiler}.json` + top-level `manifest.json` (N subdomains × 2 stages) |
| 2 | 🔬 EDA Analysis | `agents/data_forge.md` | `specs/eda/<name>/spec.md` + `output/eda/<name>/sql/consumer_header_query.sql` + `output/eda/<name>/notebooks/` |
| 3 | ⚙️ Data Prep Pipeline | `agents/data_prep.md` | `specs/dataprep/<name>/spec.md` + `output/dataprep/<name>/configs/*.json` (6 stages + manifest) |
| 4 | 📋 Document Pipeline | `agents/data_doc.md` | `output/docs/<name>/{ingestion_info,dataprep_info,runbook}.md` (per mode) |
| 5 | 🧩 Onboard New Pipeline | Runtime-extensible — teams create their own pipeline types without editing code (persists to localStorage) | new tab + `specs/<phase>/<name>/spec.md` once generated |

**Cross-cutting agent** (no tab — runs from the 🗺 Lineage modal in the footer):

| Agent | Drives | Writes to |
|---|---|---|
| 🗺 `agents/data_lineage.md` | Whole-project DAG · column index · per-column impact analysis | `output/lineage/<scope>/{lineage.md, .mmd, column_index.md, impact_<col>.md}` |

### Key Ingestion-tab features (v1.0)

- **Multi-subdomain** — one pipeline can declare N Bronze target tables (each "subdomain" = a table name in the ingestion app's terminology). Cards mirror the EDA tables pattern.
- **Source database & schema** — combobox tells the agent WHERE TO READ FROM (`BANK.DBO` for JDBC · `raw/path/prefix` for ADLS).
- **Per-subdomain load query OR query volume path** — paste SQL inline OR drop a path to a `.sql` file in a UC volume (`/Volumes/...`), DBFS, or cloud storage. Agent auto-detects which mode you used.
- **Sticky stage toolbar + collapsible sections** — every form panel has a sticky toolbar (pipeline name · live validation badge · Expand/Collapse all) and the long form is split into 2–3 collapsible `<details>` sections with auto-open-on-error + persistence.

### Workflow

Link your project folder once (File System Access API) → fill the form →
click **Generate ⚡** — the console writes the spec + bootstrap JSONs directly
into your project, copies the chat invocation to clipboard, and auto-launches
VS Code with Copilot Chat. You just hit `Ctrl+V` in chat.

**B) Edit `spec.md` by hand** — the original workflow below still works.

---

## data_forge manual workflow (option B — hand-edit the EDA spec)

> Recommended only if you skipped option A above (the Spec Console). These
> steps apply to **data_forge only** — the EDA agent. For data_ingest,
> data_prep, and data_doc, use the Spec Console.
> Edit `specs/eda/<pipeline_name>/spec.md` (start from
> `.github/skills/eda/schema_intelligence/references/spec.md.example`).

### Step 0 — (Optional) Extract schemas from your live Databricks tables

If your tables already exist in Unity Catalog, skip writing spec.md by hand.
Upload `tools/00_extract_schema.py` to Databricks, set the catalog/schema widgets, and run it.
It queries your live tables and outputs a ready-to-paste `spec.md` section.

```
Widgets:
  catalog  →  main          (your Unity Catalog name)
  schema   →  silver        (your schema)
  tables   →  customers,orders   (blank = all tables)
```

Copy the Step 5 output from the notebook into `spec.md`, add context sentences, done.

---

### Step 1 — Describe your tables in `spec.md`

If your tables aren't in Databricks yet (or you want to add context), copy
`.github/skills/eda/schema_intelligence/references/spec.md.example` → `specs/eda/<pipeline_name>/spec.md`
and describe your tables in plain English.

```markdown
## Tables

### customers
Our main customer table:
- customer_id (primary key)
- first_name, last_name, email, phone
- account_status (ACTIVE, INACTIVE, SUSPENDED)
- created_at, updated_at

### orders
CREATE TABLE orders (
  order_id    STRING NOT NULL,
  customer_id STRING,
  total_amount DECIMAL(10,2),
  order_date  TIMESTAMP
)
```

You can mix natural English, DDL SQL, JSON, column lists — any format.

---

### Step 2 — Open GitHub Copilot Chat in VS Code

`Ctrl+Alt+I` to open Copilot Chat, then type:

```
#file:agents/data_forge.md  #file:specs/eda/{pipeline_name}/spec.md

Run data_forge on my spec
```

data_forge reads your spec and produces everything automatically.

---

### Step 3 — Upload notebooks to Databricks and run

data_forge writes two notebooks to `output/eda/<pipeline_name>/notebooks/`:

| Notebook | What it does |
|----------|-------------|
| `01_analysis.py` | Set catalog/schema widgets → run all cells → profiling, DQ assertions, DQ scorecard, JOIN SQL, golden record MERGE |
| `02_dashboard.py` | Plotly charts: fill rates, DQ gauges, monthly trends, PII risk map |

Upload and run:
```
databricks workspace import output/eda/<pipeline_name>/notebooks/01_analysis.py /Shared/dataforge/01_analysis.py
databricks workspace import output/eda/<pipeline_name>/notebooks/02_dashboard.py /Shared/dataforge/02_dashboard.py
```

Or drag-and-drop the `.py` files into the Databricks workspace browser.

---

## What's in the notebooks

`01_analysis.py` covers everything in one notebook:

| Section | SQL generated |
|---------|--------------|
| Table overview | Row counts, date ranges, duplicate detection |
| Fill rates | Null rate per column |
| Column profile | Type, distinct count, min/max/mean/stddev per column |
| Top values | Frequency distribution for categorical columns |
| Distributions | Percentiles (p25/p50/p75/p95) for numeric columns |
| Monthly trend | Volume over time |
| DQ assertions | Pass/fail per business rule (NOT NULL, UNIQUE, format, range, enum) |
| DQ scorecard | Weighted score: completeness 35% + uniqueness 30% + validity 25% + freshness 10% |
| Relationships | Optimized JOIN SQL for all detected table links |
| Golden record | Survivorship CTEs + MERGE INTO for entity master table |

`02_dashboard.py` — interactive Plotly charts for all of the above.

---

## Other output files

| File | What it is |
|------|-----------|
| `output/eda/<pipeline_name>/reports/schema_report.md` | Column-by-column intelligence (class, PII, governance score) |
| `output/eda/<pipeline_name>/reports/relationship_diagram.md` | Mermaid ER diagram — opens in VS Code preview |
| `output/eda/<pipeline_name>/sql/unity_catalog_tags.sql` | Run in Databricks SQL to tag PII columns in Unity Catalog |
| `output/eda/{pipeline_name}/reports/data_catalog.md` | Data dictionary — publish to Confluence or SharePoint |

---

## Running specific skills

```
"Run data_forge schema intelligence on my spec"
"Run data_forge entity builder for customers and orders"
"Run data_forge notebooks only"
```

Or attach a specific skill for more detail:
```
#file:agents/data_forge.md  #file:specs/eda/{pipeline_name}/spec.md  #file:.github/skills/eda/data_quality/SKILL.md
Run data quality on my spec
```

---

## What you can put in spec.md

**Plain English**
```
Our customers table has customer_id as the primary key, first_name, last_name, email, phone...
```

**DDL SQL**
```sql
CREATE TABLE orders (order_id STRING NOT NULL, customer_id STRING, amount DECIMAL(10,2))
```

**Column list**
```
customer_id STRING PK | first_name STRING | email STRING | created_at TIMESTAMP
```

**JSON**
```json
{"name": "products", "columns": [{"name": "product_id", "type": "STRING", "pk": true}]}
```

**Mix everything** — data_forge handles all formats.

---

## Project structure

```
df-pipeline-studio/
├── .github/                                       ← all agent intelligence lives here
│   ├── copilot-instructions.md                    ← deterministic contract (loaded by Copilot)
│   ├── rules/                                     ← rule catalog · 38 standard rules across 10 categories (auto-applied per column)
│   ├── instructions/                              ← cross-skill standards
│   │   ├── sql-standards.md
│   │   ├── pii-policy.md
│   │   ├── spark-patterns.md
│   │   └── databricks-standards.md
│   └── skills/                                    ← Pythonic snake_case modules · referenced as <phase>.<name>
│       ├── ingestion/                             (used by data_ingest)
│       │   ├── pipeline/                          orchestrator · references/{spec.md.example, manifest.template.json}
│       │   ├── bronze_load/                       SKILL.md + references/example.json
│       │   └── profiler/                          SKILL.md + references/example.json
│       │
│       ├── eda/                                   (used by data_forge)
│       │   ├── schema_intelligence/               SKILL.md + references/ (spec.md.example) + assets/
│       │   ├── relationship_discovery/            SKILL.md + references/ + assets/
│       │   ├── sql_profiling/                     SKILL.md + references/ + assets/
│       │   ├── entity_builder/                    SKILL.md + references/ + assets/
│       │   ├── data_quality/                      SKILL.md + references/
│       │   ├── documentation/                     SKILL.md + references/ + assets/
│       │   └── notebook_generator/                SKILL.md + references/
│       │
│       ├── dataprep/                              (used by data_prep)
│       │   ├── pipeline/                          orchestrator · references/{spec.md.example, manifest.template.json}
│       │   ├── extraction/                        SKILL.md + references/example.json
│       │   ├── extraction_profiler/               SKILL.md + references/example.json
│       │   ├── preparation/                       SKILL.md + references/example.json
│       │   ├── address_standardization/           SKILL.md + references/example.json
│       │   ├── address_profiler/                  SKILL.md + references/example.json
│       │   └── conversion/                        SKILL.md + references/example.json
│       │
│       └── docs/                                  (used by data_doc)
│           └── pipeline_doc/                      SKILL.md
│
├── agents/                                        ← agent prompts (attach to Copilot Chat)
│   ├── data_ingest.md                              📥 sources → Bronze (N subdomains per pipeline)
│   ├── data_forge.md                               🔬 EDA + relationships
│   ├── data_prep.md                                ⚙️ standardize + Silver/Gold (6 stages)
│   ├── data_doc.md                                 📋 document pipelines (3 modes)
│   ├── data_lineage.md                             🗺 whole-project DAG · column index · impact analysis
│   └── data_pipeline_master.md                     🧭 master orchestrator · one paste runs all 4 phase agents end-to-end
│
├── specs/                                         ← user-authored input (one folder per pipeline per phase)
│   ├── ingestion/<pipeline_name>/spec.md
│   ├── eda/<pipeline_name>/spec.md
│   └── dataprep/<pipeline_name>/spec.md
│
├── tools/                                         ← browser apps + tests
│   ├── data-factory-pipeline-studio.html          the Studio (spec-only · spec is the agent's input)
│   ├── json-studio.html                           view / edit / validate any stage JSON
│   ├── 00_extract_schema.py                       extract live UC schemas → paste into spec.md
│   ├── studio-tests.py                            15 suites · 99 tests · main studio logic
│   ├── studio-tests.js                            JS port of above (manual cross-runtime check)
│   ├── json-studio-tests.py                       13 suites · 99 tests · JSON Studio rule composer
│   ├── project-consistency-tests.py               16 suites · 432 tests · cross-reference + drift checks
│   └── README.md
│
├── docs/
│   ├── data-factory-pipeline-architecture.html    leadership-facing architecture slide
│   ├── QUICKSTART.md                              5-minute getting-started walkthrough
│   └── architecture/fiserv-logo.svg               standalone brand asset
│
├── CHANGELOG.md                                   v1.0 release notes (Keep a Changelog format)
│
├── .vscode/
│   ├── settings.json
│   └── extensions.json
│
└── output/                     ← All generated artifacts · per phase · per pipeline · grouped by purpose
    │
    ├── ingestion/<pipeline_name>/
    │   ├── configs/                            stage JSON contracts + top-level manifest
    │   │   ├── manifest.json                   chains all subdomains × 2 stages
    │   │   ├── <subdomain_slug_1>/             per-subdomain configs (one dir per Bronze target)
    │   │   │   ├── bronze_load.json
    │   │   │   └── profiler.json               (enabled:false if no columns for this subdomain)
    │   │   └── <subdomain_slug_2>/
    │   │       ├── bronze_load.json
    │   │       └── profiler.json
    │   └── reports/
    │       └── validation_report.md            per-subdomain pass/fail
    │
    ├── eda/<pipeline_name>/
    │   ├── notebooks/                          analytical / dashboard notebooks
    │   │   ├── 01_analysis.py
    │   │   └── 02_dashboard.py
    │   ├── reports/                            markdown reports for governance
    │   │   ├── schema_report.md
    │   │   ├── relationship_diagram.md
    │   │   └── data_catalog.md
    │   └── sql/                                standalone SQL artifacts
    │       ├── consumer_header_query.sql       ← bridge → data_prep (Import button reads this)
    │       └── unity_catalog_tags.sql
    │
    ├── dataprep/<pipeline_name>/
    │   ├── configs/                            6 stage JSON contracts + manifest
    │   │   ├── extraction.json
    │   │   ├── extraction_profiler.json
    │   │   ├── preparation.json
    │   │   ├── address_standardization.json
    │   │   ├── address_profiler.json
    │   │   ├── conversion.json
    │   │   └── manifest.json
    │   └── reports/
    │       └── validation_report.md
    │
    └── docs/<pipeline_name>/
        ├── ingestion_info.md   ← data_doc mode:ingest   (15-section ingestion reference)
        ├── dataprep_info.md    ← data_doc mode:dataprep (15-section data-prep reference)
        └── runbook.md          ← data_doc mode:runbook  (16-section production runbook)
```

---

## Tips

- **Not sure what to write in spec.md?** Just describe your tables in plain sentences.
- **Need just one table?** Say "Run data_forge on just the customers table from my spec".
- **Want stricter DQ?** Say "Regenerate DQ assertions for orders with stricter validity checks".
- **Sharing the catalog?** `output/eda/{pipeline_name}/reports/data_catalog.md` is formatted for Confluence / SharePoint.
