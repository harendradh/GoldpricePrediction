# output/ — Agent-Created Artifacts Only

> 🚨 **Contract:** Nothing under this directory is written by humans or by the
> Studio. **Every file here was created by a Copilot agent** in response to
> a spec at `specs/<phase>/<pipeline_name>/spec.md`. If you find files here
> that you didn't ask Copilot to produce, delete them.

---

## Required directory shape

Every pipeline writes to a strict sub-layout. Agents MUST follow this exactly.

```
output/
├── ingestion/<pipeline_name>/
│   ├── configs/                                   ← stage JSON contracts + top-level manifest (mandatory)
│   │   ├── manifest.json                          (orchestrator · chains all subdomains × 2 stages with depends_on edges)
│   │   ├── <subdomain_slug_1>/                    (one directory per Bronze target table)
│   │   │   ├── bronze_load.json                   (stage 1 contract for this subdomain)
│   │   │   └── profiler.json                      (stage 2 contract · enabled:false if no columns for this subdomain)
│   │   └── <subdomain_slug_2>/
│   │       ├── bronze_load.json
│   │       └── profiler.json
│   └── reports/                                   ← validation report (mandatory · per-subdomain pass/fail)
│       └── validation_report.md
│
├── eda/<pipeline_name>/
│   ├── notebooks/                                 ← Databricks analysis + dashboard notebooks
│   │   ├── 01_analysis.py
│   │   └── 02_dashboard.py
│   ├── reports/                                   ← governance + relationship reports
│   │   ├── schema_report.md
│   │   ├── relationship_diagram.md                (Mermaid ER)
│   │   ├── data_catalog.md
│   │   └── entity_mapping.md
│   └── sql/                                       ← standalone SQL artifacts
│       ├── consumer_header_query.sql              ← bridge → data_prep stage 1
│       └── unity_catalog_tags.sql
│
├── dataprep/<pipeline_name>/
│   ├── configs/                                   ← 6 stage JSONs + manifest (mandatory)
│   │   ├── extraction.json
│   │   ├── extraction_profiler.json
│   │   ├── preparation.json
│   │   ├── address_standardization.json           (enabled:false + skip_reason if no address cols)
│   │   ├── address_profiler.json                  (enabled:false + skip_reason if no address cols)
│   │   ├── conversion.json
│   │   └── manifest.json                          (full 6-stage depends_on chain)
│   └── reports/
│       └── validation_report.md
│
└── docs/<pipeline_name>/
    ├── ingestion_info.md                          ← data_doc mode:ingest    (15-section ingestion reference)
    ├── dataprep_info.md                           ← data_doc mode:dataprep  (15-section data-prep reference)
    └── runbook.md                                 ← data_doc mode:runbook   (16-section production runbook)
```

## Rules for agents

1. **Always create the full sub-layout.** Even if a phase has no `sql/`
   artifacts (e.g. ingestion), the `configs/` and `reports/` dirs must
   all be created — empty if nothing to put in them.
2. **Never write outside `<phase>/<pipeline_name>/<subdir>/`.** No files at
   `output/`, `output/<phase>/`, or `output/<phase>/<pipeline_name>/` root.
3. **Stage JSON files go in `configs/` only.** Never in `reports/`.
4. **For `ingestion`, per-subdomain configs nest one level deeper** — every
   subdomain declared in the spec gets its own `configs/<subdomain_slug>/`
   directory holding that subdomain's `bronze_load.json` + `profiler.json`.
   The top-level `configs/manifest.json` chains every subdomain's stages.
5. **The manifest's `stages[*].config_path`** is the relative path from
   `configs/`. For ingestion that's `<subdomain_slug>/<file>.json`
   (e.g. `consumer/bronze_load.json`); for other phases it's the bare
   filename (`extraction.json`). Stage runners join it to
   `<configs_dir>/<config_path>`.
6. **`<pipeline_name>` is the slugified spec name** — see the
   `slugify()` rule in `.github/copilot-instructions.md` § 4. Lowercase,
   `_`-separated, no special characters. `<subdomain_slug>` follows the
   same rule.
7. **Each stage JSON ends with `_meta`** including `stage`, `pipeline`,
   `generated_by`, `generated_at`, `unresolved[]`. Ingestion stages add
   `subdomain` to `_meta` so the file's home dir is unambiguous. See
   `.github/copilot-instructions.md` § 7.
8. **No `runners/` directory.** Runner notebooks were removed —
   `manifest.json` IS the orchestrator. Drive workflows from there
   directly (Databricks Workflows, Airflow, etc.).

## What goes where (cheat sheet)

| Artifact type | Goes in | Examples |
|--------------|---------|----------|
| Stage JSON contract (non-ingestion) | `configs/` | `extraction.json`, `preparation.json`, `conversion.json` |
| Stage JSON contract (ingestion · per subdomain) | `configs/<subdomain_slug>/` | `consumer/bronze_load.json`, `consumer/profiler.json` |
| Manifest (orchestrator · always top-level) | `configs/` | `manifest.json` |
| Pass/fail report | `reports/` | `validation_report.md` |
| Markdown report (governance / lineage / catalog) | `reports/` | `schema_report.md`, `data_catalog.md`, `entity_mapping.md`, `relationship_diagram.md` |
| Standalone SQL artifact | `sql/` | `consumer_header_query.sql`, `unity_catalog_tags.sql` |
| Databricks analysis / dashboard notebook | `notebooks/` | `01_analysis.py`, `02_dashboard.py` |
| Per-mode doc (data_doc only) | (root of `docs/<name>/`) | `ingestion_info.md` · `dataprep_info.md` · `runbook.md` |

## What to inspect after an agent run

```bash
# After running data_ingest:
ls output/ingestion/<pipeline_name>/configs/                       # manifest.json + one dir per subdomain
ls output/ingestion/<pipeline_name>/configs/<subdomain_slug>/      # bronze_load.json + profiler.json
cat output/ingestion/<pipeline_name>/reports/validation_report.md  # per-subdomain pass/fail

# After running data_prep:
ls output/dataprep/<pipeline_name>/configs/          # 6 stage JSONs + manifest.json
cat output/dataprep/<pipeline_name>/reports/validation_report.md

# Validate any single JSON in the JSON Studio:
start tools/json-studio.html
# Drag any file from output/<phase>/<pipeline>/configs/ into it.
```

## Why this contract exists

- **Predictability.** Anyone opening the project can find any artifact by
  navigating `output/<phase>/<pipeline>/<purpose>/`.
- **Multi-pipeline support.** Every pipeline lives in its own
  `<pipeline_name>/` subdirectory — they never collide.
- **Validation.** Tests + the Studio's Portfolio scanner know exactly where
  to look — `output/<phase>/*/configs/manifest.json`.
- **Auditability.** A glance at `output/` tells you exactly what pipelines
  exist and what state each is in.
