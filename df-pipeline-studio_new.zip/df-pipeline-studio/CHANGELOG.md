# Changelog · DCS Data Factory Pipeline Studio

All notable changes to this project. Format: [Keep a Changelog](https://keepachangelog.com/).

---

## [1.0.0] — 2026-05-23

First broadly-shippable version. Spec-authoring tool + 5 deterministic Copilot
agents + 19 skill files, all wired together with a single-HTML browser studio.

### Added

**Agents** (`agents/`)
- `data_ingest.md` — pulls JDBC / ADLS sources to Bronze Delta tables
- `data_forge.md` — EDA + relationship discovery + golden-record SQL
- `data_prep.md` — 6-stage Bronze → Silver/Gold pipeline (extract → profile → prep → address-std → addr-profile → conversion)
- `data_doc.md` — pipeline documentation in 3 modes:
  - `mode: ingest` → `ingestion_info.md` (15 sections)
  - `mode: dataprep` → `dataprep_info.md` (15 sections)
  - `mode: runbook` → `runbook.md` (16-section production runbook)
- `data_lineage.md` — whole-project DAG · column index · per-column impact analysis

**Skills** (`.github/skills/`)
- 7 EDA skills (data_quality · documentation · entity_builder · notebook_generator · relationship_discovery · schema_intelligence · sql_profiling)
- 7 Data Prep skills (address_profiler · address_standardization · conversion · extraction · extraction_profiler · pipeline · preparation)
- 3 Ingestion skills (bronze_load · pipeline · profiler)
- 1 Docs skill (pipeline_doc) with 4 reference docs (runbook-structure · upstream-tech-stack · downstream-tech-stack · sop-templates)
- 1 Lineage skill (builder) with 3 reference docs (extraction_rules · mermaid_template · output_template)

**Rule catalog** (`.github/rules/`)
- 38 rules across 10 categories (identity · pii_masking · contact · name · address · datetime · monetary · categorical · boolean · always_on)
- `catalog.yaml` master index · `rule_schema.yaml` meta-schema · 10 category YAMLs

**Studio** (`tools/data-factory-pipeline-studio.html`)
- Single HTML, no build step, no install
- 6 tabs: 🏠 Portfolio · 📥 Ingestion Pipeline · 🔬 EDA Analysis · ⚙️ Data Prep Pipeline · 📋 Document Pipeline · 🧩 Onboard New Pipeline
- 🏠 **Home Dashboard** — Portfolio tab is now a live ops dashboard: 5 KPI cards (pipelines · active this week · spec coverage % · open gaps · PII columns) · sortable pipeline-health table with 5-category 100-pt scoring · activity feed (last 10 by `generated_at`) · governance widget (spec/PII/runbook progress bars) · quick-lineage shortcut · responsive 5→3→2 column grid
- 📥 **Ingestion · multi-subdomain** — one ingestion pipeline can now declare N Bronze target tables (in the ingestion app's terminology, each = a "subdomain"). Cards mirror the EDA tables pattern: add/remove rows, each with its own name + optional columns. Validation enforces ≥1 subdomain + unique names. Profiler pill shows `ENABLED · N/M subdomains`. Spec generator iterates per-subdomain (own schema contract + Bronze target + auto-expectations + PII) under one shared source connection + schedule. Legacy single-subdomain drafts auto-migrate on restore. Consumer Master template demos 3 subdomains (Consumer + Address + Account)
- 📥 **Source database & schema** — new combobox next to `Schema (Bronze target)` lets the user tell the agent WHERE TO READ FROM in the source system (JDBC `DB.SCHEMA` or ADLS `container/path/prefix`). Datalist of presets + free text · feeds the shared connection block in the spec so agents stop guessing `<<FILL_IN: BANK.<TABLE>>>`. Warning surfaces if both this and per-subdomain load_query are empty
- 📥 **Per-subdomain load query / path** — optional textarea on each subdomain card. JDBC label is **"Load query or Query Volume Path"** — paste SQL inline for small queries OR drop a path to a `.sql` file in a UC volume (`/Volumes/...`), DBFS (`dbfs:/...`), or cloud storage (`abfss://`, `s3://`, `gs://`) for queries too big to paste. `classifyLoadQuery()` heuristic auto-detects mode; spec emits `query_source: inline | file | table` accordingly with `query_path` so agent loads the SQL at runtime. ADLS sources still show "Load path / glob". `## Pipeline metadata` reports `load_overrides: { inline_sql: N, volume_path: N }` so reviewers can see which subdomains diverge from the default
- 📦 **Deliverables tier · 1-to-1 mapping with Problem cards** — rewritten so every deliverable explicitly answers one of the 5 pain points: **🧩 → 📦 One-form Job Profiles** (ingestion + data-prep configs, per-subdomain, schema-checked, zero hand-edit) · **🔍 → 🔬 Auto-tuned Profiling** (column classifier picks targets · auto-derives expectations + drift + freshness) · **📊 → 🧬 Reusable EDA + Golden Record** (`consumer_header_query.sql` bridges EDA → Data Prep · profile once, reuse downstream) · **📝 → 📚 Auto-generated Docs + Runbooks** (3 modes · emitted from manifest · always in sync) · **🌀 → 🧭 Shared Spec Format & Catalog** (one spec template · one 38-rule catalog · one output-path contract). Each tile carries a red-bordered "→ solves" chip that names the pain card it answers, so reviewers can trace pain ↔ solution at a glance. **Lineage Graph tile dropped** (out of scope). Value-prop row updated: the misleading "PII auto-masked" claim removed (Fiserv Protector handles encryption at source); replaced with "38-rule catalog · auto-derived expectations · drift · freshness · quarantine".
- ✨ **Problem panel · premium boxes + animated connectors** — Cards upgraded from flat rectangles to high-end:
  - **Layered backgrounds** · radial orange highlight up top + deep crimson-to-black vertical gradient + inner top/bottom shadows for 3D depth
  - **Glowing top accent line** · orange-to-red gradient bar across the card top, brightens on hover
  - **Icon-in-halo badge** · 42px round badge with radial gradient + orange ring + soft glow behind every emoji; rotates -3° + scales on hover
  - **Pulsing red alert dot** in top-right corner of each card (`@keyframes dotPulse` · 1.8s)
  - **Card-breathe animation** · each card's border glow pulses on a 4.5s cycle, staggered 0.9s apart so the row "waves" left-to-right
  - **Cascading horizontal connectors** between adjacent cards — orange gradient line + glowing chevron tip + a bright pulse dot that travels left-to-right through every connector with sequential 0.9s delay (cards 1→2→3→4→5)
  - Hover lift bumped to 5px + 1.5% scale + dramatic glow shadow
  - Connectors auto-hide on wrapped layouts (< 1100px) · full `prefers-reduced-motion` fallback
- 📜 **Architecture slide · vertical scroll fix + custom Fiserv scrollbar** — the slide was originally designed as a single-screen pitch deck (`html, body { overflow:hidden }`), but it has since grown to include the Problem panel · animated agent flow · Deliverables tier — all of which need vertical real estate. Reviewers couldn't scroll up/down. Fix: `html, body` now scrollable (`overflow-y:auto`), `.slide` uses `min-height:100vh` so content can extend past viewport, `.stage` backdrop stays fixed but `pointer-events:none` so it doesn't trap clicks. **Custom 14px Fiserv-orange scrollbar** on the right edge (`::-webkit-scrollbar` for Chrome/Edge/Safari · `scrollbar-color` for Firefox) — gradient thumb with glow, dark track — clearly visible so reviewers know they CAN scroll. 5 new regression tests in Suite 12 lock the scroll behaviour so it can't accidentally revert.
- ⚠️ **Architecture slide · Problem panel** — high-impact "why this exists" section pinned ABOVE the solution flow. Animated warning stripe (left edge) + pulsing ⚠ badge + gradient orange-on-red title. 5 pain-point cards focused on the **real day-to-day pain**: *🧩 Complex job-profile onboarding · 🔍 Data profiling is manual guesswork · 📊 EDA done twice — late and inconsistent · 📝 Runbooks are last-minute & hand-typed · 🌀 Every team reinvents the wheel*. **PII compliance is intentionally NOT in this list** (Fiserv Protector encrypts at source — plain PII never lands), and **lineage is also out of scope** for v1.0. Each card has icon + bold title + 1–2 line description with hover-lift. A "✨ The framework — one console solves all of the above" pill divider transitions cleanly into the existing Inputs → UI → Agents → Deliverables tiers. Sets the stakes for first-time viewers in 5 seconds. Suite 12 now hard-locks the 5 covered pains AND guards against the 2 out-of-scope ones being reintroduced.
- 🎞 **Architecture slide · animated Read → Spec → Agent → Write flow per agent card** — replaces the static 2×2 details grid with a 4-step horizontal flow chart. Each step is a **yellow circle** (numbered badge top-right · large icon · radial gradient) above a **dark rectangle card** that lists the step's responsibilities as bullet points. Bullets are auto-split from `·`-separated `data-*` attributes, with extra standard bullets added under the AGENT step ("consults `.github/skills/<phase>/`" + "applies `.github/rules/`"). Sequenced animation: each circle+rectangle pair brightens in turn (1.5s slot · 6s full cycle · infinite loop while a card is active); a yellow pulse dot travels through each arrow with `@keyframes pulseTravel`. JS `startFlowSequence()` scheduler keeps the `.is-active` accent in lockstep. Vertical-stack layout at < 800px (arrows flip to down-chevrons), full `prefers-reduced-motion` fallback.
- 📑 **Architecture slide refreshed for v1.0** — `docs/data-factory-pipeline-architecture.html`: `data_ingest` agent card now describes multi-subdomain shape (N Bronze tables · `source_db_schema` · per-subdomain `load_query` / `query_path` UC volume) · `data_doc` card mentions per-subdomain `configs/<subdomain>/` walking · UI tier expanded to 4 tiles (Pipeline Studio · 🏠 Home Dashboard · 🗺 Lineage·Review·Run-All · 👥 Team filter) · footer label updated. Suite 12 (architecture-slide alignment) extended with 5 new checks that fail if any of these are reverted.
- ✏ **Editable spec preview · per-tab override** — every spec-producing tab (Ingestion · EDA · Data Prep · Document · custom pipelines) now has a `✏ Edit` button in the Generated Spec Preview header. Click it and the read-only `<pre>` swaps to a full textarea with an orange focus ring; tweak the spec freely; click `💾 Apply` (or hit `Ctrl+Enter`) to persist the override to `STATE._specOverrides[tab]` in localStorage. `buildSpec()` now returns the override if set, otherwise regenerates from the form. An amber `✎ EDITED` pill appears on the file-pill header when an override is active; click `↺ Reset` to discard the override and re-sync with the form. `✕ Cancel` (or `Esc`) discards in-flight edits without touching the saved override. Edits survive reload, sub-tab switches, and Run-All Stages (the saved spec ships verbatim).
- 🪟 **Render toggle on all 4 spec tabs** — the RAW / RENDERED preview toggle (previously only on Document Pipeline) now appears on Ingestion · EDA · Data Prep · Document. Switch to RENDERED to see your spec.md as it would render on GitHub/Confluence; switch back to RAW to copy the markdown source. Driven by a single `RENDER_TABS` constant so adding a new spec-producing tab in future just appends to that array.
- 📂 **Fix VS Code auto-launch · workspace absolute-path input** — root cause: the File System Access API only exposes the leaf folder name (`handle.name` → `df-pipeline-studio`), not the absolute filesystem path. So `vscode://file/<leaf>` was firing but VS Code couldn't resolve it, and the linked folder never actually opened on Generate / Run-All. **Fix**: a new "Workspace path" input appears under the **📁 Link project** button after a folder is linked; user pastes the absolute path once (`C:\Users\you\df-pipeline-studio` or `/home/you/df-pipeline-studio`), it persists in localStorage, and `launchAgent()` / `openVsCode()` use it to build proper `vscode://file/<absolute>` URLs (with path-aware encoding that preserves slashes). New `resolveAbsFolderPath()` helper centralises the lookup; new `vscodeUrlPath()` encodes each segment without mangling separators. First-time link triggers a `Tip:` toast prompting for the path; clear button (×) resets it.
- 🎯 **Run-All wizard · always-master invocation** — final Submit screen now ALWAYS emits the master orchestrator pattern (`#file:agents/data_pipeline_master.md` + every *attached* spec + `Run the full pipeline end-to-end`), regardless of how many phases the user saved vs. skipped. The master agent prompt was strengthened to explicitly handle partial spec sets: phases without an attached spec are reported as `NOT_ATTEMPTED` in the end-of-run summary rather than silently dropped. This replaces the earlier two-mode logic (master OR per-step chain) — one consistent invocation pattern that always reads correctly even when 1/2/3/4 specs are attached. Mode-header chip above the invocation pre block now shows `✓ Master invocation · 3 specs attached · 1 skipped (master marks NOT_ATTEMPTED)`. Per-step builder kept as legacy helper for back-compat.
- 📐 **Modal scroll fix · Submit button always reachable** — `.modal` now capped at `92vh` with `overflow-y:auto` so tall content (long spec previews + master invocations) scrolls internally instead of pushing the action row below the viewport. The `.modal > .modal-actions` row is now `position:sticky; bottom:-18px` with a fade-to-bg gradient so action buttons stay pinned at the bottom of the visible area, no matter how much scroll the body has.
- 🔄 **Model fallback chain in agent frontmatter** — every agent's primary `model: claude-sonnet-4` is now followed by a `fallback_models: ['claude-3.7-sonnet', 'claude-3.5-sonnet', 'gpt-5', 'gpt-4o', 'gpt-4.1', 'claude-3.5-haiku']` array. Frontmatter-aware tooling can walk the list if the primary is unavailable in the user's IDE/quota. Suite 2 enforces every agent declares the list.
- 🪪 **Agent YAML frontmatter for slash-command discoverability** — every agent file (`agents/*.md`) now opens with a YAML frontmatter block carrying `type: agent` + `name` + `description` + `phase` + `reads` + `writes` + `skills` + `model` + `tools`. Tools that scan agent prompts (Copilot Chat custom modes, Claude Code, Cursor) can now surface each agent in the `/` command menu with the right description and capability hints. Suite 2 enforces every agent has the frontmatter.
- 🧭 **Master orchestrator agent + one-click end-to-end Run-All** — added `agents/data_pipeline_master.md` that delegates to all 4 phase agents (`data_ingest` → `data_forge` → `data_prep` → `data_doc`) in strict dependency order. Document Pipeline now included in the E2E flow (`includeInE2E: true`). The Studio's footer **🧭 Run All Stages** wizard now ends with a single master invocation: `#file:agents/data_pipeline_master.md` + every saved spec + `"Run the full pipeline end-to-end"` — one paste in Copilot Chat produces every artifact under `output/` in one turn. The old per-step chained form is kept as a fallback via `e2eBuildPerStepInvocation()`.
- 🎯 **Data Prep source-mode panes · uniform sizing + interactive polish** — the 3 source-mode pane panels (Input Table · Consumer Header Query · Custom Extraction Query) now share `min-height:240px` so the form doesn't jump when the user switches modes. Each pane has a layered gradient background + slide-in fade animation (`@keyframes paneFadeIn`) + orange-tinted hover border. Radio pills stretch to equal height (`align-items:stretch`, `min-height:64px`) and lift 2px on hover with an orange glow. Textareas + inputs get a clean orange focus ring on tab/click. Full keyboard a11y via `:focus-visible`.
- 📁 **Folder rename · `dcs-pipeline-studio` → `df-pipeline-studio`** — folder rebrand. Hardcoded references updated in top README project-tree, `.github/apps/_monorepo-layout.md` (illustrative `$STUDIO` paths), and the studio's localStorage keys (`LS_KEY` + `SECT_LS_KEY` migrated from `dcs_*` → `df_*` prefix). A `migrateLegacyStorageKeys()` shim runs once on init to copy existing user drafts from the old keys to the new ones before `restoreState()` reads them — zero data loss for existing users. UC catalog names (`cert_dcs_catalog`, `prod_dcs_catalog`) are unchanged (different DCS — they're the Databricks Unity Catalog names).
- 🔁 **Full project sync · agents + skills + instructions + READMEs aligned** — top-to-bottom sweep after the v1.0 feature batch (multi-subdomain · source_db_schema · load_query · dashboard · sticky toolbar). Updated: `agents/data_ingest.md` + `agents/data_prep.md` + `agents/data_doc.md` (per-subdomain output contract · no more "and runner" language); `.github/skills/ingestion/{bronze_load,profiler,pipeline}/SKILL.md` (new keys `subdomain`, `source.db_schema`, `source.query_source`, `source.query_path`); `.github/skills/ingestion/pipeline/references/{spec.md.example,manifest.template.json}` (multi-subdomain shape from scratch); `.github/skills/ingestion/bronze_load/references/example.json` + `profiler/references/example.json` (new marker fields); `.github/skills/docs/pipeline_doc/SKILL.md` + `.github/skills/lineage/builder/SKILL.md` (walk `configs/<subdomain_slug>/`); `.github/copilot-instructions.md` (per-subdomain path contract, `runners/` removed from sub-layout, 460-test summary); `.github/instructions/databricks-standards.md` (notebook path lives under EDA only); top-level `README.md` (5 agents, 6 tabs, current ingestion tree, v1.0 feature list); `tools/README.md` (3 test suites, 460-test total); `output/README.md` (per-subdomain layout + 8 rules · no runners callout); `.github/apps/README.md` (6-stage data-prep); `docs/QUICKSTART.md` (ingestion path block + UX tip on toolbar/sections); fixed orphan typo in `specs/dataprep/consumer_master_prep/spec.md` and broken cross-link in `specs/docs/corebanking_dna/spec.md`.
- 🪟 **De-congestion · sticky stage toolbar + collapsible sections** — every form panel now has a sticky toolbar (stage icon · pipeline name echo · live validation badge · Expand-all/Collapse-all) and the long flat forms are split into collapsible `<details>` sections with auto-open-on-error, per-section status chips, and localStorage-persisted open/closed state:
  - 📥 **Ingestion** · 2 sections: `1. Source connection` · `2. Subdomains`
  - 🔬 **EDA** · 3 sections: `1. Project setup` · `2. Tables to analyze` · `3. Header query`
  - ⚙️ **Data Prep** · 3 sections: `1. Pipeline setup` · `2. Table columns` · `3. Source for Stage 1` (with PII banner pinned above)
  - Status chips render live progress per section: `4/4 fields`, `3 named · 2 with cols · 1 override`, `12 cols · 1 PK · 3 PII`, `header query · ready`, etc.
  - Error-to-section map auto-opens any section containing a validation blocker so it can't be missed
  - Document + Onboard tabs left as-is (already small)
- Pipeline registry (PIPELINES) drives tab nav, form rendering, output paths · adding a new tab is a registry entry
- Team-based tab visibility — Ingestion Team sees full lifecycle · Pre-Purposing Team sees their journey
- 🗺 **Lineage modal** — interactive Mermaid graph of the whole project · 5 phase filters · per-pipeline multi-select · column-level search · click any node for column inspector · "🤖 Generate docs" invokes data_lineage agent directly
- 👁 **Review modal** — recursive walker shows every artifact under output/ + specs/ with syntax-highlighted JSON and rendered markdown
- 🧭 **Run All Stages** wizard — stepper walks through Ingestion → EDA → Data Prep in order · launches VS Code with chained invocation
- 🧩 **Onboard tab** — runtime-extensible: teams create their own pipeline types without editing code · persists to localStorage
- Column classifier — semantic tagging (pk · pii · email · phone · address · datetime · money · etc.) drives expectations + transformations
- Spec generators per pipeline type · standardized wrappers (header · overview · runtime · governance · open items · footer)
- Auto-launch VS Code via `vscode://` URLs · folder linking via File System Access API

**JSON Studio** (`tools/json-studio.html`)
- Phase-1 rule composer: applied rules list · add-rule dropdown · inline parameter editing · raw JSON view
- Embeds the 38-rule catalog as a JS constant
- Reuses the same column classifier as the main studio

**Architecture slide** (`docs/data-factory-pipeline-architecture.html`)
- 4-tier swim-lane: Inputs → UI Layer → AI Agents → Deliverables
- Interactive master-detail pattern: click any agent card → details panel shows Reads/Writes/Spec/Agent
- Animated lifecycle strip with numbered ticks 1·2·3·4·5
- Fiserv-style brand logo (inline SVG + standalone `docs/architecture/fiserv-logo.svg`)

**Apps context** (`.github/apps/`) — monorepo Copilot integration
- Root `copilot-instructions.md` template
- Path-scoped `instructions.md` for each of 3 apps (data-ingestion · data-profiler · data-prep)
- Shared `glossary.md` of domain vocabulary
- Drop-in copy commands in `_monorepo-layout.md`

**Tests** (`tools/`)
- `studio-tests.py` — 15 suites · 99 tests covering column classification · spec generators · path helpers · expectations · transforms · E2E
- `json-studio-tests.py` — 13 suites · 99 tests covering rule composer logic
- `project-consistency-tests.py` — 16 suites · 306 tests covering cross-references · stale-feature detection · structural invariants · architecture-slide alignment · home-dashboard wiring · multi-subdomain ingestion form · source-db-schema + per-subdomain load_query · sticky toolbar + collapsible sections (Ingestion · EDA · Data Prep) · **doc/instruction freshness suite that flags stale counts, missing `<subdomain_slug>/` path segments, runner-notebook leftovers, and post-folder-rename LS_KEY drift**

**Documentation**
- `README.md` — project overview · tech stack · 4 quick references
- `docs/QUICKSTART.md` — 5-minute getting-started walkthrough
- `tools/README.md` — studio architecture · how to add a pipeline type
- `output/README.md` — output layout contract for agents
- `.github/copilot-instructions.md` — repo-wide Copilot context (~470 lines)
- `.github/rules/README.md` — rule resolution algorithm
- `.github/apps/README.md` — monorepo Copilot package overview

### Standardized

- All five agents follow the same output-path contract: `output/<phase>/<name>/{configs,reports,sql,notebooks}/`
- `data_doc` produces one of three distinctly-named files per mode (no overwrite risk):
  - `ingestion_info.md` (mode: ingest)
  - `dataprep_info.md` (mode: dataprep)
  - `runbook.md` (mode: runbook)
- Generate button color unified to Fiserv orange across all pipelines (per-tab accent only on indicator underline)
- Spec generators all use the same wrapper functions (specHeader · specOverviewBlock · specRuntimeBlock · specGovernanceBlock · specOpenItemsBlock · specFooter)

### Removed

- Runner notebook generation references (`output/<phase>/<name>/runners/` directory) — not part of current scope
- Artifact-detection card on Document tab (the Review modal supersedes it)
- Per-pipeline Generate button color (unified to orange)
- Original `🚀` rocket emoji (replaced with Fiserv-style inline SVG)
- 4-tab Document layout (now 3-mode picker · single tab)

### Validated

- 635 automated tests · 0 failures
- Cross-reference consistency validated: every agent referenced from `copilot-instructions.md` exists · every skill referenced from each agent.md exists · every reference doc exists
- No stale references to deprecated features
- Architecture HTML matches current framework state (5 agents · 38-rule catalog · lineage callout · per-mode doc filenames)

### Known limitations

- Drafts persist in browser `localStorage` — not synced across devices or users
- Custom pipelines created via Onboard tab live in YOUR localStorage — to share, commit `specs/<custom-phase>/<name>/spec.md` to the repo
- File System Access API requires Chrome / Edge (≥ 100) — Firefox / Safari fall back to download-only
- Studio uses ES2020 optional chaining (`?.`) — modern browsers only (internal tool)

---

## Versioning

- Format: `MAJOR.MINOR.PATCH`
- MAJOR — breaking changes to the agent prompts, spec format, or output paths
- MINOR — new agents / skills / studio features
- PATCH — bug fixes, doc tweaks, dead-code cleanup

Tag releases with `git tag v<version>`.

---

## How to report a bug

When filing an issue, include:
1. **Version**: see this CHANGELOG · use the most recent shipped tag
2. **Browser**: Chrome / Edge version (Studio UI bugs only)
3. **Steps to reproduce**: which tab, what you clicked, what you expected vs. what happened
4. **Test results**: paste output of `python tools/project-consistency-tests.py`
