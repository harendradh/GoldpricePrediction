# Quick Start — DCS Data Factory Pipeline Studio

> **5 minutes from zero to your first generated pipeline spec.**

---

## What this is

A spec-authoring tool that helps you describe a data pipeline in plain
English (via a form), then hands the spec to a GitHub Copilot agent that
produces the JSON profiles, manifest, validation report, and (optionally)
documentation + runbook automatically.

**You write specs.** **Agents write code.**

---

## Prerequisites

| Need | Why |
|------|-----|
| Chrome or Edge browser (v100+) | Studio uses File System Access API + optional chaining |
| VS Code with GitHub Copilot Chat extension (≥ Nov 2024) | To run the agents |
| Read/write access to your team's project folder | Studio writes `specs/<phase>/<name>/spec.md` into it |

---

## 5-step walkthrough

### 1 · Open the studio

```
Open this file in Chrome / Edge:
   tools/data-factory-pipeline-studio.html
```

(Drag-and-drop the file into the browser if double-click doesn't work.)

### 2 · Link your project folder

- Click **📁 Link project…** in the top-right
- Pick the folder that holds (or will hold) `specs/` and `output/`
- Grant read+write permission when prompted

### 3 · Pick your team

- In the **"Viewing as"** chip (top-right), pick the team you belong to:
  - **Ingestion Team** — sees the full lifecycle (Portfolio → Ingestion → EDA → Data Prep → Document → Onboard)
  - **Pre-Purposing Team** — sees their journey (Portfolio → Data Prep → Document → Onboard)
- The tab nav updates instantly to show only your team's stages

### 4 · Fill a pipeline form + generate

Pick the tab for the pipeline type you're building:

| Pipeline | Tab | What you fill |
|----------|-----|---------------|
| Source → Bronze | **📥 Ingestion Pipeline** | name · domain · source type · **source database & schema** (where to read) · catalog · schema (Bronze target) · 1-to-N subdomains (= Bronze table names), each with optional columns + optional load query / path |
| Tables → relationships + golden record | **🔬 EDA Analysis** | project · catalog · schema · tables + columns |
| Bronze/Header → Silver/Gold | **⚙️ Data Prep Pipeline** | name · subdomain · catalog · schema · columns · source mode (table / EDA query / custom SQL) |
| Generate docs for existing pipeline | **📋 Document Pipeline** | mode (ingest / dataprep / runbook) · pipeline name(s) |

Click **🚀 Generate \<phase\> Pipeline**. The studio:
1. Writes `specs/<phase>/<name>/spec.md` into your linked folder
2. Copies the Copilot invocation to your clipboard
3. Launches VS Code (if `Auto-launch` is on)

### 5 · Paste in Copilot Chat

In VS Code:
- Press `Ctrl + Alt + I` to open Copilot Chat
- Press `Ctrl + V` — your invocation pastes (looks like `#file:agents/data_ingest.md  #file:specs/.../spec.md\n\nRun data_ingest on my spec`)
- Press `Enter`

The agent reads the spec + its skill files and produces:
```
# EDA, Data Prep, Document: flat configs/
output/<phase>/<name>/configs/<stage>.json              (one per stage)
output/<phase>/<name>/configs/manifest.json             (orchestrator · depends_on chain)
output/<phase>/<name>/reports/validation_report.md

# Ingestion: per-subdomain configs (one dir per Bronze target table)
output/ingestion/<name>/configs/manifest.json           (chains all subdomains × 2 stages)
output/ingestion/<name>/configs/<subdomain>/bronze_load.json
output/ingestion/<name>/configs/<subdomain>/profiler.json
output/ingestion/<name>/reports/validation_report.md
```

Inspect what was created via the **👁 Review** button in the studio footer
or via the live **🏠 Home Dashboard** (KPI cards · pipeline-health table ·
activity feed) on the Portfolio tab.

> 💡 **UX tip** — every form panel has a sticky toolbar at the top (pipeline
> name · live validation badge · Expand/Collapse all) and is split into
> collapsible sections that auto-open when a validation error lands inside
> them. Your open/closed preference per section persists in localStorage.

---

## The 5 agents at a glance

| Agent | Stage | Reads | Writes |
|-------|------:|-------|--------|
| 📥 `data_ingest`  | 1 | JDBC / ADLS sources | `bronze_load.json` · `profiler.json` · `manifest.json` |
| 🔬 `data_forge`   | 2 | Bronze tables + schema | `consumer_header_query.sql` · ER diagram · profile report |
| ⚙️ `data_prep`    | 3 | Bronze + EDA SQL | 6 stage JSONs · KNL/Prep-Purp files |
| 📋 `data_doc`     | 4 | configs/ + manifest | `ingestion_info.md` / `dataprep_info.md` / `runbook.md` (per mode) |
| 🗺 `data_lineage` | ⊥ cross | every spec + manifest | `lineage.md` · `.mmd` · `column_index.md` · `impact_<col>.md` |

---

## Common workflows

### "I'm onboarding a brand-new source"
**Ingestion** tab → fill name/source/columns → Generate. Then **EDA** tab → fill tables → Generate. Then **Data Prep** → Generate. Then **Document Pipeline** → mode: `runbook` → Generate. The **🧭 Run All Stages** button in the footer walks you through it in order.

### "I want to see the whole-project data flow"
Click **🗺 Lineage** in the footer. It scans every spec + manifest and renders an interactive Mermaid diagram. Click any node to inspect its columns. Type a column name in the search box to find every pipeline that uses it.

### "I need a production runbook for my pipeline"
**Document Pipeline** tab → pick the **🏃 Production Runbook** mode → enter Data Prep pipeline name → Generate. Agent reads BOTH the ingestion + data-prep configs and emits a 16-section operational runbook.

### "Our team wants its own pipeline type that's not in the studio"
**🧩 Onboard New Pipeline** tab → fill name / domain / subdomain / description / columns → click "+ Create Pipeline Tab". A new tab appears with the standardized Data-Prep-style form, persists across reloads, and the agent picks it up via `agents/<id>.md`.

### "I need to audit what the agent actually wrote"
**👁 Review** in the footer → recursive file walker shows every artifact under your linked folder. JSON files render syntax-highlighted; markdown renders. Click ⟳ Refresh after the agent finishes.

---

## Troubleshooting

| Symptom | Fix |
|---------|-----|
| Pipeline tabs not visible | Pick your team in the "Viewing as" chip (Ingestion or Pre-Purposing) |
| Dropdown of existing pipelines is empty | Click the ⟳ button next to the input — re-scans the linked folder |
| Generated spec downloads instead of saving | You haven't linked the project folder (📁 button in header) |
| Copilot Chat doesn't auto-open | Toggle off "Auto-launch agent" in the footer and press Ctrl+Alt+I manually |
| Tests fail after editing the studio | `python tools/project-consistency-tests.py` shows what's drifted |

---

## What to share with your reviewer

> **DCS Data Factory Pipeline Studio v1.0**
>
> Spec-driven pipeline authoring backed by 5 specialized Copilot agents. Open `tools/data-factory-pipeline-studio.html` in Chrome, link your project folder, pick your team, fill a form, click Generate. Agent produces validated JSON + reports automatically.
>
> Full architecture: `docs/data-factory-pipeline-architecture.html`
> Detailed setup: `docs/QUICKSTART.md` (this file)
> Validation: `python tools/{studio,json-studio,project-consistency}-tests.py` → 635 tests · all pass

---

## Where to ask questions

- Bugs / feature requests → file an issue mentioning the studio version (see `CHANGELOG.md`)
- "How do I model X?" → check existing specs under `specs/<phase>/*/spec.md` for examples
- Agent producing weird output → run `python tools/project-consistency-tests.py` first to rule out drift

Happy spec-ing.
