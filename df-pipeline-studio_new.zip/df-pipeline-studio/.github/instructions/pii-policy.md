# PII Policy — Zero-False-Negative

## Principle

**When in doubt — flag it.** Missed PII is a GDPR violation risk.
A false positive (flagging something that isn't PII) costs a review.
A false negative (missing real PII) can cost millions in fines.

## 14 recognised PII types

| Type | Severity | Regulations | Standard masking |
|------|----------|------------|-----------------|
| `ssn` | CRITICAL | GDPR, CCPA, HIPAA | `CONCAT('***-**-', RIGHT(col, 4))` |
| `credit_card` | CRITICAL | PCI-DSS | `CONCAT('****-****-****-', RIGHT(col, 4))` |
| `bank_account` | CRITICAL | GDPR, PCI-DSS | `SHA2(col, 256)` |
| `passport` | CRITICAL | GDPR, CCPA | `SHA2(col, 256)` |
| `driving_license` | CRITICAL | GDPR, CCPA | `SHA2(col, 256)` |
| `biometric` | CRITICAL | GDPR, BIPA | `SHA2(col, 256)` |
| `medical_record` | CRITICAL | HIPAA | `SHA2(col, 256)` |
| `email` | HIGH | GDPR, CCPA, CAN-SPAM | `CONCAT(LEFT(col, 2), '***@', SPLIT(col, '@')[1])` |
| `phone` | HIGH | GDPR, CCPA, TCPA | `CONCAT('***-***-', RIGHT(col, 4))` |
| `dob` | HIGH | GDPR, CCPA, HIPAA | `DATE_TRUNC('year', col)` |
| `name` | HIGH | GDPR, CCPA | `CONCAT(LEFT(col, 1), '***')` |
| `address` | MEDIUM | GDPR, CCPA | `SHA2(col, 256)` |
| `ip_address` | MEDIUM | GDPR | `REGEXP_REPLACE(col, '\\d+$', '***')` |
| `national_id` | MEDIUM | Country-specific | `SHA2(col, 256)` |

## Retention periods (GDPR defaults)

| Data category | Max retention |
|--------------|--------------|
| Contact data (email, phone) | Duration of consent + 1 year |
| Transaction records | 7 years (financial regulation) |
| Health data | 10 years (HIPAA) |
| Employee records | Employment + 7 years |
| Marketing preferences | Until consent withdrawn |
| Audit logs | 2 years minimum |

## Governance actions required per severity

| Severity | Unity Catalog tag | Masking view | Row-level security | Retention policy |
|----------|------------------|-------------|-------------------|-----------------|
| CRITICAL | Required | Required | Recommended | Required |
| HIGH | Required | Required | Optional | Recommended |
| MEDIUM | Required | Recommended | Optional | Optional |
