# Spark SQL Performance Patterns

## When to Apply These Patterns

Apply these patterns whenever generating SQL that runs in Databricks. They are defaults — every generated query should follow them.

---

## 1. Adaptive Query Execution (AQE)

Always include AQE settings in notebook preamble or job configuration. AQE eliminates the need to manually tune `spark.sql.shuffle.partitions`.

```python
spark.conf.set("spark.sql.adaptive.enabled",                     "true")
spark.conf.set("spark.sql.adaptive.coalescePartitions.enabled",  "true")
spark.conf.set("spark.sql.shuffle.partitions",                   "auto")
```

---

## 2. Broadcast Join Hints

Apply `/*+ BROADCAST(alias) */` when joining small dimension tables (typically < 200 MB) to large fact tables. This avoids a full shuffle of the large table.

```sql
SELECT
    f.`order_id`,
    f.`total_amount`,
    d.`category_name`
FROM `catalog`.`schema`.`orders`         AS f
INNER JOIN `catalog`.`schema`.`categories` AS d  /*+ BROADCAST(d) */
    ON f.`category_id` = d.`category_id`
```

**Broadcast when:** dimension/lookup tables, tables on the "one" side of one-to-many joins, bridge tables.  
**Do NOT broadcast:** fact tables, tables with unknown row counts, tables > 200 MB.

---

## 3. APPROX_COUNT_DISTINCT vs COUNT(DISTINCT)

`COUNT(DISTINCT col)` is an exact but expensive operation requiring a full shuffle. Use the approximate version for profiling and analytics.

```sql
-- Profiling: use approximate (fast, within 2% accuracy)
APPROX_COUNT_DISTINCT(`customer_id`)  AS `approx_unique_customers`

-- Reporting where exactness matters: use exact
COUNT(DISTINCT `customer_id`)         AS `exact_unique_customers`
```

---

## 4. PERCENTILE_APPROX vs PERCENTILE

`PERCENTILE` (exact) is expensive on large datasets. `PERCENTILE_APPROX` uses the Greenwald-Khanna algorithm with configurable accuracy.

```sql
-- Preferred for profiling
PERCENTILE_APPROX(`amount`, 0.50)   AS `median_amount`,
PERCENTILE_APPROX(`amount`, 0.95)   AS `p95_amount`,

-- Array of percentiles in one pass (efficient)
PERCENTILE_APPROX(`amount`, ARRAY(0.25, 0.50, 0.75, 0.95, 0.99))  AS `percentiles`
```

---

## 5. CTE over Subquery

Always use CTEs for readability and plan optimization. Databricks can sometimes collapse CTEs into the physical plan more efficiently.

```sql
-- Correct: CTE
WITH base AS (
    SELECT `customer_id`, SUM(`amount`) AS `total`
    FROM `catalog`.`schema`.`orders`
    GROUP BY `customer_id`
),
ranked AS (
    SELECT *, RANK() OVER (ORDER BY `total` DESC) AS `rnk`
    FROM base
)
SELECT * FROM ranked WHERE `rnk` <= 10;

-- Avoid: nested subquery
SELECT * FROM (
    SELECT *, RANK() OVER (ORDER BY `total` DESC) AS `rnk`
    FROM (
        SELECT `customer_id`, SUM(`amount`) AS `total`
        FROM `catalog`.`schema`.`orders`
        GROUP BY `customer_id`
    )
) WHERE `rnk` <= 10;
```

---

## 6. Partition Pruning

Always filter on partition columns to avoid full table scans. If a Delta table is partitioned by `date` or `year_month`, include the partition column in every `WHERE` clause.

```sql
-- Good: partition pruning — Spark reads only the relevant partitions
SELECT *
FROM `catalog`.`schema`.`events`
WHERE `event_date` >= DATE_SUB(CURRENT_DATE(), 30)   -- partition column

-- Bad: no partition filter — full table scan on a multi-TB table
SELECT *
FROM `catalog`.`schema`.`events`
WHERE `user_id` = '12345'
```

---

## 7. Z-Order for Point Lookups

After large writes, `OPTIMIZE ... ZORDER BY` co-locates data by frequently filtered columns, reducing I/O for selective queries.

```sql
-- After loading/merging fact data
OPTIMIZE `catalog`.`schema`.`orders`
    ZORDER BY (`customer_id`, `order_date`);

-- Rule: Z-order on columns used in WHERE and JOIN ON clauses
-- Limit to 1–4 columns (diminishing returns beyond 4)
```

---

## 8. NULLIF for Safe Division

Never divide without protecting against zero denominators. Spark returns `null` (not an error) for division by null, which propagates cleanly.

```sql
-- Correct: null-safe division
ROUND(COUNT(`email`) * 100.0 / NULLIF(COUNT(*), 0), 2)  AS `email_fill_pct`

-- Avoid: can produce error or infinity if COUNT(*) = 0
COUNT(`email`) * 100.0 / COUNT(*)
```

---

## 9. Window Function Patterns

### ROW_NUMBER for deduplication
```sql
WITH ranked AS (
    SELECT *,
        ROW_NUMBER() OVER (
            PARTITION BY `customer_id`
            ORDER BY `updated_at` DESC NULLS LAST
        ) AS `rn`
    FROM `catalog`.`schema`.`customers_staged`
)
SELECT * FROM ranked WHERE `rn` = 1;
```

### FIRST_VALUE for survivorship
```sql
FIRST_VALUE(`email`) OVER (
    PARTITION BY `customer_id`
    ORDER BY CASE `source` WHEN 'crm' THEN 1 ELSE 2 END
) AS `email`
```

### Running total
```sql
SUM(`amount`) OVER (
    PARTITION BY `customer_id`
    ORDER BY `order_date`
    ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
) AS `cumulative_spend`
```

---

## 10. Delta Lake Write Optimization

```python
# Always set these for large writes
spark.conf.set("spark.databricks.delta.optimizeWrite.enabled", "true")
spark.conf.set("spark.databricks.delta.autoCompact.enabled",   "true")

# Append pattern (fact tables, audit logs)
df.write.format("delta").mode("append").saveAsTable("catalog.schema.table")

# Full overwrite (small dimension tables, daily snapshots)
df.write.format("delta").mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable("catalog.schema.table")

# MERGE (entity tables, golden records — never INSERT OVERWRITE)
# Use spark.sql("""MERGE INTO ...""")
```

---

## 11. Column Selection — Never SELECT *

Always name columns explicitly. This makes SQL readable, prevents schema-drift errors, and avoids pulling unnecessary columns over the network.

```sql
-- Correct
SELECT `customer_id`, `email`, `account_status`, `updated_at`
FROM `catalog`.`schema`.`customers`

-- Forbidden in generated SQL
SELECT * FROM `catalog`.`schema`.`customers`
```

---

## 12. COALESCE vs IF/CASE for Null Handling

```sql
-- Prefer COALESCE for null replacement
COALESCE(`middle_name`, '')   AS `middle_name`

-- Use CASE for conditional logic with multiple branches
CASE
    WHEN `balance` < 0      THEN 'Overdrawn'
    WHEN `balance` = 0      THEN 'Zero'
    WHEN `balance` < 10000  THEN 'Low'
    ELSE 'High'
END AS `balance_band`

-- Use IF for simple binary conditions
IF(`is_deleted` = 1, 'Deleted', 'Active')  AS `record_status`
```

---

## 13. COUNT_IF — Readable Conditional Counting

Prefer `COUNT_IF` over `SUM(CASE WHEN ...)` for boolean aggregations:

```sql
-- Preferred
COUNT_IF(`status` = 'ACTIVE')       AS `active_count`,
COUNT_IF(`amount` > 1000)           AS `high_value_orders`

-- Equivalent but less readable
SUM(CASE WHEN `status` = 'ACTIVE' THEN 1 ELSE 0 END)  AS `active_count`
```
