# Databricks Standards — data_forge Reference

## Unity Catalog

### Fully qualified table references

Always use three-part names. Never assume a default catalog or schema.

```sql
-- Correct
SELECT * FROM `main`.`gold`.`customers`

-- Avoid
SELECT * FROM customers           -- relies on session default
SELECT * FROM gold.customers      -- missing catalog
```

### Table creation standard

```sql
CREATE TABLE IF NOT EXISTS `{catalog}`.`{schema}`.`{table}`
(
    `{pk_col}`    STRING    NOT NULL,
    `{col1}`      STRING,
    `{col2}`      DECIMAL(18,2),
    `created_at`  TIMESTAMP NOT NULL,
    `updated_at`  TIMESTAMP NOT NULL
)
USING DELTA
PARTITIONED BY (`{partition_col}`)        -- omit if table < 100 GB
TBLPROPERTIES (
    'delta.enableChangeDataFeed'             = 'true',
    'delta.autoOptimize.optimizeWrite'       = 'true',
    'delta.autoOptimize.autoCompact'         = 'true',
    'quality'                                = 'gold',    -- bronze|silver|gold
    'layer'                                  = 'entity'   -- raw|staging|entity|mart
);
```

### Unity Catalog tags

Apply tags for governance, PII tracking, and data cataloging:

```sql
-- Table-level tags
ALTER TABLE `{catalog}`.`{schema}`.`{table}`
SET TAGS (
    'quality'        = 'gold',
    'domain'         = 'customer',
    'pii'            = 'true',
    'steward'        = '{team_name}',
    'refresh'        = 'daily'
);

-- Column-level tags (PII columns)
ALTER TABLE `{catalog}`.`{schema}`.`{table}`
    ALTER COLUMN `{column}`
    SET TAGS (
        'pii_type'     = '{pii_type}',
        'pii_severity' = '{severity}',
        'masking'      = '{masking_strategy}'
    );
```

### Column masking policies

Attach masking via Unity Catalog column masks (Databricks runtime 12.2+):

```sql
-- Create masking function
CREATE OR REPLACE FUNCTION `{catalog}`.`{schema}`.`mask_{column}`(col STRING)
    RETURNS STRING
    RETURN CASE
        WHEN IS_MEMBER('analytics_team') THEN col      -- full access for approved roles
        ELSE CONCAT(LEFT(col, 2), '***@', SPLIT(col, '@')[1])   -- masked for others
    END;

-- Attach to column
ALTER TABLE `{catalog}`.`{schema}`.`{table}`
    ALTER COLUMN `{column}`
    SET MASK `{catalog}`.`{schema}`.`mask_{column}`;
```

---

## Delta Lake

### Change Data Feed (CDF)

Enable CDF on all entity and golden record tables. This allows downstream consumers to process only changed rows.

```sql
TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true')
```

Read changes in a notebook:
```python
changes_df = (spark.read.format("delta")
    .option("readChangeFeed", "true")
    .option("startingVersion", last_processed_version)
    .table(f"{catalog}.{schema}.{table}"))
```

### OPTIMIZE and Z-Order

Run after every large batch load or MERGE operation:

```sql
-- Z-order on the columns most used in WHERE and JOIN ON
OPTIMIZE `{catalog}`.`{schema}`.`{table}`
    ZORDER BY (`{pk_col}`, `{date_col}`);

-- Z-order column guidelines:
-- 1–2 columns: good
-- 3–4 columns: acceptable
-- 5+ columns: diminishing returns — do not exceed 4
```

### VACUUM

Always retain at least 168 hours (7 days). This is the GDPR-safe minimum. It also keeps Time Travel working for a week.

```sql
-- Minimum: 168 hours (7 days)
VACUUM `{catalog}`.`{schema}`.`{table}` RETAIN 168 HOURS;

-- For GDPR audit tables: 720 hours (30 days)
VACUUM `{catalog}`.`{schema}`.`audit_log` RETAIN 720 HOURS;
```

Never run `VACUUM` with 0 hours — this deletes Time Travel history and cannot be undone.

### Liquid Clustering (Databricks runtime 13.3+)

For new tables that need flexible query acceleration without fixed partition columns:

```sql
CREATE TABLE `{catalog}`.`{schema}`.`{table}`
CLUSTER BY (`{col1}`, `{col2}`)   -- replaces PARTITIONED BY + ZORDER
USING DELTA;
```

Use liquid clustering for:
- Tables queried on many different column combinations
- Fact tables with complex filtering patterns
- Tables receiving continuous streaming writes

---

## Databricks Asset Bundle (DAB)

### Job definition pattern (`databricks.yml`)

```yaml
resources:
  jobs:
    {job_name}:
      name: "{Job Display Name}"
      schedule:
        quartz_cron_expression: "0 0 6 * * ?"   # 6 AM daily UTC
        timezone_id: "UTC"
        pause_status: UNPAUSED
      email_notifications:
        on_failure: ["${var.notification_email}"]
      tasks:
        - task_key: run_{skill}
          notebook_task:
            notebook_path: "output/eda/{pipeline}/notebooks/{notebook}.py"   # notebooks live under EDA phase only · other phases drive workflows from configs/manifest.json
            base_parameters:
              catalog: "${var.catalog}"
              schema:  "${var.schema}"
              table:   "${var.table}"
          existing_cluster_id: "${var.cluster_id}"
          timeout_seconds: 3600
          retry_on_timeout: true
          max_retries: 1
```

### Variables pattern

```yaml
variables:
  catalog:
    description: "Unity Catalog name"
    default: "main"
  schema:
    description: "Target schema"
    default: "gold"
  cluster_id:
    description: "Interactive cluster ID for dev; use job cluster in prod"
    default: ""
  notification_email:
    description: "Email for job failure alerts"
    default: ""
```

### Targets (environments)

```yaml
targets:
  dev:
    default: true
    mode: development      # enables run_as_jobs: false, no schedule enforcement
    workspace:
      host: "${workspace.host}"
  staging:
    mode: staging
  prod:
    mode: production
    workspace:
      host: "${workspace.host}"
```

---

## Secrets

Never hardcode credentials. Always use `dbutils.secrets.get()` in notebooks.

```python
# Correct
token = dbutils.secrets.get(scope="dataforge", key="api_token")

# Forbidden — never in generated notebooks
token = "dapi1234abc..."
```

Secrets in YAML (DAB jobs):
```yaml
spark_env_vars:
  API_TOKEN: "{{secrets/dataforge/api_token}}"
```

---

## Cluster Configuration Recommendations

### Job cluster (production)
```yaml
new_cluster:
  spark_version: "15.4.x-scala2.12"
  node_type_id: "Standard_DS3_v2"   # Azure; adjust for AWS/GCP
  num_workers: 2
  spark_conf:
    spark.sql.adaptive.enabled: "true"
    spark.sql.adaptive.coalescePartitions.enabled: "true"
    spark.databricks.delta.optimizeWrite.enabled: "true"
  azure_attributes:
    availability: SPOT_WITH_FALLBACK_AZURE   # cost optimization
    spot_bid_max_price: -1
```

### Photon acceleration

Enable for heavy SQL workloads (profiling, aggregations):
```yaml
spark_version: "15.4.x-photon-scala2.12"   # "-photon" suffix enables Photon
```

---

## Delta Live Tables (DLT)

For streaming DQ enforcement:

```python
import dlt

@dlt.table(
    comment="Validated {table} records",
    table_properties={"quality": "silver"}
)
@dlt.expect_or_drop("valid_pk",    "`{pk_col}` IS NOT NULL")
@dlt.expect_or_drop("valid_email", "`email` RLIKE '^[^@\\\\s]+@[^@\\\\s]+\\\\.[^@\\\\s]+$'")
@dlt.expect("positive_amount",     "`amount` >= 0")    # warn, don't drop
def validated_{table}():
    return spark.table("{catalog}.{schema}.{table}_raw")
```

### DLT expectation severity

| Decorator | Effect on violation |
|-----------|---------------------|
| `@dlt.expect` | Log; keep record |
| `@dlt.expect_or_drop` | Drop violating rows |
| `@dlt.expect_or_fail` | Fail the entire pipeline |

---

## Notebook Best Practices

1. **Always use widgets** — parameterize catalog, schema, table, date ranges
2. **Always display** with `display(df)` not `df.show()` — renders in Databricks UI
3. **Write magic SQL** with `%sql` cell for ad-hoc queries; use `spark.sql(...)` when building the SQL string programmatically
4. **Do not use `.collect()`** on large DataFrames — convert to Pandas with `.toPandas()` only after aggregating to a small result set (< 100K rows)
5. **Restart Python after `%pip install`** — `dbutils.library.restartPython()` is required for the install to take effect
6. **Use `dbutils.fs.ls()`** to verify paths before reading files
