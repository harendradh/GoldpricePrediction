# Rule Catalog

> **Declarative library of standard rules** that automatically apply to
> ingestion + data prep stage JSONs based on column names, classifier tags,
> and data types. Eliminates per-pipeline rule duplication.

---

## Why it exists

Before the rule catalog: every time a pipeline was created with a `cust_email`
column, the agent (or the user) had to remember to add an email-format regex,
a lowercase transformation, and a "warn if null rate > 5%" expectation.
Multiply by 100 pipelines × 50 columns each — too much room for drift.

After the rule catalog: every `email`-tagged column **automatically** gets the
email rule bundle. The agent looks up `column_match` for the column's tags +
name + type, finds matching rules, and emits their `transformations[]` and
`expectations[]` into the right stage JSON.

The rule is the contract. The agent is the executor. The catalog is the
single source of truth.

---

## File layout

```
.github/rules/
├── README.md                             this file
├── rule_schema.yaml                      the meta-schema · every rule conforms to it
├── catalog.yaml                          master index · rule_id → category file
└── categories/
    ├── identity.yaml                     PK / id detection + uniqueness
    ├── pii_masking.yaml                  ssn / tax_id / card / dob → mask
    ├── contact.yaml                      email + phone normalization & validation
    ├── name.yaml                         first/last/full name trim + case
    ├── address.yaml                      address line/city/state/postal/country
    ├── datetime.yaml                     cast + not_in_future + freshness
    ├── monetary.yaml                     amount/balance/price range checks
    ├── categorical.yaml                  status/code/type enums + cardinality
    ├── boolean.yaml                      is_*/has_* + Y/N normalization
    └── always_on.yaml                    row_count_min · schema_drift · freshness
```

---

## How the agent uses it

For every column in the spec, the agent performs **5 steps**:

1. **Classify** the column (tag it: `email`, `pii`, `money`, `datetime`, etc.)
   per the rules in `.github/copilot-instructions.md § 4`.
2. **Walk** `.github/rules/catalog.yaml` to enumerate all rules.
3. **Match** each rule's `column_match` block against the column:
   - `column_match.patterns` — regex(es) against the column name (case-insensitive)
   - `column_match.classifier_tags` — match if column has ANY of these tags
   - `column_match.data_types` — match only if column type is in this set (AND constraint)
   - Logic: `(any pattern matches OR any tag matches) AND (data_type passes if specified)`
4. **Apply** `schema_adjustments` if the column's nullability / type triggers any
   conditional clause.
5. **Emit** the rule's `emits.*` blocks into the corresponding stage JSON:
   - `emits.transformations[]` → appended to `preparation.json`
   - `emits.expectations[]` → appended to `extraction_profiler.json` or `profiler.json`
   - `emits.post_actions[]` → appended to `conversion.json` post_actions

Always-on rules (no `column_match` block) apply once per stage regardless of
columns — these are pipeline-level invariants (e.g., `row_count_min`).

---

## Rule structure (mandatory)

Every rule in every category file MUST follow `rule_schema.yaml`. The minimum
required fields:

```yaml
rule_id: contact_email_regex                     # globally unique snake_case
name: Email Format Regex
description: Validate email format with standard regex
category: contact
priority: 50                                     # 1-100 · lower = applied first
applicable_phases: [dataprep]                    # which phases this rule belongs to
applicable_stages: [extraction_profiler]         # which specific stages
column_match:                                    # WHEN it fires
  classifier_tags: [email]
  patterns: ['^email$', '_email$', '^email_']
  data_types: [STRING, VARCHAR]                  # optional AND constraint
emits:                                           # WHAT it contributes
  expectations:
    - rule: regex
      args: { pattern: '^[^@]+@[^@]+\.[^@]+$' }
      threshold: 0.95
      severity: HIGH
      action: warn_only
```

See `rule_schema.yaml` for the full specification.

---

## Adding a new rule

1. Pick the right category file under `categories/` (or create a new one).
2. Append your rule entry following `rule_schema.yaml`.
3. Add the entry to `catalog.yaml` (rule_id → category mapping).
4. Tests in `tools/studio-tests.py` should be extended if the rule introduces
   a new column-tag detection.

---

## When NOT to use the catalog

- Pipeline-specific business rules (e.g., "for customer_master, reject rows
  where account_status = 'PENDING' AND created_at > 30 days ago") — these
  live in the spec.md and the agent emits them inline.
- Source-system-specific quirks (e.g., "Oracle returns DATE as STRING here") —
  handled in `extraction.json` source.options.

The catalog is for **portable, reusable patterns** that should apply uniformly
across all pipelines.
