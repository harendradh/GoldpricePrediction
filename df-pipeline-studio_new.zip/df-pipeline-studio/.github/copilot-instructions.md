# GitHub Copilot Workspace Instructions — Data Factory Pipeline Studio

> 🚀 **Read this first.** It is the deterministic contract every Copilot Chat
> session in this workspace must follow. The **six** agents (4 sequential
> + 1 cross-cutting + 1 orchestrator), four phases, file system layout,
> naming conventions, and per-stage rules below are not suggestions — they
> are the contract.

---

## 1 · What this project is

**Data Factory Pipeline Studio** is a spec-driven · multi-agent · Databricks-native
pipeline-onboarding workbench.

**The contract is simple:**
- The **user** writes a spec (via `tools/data-factory-pipeline-studio.html` or by hand)
- The **spec** is the single input to the agent
- The **Copilot agent** reads the spec + the skill definitions under `.github/skills/`
  + the cross-skill standards under `.github/instructions/` — and produces **every
  artifact under `output/`** from scratch.

The studio writes **only** `specs/<phase>/<pipeline_name>/spec.md`. It never
writes to `output/`. Everything under `output/` exists because Copilot put it
there. This is a hard contract — never violate it.

The agents form a strict lifecycle (4 sequential + 1 cross-cutting):

```
📥 data_ingest  →  🔬 data_forge  →  ⚙️ data_prep  →  📋 data_doc
   ingest          EDA + relationships    standardize       document
                                                            🗺 data_lineage (runs on demand · whole-project view)
```

Each agent runs **after** the previous one has produced its outputs (or in
isolation, on demand). Each writes only into its own phase's output folder.
Skill modules live under `.github/skills/<phase>/<name>/` and are loaded
automatically by their owning agent.

---

## 2 · The six agents — at a glance

| Agent | Phase | Reads (input spec) | Writes (output dir) | Use when |
|-------|-------|--------------------|---------------------|----------|
| 📥 `agents/data_ingest.md` | `ingestion` | `specs/ingestion/<pipeline_name>/spec.md` | `output/ingestion/<pipeline_name>/{configs,reports}/` | A new feed needs to land in Bronze |
| 🔬 `agents/data_forge.md` | `eda`       | `specs/eda/<pipeline_name>/spec.md`       | `output/eda/<pipeline_name>/{notebooks,reports,sql}/`         | Profiling + relationships on tables already in Bronze |
| ⚙️ `agents/data_prep.md`   | `dataprep`  | `specs/dataprep/<pipeline_name>/spec.md`  | `output/dataprep/<pipeline_name>/{configs,reports}/`   | Standardize Bronze → Silver/Gold (6-stage chain) |
| 📋 `agents/data_doc.md`    | `docs`      | `specs/docs/<pipeline_name>/spec.md`      | `output/docs/<pipeline_name>/{ingestion_info,dataprep_info,runbook}.md` (per mode) | Document an existing pipeline's artifacts |
| 🗺 `agents/data_lineage.md` | `lineage` (cross-cutting) | `specs/lineage/<scope>/spec.md` | `output/lineage/<scope>/{lineage.md,lineage_diagram.mmd,column_index.md,impact_<col>.md}` | Whole-project DAG · column index · column impact analysis |
| 🧭 `agents/data_pipeline_master.md` | `orchestrator` (multi-phase) | All 4 phase specs attached together | Every phase agent's output dir (in dependency order) | One-paste end-to-end run · the Studio's 🧭 **Run All Stages** wizard emits this on Submit |

---

## 3 · File system contract · paths are deterministic

The Studio + tests enforce these path patterns. Agents must read/write only
from these locations — never the flat legacy layout, never invent new
folders.

### 3.1 Specs

```
specs/<phase>/<pipeline_name>/spec.md
```

| Phase     | Example |
|-----------|---------|
| ingestion | `specs/ingestion/consumer_master/spec.md` |
| eda       | `specs/eda/consumer_master/spec.md` |
| dataprep  | `specs/dataprep/consumer_master_prep/spec.md` |
| docs      | `specs/docs/consumer_master_prep/spec.md` |

### 3.2 Outputs · grouped by purpose

```
output/<phase>/<pipeline_name>/
├── configs/      ← all stage JSON contracts + manifest.json
├── reports/      ← validation reports, scorecards, ER diagrams, governance docs
├── sql/          ← standalone SQL artifacts (header query, UC tags)
└── notebooks/    ← analytical / dashboard notebooks (EDA only)
```

| Phase artifact | Path |
|---------------|------|
| Ingestion stage config (per subdomain) | `output/ingestion/<name>/configs/<subdomain_slug>/bronze_load.json` |
| Ingestion profiler (per subdomain) | `output/ingestion/<name>/configs/<subdomain_slug>/profiler.json` |
| Ingestion manifest (top-level · chains all subdomains × 2 stages) | `output/ingestion/<name>/configs/manifest.json` |
| Ingestion validation report | `output/ingestion/<name>/reports/validation_report.md` |
| Data prep stage configs | `output/dataprep/<name>/configs/{extraction,extraction_profiler,preparation,address_standardization,address_profiler,conversion}.json` |
| Data prep manifest | `output/dataprep/<name>/configs/manifest.json` |
| Data prep validation report | `output/dataprep/<name>/reports/validation_report.md` |
| EDA notebooks | `output/eda/<name>/notebooks/{01_analysis,02_dashboard}.py` |
| EDA consumer header query (bridge → data_prep) | `output/eda/<name>/sql/consumer_header_query.sql` |
| EDA UC tags | `output/eda/<name>/sql/unity_catalog_tags.sql` |
| EDA reports | `output/eda/<name>/reports/{schema_report,relationship_diagram,data_catalog,entity_mapping}.md` |
| Docs output | `output/docs/<name>/ingestion_info.md` · `dataprep_info.md` · `runbook.md` (per mode — distinctly named so all three can coexist) |

### 3.3 Skills (where Copilot loads behavior from)

```
.github/skills/<phase>/<name>/
├── SKILL.md                    ← the contract: required keys, validation rules
└── references/                 ← reference material the agent reads
    └── example.json            ← canonical JSON shape (stage skills only)
```

Every skill's ID is the **dotted form**: `<phase>.<name>`. Examples:
- `ingestion.bronze_load`
- `ingestion.profiler`
- `dataprep.extraction`
- `dataprep.extraction_profiler`
- `dataprep.preparation`
- `dataprep.address_standardization`
- `dataprep.address_profiler`
- `dataprep.conversion`
- `dataprep.pipeline` (orchestrator)
- `eda.schema_intelligence`, `eda.relationship_discovery`, `eda.sql_profiling`, `eda.entity_builder`, `eda.data_quality`, `eda.documentation`, `eda.notebook_generator`
- `docs.pipeline_doc`
- `lineage.builder`

The manifest's `stages[].skill` field uses this dotted form. The folder name
matches the part after the dot (snake_case · no numeric prefix · no dashes).

---

## 4 · Naming conventions

| Subject | Convention | Example |
|---------|-----------|---------|
| Pipeline name | snake_case · letters/digits/_ only | `consumer_master_prep` |
| Pipeline slug (used in paths) | `slugify(name)` — lowercase, non-alphanumeric → `_`, collapse `_+`, trim | `Consumer Master 2!` → `consumer_master_2` |
| Skill folder | snake_case · no prefix · no dashes | `bronze_load`, not `ing-01-bronze-load` |
| Skill ID (manifest) | dotted `<phase>.<name>` | `dataprep.extraction` |
| Stage ID (manifest) | snake_case · no numeric prefix | `bronze_load`, not `01_bronze_load` |
| Config filename | descriptive snake_case `.json` | `extraction.json`, not `01_extraction.json` |
| Output dataset | snake_case · matches `^[a-z][a-z0-9_]{1,62}$` | `customers_extracted` |
| Column name in spec | matches source verbatim (case + spelling) | `customer_id` |

**Never** revert to old naming patterns (`dp-XX-*`, `01_extraction.json`,
`output/ingest/` flat layout). The studio + 101-test suite will reject drift.

---

## 5 · How to invoke an agent (Copilot Chat)

Always attach **two files** as context: the agent + the spec for the
pipeline. Optionally attach a specific skill for narrow tasks.

```text
#file:agents/data_ingest.md  #file:specs/ingestion/<pipeline_name>/spec.md
Run data_ingest on my spec
```

```text
#file:agents/data_forge.md   #file:specs/eda/<pipeline_name>/spec.md
Run data_forge on my spec
```

```text
#file:agents/data_prep.md    #file:specs/dataprep/<pipeline_name>/spec.md
Run data_prep on my spec
```

```text
#file:agents/data_doc.md     #file:specs/docs/<pipeline_name>/spec.md
Run data_doc on my spec
```

```text
#file:agents/data_lineage.md #file:specs/lineage/<scope>/spec.md
Run data_lineage on my spec
```

```text
#file:agents/data_pipeline_master.md
#file:specs/ingestion/<name>/spec.md
#file:specs/eda/<name>/spec.md
#file:specs/dataprep/<name>/spec.md
#file:specs/docs/<name>/spec.md

Run the full pipeline end-to-end
```

The Studio (`tools/data-factory-pipeline-studio.html`) generates these exact
invocations and copies them to the clipboard — paste verbatim. The Lineage
modal in the studio footer auto-generates the lineage spec + launches the
single-phase invocation in one click. The 🧭 **Run All Stages** wizard in
the footer emits the **master** invocation (last block above) — attaching
only the specs the user actually saved; partial sets are handled by
`data_pipeline_master` as `NOT_ATTEMPTED` for skipped phases.

### 5.1 Per-task skill attachment

When the user asks for narrow work on one skill, also attach that skill:

| Task | Files to attach |
|------|-----------------|
| Schema intelligence + PII detection only | `agents/data_forge.md` + EDA spec + `.github/skills/eda/schema_intelligence/SKILL.md` |
| Find table relationships only | `agents/data_forge.md` + EDA spec + `.github/skills/eda/relationship_discovery/SKILL.md` |
| Generate analysis notebook only | `agents/data_forge.md` + EDA spec + `.github/skills/eda/notebook_generator/SKILL.md` |
| Build golden record (header query) | `agents/data_forge.md` + EDA spec + `.github/skills/eda/entity_builder/SKILL.md` |
| DQ assertions + scorecard only | `agents/data_forge.md` + EDA spec + `.github/skills/eda/data_quality/SKILL.md` |
| Data catalog only | `agents/data_forge.md` + EDA spec + `.github/skills/eda/documentation/SKILL.md` |
| Address standardization only | `agents/data_prep.md` + Data Prep spec + `.github/skills/dataprep/address_standardization/SKILL.md` |
| Single ingestion stage refinement | `agents/data_ingest.md` + Ingestion spec + `.github/skills/ingestion/<bronze_load|profiler>/SKILL.md` |
| Document an existing pipeline | `agents/data_doc.md` + Docs spec + (the manifests + stage JSONs you want documented) |

For full-pipeline runs (the common case), do **not** attach individual
skill files — the agent loads them automatically via the references inside
its own `agents/*.md`.

---

## 5.2 · Rule catalog (single source of truth for stage rules)

**Stop hand-rolling rules per pipeline.** The catalog at `.github/rules/`
declares every standard rule once — the agent looks up matches and emits them.

```
.github/rules/
├── README.md                          how the catalog works
├── rule_schema.yaml                   meta-schema every rule conforms to
├── catalog.yaml                       master rule_id → category index (38 rules)
└── categories/
    ├── identity.yaml                  PK / id rules (3)
    ├── pii_masking.yaml               ssn / tax_id / card / dob → mask + UC tag (7)
    ├── contact.yaml                   email + phone normalize & validate (5)
    ├── name.yaml                      trim, case-normalize name parts (2)
    ├── address.yaml                   line/city/state/postal/country + USPS hand-off (6)
    ├── datetime.yaml                  cast + not_in_future + freshness (3)
    ├── monetary.yaml                  amount range + balance bounds (2)
    ├── categorical.yaml               distinct count + status enums (2)
    ├── boolean.yaml                   in_set {true,false,Y,N,0,1} + normalize (2)
    └── always_on.yaml                 row_count_min · drift · freshness · audit · OPTIMIZE · VACUUM (6)
```

### Resolution algorithm (the agent MUST follow this exactly)

For each column in the parsed spec schema, do **5 steps**:

1. **Classify** the column per § 4 (tags: `email`, `pii`, `money`, `pk`, etc.)
2. **Walk** `.github/rules/catalog.yaml` to enumerate all 38 rules.
3. **Match each rule's `column_match`** against the column:
   - `column_match.patterns` → regex(es) tested against column name (case-insensitive)
   - `column_match.classifier_tags` → match if column has ANY of these tags
   - `column_match.data_types` → optional AND constraint (must match if present)
   - `column_match.exclude_patterns` → skip if column name matches any of these
   - **Match logic:** `( any pattern matches OR any tag matches ) AND ( type passes if data_types specified ) AND ( no exclude_pattern matches )`
4. **Apply `schema_adjustments`** if column nullability / type triggers a clause.
5. **Emit** the rule's `emits.*` blocks into the relevant stage JSON:
   - `emits.transformations[]` → appended to `preparation.json` `transformations[]`
   - `emits.expectations[]` → appended to `extraction_profiler.json` or `profiler.json` `expectations[]`
   - `emits.post_actions[]` → appended to `conversion.json` `post_actions[]`
   - Special blocks like `freshness:`, `drift_detection:`, `audit_columns:` fill named top-level keys in the stage JSON

**Always-on rules** (no `column_match` block) fire once per stage regardless
of columns — these are pipeline-level invariants (e.g., `row_count_min`,
`schema_drift`, `freshness`, `audit_columns`, `optimize`, `vacuum`).

### Placeholder substitution

Some rule `emits` blocks contain placeholders the agent fills at apply time:

| Placeholder | Substituted with |
|-------------|------------------|
| `{COLUMN}` | The matched column's name |
| `{LIST_OF_MATCHED_COLUMNS}` | Comma-separated list of all columns this rule fired on |
| `{AUTO_DETECTED}` | Agent's best guess (e.g., for `freshness.timestamp_column` it picks `updated_at` if present, else flags as `_meta.unresolved`) |

### Spec overrides

The user's `spec.md` may override rule arguments. Example: the spec contains
a `## Status Enums` section listing custom values — the agent merges these
into `categorical_status_in_set.emits.expectations[0].args.values` instead
of replacing.

When the spec disables an opt-in rule (e.g., `name_title_case` is
`default_enabled: false`), the agent omits it unless the spec explicitly
enables it.

---

## 6 · Spec → Agent flow (agent creates everything in output/)

When invoked, the agent does the following — in this order — for the
phase it owns:

1. **Read the spec** at `specs/<phase>/<pipeline_name>/spec.md`. This is the
   single source of intent.
2. **Read every skill's `SKILL.md` for the phase** at
   `.github/skills/<phase>/<name>/SKILL.md`. These define required keys,
   allowed enum values, and validation rules.
3. **Read each skill's `references/example.json`** (where present). This is
   the canonical shape every emitted JSON must match — key order, key
   names, nesting.
4. **Read the rule catalog** at `.github/rules/` — `catalog.yaml` indexes
   38 standard rules under `categories/*.yaml`. For each column in the spec
   schema, run the **5-step resolution algorithm in § 5.2** to discover which
   rules apply, then accumulate their `emits.*` blocks.
5. **Read the orchestrator's reference templates** at
   `.github/skills/<phase>/pipeline/references/{spec.md.example, manifest.template.json}`.
   These show the canonical manifest shape and spec format.
6. **Read the cross-skill standards** at `.github/instructions/`
   (SQL standards, PII policy, Spark patterns, Databricks standards).
   These apply to all generated SQL + notebooks regardless of phase.
7. **Create the artifacts** under `output/<phase>/<pipeline_name>/`. The
   set of artifacts is fixed per phase — see §10. Merge the rule-catalog
   `emits.*` outputs into the appropriate stage JSONs. Stage dependencies
   are declared explicitly in the manifest's `stages[*].depends_on`.

**The agent — not the studio — creates every file under `output/`.** The
studio's job ends after writing the spec. If `output/<phase>/<pipeline_name>/`
already exists from a prior agent run, the agent may treat the prior output
as a starting point and refine it. If it does not exist, the agent creates
the full directory tree fresh.

### What the agent must emit per phase

| Phase | Required artifacts (created by agent) |
|-------|----------------------------------------|
| `ingestion` | Per subdomain: 2 stage JSONs under `configs/<subdomain_slug>/` (`bronze_load.json` + `profiler.json`) · Top-level: `configs/manifest.json` (chains N × 2 stages with `depends_on` wiring) + `reports/validation_report.md` (per-subdomain pass/fail) |
| `eda` | `notebooks/01_analysis.py` + `notebooks/02_dashboard.py` + `reports/*.md` (schema_report, relationship_diagram, data_catalog, entity_mapping) + `sql/consumer_header_query.sql` + `sql/unity_catalog_tags.sql` |
| `dataprep` | 6 stage JSONs (`extraction.json`, `extraction_profiler.json`, `preparation.json`, `address_standardization.json`, `address_profiler.json`, `conversion.json`) + `manifest.json` (with full 6-stage `depends_on` chain) + `reports/validation_report.md` |
| `docs` | `ingestion_info.md` / `dataprep_info.md` (15 sections) · `runbook.md` (16 sections) — see §10 |

The manifest's `stages[*].depends_on` array MUST reflect actual data flow:
- ingestion (per subdomain): `<sub>_profiler` depends on `<sub>_bronze_load`. Subdomains are independent — no cross-subdomain edges.
- dataprep: `extraction_profiler` depends on `extraction`; `preparation` on `extraction_profiler`; `address_standardization` on `preparation`; `address_profiler` on `address_standardization`; `conversion` on `address_standardization` (or on `address_profiler` if profiler is enabled and conversion should run only after profiling clears)

When a stage is auto-skipped (e.g. `address_standardization` when no
address columns exist), its manifest entry MUST still appear with
`enabled: false` and a `skip_reason` — never silently omit a stage.

---

## 7 · Determinism rules (apply to every stage JSON)

1. **Match the canonical shape.** Every stage skill has
   `.github/skills/<phase>/<name>/references/example.json`. Output JSON keys
   must match its order and naming exactly.
2. **Never invent enum values.** When a field has an allowed set in
   `SKILL.md` (e.g. `source.type ∈ {s3, abfs, gcs, jdbc, rest_api, kafka, ...}`),
   only emit values from that set. If the spec asks for something not in
   the set, halt and ask the user.
3. **Every JSON ends with a `_meta` block**:
   ```json
   "_meta": {
     "stage": "<stage_id>",
     "pipeline": "<pipeline_name>",
     "generated_by": "data_ingest" | "data_prep" | "data_forge" | "data_doc" | "spec-console",
     "spec_section": "<which section of spec.md drove this>",
     "generated_at": "<ISO8601>",
     "unresolved": ["field.path.here", "..."]
   }
   ```
4. **Cross-stage chain must hold.** Stage N's `output_dataset` ≡ Stage N+1's
   `input_dataset`. The orchestrator skill enforces this — never break it.
5. **No placeholders in production fields.** If a value cannot be derived
   from the spec, set the field to `null` and add its dotted path to
   `_meta.unresolved`.
6. **Stage IDs in manifests** match the skill folder name (snake_case, no
   prefix). The `config_path` matches the on-disk filename.

---

## 8 · PII handling (zero-false-negative)

When in doubt, flag a column as PII. Every PII column must be either masked
or tagged in Unity Catalog.

**Auto-mask rules (data_prep stage 3 · preparation):**

| Tag | Mask method | Notes |
|-----|------------|-------|
| `gov_id` (ssn, tax_id, ein, sin, etc.) | `mask` `sha2_256` | Cannot be reversed |
| `financial_id` (card_num, iban, account_num, routing, etc.) | `mask` `sha2_256` | Or `last4` for analytics views |
| `doc_id` (passport, driver_lic, etc.) | `mask` `sha2_256` | |
| `dob` (date_of_birth) | `mask` `truncate_date` `precision: year` | Preserves age cohort |
| `email` (optional analytics view) | `email_partial` | `LEFT(2) + '***@' + domain` |
| `phone` (optional analytics view) | `phone_partial` | `'***-***-' + RIGHT(4)` |

**PII columns must also be:**
- Tagged via UC: `post_actions: [{type:'tag_uc', args:{tags:{data_class:'pii', pii_columns:[...]}}}]` in `conversion.json`
- Listed in `_meta.pii_columns_masked[]` of the stage that masks them
- Surfaced in the per-mode doc file (`ingestion_info.md` / `dataprep_info.md` / `runbook.md`) § PII section by data_doc

**Never:**
- Log PII column values in error messages or Spark stage prints
- Leave PII columns un-masked in Gold target unless the user explicitly opts out (in which case, add to `_meta.unresolved`)
- Emit raw PII into the EDA `consumer_header_query.sql` — use masking-view aliases instead

---

## 9 · SQL & Delta Lake code standards

Apply to all SQL generated in notebooks, header queries, masking views, and stage configs.

### SQL (Databricks Spark SQL)

- Always use CTEs — never nested subqueries
- Always backtick-quote identifiers: `` `customer_id` ``, `` `main`.`bronze`.`customers` ``
- Always explicit column list — never `SELECT *` (except in `extraction.json` source.query bootstrap, which a downstream agent will refine)
- Always `NULLIF(denominator, 0)` in division expressions
- `APPROX_COUNT_DISTINCT` for cardinality on large tables
- `PERCENTILE_APPROX` for median and quartiles
- `MERGE INTO` for upserts on entity tables — never `INSERT OVERWRITE`
- `/*+ BROADCAST(alias) */` on dimension-side joins
- Address regex: `RLIKE(\`email\`, '^[^@]+@[^@]+\\.[^@]+$')`

### Notebooks

- All SQL goes inside `# MAGIC %sql` cells
- Use `dbutils.widgets` for catalog, schema, run_id, table parameters
- Use `display(df)` — not `df.show()`
- Use `.toPandas()` only after aggregating to a small result set
- Stages load `manifest.json` from `output/<phase>/<name>/configs/manifest.json` (the agent's authoritative chain definition)

### Delta Lake

- `CREATE TABLE IF NOT EXISTS` with `USING DELTA`
- `TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true')` on entity tables
- `OPTIMIZE … ZORDER BY (pk_col, updated_ts)` after large writes
- `VACUUM … RETAIN 168 HOURS` minimum

---

## 10 · Per-phase quick reference

### 📥 Ingestion (data_ingest · 2 stages × N subdomains)

A pipeline declares **N subdomains** (= Bronze target tables) sharing one connection. Each subdomain contributes 2 stages, so the manifest chains **2N stages** under one `pipeline_name`.

| Stage | Skill | Config file (per subdomain) | Required keys |
|-------|-------|------------------------------|---------------|
| 1 | `ingestion.bronze_load` | `<subdomain_slug>/bronze_load.json` | `subdomain`, `source.{type, db_schema, query_source, query?, query_path?, path?, topic?, credentials_ref, options}`, `format`, `schema_mode`, `columns[]`, `target.{catalog,schema,table,location}`, `write_mode`, `output_dataset` |
| 2 | `ingestion.profiler` | `<subdomain_slug>/profiler.json` | `subdomain`, `input_dataset`, `bronze_table_fqn`, `profile_report_dataset`, `metrics[]`, `expectations[]`, `on_failure` |

- `source.db_schema` is the **READ-side qualifier** (`BANK.DBO` for JDBC, `raw/path/prefix` for ADLS) — shared across all subdomains, sourced from the spec's `source_db_schema:` field.
- `source.query_source ∈ {table, inline, file}` routes how the SQL is supplied: `table` → agent auto-generates `SELECT * FROM <db_schema>.<subdomain>`; `inline` → use embedded `source.query`; `file` → load SQL from `source.query_path` (UC volume `/Volumes/...`, DBFS, ADLS) at runtime.
- `subdomain` marker on each JSON MUST equal its `configs/<subdomain_slug>/` directory name AND its sibling stage's `subdomain`.
- Profiler is **skipped (enabled:false)** per subdomain if no `columns[]` is provided for that subdomain in the spec.
- Audit columns include `_subdomain` so downstream readers can attribute every row.

### 🔬 EDA (data_forge · skill-driven, no fixed stage count)

Skills run together (or individually on request). Produces notebooks, reports, SQL, and the bridge header query.

| Output | Skill responsible |
|--------|-------------------|
| `notebooks/01_analysis.py` | `eda.notebook_generator` |
| `notebooks/02_dashboard.py` | `eda.notebook_generator` |
| `reports/schema_report.md` | `eda.schema_intelligence` |
| `reports/relationship_diagram.md` (Mermaid ER) | `eda.relationship_discovery` |
| `sql/consumer_header_query.sql` (**bridge → data_prep**) | `eda.entity_builder` + `eda.relationship_discovery` |
| `sql/unity_catalog_tags.sql` | `eda.schema_intelligence` |
| `reports/data_catalog.md` | `eda.documentation` |
| `reports/entity_mapping.md` | `eda.entity_builder` |

### ⚙️ Data Prep (data_prep · 6 stages, fixed order)

| # | Stage ID | Skill | Config file |
|---|----------|-------|-------------|
| 1 | `extraction` | `dataprep.extraction` | `extraction.json` |
| 2 | `extraction_profiler` | `dataprep.extraction_profiler` | `extraction_profiler.json` |
| 3 | `preparation` | `dataprep.preparation` | `preparation.json` |
| 4 | `address_standardization` | `dataprep.address_standardization` | `address_standardization.json` |
| 5 | `address_profiler` | `dataprep.address_profiler` | `address_profiler.json` |
| 6 | `conversion` | `dataprep.conversion` | `conversion.json` |

Stage 4 auto-disables (`enabled:false` + `skip_reason`) if the input columns
contain no address fields (detected by the classifier via `street`/`city`/
`state`/`postal`/`country` tags).

Stage 1 source mode is one of `table` | `header_query` | `extract_query`:
- `table`: `source.query = "SELECT * FROM <cat>.<sch>.<t_extract_in>"`
- `header_query`: `source.query` ≡ EDA's `consumer_header_query.sql`, `_meta.source_kind = "header_query"`
- `extract_query`: user-supplied custom SELECT, `_meta.source_kind = "extract_query"`

### 📋 Documentation (data_doc)

Reads existing manifests + stage JSONs and produces a per-mode doc file at
`output/docs/<pipeline_name>/<ingestion_info|dataprep_info|runbook>.md`.
Single-pipeline modes (`ingest`, `dataprep`) → 15 sections in order:
Header · Overview · Source · Target · Pipeline stages · Schema contract ·
Data Quality / Profiler · Transformations · Address standardization ·
PII / sensitive columns · Lineage · How to run · File index · Open items ·
Document metadata (YAML).

Idempotent — re-running produces an identical file modulo `generated_at`.

---

## 11 · What never to do

- ❌ Never write to `output/` outside the `<phase>/<pipeline_name>/{configs,reports,sql,notebooks}/` sub-layout (runner notebooks were removed — `manifest.json` is the orchestrator)
- ❌ Never re-introduce numeric prefixes in stage IDs, config filenames, or `_meta.stage` values (`01_bronze_load` is wrong; `bronze_load` is right)
- ❌ Never use the legacy `dp-XX-*` / `ing-XX-*` slug naming
- ❌ Never reference `skills/...` without the `.github/` prefix
- ❌ Never invent enum values not in the relevant `SKILL.md`
- ❌ Never rewrite a JSON value that is not in `_meta.unresolved`
- ❌ Never emit raw PII into SQL outputs unless the user explicitly opts out
- ❌ Never break the cross-stage dataset chain (Stage N output ≡ Stage N+1 input)
- ❌ Never delete `_meta` blocks — they are the audit trail
- ❌ Never assume default values for `catalog`, `schema`, `pipeline_name` — read them from the spec

---

## 12 · Validation

Before announcing completion, the agent MUST:

1. Re-read every JSON it wrote/touched
2. Confirm every required key per the relevant `SKILL.md` is present
3. Confirm the dataset chain across stages
4. List every `_meta.unresolved[]` entry across all files
5. Write `output/<phase>/<pipeline_name>/reports/validation_report.md` with per-stage pass/unresolved status
6. End-of-run summary includes the validation report path + open-item count

The repo runs three Python test suites (all must pass · 0 failures):

- `python tools/studio-tests.py` — 15 suites · 99 tests · main studio logic (column classifier, parser, path helpers, spec generators, bootstrap patterns)
- `python tools/json-studio-tests.py` — 13 suites · 99 tests · JSON Studio rule composer logic
- `python tools/project-consistency-tests.py` — 16 suites · 432 tests · cross-reference + structural + drift-detection checks (catches things like stale `runners/` references, mismatched test counts in READMEs, missing `<subdomain_slug>/` path segments, etc.)

**Total: 630 tests across 44 suites · 0 failures required.**

---

## 13 · One-line operational checklist

> Before responding to any pipeline-related prompt:
> 1. Read the spec at `specs/<phase>/<pipeline_name>/spec.md`
> 2. Read existing skeleton JSONs at `output/<phase>/<pipeline_name>/configs/`
> 3. Read the relevant skill's `SKILL.md` + `references/example.json`
> 4. Fill `_meta.unresolved` gaps · preserve everything else
> 5. Write validation report · summarize open items
