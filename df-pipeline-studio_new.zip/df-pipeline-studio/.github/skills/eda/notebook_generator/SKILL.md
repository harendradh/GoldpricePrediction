# Skill: Notebook Generator

```
skill:    eda.notebook_generator
version:  3.0
trigger:  "notebook", "dashboard", "visualization", "run"
outputs:  output/eda/{pipeline_name}/notebooks/01_analysis.py
          output/eda/{pipeline_name}/notebooks/02_dashboard.py
```

---

## Purpose

Generate two production-ready Databricks notebooks with **all SQL embedded inline**.
The user opens them in Databricks, sets the catalog/schema widgets, and runs all cells.
No other scripts or files needed.

---

## `01_analysis.py` — Complete Analysis Notebook

This notebook covers everything: profiling, DQ, relationships, and golden-record SQL.
Cells are separated by `# COMMAND ----------`.

Use **real column names from spec.md** in every SQL statement — never placeholder names.

---

### Cell structure

#### Cell 1 — Notebook header

```python
# Databricks notebook source
# MAGIC %md
# MAGIC # {Project Name} — data_forge Analysis
# MAGIC **Tables:** {table_1}, {table_2}, ...  |  **Domain:** {domain}
# MAGIC
# MAGIC Run all cells top-to-bottom. Set catalog/schema widgets before running.
```

---

#### Cell 2 — Widgets

```python
# COMMAND ----------
dbutils.widgets.text("catalog", "{catalog_from_spec}", "Unity Catalog")
dbutils.widgets.text("schema",  "{schema_from_spec}",  "Schema")

catalog = dbutils.widgets.get("catalog")
schema  = dbutils.widgets.get("schema")
print(f"Target: {catalog}.{schema}")
```

---

#### Cell 3 — Spark config

```python
# COMMAND ----------
spark.conf.set("spark.sql.adaptive.enabled",                    "true")
spark.conf.set("spark.sql.adaptive.coalescePartitions.enabled", "true")
print(f"Spark {spark.version} — AQE enabled")
```

---

#### Cells 4-N — One section per table (repeat for each table in spec)

For each table, generate the following cells in order:

**Section header:**
```python
# COMMAND ----------
# MAGIC %md
# MAGIC ---
# MAGIC ## Table: `{table_name}`
```

**Table overview:**
```python
# COMMAND ----------
# MAGIC %sql
# MAGIC -- ── TABLE OVERVIEW ────────────────────────────────────────────────────────
# MAGIC SELECT
# MAGIC     COUNT(*)                                       AS `total_rows`,
# MAGIC     COUNT(DISTINCT `{pk_col}`)                     AS `distinct_{pk_col}`,
# MAGIC     COUNT(*) - COUNT(DISTINCT `{pk_col}`)          AS `duplicate_count`,
# MAGIC     MIN(`{date_col}`)                              AS `earliest_record`,
# MAGIC     MAX(`{date_col}`)                              AS `latest_record`,
# MAGIC     DATEDIFF(MAX(`{date_col}`), MIN(`{date_col}`)) AS `date_span_days`,
# MAGIC     COUNT_IF(`{date_col}` >= DATE_SUB(CURRENT_DATE(), 30)) AS `rows_last_30d`
# MAGIC FROM `${catalog}`.`${schema}`.`{table_name}`;
```

**Fill rates** (one expression per column, all real column names):
```python
# COMMAND ----------
# MAGIC %sql
# MAGIC -- ── FILL RATES ────────────────────────────────────────────────────────────
# MAGIC SELECT
# MAGIC     COUNT(*) AS `total_rows`,
# MAGIC     ROUND(COUNT(`{col_1}`) * 100.0 / NULLIF(COUNT(*), 0), 2) AS `{col_1}_pct`,
# MAGIC     ROUND(COUNT(`{col_2}`) * 100.0 / NULLIF(COUNT(*), 0), 2) AS `{col_2}_pct`,
# MAGIC     ROUND(COUNT(`{col_3}`) * 100.0 / NULLIF(COUNT(*), 0), 2) AS `{col_3}_pct`
# MAGIC     -- one line per column
# MAGIC FROM `${catalog}`.`${schema}`.`{table_name}`;
```

**Column profile** (UNION ALL, one block per column with appropriate stat):
```python
# COMMAND ----------
# MAGIC %sql
# MAGIC -- ── COLUMN PROFILE ────────────────────────────────────────────────────────
# MAGIC SELECT '{col}' AS `column_name`, 'string' AS `type`,
# MAGIC   COUNT(`{col}`) AS `non_null`, COUNT(*)-COUNT(`{col}`) AS `nulls`,
# MAGIC   ROUND(COUNT(`{col}`)*100.0/NULLIF(COUNT(*),0),2) AS `fill_pct`,
# MAGIC   APPROX_COUNT_DISTINCT(`{col}`) AS `distinct_count`,
# MAGIC   MIN(LENGTH(`{col}`)) AS `min_len`, MAX(LENGTH(`{col}`)) AS `max_len`,
# MAGIC   NULL AS `min_val`, NULL AS `max_val`, NULL AS `mean`, NULL AS `stddev`
# MAGIC FROM `${catalog}`.`${schema}`.`{table_name}`
# MAGIC UNION ALL
# MAGIC -- numeric columns: swap in MIN/MAX/AVG/STDDEV instead of length
# MAGIC SELECT '{num_col}' AS `column_name`, 'numeric' AS `type`,
# MAGIC   COUNT(`{num_col}`) AS `non_null`, COUNT(*)-COUNT(`{num_col}`) AS `nulls`,
# MAGIC   ROUND(COUNT(`{num_col}`)*100.0/NULLIF(COUNT(*),0),2) AS `fill_pct`,
# MAGIC   APPROX_COUNT_DISTINCT(`{num_col}`) AS `distinct_count`,
# MAGIC   NULL AS `min_len`, NULL AS `max_len`,
# MAGIC   CAST(MIN(`{num_col}`) AS STRING) AS `min_val`,
# MAGIC   CAST(MAX(`{num_col}`) AS STRING) AS `max_val`,
# MAGIC   ROUND(AVG(`{num_col}`),4) AS `mean`, ROUND(STDDEV(`{num_col}`),4) AS `stddev`
# MAGIC FROM `${catalog}`.`${schema}`.`{table_name}`
# MAGIC ORDER BY `fill_pct` ASC;
```

**Top values** (for low-cardinality columns like status, category, country):
```python
# COMMAND ----------
# MAGIC %sql
# MAGIC -- ── TOP VALUES: {low_cardinality_col} ─────────────────────────────────────
# MAGIC SELECT
# MAGIC     CAST(`{low_cardinality_col}` AS STRING)                         AS `value`,
# MAGIC     COUNT(*)                                                         AS `count`,
# MAGIC     ROUND(COUNT(*)*100.0/NULLIF(SUM(COUNT(*)) OVER(),0),2)          AS `pct`
# MAGIC FROM `${catalog}`.`${schema}`.`{table_name}`
# MAGIC WHERE `{low_cardinality_col}` IS NOT NULL
# MAGIC GROUP BY `{low_cardinality_col}`
# MAGIC ORDER BY `count` DESC LIMIT 20;
```

**Numeric distribution** (only for numeric columns that matter — amounts, scores):
```python
# COMMAND ----------
# MAGIC %sql
# MAGIC -- ── DISTRIBUTION: {numeric_col} ───────────────────────────────────────────
# MAGIC SELECT
# MAGIC     ROUND(PERCENTILE_APPROX(`{numeric_col}`, 0.0),  2) AS `min`,
# MAGIC     ROUND(PERCENTILE_APPROX(`{numeric_col}`, 0.25), 2) AS `p25`,
# MAGIC     ROUND(PERCENTILE_APPROX(`{numeric_col}`, 0.50), 2) AS `median`,
# MAGIC     ROUND(PERCENTILE_APPROX(`{numeric_col}`, 0.75), 2) AS `p75`,
# MAGIC     ROUND(PERCENTILE_APPROX(`{numeric_col}`, 0.95), 2) AS `p95`,
# MAGIC     ROUND(PERCENTILE_APPROX(`{numeric_col}`, 1.0),  2) AS `max`,
# MAGIC     ROUND(AVG(`{numeric_col}`), 4)                      AS `mean`,
# MAGIC     ROUND(STDDEV(`{numeric_col}`), 4)                   AS `stddev`
# MAGIC FROM `${catalog}`.`${schema}`.`{table_name}`
# MAGIC WHERE `{numeric_col}` IS NOT NULL;
```

**Monthly trend** (only if table has a date/timestamp column):
```python
# COMMAND ----------
# MAGIC %sql
# MAGIC -- ── MONTHLY TREND ─────────────────────────────────────────────────────────
# MAGIC SELECT
# MAGIC     DATE_TRUNC('month', `{date_col}`)  AS `month`,
# MAGIC     COUNT(*)                            AS `row_count`,
# MAGIC     COUNT(DISTINCT `{pk_col}`)          AS `distinct_{pk_col}`
# MAGIC     {, SUM(`{metric_col}`) AS `total_{metric_col}`}  -- add if metric col exists
# MAGIC FROM `${catalog}`.`${schema}`.`{table_name}`
# MAGIC WHERE `{date_col}` >= DATE_SUB(CURRENT_DATE(), 365)
# MAGIC GROUP BY DATE_TRUNC('month', `{date_col}`)
# MAGIC ORDER BY `month`;
```

**DQ assertions** (from data-quality SKILL.md — one UNION ALL per rule):
```python
# COMMAND ----------
# MAGIC %md ### Data Quality Assertions — {table_name}
# COMMAND ----------
# MAGIC %sql
# MAGIC -- ── DQ ASSERTIONS ─────────────────────────────────────────────────────────
# MAGIC [full DQ assertions SQL from data-quality SKILL.md Step 2, using real columns]
```

**DQ scorecard**:
```python
# COMMAND ----------
# MAGIC %sql
# MAGIC -- ── DQ SCORECARD ──────────────────────────────────────────────────────────
# MAGIC [full DQ scorecard SQL from data-quality SKILL.md Step 3, using real columns]
```

---

#### Relationship JOIN section (after all tables)

```python
# COMMAND ----------
# MAGIC %md
# MAGIC ---
# MAGIC ## Relationships & JOIN SQL
```

For each detected relationship, one cell:
```python
# COMMAND ----------
# MAGIC %sql
# MAGIC -- ── JOIN: {table_a} → {table_b} (confidence: {level}) ────────────────────
# MAGIC SELECT
# MAGIC     a.`{pk_a}`,
# MAGIC     a.`{col_a1}`, a.`{col_a2}`,
# MAGIC     b.`{col_b1}`, b.`{col_b2}`
# MAGIC FROM `${catalog}`.`${schema}`.`{table_a}` AS a
# MAGIC INNER JOIN `${catalog}`.`${schema}`.`{table_b}` AS b  /*+ BROADCAST(b) */
# MAGIC     ON a.`{fk_col}` = b.`{pk_b}`
# MAGIC LIMIT 100;
```

Full join chain across all tables:
```python
# COMMAND ----------
# MAGIC %sql
# MAGIC -- ── FULL JOIN CHAIN ───────────────────────────────────────────────────────
# MAGIC SELECT
# MAGIC     {all relevant columns from all tables, fully qualified}
# MAGIC FROM `${catalog}`.`${schema}`.`{fact_table}` AS fact
# MAGIC INNER JOIN `${catalog}`.`${schema}`.`{dim_1}` AS d1  /*+ BROADCAST(d1) */
# MAGIC     ON fact.`{fk1}` = d1.`{pk1}`
# MAGIC LEFT JOIN  `${catalog}`.`${schema}`.`{dim_2}` AS d2  /*+ BROADCAST(d2) */
# MAGIC     ON fact.`{fk2}` = d2.`{pk2}`
# MAGIC LIMIT 1000;
```

---

#### Golden record section (if entity builder applies)

```python
# COMMAND ----------
# MAGIC %md
# MAGIC ---
# MAGIC ## Golden Record — {entity_name}
```

```python
# COMMAND ----------
# MAGIC %sql
# MAGIC -- ── CREATE MASTER TABLE ───────────────────────────────────────────────────
# MAGIC CREATE TABLE IF NOT EXISTS `${catalog}`.`${schema}`.`{entity}_master`
# MAGIC (
# MAGIC     `{entity_id}`   STRING NOT NULL,
# MAGIC     `first_name`    STRING,
# MAGIC     `last_name`     STRING,
# MAGIC     `email`         STRING,
# MAGIC     `phone`         STRING,
# MAGIC     -- all golden record columns from spec
# MAGIC     `source_systems`  ARRAY<STRING>,
# MAGIC     `record_version`  BIGINT DEFAULT 1,
# MAGIC     `created_at`      TIMESTAMP,
# MAGIC     `updated_at`      TIMESTAMP
# MAGIC )
# MAGIC USING DELTA
# MAGIC TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true');
```

```python
# COMMAND ----------
# MAGIC %sql
# MAGIC -- ── MERGE INTO GOLDEN RECORD ──────────────────────────────────────────────
# MAGIC [full survivorship CTE + MERGE INTO from entity-builder SKILL.md,
# MAGIC  using real table names and columns from spec]
```

---

#### Final cell — Write profiling results

```python
# COMMAND ----------
# MAGIC %md ---
# MAGIC ## Save Results
# COMMAND ----------
from pyspark.sql import functions as F

# Re-run the column profile query and persist
profile_df = spark.sql("""[column profile UNION ALL SQL]""")

(profile_df
    .withColumn("source_table", F.lit("{table_name}"))
    .withColumn("profiled_at",  F.current_timestamp())
    .write
    .format("delta")
    .mode("append")
    .option("mergeSchema", "true")
    .saveAsTable(f"{catalog}.{schema}.dataforge_profiling_results"))

print("Profiling results saved.")
```

---

## `02_dashboard.py` — Plotly Dashboard Notebook

### Cell 1 — Header
```python
# Databricks notebook source
# MAGIC %md
# MAGIC # {Project Name} — data_forge Dashboard
# MAGIC Interactive Plotly charts. Run after `01_analysis.py`.
```

### Cell 2 — Imports and widgets
```python
# COMMAND ----------
import plotly.express       as px
import plotly.graph_objects as go
from plotly.subplots        import make_subplots
import pandas               as pd

dbutils.widgets.text("catalog", "{catalog_from_spec}")
dbutils.widgets.text("schema",  "{schema_from_spec}")
catalog = dbutils.widgets.get("catalog")
schema  = dbutils.widgets.get("schema")
```

### Cell 3 — Fill rate bar chart
```python
# COMMAND ----------
# MAGIC %md ### Fill Rate by Column
# COMMAND ----------
fill_pdf = spark.sql(f"""
    SELECT
        '{col_1}' AS column_name, ROUND(COUNT(`{col_1}`) * 100.0 / COUNT(*), 1) AS fill_pct
    FROM `{catalog}`.`{schema}`.`{table_name}`
    UNION ALL
    SELECT '{col_2}', ROUND(COUNT(`{col_2}`) * 100.0 / COUNT(*), 1)
    FROM `{catalog}`.`{schema}`.`{table_name}`
    -- one row per column, using real column names from spec
""").toPandas()

fig = px.bar(
    fill_pdf.sort_values("fill_pct"),
    x="fill_pct", y="column_name", orientation="h",
    title="Fill Rate by Column — {table_name}",
    color="fill_pct",
    color_continuous_scale=["#d73027","#fdae61","#1a9850"],
    range_x=[0, 100]
)
fig.add_vline(x=95, line_dash="dash", line_color="green",  annotation_text="95%")
fig.add_vline(x=80, line_dash="dash", line_color="orange", annotation_text="80%")
fig.update_layout(showlegend=False, height=max(400, len(fill_pdf)*22))
fig.show()
```

### Cell 4 — DQ scorecard gauges
```python
# COMMAND ----------
# MAGIC %md ### Data Quality Scorecard
# COMMAND ----------
# Pull scorecard scores from the DQ scorecard SQL (re-run or read from saved results)
scores = spark.sql(f"""
    [DQ scorecard SQL from 01_analysis.py — same SQL, real column names]
""").collect()[0]

fig = make_subplots(rows=1, cols=4, specs=[[{"type":"indicator"}]*4],
    subplot_titles=["Completeness","Uniqueness","Validity","Freshness"])

for col_idx, (label, value) in enumerate([
    ("Completeness", scores.completeness_score),
    ("Uniqueness",   scores.uniqueness_score),
    ("Validity",     scores.validity_score),
    ("Freshness",    scores.freshness_score)
], 1):
    color = "#1a9850" if value >= 90 else "#fdae61" if value >= 75 else "#d73027"
    fig.add_trace(go.Indicator(
        mode="gauge+number", value=value,
        gauge={"axis":{"range":[0,100]}, "bar":{"color":color}}
    ), row=1, col=col_idx)

fig.update_layout(title="{table_name} — DQ Scorecard", height=300)
fig.show()
```

### Cell 5 — Monthly trend line chart
```python
# COMMAND ----------
# MAGIC %md ### Volume Trend
# COMMAND ----------
trend_pdf = spark.sql(f"""
    SELECT DATE_TRUNC('month', `{date_col}`) AS month, COUNT(*) AS row_count
    FROM `{catalog}`.`{schema}`.`{table_name}`
    WHERE `{date_col}` >= DATE_SUB(CURRENT_DATE(), 365)
    GROUP BY DATE_TRUNC('month', `{date_col}`)
    ORDER BY month
""").toPandas()

fig = px.line(trend_pdf, x="month", y="row_count",
              title="Monthly Record Volume — {table_name}", markers=True,
              labels={"row_count":"Records","month":"Month"})
fig.show()
```

### Cell 6 — PII risk map (generate only if PII columns detected)
```python
# COMMAND ----------
# MAGIC %md ### PII Risk Map
# COMMAND ----------
pii_data = pd.DataFrame([
    # One row per PII column — use real column names from spec
    {"table": "{table}", "column": "{pii_col}", "pii_type": "{type}", "severity": "{sev}"},
    # ... one row per PII column detected across all tables
])

if not pii_data.empty:
    fig = px.scatter(pii_data, x="table", y="column", color="severity", symbol="pii_type",
        color_discrete_map={"CRITICAL":"#d73027","HIGH":"#fc8d59","MEDIUM":"#fee090"},
        title="PII Column Risk Map",
        labels={"table":"Table","column":"Column","severity":"Severity"})
    fig.update_traces(marker_size=14)
    fig.show()
```

---

## Output location

```
output/
└── notebooks/
    ├── 01_analysis.py    ← Upload to Databricks and run all cells
    └── 02_dashboard.py   ← Run after 01_analysis.py
```

Upload to Databricks workspace (Databricks CLI):
```
databricks workspace import output/eda/{pipeline_name}/notebooks/01_analysis.py /Shared/dataforge/01_analysis.py
databricks workspace import output/eda/{pipeline_name}/notebooks/02_dashboard.py /Shared/dataforge/02_dashboard.py
```

---

## Reference files

- `references/databricks-patterns.md` — cell patterns, widget usage, Plotly color scales
