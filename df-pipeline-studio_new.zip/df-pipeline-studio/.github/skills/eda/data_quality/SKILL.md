# Skill: Data Quality

```
skill:    eda.data_quality
version:  3.0
trigger:  "DQ", "data quality", "assertions", "scorecard", "validate"
outputs:  embedded in output/eda/{pipeline_name}/notebooks/01_analysis.py (Section 3)
```

---

## Purpose

Generate business-meaningful SQL DQ assertions and a 4-dimension scorecard,
embedded directly in the analysis notebook. No external libraries required —
everything runs as plain Spark SQL cells in Databricks.

---

## Step 1 — Assign rules per column

For every column, determine applicable rules based on its semantic class:

| Semantic class | Rules to apply |
|---------------|----------------|
| `key` (PK) | NOT NULL + UNIQUE |
| `key` (FK) | NOT NULL |
| `contact` → email | Format regex: `^[^@]+@[^@]+\.[^@]+$` |
| `contact` → phone | Length after stripping non-digits: BETWEEN 7 AND 15 |
| `financial` → amount | `>= 0` (or allow negatives for balance columns) |
| `date` → created_at | NOT NULL + `<= current_timestamp()` |
| `date` → expiry | Must be after created_at if both exist |
| `transaction` → status | IN (enumerate values from spec) |
| `metric` | Within reasonable range (infer from name) |

---

## Step 2 — DQ assertions SQL block

Embed this as one SQL cell in `01_analysis.py` Section 3.
Generate one `UNION ALL` block per rule. Use **real column names** from spec.

```sql
-- ═══ DQ ASSERTIONS: `{catalog}`.`{schema}`.`{table}` ═══
SELECT * FROM (

  -- [pk_col] NOT NULL (completeness — critical)
  SELECT
    'completeness_{pk_col}'                       AS `rule_id`,
    '{pk_col}'                                    AS `column_name`,
    'completeness'                                AS `dimension`,
    'Primary key must not be null'                AS `description`,
    'CRITICAL'                                    AS `severity`,
    SUM(CASE WHEN `{pk_col}` IS NULL THEN 1 ELSE 0 END)  AS `violation_count`,
    COUNT(*)                                      AS `total_rows`,
    ROUND(COUNT(`{pk_col}`) * 100.0 / NULLIF(COUNT(*), 0), 2) AS `pass_rate_pct`
  FROM `{catalog}`.`{schema}`.`{table}`

  UNION ALL

  -- [pk_col] UNIQUE (uniqueness — critical)
  SELECT
    'uniqueness_{pk_col}', '{pk_col}', 'uniqueness',
    'Primary key must be unique', 'CRITICAL',
    COUNT(*) - COUNT(DISTINCT `{pk_col}`), COUNT(*),
    ROUND(COUNT(DISTINCT `{pk_col}`) * 100.0 / NULLIF(COUNT(*), 0), 2)
  FROM `{catalog}`.`{schema}`.`{table}`

  UNION ALL

  -- email format (validity — high) — add only if email column exists
  SELECT
    'validity_email_format', 'email', 'validity',
    'Email must match standard format', 'HIGH',
    SUM(CASE WHEN NOT RLIKE(`email`, '^[^@]+@[^@]+\\.[^@]+$') THEN 1 ELSE 0 END),
    COUNT(*),
    ROUND(SUM(CASE WHEN RLIKE(`email`, '^[^@]+@[^@]+\\.[^@]+$') THEN 1 ELSE 0 END) * 100.0
          / NULLIF(COUNT(*), 0), 2)
  FROM `{catalog}`.`{schema}`.`{table}`
  WHERE `email` IS NOT NULL

  UNION ALL

  -- status enumeration (validity — high) — add only if status-like column exists
  SELECT
    'validity_{status_col}_values', '{status_col}', 'validity',
    'Status must be in allowed set', 'HIGH',
    SUM(CASE WHEN `{status_col}` NOT IN ('{val1}', '{val2}', '{val3}') THEN 1 ELSE 0 END),
    COUNT(*),
    ROUND(SUM(CASE WHEN `{status_col}` IN ('{val1}', '{val2}', '{val3}') THEN 1 ELSE 0 END) * 100.0
          / NULLIF(COUNT(*), 0), 2)
  FROM `{catalog}`.`{schema}`.`{table}`
  WHERE `{status_col}` IS NOT NULL

  UNION ALL

  -- amount non-negative (validity — high) — add only for amount/price/balance columns
  SELECT
    'validity_{amount_col}_non_negative', '{amount_col}', 'validity',
    'Amount must be >= 0', 'HIGH',
    SUM(CASE WHEN `{amount_col}` < 0 THEN 1 ELSE 0 END), COUNT(*),
    ROUND(SUM(CASE WHEN `{amount_col}` >= 0 THEN 1 ELSE 0 END) * 100.0
          / NULLIF(COUNT(*), 0), 2)
  FROM `{catalog}`.`{schema}`.`{table}`
  WHERE `{amount_col}` IS NOT NULL

  UNION ALL

  -- date not in future (validity — warn) — add for created_at, order_date etc.
  SELECT
    'validity_{date_col}_not_future', '{date_col}', 'validity',
    'Date must not be in the future', 'WARN',
    SUM(CASE WHEN `{date_col}` > CURRENT_TIMESTAMP() THEN 1 ELSE 0 END), COUNT(*),
    ROUND(SUM(CASE WHEN `{date_col}` <= CURRENT_TIMESTAMP() THEN 1 ELSE 0 END) * 100.0
          / NULLIF(COUNT(*), 0), 2)
  FROM `{catalog}`.`{schema}`.`{table}`
  WHERE `{date_col}` IS NOT NULL

  -- add more UNION ALL blocks as needed for additional columns

)
ORDER BY
  CASE `severity` WHEN 'CRITICAL' THEN 1 WHEN 'HIGH' THEN 2 WHEN 'WARN' THEN 3 ELSE 4 END,
  `pass_rate_pct` ASC;
```

---

## Step 3 — DQ Scorecard SQL block

Embed immediately after the assertions block. One scorecard per table.

```sql
-- ═══ DQ SCORECARD: `{catalog}`.`{schema}`.`{table}` ═══
-- Weighted: completeness 35% | uniqueness 30% | validity 25% | freshness 10%
WITH metrics AS (
  SELECT
    COUNT(*)                                                          AS `total_rows`,
    COUNT(`{pk_col}`)                                                 AS `non_null_pk`,
    COUNT(DISTINCT `{pk_col}`)                                        AS `unique_pk`,
    COUNT(`{required_col}`)                                           AS `non_null_required`,
    SUM(CASE WHEN RLIKE(`email`, '^[^@]+@[^@]+\\.[^@]+$') THEN 1 ELSE 0 END) AS `valid_emails`,
    COUNT_IF(`{amount_col}` >= 0)                                     AS `non_negative_amounts`,
    MAX(`{date_col}`)                                                 AS `latest_record`
  FROM `{catalog}`.`{schema}`.`{table}`
)
SELECT
  '{table}'                                                           AS `table_name`,
  `total_rows`,
  ROUND(`non_null_pk`       * 100.0 / NULLIF(`total_rows`, 0), 1)   AS `completeness_score`,
  ROUND(`unique_pk`         * 100.0 / NULLIF(`total_rows`, 0), 1)   AS `uniqueness_score`,
  ROUND(`valid_emails`      * 100.0 / NULLIF(`total_rows`, 0), 1)   AS `validity_score`,
  CASE
    WHEN DATEDIFF(CURRENT_DATE(), DATE(`latest_record`)) <= 1  THEN 100.0
    WHEN DATEDIFF(CURRENT_DATE(), DATE(`latest_record`)) <= 7  THEN 80.0
    WHEN DATEDIFF(CURRENT_DATE(), DATE(`latest_record`)) <= 30 THEN 50.0
    ELSE 20.0
  END                                                                 AS `freshness_score`,
  ROUND(
    (`non_null_pk`   * 100.0 / NULLIF(`total_rows`, 0)) * 0.35 +
    (`unique_pk`     * 100.0 / NULLIF(`total_rows`, 0)) * 0.30 +
    (`valid_emails`  * 100.0 / NULLIF(`total_rows`, 0)) * 0.25 +
    CASE
      WHEN DATEDIFF(CURRENT_DATE(), DATE(`latest_record`)) <= 1  THEN 100.0
      WHEN DATEDIFF(CURRENT_DATE(), DATE(`latest_record`)) <= 7  THEN  80.0
      ELSE 50.0
    END * 0.10,
  1)                                                                  AS `overall_dq_score`,
  CURRENT_TIMESTAMP()                                                 AS `scored_at`
FROM metrics;
```

---

## DQ score interpretation

| Score | Grade | Action |
|-------|-------|--------|
| 90–100 | Excellent | Safe for production |
| 75–89 | Good | Monitor; fix medium issues |
| 60–74 | Fair | Fix high-severity issues first |
| < 60 | Poor | Block from downstream use |

---

## Reference files

- `references/dq-dimensions.md` — full dimension definitions and thresholds
