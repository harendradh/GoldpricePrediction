# Data Quality Dimensions — Definitions and Thresholds

## The 4 DQ Dimensions

data_forge scores every table across four dimensions. The weighted average produces the overall DQ score (0–100).

| Dimension | Weight | What it measures |
|-----------|--------|-----------------|
| Completeness | 35% | Are required fields populated? |
| Uniqueness | 30% | Are records free of duplicates? |
| Validity | 25% | Do values conform to business rules? |
| Freshness | 10% | Is data up to date? |

---

## Dimension 1: Completeness (35%)

**Definition:** The percentage of required or important columns that have non-null values.

**Score formula:**
```
completeness_score = AVG(fill_rate) across all required columns × 100
```

**Thresholds:**

| Score | Grade | Action |
|-------|-------|--------|
| 95–100 | PASS | None |
| 85–94 | WARN | Investigate nulls |
| 70–84 | FAIL | Data source issue |
| < 70 | CRITICAL | Block downstream use |

**Assertion SQL pattern:**
```sql
SELECT
    'completeness'                                                   AS `dimension`,
    '{column}_not_null'                                              AS `rule_name`,
    'CRITICAL'                                                       AS `severity`,
    COUNT_IF(`{column}` IS NULL)                                     AS `violation_count`,
    ROUND(COUNT_IF(`{column}` IS NULL) * 100.0 / NULLIF(COUNT(*), 0), 2) AS `violation_pct`,
    ROUND(100 - COUNT_IF(`{column}` IS NULL) * 100.0 / NULLIF(COUNT(*), 0), 2) AS `pass_rate_pct`
FROM `{catalog}`.`{schema}`.`{table}`
```

**Required vs optional heuristic:**
- Columns in the PRIMARY KEY → always required
- Columns ending in `_id`, `_date`, `_status` → treat as required
- Contact columns (email, phone) → required if semantic class = `contact`
- All other columns → optional (warn if fill < 80%)

---

## Dimension 2: Uniqueness (30%)

**Definition:** The percentage of rows that do not duplicate on the primary key or business key.

**Score formula:**
```
uniqueness_score = COUNT(DISTINCT pk) / COUNT(*) × 100
```

**For compound uniqueness** (e.g., unique on order_id + line_number):
```
uniqueness_score = COUNT(DISTINCT CONCAT(col1, '|', col2)) / COUNT(*) × 100
```

**Thresholds:**

| Score | Grade | Action |
|-------|-------|--------|
| 100 | PASS | None |
| 99–99.9 | WARN | Small number of duplicates; investigate source |
| 95–98.9 | FAIL | Systematic duplication; ETL or merge bug |
| < 95 | CRITICAL | Do not use for golden record or reporting |

**Assertion SQL pattern:**
```sql
SELECT
    'uniqueness'                                                     AS `dimension`,
    '{pk}_is_unique'                                                 AS `rule_name`,
    'CRITICAL'                                                       AS `severity`,
    COUNT(*) - COUNT(DISTINCT `{pk}`)                                AS `violation_count`,
    ROUND((COUNT(*) - COUNT(DISTINCT `{pk}`)) * 100.0 / NULLIF(COUNT(*), 0), 2) AS `violation_pct`,
    ROUND(COUNT(DISTINCT `{pk}`) * 100.0 / NULLIF(COUNT(*), 0), 2)  AS `pass_rate_pct`
FROM `{catalog}`.`{schema}`.`{table}`
```

---

## Dimension 3: Validity (25%)

**Definition:** The percentage of values that conform to their expected format, range, or enumeration.

**Score formula:**
```
validity_score = AVG(pass_rate) across all validity rules × 100
```

**Thresholds:**

| Score | Grade | Action |
|-------|-------|--------|
| 98–100 | PASS | None |
| 90–97 | WARN | Review source data |
| 75–89 | FAIL | Source mapping error |
| < 75 | CRITICAL | Reject data |

### Validity Rule Library

#### Email format
```sql
COUNT_IF(`email` NOT REGEXP '^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$') AS `invalid_email_count`
```

#### Phone format (digits only, 7–15 chars after stripping)
```sql
COUNT_IF(LENGTH(REGEXP_REPLACE(`phone`, '[^0-9]', '')) NOT BETWEEN 7 AND 15) AS `invalid_phone_count`
```

#### Positive amounts
```sql
COUNT_IF(CAST(`amount` AS DOUBLE) < 0) AS `negative_amount_count`
```

#### Status enumeration
```sql
COUNT_IF(`status` NOT IN ('ACTIVE', 'INACTIVE', 'PENDING', 'SUSPENDED')) AS `invalid_status_count`
```

#### Date range (not in the future, not before 1900)
```sql
COUNT_IF(`{date_col}` > CURRENT_TIMESTAMP() OR `{date_col}` < '1900-01-01') AS `invalid_date_count`
```

#### Date of birth sanity (age 0–120)
```sql
COUNT_IF(DATEDIFF(CURRENT_DATE(), CAST(`date_of_birth` AS DATE)) NOT BETWEEN 0 AND 43800) AS `invalid_dob_count`
```

#### Non-negative percentage (0–100)
```sql
COUNT_IF(CAST(`{pct_col}` AS DOUBLE) NOT BETWEEN 0 AND 100) AS `invalid_pct_count`
```

#### Referential integrity (FK exists in parent table)
```sql
COUNT_IF(fk.`{parent_id}` IS NULL) AS `orphan_fk_count`
-- From a LEFT JOIN against the parent table
```

#### ISO country code (2-char)
```sql
COUNT_IF(LENGTH(`country_code`) != 2 OR `country_code` != UPPER(`country_code`)) AS `invalid_country_count`
```

#### Currency code (3-char ISO 4217)
```sql
COUNT_IF(LENGTH(`currency_code`) != 3 OR `currency_code` != UPPER(`currency_code`)) AS `invalid_currency_count`
```

---

## Dimension 4: Freshness (10%)

**Definition:** How recently the data was updated relative to its expected refresh cadence.

**Score formula:**
```
hours_since_update = DATEDIFF(CURRENT_TIMESTAMP(), MAX(updated_at)) × 24
freshness_score = GREATEST(0, 100 - (hours_since_update / expected_refresh_hours × 100))
```

**Thresholds by expected cadence:**

| Cadence | Expected hours | WARN threshold | FAIL threshold |
|---------|---------------|----------------|----------------|
| Real-time | 1 h | > 2 h | > 6 h |
| Hourly | 1 h | > 3 h | > 12 h |
| Daily | 24 h | > 36 h | > 72 h |
| Weekly | 168 h | > 200 h | > 336 h |

**Assertion SQL pattern:**
```sql
SELECT
    'freshness'                                                      AS `dimension`,
    '{table}_freshness'                                              AS `rule_name`,
    'WARN'                                                           AS `severity`,
    DATEDIFF(CURRENT_TIMESTAMP(), MAX(`updated_at`)) * 24           AS `hours_since_update`,
    CASE
        WHEN DATEDIFF(CURRENT_TIMESTAMP(), MAX(`updated_at`)) * 24 <= 36  THEN 'PASS'
        WHEN DATEDIFF(CURRENT_TIMESTAMP(), MAX(`updated_at`)) * 24 <= 72  THEN 'WARN'
        ELSE 'FAIL'
    END                                                              AS `freshness_grade`
FROM `{catalog}`.`{schema}`.`{table}`
```

---

## Overall DQ Score Calculation

```sql
WITH dimension_scores AS (
    SELECT
        ROUND({completeness_score}, 1)  AS `completeness`,
        ROUND({uniqueness_score},   1)  AS `uniqueness`,
        ROUND({validity_score},     1)  AS `validity`,
        ROUND({freshness_score},    1)  AS `freshness`
)
SELECT
    `completeness`,
    `uniqueness`,
    `validity`,
    `freshness`,
    ROUND(
        `completeness` * 0.35
      + `uniqueness`   * 0.30
      + `validity`     * 0.25
      + `freshness`    * 0.10,
    1) AS `overall_dq_score`,
    CASE
        WHEN `completeness` * 0.35 + `uniqueness` * 0.30
           + `validity`     * 0.25 + `freshness`  * 0.10 >= 90 THEN 'EXCELLENT'
        WHEN `completeness` * 0.35 + `uniqueness` * 0.30
           + `validity`     * 0.25 + `freshness`  * 0.10 >= 75 THEN 'GOOD'
        WHEN `completeness` * 0.35 + `uniqueness` * 0.30
           + `validity`     * 0.25 + `freshness`  * 0.10 >= 60 THEN 'FAIR'
        ELSE 'POOR'
    END AS `dq_grade`
FROM dimension_scores;
```

**Score interpretation:**

| Score | Grade | Meaning |
|-------|-------|---------|
| 90–100 | EXCELLENT | Production-ready; safe for analytics and ML |
| 75–89 | GOOD | Minor issues; usable with awareness |
| 60–74 | FAIR | Data quality issues; use with caution |
| < 60 | POOR | Block from production use; fix at source |

---

## Rule Severity Levels

| Severity | Meaning | Action |
|----------|---------|--------|
| CRITICAL | Record should be rejected; key constraint violated | Block pipeline; alert immediately |
| HIGH | Serious issue affecting data integrity | Alert; quarantine affected records |
| WARN | Anomaly worth investigating | Log; do not block pipeline |
| INFO | Informational metric | Log only |
