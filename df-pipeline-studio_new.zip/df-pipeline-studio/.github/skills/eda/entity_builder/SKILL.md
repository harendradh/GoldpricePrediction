# Skill: Entity Builder (Golden Record)

```
skill:    eda.entity_builder
version:  2.0
trigger:  "golden record", "master data", "entity", "merge sources", "deduplicate", "single view"
outputs:  output/eda/{pipeline_name}/reports/entity_mapping.md, output/eda/{pipeline_name}/sql/[entity_name]_suite.sql
```

---

## Purpose

Build a "golden record" — one authoritative version of the core entity —
by merging multiple source tables, applying survivorship rules, and generating
a complete Delta Lake MERGE INTO pipeline.

Works for any domain entity: customer, patient, employee, policy, product, claim.

---

## Step-by-step instructions

### Step 1 — Identify the entity

From spec.md, determine:
- **Entity name** — stated in spec.md OR infer from domain (customer/patient/employee/policy)
- **Primary key column** — stated OR the most likely unique identifier column
- **Source tables** — all tables that contribute data to the golden record
- **Source priority** — stated in spec.md OR infer: more complete / official source = higher priority

If spec.md doesn't state priority, rank sources:
1. Tables with more columns → higher priority (more data = more authoritative)
2. Tables with government ID columns → highest priority
3. Tables named `core_*`, `master_*`, `crm_*` → higher priority than `web_*`, `digital_*`, `legacy_*`

### Step 2 — Design the canonical schema

Identify which canonical fields exist across the source tables.
Group by category and assign the best source for each:

#### Template canonical schema (adapt to detected domain)

**Identity fields:** first_name, last_name, full_name, date_of_birth, gender
**Contact fields:** primary_email, primary_phone, secondary_phone, newsletter_opt_in
**Address fields:** address_line1, address_line2, city, state, zip_code, country
**Government ID fields:** ssn, passport_number, driving_license, tax_id
**Domain-specific fields:** [whatever is unique to the detected domain]
**Governance fields:** _source_systems (ARRAY), _confidence_score (DOUBLE), _golden_source (STRING), _last_updated (TIMESTAMP), _is_deleted (BOOLEAN)

For each canonical field:
- Which source table provides the best value?
- Which survivorship rule applies?

### Step 3 — Assign survivorship rules

| Canonical field type | Rule | SQL expression |
|---------------------|------|---------------|
| Primary key / government ID | SOURCE_PRIORITY | `FIRST_VALUE(col IGNORE NULLS) OVER (PARTITION BY entity_key ORDER BY _priority ASC)` |
| Contact (email, phone) | MOST_RECENT | `FIRST_VALUE(col IGNORE NULLS) OVER (PARTITION BY entity_key ORDER BY _updated_at DESC NULLS LAST)` |
| Address | MOST_RECENT | same as contact |
| Full name / description | LONGEST_VALUE | `MAX_BY(col, LENGTH(COALESCE(col, ''))) OVER (PARTITION BY entity_key)` |
| Status / category flags | MOST_FREQUENT | use the value that appears in most sources |
| Any other field | NOT_NULL | `FIRST_VALUE(col IGNORE NULLS) OVER (PARTITION BY entity_key ORDER BY _priority ASC)` |

### Step 4 — Generate `output/eda/{pipeline_name}/reports/entity_mapping.md`

```markdown
# Entity Mapping Report: [entity_name]

**Domain:** [domain] | **Entity type:** [customer/patient/employee/...]
**Primary key:** [pk_col] | **Sources:** [list in priority order]

## Field Mapping

| Canonical Field | Source Table | Source Column | Survivorship Rule | Notes |
|----------------|-------------|--------------|------------------|-------|
| first_name | customers | first_name | LONGEST_VALUE | Most complete name |
| primary_email | customers | email | SOURCE_PRIORITY | CRM is authoritative |
| primary_phone | crm_contacts | mobile_no | MOST_RECENT | CRM has latest contact |
| _source_systems | (all) | (derived) | ARRAY_AGG | Tracks all contributing sources |

## Source Priority
1. [source_1] — [reason why most trusted]
2. [source_2] — [reason]
```

### Step 5 — Generate `output/eda/{pipeline_name}/sql/[entity_name]_suite.sql`

#### Part 1 — Create target table DDL

```sql
-- ═══ STEP 1: CREATE GOLDEN RECORD TABLE ═══
CREATE TABLE IF NOT EXISTS [catalog].[schema].[entity_name] (
  [pk_col]           STRING NOT NULL  COMMENT 'Primary key for the golden record',
  -- identity fields
  first_name         STRING           COMMENT 'Given name — PII (name), GDPR',
  last_name          STRING           COMMENT 'Surname — PII (name), GDPR',
  -- contact fields
  primary_email      STRING           COMMENT 'Primary email — PII (email), GDPR',
  primary_phone      STRING           COMMENT 'Primary phone — PII (phone), GDPR',
  -- domain-specific fields
  [domain_field_1]   [TYPE],
  [domain_field_2]   [TYPE],
  -- governance fields
  _source_systems    ARRAY<STRING>    COMMENT 'All source systems that contributed to this record',
  _confidence_score  DOUBLE           COMMENT 'Confidence score 0.0–1.0 based on source coverage',
  _golden_source     STRING           COMMENT 'Highest-priority source for this record',
  _last_updated      TIMESTAMP        COMMENT 'Last time this golden record was refreshed',
  _is_deleted        BOOLEAN          DEFAULT FALSE COMMENT 'Soft-delete flag'
)
USING DELTA
COMMENT '[Entity] golden record — built by data_forge entity builder'
TBLPROPERTIES (
  'delta.enableChangeDataFeed' = 'true',
  'delta.autoOptimize.optimizeWrite' = 'true',
  'delta.autoOptimize.autoCompact' = 'true'
);
```

#### Part 2 — Staged UNION CTE

```sql
-- ═══ STEP 2: STAGE ALL SOURCES ═══
WITH staged AS (
  -- Source 1: [source_1] (priority 1 — most trusted)
  SELECT
    `[source_pk]`      AS entity_key,
    `first_name`       AS first_name,
    `email`            AS primary_email,
    NULL               AS primary_phone,     -- not in this source
    1                  AS _priority,
    'source_1'         AS _source,
    `updated_at`       AS _updated_at
  FROM [catalog].[schema].[source_table_1]
  WHERE `[source_pk]` IS NOT NULL

  UNION ALL

  -- Source 2: [source_2] (priority 2)
  SELECT
    `cust_ref`         AS entity_key,        -- NOTE: maps to source_1 PK
    NULL               AS first_name,
    NULL               AS primary_email,
    `mobile_no`        AS primary_phone,
    2                  AS _priority,
    'source_2'         AS _source,
    `last_contacted_at` AS _updated_at
  FROM [catalog].[schema].[source_table_2]
  WHERE `cust_ref` IS NOT NULL
  -- ... repeat for all sources
),
```

#### Part 3 — Survivorship CTE

```sql
-- ═══ STEP 3: APPLY SURVIVORSHIP RULES ═══
survived AS (
  SELECT
    entity_key,
    FIRST_VALUE(first_name IGNORE NULLS)
      OVER (PARTITION BY entity_key ORDER BY _priority, _updated_at DESC
            ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) AS first_name,
    FIRST_VALUE(primary_email IGNORE NULLS)
      OVER (PARTITION BY entity_key ORDER BY _priority ASC
            ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) AS primary_email,
    FIRST_VALUE(primary_phone IGNORE NULLS)
      OVER (PARTITION BY entity_key ORDER BY _updated_at DESC NULLS LAST
            ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) AS primary_phone,
    COLLECT_SET(_source)
      OVER (PARTITION BY entity_key
            ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) AS _source_systems,
    MIN(_priority)
      OVER (PARTITION BY entity_key) AS _min_priority,
    MAX(_updated_at)
      OVER (PARTITION BY entity_key) AS _last_updated
  FROM staged
),
deduped AS (
  SELECT DISTINCT entity_key, first_name, primary_email, primary_phone,
    _source_systems, _last_updated,
    ROUND(ARRAY_SIZE(_source_systems) * 1.0 / [total_sources], 2) AS _confidence_score,
    _source_systems[0] AS _golden_source
  FROM survived
),
```

#### Part 4 — MERGE INTO golden record

```sql
-- ═══ STEP 4: MERGE INTO GOLDEN RECORD ═══
MERGE INTO [catalog].[schema].[entity_name] tgt
USING deduped src
ON tgt.`[pk_col]` = src.entity_key
WHEN MATCHED AND src._is_deleted = TRUE
  THEN UPDATE SET tgt._is_deleted = TRUE, tgt._last_updated = current_timestamp()
WHEN MATCHED
  THEN UPDATE SET
    tgt.first_name       = src.first_name,
    tgt.primary_email    = src.primary_email,
    tgt.primary_phone    = src.primary_phone,
    tgt._source_systems  = src._source_systems,
    tgt._confidence_score = src._confidence_score,
    tgt._golden_source   = src._golden_source,
    tgt._last_updated    = current_timestamp()
WHEN NOT MATCHED AND (src._is_deleted IS NULL OR src._is_deleted = FALSE)
  THEN INSERT (
    `[pk_col]`, first_name, primary_email, primary_phone,
    _source_systems, _confidence_score, _golden_source, _last_updated, _is_deleted
  ) VALUES (
    src.entity_key, src.first_name, src.primary_email, src.primary_phone,
    src._source_systems, src._confidence_score, src._golden_source, current_timestamp(), FALSE
  );
```

#### Part 5 — Verification query

```sql
-- ═══ STEP 5: VERIFY ═══
SELECT
  COUNT(*)                                   AS total_golden_records,
  COUNT(DISTINCT _golden_source)             AS contributing_sources,
  AVG(_confidence_score)                     AS avg_confidence,
  SUM(CASE WHEN _is_deleted THEN 1 ELSE 0 END) AS soft_deleted_count,
  MIN(_last_updated)                         AS earliest_record,
  MAX(_last_updated)                         AS latest_record
FROM [catalog].[schema].[entity_name];
```

---

## Reference files

- `references/survivorship-rules.md` — complete rule library with SQL patterns
- `assets/merge-templates.sql` — MERGE INTO templates for common patterns
