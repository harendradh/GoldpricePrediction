# Survivorship Rule Library

## What is Survivorship?

When building a golden record from multiple source systems, the same entity (customer, product, employee) exists in several tables with potentially conflicting values. Survivorship rules decide **which value wins** for each field.

---

## 5 Canonical Survivorship Rules

### Rule 1: `SOURCE_PRIORITY`

**Use when:** One source is more authoritative than others for this field.  
**How it works:** Assign numeric priority to each source. Lowest number wins (1 = highest priority).

```sql
FIRST_VALUE(`{column}`) OVER (
    PARTITION BY `{entity_id}`
    ORDER BY
        CASE `source_system`
            WHEN '{source_1}' THEN 1
            WHEN '{source_2}' THEN 2
            WHEN '{source_3}' THEN 3
            ELSE 99
        END
) AS `{column}`
```

**When to assign:**
- `email` → CRM is most accurate, then billing system
- `address` → shipping system beats CRM
- `credit_score` → credit bureau beats internal estimate
- `phone` → marketing opt-in system beats CRM (consent-verified)

---

### Rule 2: `MOST_RECENT`

**Use when:** Freshest data is most accurate (status, address, preferences).  
**How it works:** Order by the record's `updated_at` DESC; take the first non-null value.

```sql
FIRST_VALUE(`{column}`) OVER (
    PARTITION BY `{entity_id}`
    ORDER BY `updated_at` DESC NULLS LAST
) AS `{column}`
```

**When to assign:**
- `account_status` → most recent change wins
- `address` → most recent update wins
- `email_opt_in` → most recent consent decision wins
- `phone` → most recently provided wins
- `loyalty_tier` → most recent tier assignment wins

---

### Rule 3: `LONGEST_VALUE`

**Use when:** Fuller data is better (names, addresses, descriptions).  
**How it works:** `MAX(LENGTH(...))` picks the most complete string.

```sql
FIRST_VALUE(`{column}`) OVER (
    PARTITION BY `{entity_id}`
    ORDER BY LENGTH(COALESCE(`{column}`, '')) DESC
) AS `{column}`
```

**When to assign:**
- `full_name` → take the version with middle name if available
- `address_line2` → take the version with suite/apt number
- `company_name` → take the full legal name over the abbreviation
- `notes` → take the version with the most content
- `product_description` → richest description wins

---

### Rule 4: `MOST_FREQUENT`

**Use when:** The most common value across sources is most likely correct.  
**How it works:** `MODE()` pattern — count occurrences per value, take the winner.

```sql
FIRST_VALUE(`{column}`) OVER (
    PARTITION BY `{entity_id}`
    ORDER BY COUNT(`{column}`) OVER (
        PARTITION BY `{entity_id}`, `{column}`
    ) DESC
) AS `{column}`
```

**When to assign:**
- `gender` → consistent across most sources wins
- `date_of_birth` → majority-agreed date wins
- `country` → most frequently recorded wins
- `currency_code` → most common across transactions wins

---

### Rule 5: `NOT_NULL`

**Use when:** Any non-null value is better than null (fill gaps from any source).  
**How it works:** `COALESCE` across sources in priority order. Fallback to any non-null.

```sql
COALESCE(
    MAX(CASE WHEN `source_system` = '{source_1}' THEN `{column}` END),
    MAX(CASE WHEN `source_system` = '{source_2}' THEN `{column}` END),
    MAX(CASE WHEN `source_system` = '{source_3}' THEN `{column}` END),
    MAX(`{column}`)  -- any source
) AS `{column}`
```

**When to assign:**
- `middle_name` → not in all sources; take it from whichever has it
- `fax` → optional contact; fill from any source
- `preferred_language` → take from any source that has it
- `date_of_birth` → fill from any source (combine with MOST_FREQUENT for validation)

---

## Survivorship Assignment Table by Domain

### Retail / E-commerce — Customer Master

| Field | Rule | Source priority |
|-------|------|----------------|
| `customer_id` | SOURCE_PRIORITY | CRM → loyalty → web |
| `first_name` | MOST_RECENT | |
| `last_name` | LONGEST_VALUE | |
| `full_name` | LONGEST_VALUE | |
| `email` | SOURCE_PRIORITY | CRM → billing → web |
| `phone` | MOST_RECENT | |
| `date_of_birth` | MOST_FREQUENT | |
| `gender` | MOST_FREQUENT | |
| `address_line1` | MOST_RECENT | |
| `address_line2` | NOT_NULL | |
| `city` | MOST_RECENT | |
| `state` | MOST_RECENT | |
| `postcode` | MOST_RECENT | |
| `country` | SOURCE_PRIORITY | billing → CRM |
| `account_status` | MOST_RECENT | |
| `loyalty_tier` | SOURCE_PRIORITY | loyalty → CRM |
| `email_opt_in` | MOST_RECENT | |
| `created_at` | SOURCE_PRIORITY | CRM (earliest system) |
| `updated_at` | MOST_RECENT | |

### Banking / Financial Services — Customer 360

| Field | Rule | Notes |
|-------|------|-------|
| `customer_id` | SOURCE_PRIORITY | Core banking → CRM |
| `full_name` | SOURCE_PRIORITY | KYC-verified name wins |
| `email` | SOURCE_PRIORITY | Digital banking → CRM |
| `phone` | MOST_RECENT | Last authenticated contact |
| `date_of_birth` | SOURCE_PRIORITY | KYC system (legally verified) |
| `address` | SOURCE_PRIORITY | KYC → core banking |
| `national_id` | SOURCE_PRIORITY | KYC system only |
| `account_status` | MOST_RECENT | |
| `credit_grade` | SOURCE_PRIORITY | Credit bureau → internal |
| `risk_flag` | SOURCE_PRIORITY | Compliance → fraud → CRM |
| `kyc_status` | SOURCE_PRIORITY | KYC system |

### Healthcare — Patient Master

| Field | Rule | Notes |
|-------|------|-------|
| `patient_id` | SOURCE_PRIORITY | EMR is authoritative |
| `first_name` | SOURCE_PRIORITY | EMR → registration |
| `last_name` | LONGEST_VALUE | Maiden/hyphenated names |
| `date_of_birth` | SOURCE_PRIORITY | EMR (ID-verified) |
| `gender` | SOURCE_PRIORITY | EMR → patient portal |
| `address` | MOST_RECENT | Last verified address |
| `phone` | MOST_RECENT | Last provided |
| `insurance_id` | MOST_RECENT | Latest active policy |
| `emergency_contact` | MOST_RECENT | Most recently updated |
| `preferred_language` | NOT_NULL | Any source |
| `allergies` | NOT_NULL | Fill from any source (safety critical) |

### HR / People — Employee Master

| Field | Rule | Notes |
|-------|------|-------|
| `employee_id` | SOURCE_PRIORITY | HRIS is authoritative |
| `legal_first_name` | SOURCE_PRIORITY | Payroll system (tax documents) |
| `legal_last_name` | SOURCE_PRIORITY | Payroll system |
| `preferred_name` | MOST_RECENT | Self-service HR portal |
| `email` | SOURCE_PRIORITY | IT directory (work email) |
| `phone` | MOST_RECENT | |
| `department_id` | MOST_RECENT | Last org chart update |
| `job_title` | MOST_RECENT | Latest title |
| `salary` | SOURCE_PRIORITY | Payroll → HRIS |
| `hire_date` | SOURCE_PRIORITY | HRIS |
| `employment_status` | MOST_RECENT | |
| `manager_id` | MOST_RECENT | Latest reporting line |
| `location` | MOST_RECENT | Latest badge/desk record |

---

## MERGE INTO Pattern

```sql
MERGE INTO `{catalog}`.`{schema}`.`{entity_master}` AS tgt
USING (
    -- The survivorship CTE output
    SELECT * FROM `survivorship_cte`
) AS src
ON tgt.`{entity_id}` = src.`{entity_id}`

WHEN MATCHED AND src.`updated_at` > tgt.`updated_at` THEN
    UPDATE SET
        tgt.`first_name`     = src.`first_name`,
        tgt.`last_name`      = src.`last_name`,
        tgt.`email`          = src.`email`,
        -- ... all fields
        tgt.`updated_at`     = src.`updated_at`,
        tgt.`source_systems` = src.`source_systems`,
        tgt.`record_version` = tgt.`record_version` + 1

WHEN NOT MATCHED THEN
    INSERT (
        `{entity_id}`, `first_name`, `last_name`, `email`,
        -- ... all fields
        `created_at`, `updated_at`, `source_systems`, `record_version`
    )
    VALUES (
        src.`{entity_id}`, src.`first_name`, src.`last_name`, src.`email`,
        -- ... all fields
        CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP(), src.`source_systems`, 1
    );
```

---

## Quality Verification Query

After MERGE INTO, always verify the golden record:

```sql
SELECT
    COUNT(*)                                                       AS `total_records`,
    COUNT(DISTINCT `{entity_id}`)                                  AS `unique_entities`,
    ROUND(COUNT(`email`) * 100.0 / NULLIF(COUNT(*), 0), 1)        AS `email_fill_pct`,
    ROUND(COUNT(`phone`) * 100.0 / NULLIF(COUNT(*), 0), 1)        AS `phone_fill_pct`,
    ROUND(COUNT(`address_line1`) * 100.0 / NULLIF(COUNT(*), 0), 1) AS `address_fill_pct`,
    COUNT_IF(`record_version` = 1)                                 AS `new_records`,
    COUNT_IF(`record_version` > 1)                                 AS `updated_records`
FROM `{catalog}`.`{schema}`.`{entity_master}`;
```
