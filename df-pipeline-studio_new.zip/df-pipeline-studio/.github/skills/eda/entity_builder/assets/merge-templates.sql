-- ─────────────────────────────────────────────────────────────────────────────
-- data_forge Entity Builder — MERGE INTO Templates
-- Replace: {catalog}, {schema}, {entity}, {entity_id}, {source_*}
-- All SQL: Databricks Spark SQL with Delta Lake
-- ─────────────────────────────────────────────────────────────────────────────


-- ════════════════════════════════════════════════════════════════════════════
-- TEMPLATE 1: CREATE GOLDEN RECORD TABLE
-- ════════════════════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS `{catalog}`.`{schema}`.`{entity}_master`
(
    -- Primary identifier
    `{entity_id}`        STRING        NOT NULL,

    -- Identity fields
    `first_name`         STRING,
    `last_name`          STRING,
    `full_name`          STRING,

    -- Contact fields
    `email`              STRING,
    `phone`              STRING,

    -- Address fields
    `address_line1`      STRING,
    `address_line2`      STRING,
    `city`               STRING,
    `state`              STRING,
    `postcode`           STRING,
    `country`            STRING,

    -- Domain-specific fields (add as needed)
    `account_status`     STRING,

    -- Lineage metadata
    `source_systems`     ARRAY<STRING>,
    `record_version`     BIGINT        NOT NULL  DEFAULT 1,
    `created_at`         TIMESTAMP     NOT NULL,
    `updated_at`         TIMESTAMP     NOT NULL
)
USING DELTA
PARTITIONED BY (`country`)
TBLPROPERTIES (
    'delta.enableChangeDataFeed'     = 'true',
    'delta.autoOptimize.optimizeWrite' = 'true',
    'delta.autoOptimize.autoCompact'   = 'true',
    'quality'                        = 'gold',
    'layer'                          = 'entity'
);


-- ════════════════════════════════════════════════════════════════════════════
-- TEMPLATE 2: STAGED UNION (pull from all source systems)
-- ════════════════════════════════════════════════════════════════════════════
-- Replace source table references and column mappings for each source system
WITH staged AS (

    -- Source 1: CRM system
    SELECT
        `{entity_id}`          AS `{entity_id}`,
        `first_name`           AS `first_name`,
        `last_name`            AS `last_name`,
        `email`                AS `email`,
        `phone`                AS `phone`,
        `address_line1`        AS `address_line1`,
        `address_line2`        AS `address_line2`,
        `city`                 AS `city`,
        `state`                AS `state`,
        `postcode`             AS `postcode`,
        `country`              AS `country`,
        `status`               AS `account_status`,
        `updated_at`           AS `updated_at`,
        'crm'                  AS `source_system`
    FROM `{catalog}`.`{schema}`.`{source_table_1}`

    UNION ALL

    -- Source 2: second system (adjust column mappings)
    SELECT
        `customer_number`      AS `{entity_id}`,
        `given_name`           AS `first_name`,
        `surname`              AS `last_name`,
        `email_addr`           AS `email`,
        `mobile`               AS `phone`,
        `street_address`       AS `address_line1`,
        NULL                   AS `address_line2`,
        `suburb`               AS `city`,
        `state_code`           AS `state`,
        `postcode`             AS `postcode`,
        `country_code`         AS `country`,
        `cust_status`          AS `account_status`,
        `last_modified`        AS `updated_at`,
        'billing'              AS `source_system`
    FROM `{catalog}`.`{schema}`.`{source_table_2}`

    -- Add UNION ALL blocks for additional source systems

),


-- ════════════════════════════════════════════════════════════════════════════
-- TEMPLATE 3: SURVIVORSHIP CTE (pick winner per field)
-- ════════════════════════════════════════════════════════════════════════════
survivorship AS (
    SELECT
        `{entity_id}`,

        -- SOURCE_PRIORITY: CRM wins for email
        FIRST_VALUE(`email`) OVER (
            PARTITION BY `{entity_id}`
            ORDER BY CASE `source_system` WHEN 'crm' THEN 1 WHEN 'billing' THEN 2 ELSE 9 END
        ) AS `email`,

        -- MOST_RECENT: latest phone number wins
        FIRST_VALUE(`phone`) OVER (
            PARTITION BY `{entity_id}`
            ORDER BY `updated_at` DESC NULLS LAST
        ) AS `phone`,

        -- LONGEST_VALUE: fullest name wins
        FIRST_VALUE(`first_name`) OVER (
            PARTITION BY `{entity_id}`
            ORDER BY LENGTH(COALESCE(`first_name`, '')) DESC
        ) AS `first_name`,

        FIRST_VALUE(`last_name`) OVER (
            PARTITION BY `{entity_id}`
            ORDER BY LENGTH(COALESCE(`last_name`, '')) DESC
        ) AS `last_name`,

        -- MOST_RECENT: latest address wins
        FIRST_VALUE(`address_line1`) OVER (
            PARTITION BY `{entity_id}`
            ORDER BY `updated_at` DESC NULLS LAST
        ) AS `address_line1`,

        -- NOT_NULL: fill address_line2 from any source
        MAX(`address_line2`)                                 AS `address_line2`,

        FIRST_VALUE(`city`) OVER (
            PARTITION BY `{entity_id}`
            ORDER BY `updated_at` DESC NULLS LAST
        ) AS `city`,

        FIRST_VALUE(`state`) OVER (
            PARTITION BY `{entity_id}`
            ORDER BY `updated_at` DESC NULLS LAST
        ) AS `state`,

        FIRST_VALUE(`postcode`) OVER (
            PARTITION BY `{entity_id}`
            ORDER BY `updated_at` DESC NULLS LAST
        ) AS `postcode`,

        -- SOURCE_PRIORITY: billing has verified country
        FIRST_VALUE(`country`) OVER (
            PARTITION BY `{entity_id}`
            ORDER BY CASE `source_system` WHEN 'billing' THEN 1 WHEN 'crm' THEN 2 ELSE 9 END
        ) AS `country`,

        -- MOST_RECENT: status changes frequently
        FIRST_VALUE(`account_status`) OVER (
            PARTITION BY `{entity_id}`
            ORDER BY `updated_at` DESC NULLS LAST
        ) AS `account_status`,

        MAX(`updated_at`)                                    AS `updated_at`,
        COLLECT_SET(`source_system`)                         AS `source_systems`

    FROM staged
    GROUP BY `{entity_id}`, `email`, `phone`, `first_name`, `last_name`,
             `address_line1`, `city`, `state`, `postcode`, `country`,
             `account_status`, `updated_at`, `source_system`
),

-- Deduplicate (WINDOW functions produce one row per source per entity)
deduped AS (
    SELECT *,
        ROW_NUMBER() OVER (PARTITION BY `{entity_id}` ORDER BY `updated_at` DESC) AS `rn`
    FROM survivorship
)
SELECT
    `{entity_id}`,
    CONCAT(COALESCE(`first_name`, ''), ' ', COALESCE(`last_name`, '')) AS `full_name`,
    `first_name`, `last_name`, `email`, `phone`,
    `address_line1`, `address_line2`, `city`, `state`, `postcode`, `country`,
    `account_status`, `updated_at`, `source_systems`
FROM deduped
WHERE `rn` = 1;


-- ════════════════════════════════════════════════════════════════════════════
-- TEMPLATE 4: MERGE INTO (upsert golden record)
-- ════════════════════════════════════════════════════════════════════════════
MERGE INTO `{catalog}`.`{schema}`.`{entity}_master`   AS tgt
USING (
    -- Reference the deduped CTE output or a staging table
    SELECT * FROM deduped WHERE `rn` = 1
) AS src
ON tgt.`{entity_id}` = src.`{entity_id}`

WHEN MATCHED AND src.`updated_at` > tgt.`updated_at` THEN
    UPDATE SET
        tgt.`first_name`     = src.`first_name`,
        tgt.`last_name`      = src.`last_name`,
        tgt.`full_name`      = src.`full_name`,
        tgt.`email`          = src.`email`,
        tgt.`phone`          = src.`phone`,
        tgt.`address_line1`  = src.`address_line1`,
        tgt.`address_line2`  = src.`address_line2`,
        tgt.`city`           = src.`city`,
        tgt.`state`          = src.`state`,
        tgt.`postcode`       = src.`postcode`,
        tgt.`country`        = src.`country`,
        tgt.`account_status` = src.`account_status`,
        tgt.`source_systems` = src.`source_systems`,
        tgt.`updated_at`     = src.`updated_at`,
        tgt.`record_version` = tgt.`record_version` + 1

WHEN NOT MATCHED THEN
    INSERT (
        `{entity_id}`, `first_name`, `last_name`, `full_name`,
        `email`, `phone`,
        `address_line1`, `address_line2`, `city`, `state`, `postcode`, `country`,
        `account_status`, `source_systems`, `record_version`,
        `created_at`, `updated_at`
    )
    VALUES (
        src.`{entity_id}`, src.`first_name`, src.`last_name`, src.`full_name`,
        src.`email`, src.`phone`,
        src.`address_line1`, src.`address_line2`, src.`city`, src.`state`,
        src.`postcode`, src.`country`,
        src.`account_status`, src.`source_systems`, 1,
        CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP()
    );


-- ════════════════════════════════════════════════════════════════════════════
-- TEMPLATE 5: POST-MERGE VERIFICATION
-- ════════════════════════════════════════════════════════════════════════════
SELECT
    COUNT(*)                                                            AS `total_golden_records`,
    COUNT(DISTINCT `{entity_id}`)                                       AS `unique_entities`,
    ROUND(COUNT(`email`)         * 100.0 / NULLIF(COUNT(*), 0), 1)     AS `email_fill_pct`,
    ROUND(COUNT(`phone`)         * 100.0 / NULLIF(COUNT(*), 0), 1)     AS `phone_fill_pct`,
    ROUND(COUNT(`address_line1`) * 100.0 / NULLIF(COUNT(*), 0), 1)     AS `address_fill_pct`,
    COUNT_IF(`record_version` = 1)                                      AS `new_records_this_run`,
    COUNT_IF(`record_version` > 1)                                      AS `updated_records_this_run`,
    MAX(`record_version`)                                               AS `max_record_version`,
    COUNT_IF(SIZE(`source_systems`) >= 2)                               AS `multi_source_records`,
    ROUND(COUNT_IF(SIZE(`source_systems`) >= 2) * 100.0
          / NULLIF(COUNT(*), 0), 1)                                     AS `multi_source_pct`
FROM `{catalog}`.`{schema}`.`{entity}_master`;


-- ════════════════════════════════════════════════════════════════════════════
-- TEMPLATE 6: OPTIMIZE AFTER MERGE
-- ════════════════════════════════════════════════════════════════════════════
OPTIMIZE `{catalog}`.`{schema}`.`{entity}_master`
    ZORDER BY (`{entity_id}`, `updated_at`);

VACUUM `{catalog}`.`{schema}`.`{entity}_master`
    RETAIN 168 HOURS;   -- 7-day minimum (GDPR safe harbour)
