# Join Pattern Library — Canonical FK Naming Conventions

## Scoring Algorithm Reference

data_forge uses a cumulative scoring model to detect relationships. Scores above 50 are high confidence.

| Signal | Score |
|--------|-------|
| Column name is exact match to PK column in another table | +55 |
| Column has FK naming suffix (`_id`, `_key`, `_fk`) | +15 |
| SQL types are compatible (both STRING, or both INT) | +10 |
| Column is on the "many" side (not a PK itself) | +15 |
| Table name appears inside column name | +20 |
| Name similarity ≥ 80% via edit distance | +25 |
| User explicitly stated relationship in spec | +40 override |

**Confidence thresholds:**
- Score ≥ 80 → `CONFIRMED` (include in join chain without question)
- Score 50–79 → `LIKELY` (include with comment)
- Score 30–49 → `POSSIBLE` (mention in report, exclude from join chain unless user confirms)
- Score < 30 → `WEAK` (note in report only)

---

## Canonical FK Naming Patterns

### Standard suffix patterns (always detect as FK candidate)

| Pattern | Example | Points to |
|---------|---------|-----------|
| `{table}_id` | `customer_id` | `customers` table |
| `{table_singular}_id` | `order_id` in `order_items` | `orders` table |
| `{table}_key` | `product_key` | `products` table |
| `{table}_fk` | `supplier_fk` | `suppliers` table |
| `{table}_no` | `invoice_no` | `invoices` table |
| `{table}_num` | `account_num` | `accounts` table |
| `{table}_ref` | `transaction_ref` | `transactions` table |
| `{table}_code` | `category_code` | `categories` table |

### Aliased FK patterns (common real-world renames)

| Column | Likely joins to |
|--------|----------------|
| `cust_id` | `customers(customer_id)` |
| `client_id` | `clients(client_id)` or `customers(customer_id)` |
| `acct_id` | `accounts(account_id)` |
| `emp_id` | `employees(employee_id)` |
| `mgr_id` | `employees(employee_id)` (self-join) |
| `created_by` | `users(user_id)` |
| `updated_by` | `users(user_id)` |
| `approved_by` | `users(user_id)` |
| `owner_id` | `users(user_id)` |
| `assigned_to` | `users(user_id)` |
| `parent_id` | Same table (self-referential hierarchy) |
| `parent_{table}_id` | Same table (explicit hierarchy) |

---

## Relationship Type Matrix

| Cardinality | How to detect | Mermaid notation | Example |
|-------------|--------------|------------------|---------|
| One-to-Many | PK column ↔ FK column | `\|\|--o{` | customers → orders |
| Many-to-One | FK column ↔ PK column | `}o--\|\|` | orders → customers |
| Many-to-Many | Bridge table with two FKs | `}o--o{` | order_items: orders + products |
| One-to-One | Unique constraint on FK | `\|\|--\|\|` | users ↔ user_profiles |
| Self-referential | FK to own PK | `\|\|--o{` (same table) | employees.manager_id → employees.employee_id |

---

## Bridge Table Detection

A table is a bridge/junction table when:
1. It has ≥ 2 FK columns pointing to different tables
2. Its PK is composite (combination of the FK columns)
3. It has few non-FK columns (typically < 5 additional columns)

**Common bridge table naming patterns:**
- `{table_a}_{table_b}` → `order_products`, `user_roles`
- `{table_a}_has_{table_b}` → `customer_has_tag`
- `{table_a}_{table_b}_map` → `product_category_map`
- `{table_a}_{table_b}_rel` → `account_contact_rel`
- `{table_a}_items` → `order_items` (implicit link to both `orders` and `products`)

---

## Self-Referential Hierarchy Detection

A table is hierarchical when:
1. It has a column named `parent_id`, `manager_id`, `parent_{table_name}_id`
2. That column references the table's own PK
3. A depth-limited CTE is needed for traversal

**Common hierarchy patterns:**

| Domain | FK column | PKcolumn | Traversal |
|--------|-----------|----------|-----------|
| HR org chart | `manager_id` | `employee_id` | 5–8 levels |
| Product category | `parent_category_id` | `category_id` | 3–5 levels |
| Geography | `parent_region_id` | `region_id` | 4 levels |
| Account hierarchy | `parent_account_id` | `account_id` | 3–10 levels |
| Comment thread | `parent_comment_id` | `comment_id` | Variable |

---

## Domain-Specific Relationship Libraries

### Retail / E-commerce
```
customers(customer_id) ──< orders(customer_id)
orders(order_id) ──< order_items(order_id)
order_items(product_id) >── products(product_id)
products(category_id) >── categories(category_id)
categories(parent_category_id) >── categories(category_id)  [hierarchy]
orders(shipping_address_id) >── addresses(address_id)
customers(customer_id) ──< addresses(customer_id)
```

### Banking / Financial Services
```
customers(customer_id) ──< accounts(customer_id)
accounts(account_id) ──< transactions(account_id)
accounts(account_id) ──< loans(account_id)
customers(customer_id) ──< kyc_records(customer_id)
transactions(merchant_id) >── merchants(merchant_id)
accounts(product_id) >── products(product_id)
```

### Healthcare
```
patients(patient_id) ──< encounters(patient_id)
encounters(encounter_id) ──< diagnoses(encounter_id)
encounters(provider_id) >── providers(provider_id)
encounters(facility_id) >── facilities(facility_id)
diagnoses(icd_code) >── icd_codes(code)
encounters(encounter_id) ──< medications(encounter_id)
```

### HR / People
```
employees(employee_id) ──< contracts(employee_id)
employees(manager_id) >── employees(employee_id)  [self-join]
employees(department_id) >── departments(department_id)
departments(parent_department_id) >── departments(department_id)  [hierarchy]
employees(employee_id) ──< payroll(employee_id)
employees(employee_id) ──< performance_reviews(employee_id)
```

---

## JOIN SQL Templates

### Standard inner join (high confidence)
```sql
SELECT
    a.`col1`,
    a.`col2`,
    b.`col3`
FROM `catalog`.`schema`.`table_a`    AS a
INNER JOIN `catalog`.`schema`.`table_b`    AS b  /*+ BROADCAST(b) */
    ON a.`fk_column` = b.`pk_column`
```

### Left join (nullable FK — common for optional relationships)
```sql
LEFT JOIN `catalog`.`schema`.`table_b`    AS b
    ON a.`fk_column` = b.`pk_column`
```

### Many-to-many via bridge
```sql
INNER JOIN `catalog`.`schema`.`bridge_table`   AS br
    ON a.`pk_col` = br.`fk_a`
INNER JOIN `catalog`.`schema`.`table_b`        AS b   /*+ BROADCAST(b) */
    ON br.`fk_b`  = b.`pk_col`
```

### Self-join for hierarchy (2 levels)
```sql
employees     AS emp
LEFT JOIN employees    AS mgr  /*+ BROADCAST(mgr) */
    ON emp.`manager_id` = mgr.`employee_id`
```

### Hierarchical CTE (unlimited depth, max 10)
```sql
WITH RECURSIVE org_hierarchy AS (
    SELECT `employee_id`, `manager_id`, `full_name`, 0 AS depth
    FROM `catalog`.`schema`.`employees`
    WHERE `manager_id` IS NULL          -- root nodes

    UNION ALL

    SELECT e.`employee_id`, e.`manager_id`, e.`full_name`, h.depth + 1
    FROM `catalog`.`schema`.`employees`  AS e
    INNER JOIN org_hierarchy             AS h
        ON e.`manager_id` = h.`employee_id`
    WHERE h.depth < 10                  -- prevent infinite recursion
)
SELECT * FROM org_hierarchy
```

---

## Broadcast Hint Rules

Apply `/*+ BROADCAST(alias) */` when:
- Table has < 200 MB estimated size (dimension/lookup table)
- Table is the "one" side of a one-to-many join
- Table is a bridge/junction table

Do NOT broadcast:
- Fact tables (potentially billions of rows)
- Tables with no row-count estimate
