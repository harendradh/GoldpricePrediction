# Skill: Relationship Discovery

```
skill:    eda.relationship_discovery
version:  2.0
trigger:  "relationships", "joins", "ER diagram", "foreign keys", "how tables connect"
outputs:  output/eda/{pipeline_name}/reports/relationship_diagram.md, output/eda/{pipeline_name}/reports/relationship_diagram.drawio, output/eda/{pipeline_name}/sql/join_chain.sql
```

---

## Purpose

Automatically detect how tables in `spec.md` relate to each other —
without being told explicitly. Generate ER diagrams and production-ready JOIN SQL.

---

## Step-by-step instructions

### Step 1 — Build a column inventory

For every table, list:
- All column names (lowercase for comparison)
- Which columns are primary keys
- Which columns have FK-style names (`*_id`, `*_key`, `*_fk`, `*_ref`, `*_code`)

### Step 2 — Score all table pairs

Compare every pair of tables. For each pair, find the highest-scoring column pair:

| Signal | Score |
|--------|-------|
| Exact column name match | +55 |
| Column has FK suffix (`_id`, `_key`, `_fk`, `_ref`) | +15 |
| Data types are compatible | +10 |
| One side is declared primary key | +15 |
| Table name appears in the other column (e.g. `orders.customer_id` when `customers` exists) | +20 |
| Name similarity ≥ 80% (e.g. `cust_ref` vs `customer_id`) | +25 |
| User explicitly mentioned the join in spec.md | +40 (override) |

Keep only the highest-scoring column pair per table pair.
Only report joins with score ≥ 45 (equivalent to ~45% confidence).

### Step 3 — Determine relationship type

| Pattern | Relationship | Notes |
|---------|-------------|-------|
| Left col is PK, right col is not PK | one-to-many | most common: master → transaction |
| Right col is PK, left col is not PK | many-to-one | transaction → dimension |
| Both cols are PK | one-to-one | rare — usually same entity in two systems |
| Neither col is PK | many-to-many | flag — usually needs a bridge table |

### Step 4 — Identify the central table

The central table (root of the JOIN chain) is the one with:
- The most other tables joining to it, OR
- Declared as master / entity table in spec.md, OR
- Column name matching the domain entity (e.g. `customers` in a customer domain)

### Step 5 — Generate output files

#### `output/eda/{pipeline_name}/reports/relationship_diagram.md` — Mermaid ER diagram

````markdown
```mermaid
erDiagram
  CUSTOMERS {
    STRING customer_id PK
    STRING email
    STRING account_status
    TIMESTAMP created_at
  }
  ORDERS {
    STRING order_id PK
    STRING customer_id FK
    DECIMAL total_amount
    TIMESTAMP order_date
  }
  PRODUCTS {
    STRING product_id PK
    STRING category
    DECIMAL unit_price
  }

  CUSTOMERS ||--o{ ORDERS : "customer_id → customer_id [94%]"
  ORDERS }o--|| PRODUCTS : "product_id → product_id [88%]"
```
````

#### `output/eda/{pipeline_name}/reports/relationship_diagram.drawio`

Generate complete Draw.io XML with:
- One rectangular node per table (header = table name, rows = columns)
- Arrows between tables for each join with confidence % label
- Layout: master/dimension tables on left, transaction/fact tables on right

XML structure:
```xml
<mxGraphModel>
  <root>
    <mxCell id="0"/><mxCell id="1" parent="0"/>
    <!-- Table node -->
    <mxCell id="tbl_customers" value="customers" style="shape=table;..." vertex="1" parent="1">
      <mxGeometry x="80" y="80" width="200" height="160" as="geometry"/>
    </mxCell>
    <!-- Column rows -->
    <mxCell id="col_customer_id" value="🔑 customer_id : STRING" style="shape=tableRow;..." vertex="1" parent="tbl_customers"/>
    <mxCell id="col_email" value="📧 email : STRING" style="shape=tableRow;..." vertex="1" parent="tbl_customers"/>
    <!-- Edge/arrow -->
    <mxCell id="rel_1" style="edgeStyle=entityRelationEdgeStyle;..." edge="1" source="col_customer_id_orders" target="col_customer_id" parent="1">
      <mxGeometry relative="1" as="geometry"/>
    </mxCell>
  </root>
</mxGraphModel>
```

#### `output/eda/{pipeline_name}/sql/join_chain.sql`

```sql
-- ═══ JOIN CHAIN: [central_table] + [N] related tables ═══
-- Detected relationships: [summary line]
-- Confidence: [highest join %] | Broadcast candidates: [table list]

SELECT
  -- [central_table] columns
  c.`customer_id`,
  c.`email`,
  c.`account_status`,
  -- [joined table] columns
  o.`order_id`,
  o.`total_amount`,
  o.`order_date`,
  -- [another joined table]
  p.`product_name`,
  p.`category`
FROM [catalog].[schema].[central_table] c
LEFT JOIN [catalog].[schema].[table2] o
  ON c.`customer_id` = o.`customer_id`
LEFT JOIN /*+ BROADCAST(p) */ [catalog].[schema].[table3] p
  ON o.`product_id` = p.`product_id`;
```

Add `/*+ BROADCAST(t) */` when the joined table has few columns (likely dimension/reference table).

### Step 6 — Relationship summary table

Include in the diagram markdown:

| Join | Detected via | Confidence | Type | Broadcast? |
|------|-------------|------------|------|-----------|
| customers → orders on customer_id | exact name match + FK suffix | 94% | one-to-many | No |
| orders → products on product_id | exact name match + PK | 88% | many-to-one | Yes (products) |

---

## Reference files

- `references/join-patterns.md` — canonical FK naming convention library
- `assets/naming-conventions.yaml` — synonym pairs for fuzzy name matching

---

## Quality check before writing output

- Every table in spec.md appears in at least one join OR is noted as standalone ✓
- Any user-stated relationships are captured first (highest priority) ✓
- Mermaid diagram renders without syntax errors ✓
- JOIN SQL uses real column names from spec.md, not placeholders ✓
- Broadcast hints are applied only on the smaller side of each join ✓
