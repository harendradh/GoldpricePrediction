# Enterprise Data Catalog Writing Standards

## Purpose

These standards ensure that every table and column in the data catalog can be understood by a non-technical business user — a product manager, a compliance officer, an analyst who did not build the pipeline.

---

## Guiding Principle

Write for the reader who is **not in the room** when decisions were made. Assume they know the business domain but not the data engineering choices.

---

## Table Description Standards

### Required elements
1. **What the table contains** — one sentence
2. **Where the data comes from** — source system name
3. **Update frequency** — daily, real-time, weekly
4. **Primary use cases** — what questions this table answers
5. **Owner / steward** — team responsible

### Template
```markdown
**{Table name}** contains {what it contains}, sourced from {source system}.
Updated {frequency}. Use this table to answer questions about {use cases}.
Data steward: {team or person name}.
```

### Good example
```
customers contains one record per registered customer, sourced from the Salesforce CRM system.
Updated daily at 06:00 UTC. Use this table to answer questions about customer demographics,
account status, and acquisition channel. Data steward: CRM Engineering team.
```

### Bad examples (avoid)
```
❌ "This table stores customer data."
   (Too vague — what customer data? What is a 'customer' here?)

❌ "Loaded by the nightly ETL job from SFDC using the CustomersV3 API endpoint."
   (Technical detail belongs in lineage, not the description)

❌ "Customer master table."
   (No context — a new analyst still doesn't know what to do with this)
```

---

## Column Description Standards

### Required elements
1. **What the value represents** — in plain English
2. **Example values** — 2–3 realistic examples
3. **Constraints or rules** — nullability, allowed values, format
4. **Business meaning of null** — what null means in context

### Template
```
What: {plain English explanation}
Example values: {example_1}, {example_2}, {example_3}
Constraints: {nullability, allowed values, format}
Null means: {business meaning}
```

### Good column description examples

| Column | Description |
|--------|-------------|
| `customer_id` | Unique identifier for each registered customer. Assigned by the CRM system at account creation. Never reused after account deletion. Example: `C-000123456`. Never null. |
| `email` | Primary email address used for marketing communications and account login. Example: `jane.smith@example.com`. Null if customer registered via phone-only channel. |
| `account_status` | Current state of the customer account. One of: `ACTIVE` (can transact), `INACTIVE` (no activity 12+ months), `SUSPENDED` (flagged by risk team), `PENDING` (registration not complete). Never null. |
| `total_lifetime_value` | Total revenue received from this customer across all time, in USD. Includes completed orders only; excludes refunds. Null for customers with no completed orders yet. |
| `date_of_birth` | Customer's date of birth, used for age-gating and loyalty tier qualification. Truncated to year in analytics views (GDPR). Null if customer did not provide it. |
| `created_at` | Timestamp when the customer record was first created in the CRM system, in UTC. Reflects first registration event. Never null. |

### Bad column description examples

| Column | Bad description | What's wrong |
|--------|----------------|--------------|
| `customer_id` | "The customer ID" | Restates the name, adds nothing |
| `status` | "Status of the record" | Too vague — what values? what do they mean? |
| `ltv` | "LTV column" | Acronym undefined; no context |
| `created_at` | "Created at timestamp from ETL load" | Confuses load time with business event time |
| `is_deleted` | "Soft delete flag" | Technical jargon — a business user won't understand |

---

## PII Column Description Pattern

PII columns must include governance metadata in the description:

```
{standard description}

⚠️ PII: {pii_type} ({severity}). Masked in analytics views.
Regulations: {GDPR / CCPA / HIPAA}.
Masking: {masking expression description}.
```

**Example:**
```
email: Primary email address used for account login and marketing.
Example: jane@example.com. Null if phone-only registration.

⚠️ PII: email (HIGH). Masked to first 2 chars + *** in analytics views.
Regulations: GDPR Art. 6, CCPA, CAN-SPAM.
Masking: jane@example.com → ja***@example.com
```

---

## Enumeration / Status Column Standards

For columns with a defined set of allowed values, always list all values with plain English meanings:

```markdown
| Value | Meaning |
|-------|---------|
| ACTIVE | Customer account is in good standing and can transact |
| INACTIVE | No purchase or login activity in the past 12 months |
| SUSPENDED | Account flagged by risk team; cannot transact pending review |
| PENDING | Registration started but email verification not complete |
| CLOSED | Customer requested account deletion (GDPR erasure) |
```

---

## Data Catalog Page Structure

Every table in the catalog must have:

```markdown
# {Table Name}

## Overview
{1–3 sentence description}

## Key Facts
| Property | Value |
|----------|-------|
| Schema | {catalog.schema} |
| Update frequency | {daily/hourly/real-time} |
| Row count | ~{estimated rows} |
| Primary key | {pk column(s)} |
| Data steward | {team} |
| Classification | {Public / Internal / Confidential / Restricted} |

## Columns
{Column table with: name, type, nullable, description, PII flag}

## Relationships
{Mermaid or table showing how this table joins to others}

## Data Quality
{DQ score, last checked date, known issues}

## Usage Examples
{2–3 example SQL queries that answer common business questions}

## Change History
{Recent schema or business rule changes}
```

---

## Writing Style Guide

| Do | Don't |
|----|-------|
| "Unique identifier for each customer" | "Customer ID field" |
| "Updated daily at 06:00 UTC from Salesforce" | "ETL loads this table nightly" |
| "Null if customer has not provided their address" | "Nullable" |
| "One of: ACTIVE, INACTIVE, SUSPENDED" | "Possible values: see source system docs" |
| "In USD, with 2 decimal places" | "Decimal type" |
| Use plain English throughout | Use technical jargon (ETL, upsert, CDF, Z-order) |
| Explain what null means in business context | Just say "nullable" |
| Give 2–3 realistic example values | Skip examples |

---

## Classification Levels

| Level | Meaning | Who can access |
|-------|---------|----------------|
| Public | Safe to share externally | Everyone |
| Internal | Business use only | All employees |
| Confidential | Sensitive business data | Role-based access |
| Restricted | PII, financial, regulated data | Need-to-know only |

Tables containing CRITICAL or HIGH PII are automatically **Restricted**.  
Tables containing MEDIUM PII are automatically **Confidential**.
