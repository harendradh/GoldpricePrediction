# {Table Display Name}

> {One sentence: what does this table contain and why does it exist?}

---

## Overview

{2–3 sentences describing the table. Answer: What is it? Where does the data come from? Who uses it and for what?}

**Example:**
> `customers` contains one record per registered customer, sourced from the Salesforce CRM system.
> Updated daily at 06:00 UTC. Used by Marketing for segmentation and by Finance for revenue attribution.

---

## Key Facts

| Property | Value |
|----------|-------|
| **Full path** | `{catalog}`.`{schema}`.`{table}` |
| **Source system** | {CRM / ERP / Web / Kafka / etc.} |
| **Update frequency** | {Daily at 06:00 UTC / Hourly / Real-time / Weekly} |
| **Estimated row count** | ~{N} rows |
| **Primary key** | `{pk_column}` |
| **Partition key** | `{partition_column}` (if applicable) |
| **Data steward** | {Team or person name} |
| **Classification** | {Public / Internal / Confidential / Restricted} |
| **GDPR lawful basis** | {Consent / Contract / Legal obligation / N/A} |
| **Retention period** | {X years / Indefinite} |
| **Last DQ score** | {0–100} ({grade}) — last checked {date} |

---

## Columns

| Column | Type | Nullable | Semantic Class | PII | Description |
|--------|------|----------|---------------|-----|-------------|
| `{pk_col}` | STRING | No | key | No | Unique identifier. Example: `C-000123456`. Never null. |
| `{name_col}` | STRING | No | identity | HIGH | Full legal name. Example: `Jane Smith`. |
| `{email_col}` | STRING | Yes | contact | HIGH | Primary email. Null if phone-only registration. Masked in analytics views. |
| `{phone_col}` | STRING | Yes | contact | HIGH | Primary phone. Format: E.164 (+1XXXXXXXXXX). |
| `{status_col}` | STRING | No | transaction | No | Account status. One of: `ACTIVE`, `INACTIVE`, `SUSPENDED`, `PENDING`. |
| `{amount_col}` | DECIMAL(18,2) | Yes | metric | No | Total lifetime spend in USD. Null if no completed orders. |
| `{date_col}` | TIMESTAMP | No | date | No | Record creation timestamp in UTC. |
| `{updated_col}` | TIMESTAMP | No | date | No | Last modification timestamp in UTC. |

*Add one row per column. Descriptions follow the standards in `references/catalog-standards.md`.*

---

## Status / Enumeration Values

*Complete this section for any column with a fixed set of allowed values.*

### `{status_column}` values

| Value | Meaning |
|-------|---------|
| `ACTIVE` | {plain English meaning} |
| `INACTIVE` | {plain English meaning} |
| `SUSPENDED` | {plain English meaning} |
| `PENDING` | {plain English meaning} |

---

## Relationships

```mermaid
erDiagram
    {TABLE} {
        string {pk_col} PK
        string {fk_col} FK
    }
    {PARENT_TABLE} {
        string {parent_pk} PK
    }
    {CHILD_TABLE} {
        string {child_pk} PK
        string {child_fk} FK
    }
    {PARENT_TABLE} ||--o{ {TABLE} : "has many"
    {TABLE} ||--o{ {CHILD_TABLE} : "has many"
```

**Join guide:**

| To get | Join with | On |
|--------|-----------|-----|
| {what you get} | `{other_table}` | `{this_table}.{fk}` = `{other_table}.{pk}` |

---

## PII Summary

*Complete only if the table contains PII columns.*

| Column | PII Type | Severity | Masking Expression | Regulation |
|--------|----------|----------|-------------------|------------|
| `{email_col}` | email | HIGH | `CONCAT(LEFT(col, 2), '***@', SPLIT(col, '@')[1])` | GDPR, CCPA |
| `{phone_col}` | phone | HIGH | `CONCAT('***-***-', RIGHT(col, 4))` | GDPR, CCPA |

**Masking view:** `{catalog}`.`{schema}`.`{table}_masked`
*(Safe for analytics teams — PII columns are masked.)*

---

## Data Quality

| Metric | Value | Grade |
|--------|-------|-------|
| Overall DQ Score | {score}/100 | {EXCELLENT / GOOD / FAIR / POOR} |
| Completeness | {score}% | {PASS / WARN / FAIL} |
| Uniqueness | {score}% | {PASS / WARN / FAIL} |
| Validity | {score}% | {PASS / WARN / FAIL} |
| Freshness | {score}% | {PASS / WARN / FAIL} |
| Last checked | {date} | |

**Known issues:**
- {Issue 1: e.g., "phone_number has 8% null rate — customers registered before 2021 did not provide phone"}
- {Issue 2: e.g., "email_opt_in has 2% invalid values from legacy import batch"}

---

## Usage Examples

### Example 1: {Business question}
```sql
-- {One-line explanation of what this query answers}
SELECT
    `{col1}`,
    `{col2}`,
    COUNT(*) AS `count`
FROM `{catalog}`.`{schema}`.`{table}`
WHERE `{filter_col}` = '{filter_value}'
GROUP BY `{col1}`, `{col2}`
ORDER BY `count` DESC
LIMIT 20;
```

### Example 2: {Business question}
```sql
-- {One-line explanation}
SELECT
    DATE_TRUNC('month', `{date_col}`) AS `month`,
    COUNT(*)                           AS `row_count`,
    SUM(`{metric_col}`)               AS `total`
FROM `{catalog}`.`{schema}`.`{table}`
WHERE `{date_col}` >= DATE_SUB(CURRENT_DATE(), 90)
GROUP BY DATE_TRUNC('month', `{date_col}`)
ORDER BY `month`;
```

---

## Change History

| Date | Change | Author |
|------|--------|--------|
| {YYYY-MM-DD} | Table created | {team} |
| {YYYY-MM-DD} | Added `{new_column}` column for {reason} | {team} |

---

## Access and Governance

- **Who can access:** {role/group names}
- **How to request access:** {link to access request process}
- **Row-level security:** {Yes — filtered by {column} / No}
- **Column masking:** {Yes — via masking view `{table}_masked` / No}
- **GDPR erasure supported:** {Yes — `is_deleted` flag + VACUUM schedule / No}

---

*Generated by data_forge — Data Asset Forge. Last updated: {date}.*
