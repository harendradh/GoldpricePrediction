# Skill: SQL Profiling

```
skill:    eda.sql_profiling
version:  2.0
trigger:  "profile", "fill rate", "null check", "distribution", "quality SQL", "row count"
outputs:  output/eda/{pipeline_name}/sql/profiling_suite.sql
```

---

## Purpose

Generate a complete, copy-paste-ready SQL profiling suite for every table in `spec.md`.
All SQL runs directly in Databricks SQL or a Databricks notebook with no modification.

---

## Step-by-step instructions

### Step 1 — Identify column types for each table

From spec.md, classify each column as:
- **numeric** — INT, BIGINT, DECIMAL, DOUBLE, FLOAT
- **string** — STRING, VARCHAR, CHAR
- **date/timestamp** — DATE, TIMESTAMP
- **boolean** — BOOLEAN
- **other** — ARRAY, MAP, STRUCT

Infer from column name if data type not stated (same rules as schema-intelligence skill).

### Step 2 — Generate SQL blocks per table

For each table, generate these blocks in order, separated by `-- ───────────────────────────────────`.

All SQL uses the fully qualified table name: `[catalog].[schema].[table]` using values from spec.md (default `main.gold`).

#### Block 1 — Table summary

```sql
-- ═══ TABLE PROFILE: [catalog].[schema].[table] ═══
SELECT
  '[table_name]'                                          AS table_name,
  COUNT(*)                                                AS total_rows,
  COUNT(DISTINCT `[primary_key]`)                         AS distinct_pk_rows,
  COUNT(*) - COUNT(DISTINCT `[primary_key]`)              AS duplicate_pk_count,
  ROUND((COUNT(*) - COUNT(DISTINCT `[primary_key]`))
        * 100.0 / NULLIF(COUNT(*), 0), 2)                AS duplicate_pct,
  current_timestamp()                                     AS profiled_at
FROM [catalog].[schema].[table];
```

If no primary key in spec.md, use the first column.

#### Block 2 — Fill rate (one line per column)

```sql
-- ═══ FILL RATE: [catalog].[schema].[table] ═══
SELECT
  COUNT(*) AS total_rows,
  ROUND(COUNT(`col1`) * 100.0 / NULLIF(COUNT(*), 0), 1) AS `col1_fill_pct`,
  ROUND(COUNT(`col2`) * 100.0 / NULLIF(COUNT(*), 0), 1) AS `col2_fill_pct`,
  -- ... one line per column ...
  ROUND(COUNT(`colN`) * 100.0 / NULLIF(COUNT(*), 0), 1) AS `colN_fill_pct`
FROM [catalog].[schema].[table];
```

#### Block 3 — Duplicate detection

```sql
-- ═══ DUPLICATE DETECTION: [catalog].[schema].[table] ═══
WITH dupes AS (
  SELECT `[pk_col]`, COUNT(*) AS cnt
  FROM [catalog].[schema].[table]
  GROUP BY `[pk_col]`
  HAVING COUNT(*) > 1
)
SELECT
  COUNT(*)     AS duplicate_groups,
  SUM(cnt)     AS total_dupe_rows,
  MAX(cnt)     AS max_duplicates_per_key,
  MIN(cnt)     AS min_duplicates_per_key
FROM dupes;
```

#### Block 4 — Column profile (UNION ALL across all columns)

For each column, generate one SELECT block:

```sql
-- ═══ COLUMN PROFILE: [catalog].[schema].[table] ═══
SELECT
  '[col_name]'                 AS column_name,
  '[data_type]'                AS data_type,
  COUNT(*)                     AS total_rows,
  COUNT(`[col_name]`)          AS non_null_count,
  COUNT(*) - COUNT(`[col_name]`) AS null_count,
  ROUND((COUNT(*) - COUNT(`[col_name]`)) * 100.0 / NULLIF(COUNT(*), 0), 2) AS null_pct,
  ROUND(COUNT(`[col_name]`) * 100.0 / NULLIF(COUNT(*), 0), 2) AS fill_rate_pct,
  APPROX_COUNT_DISTINCT(`[col_name]`) AS approx_distinct_count,
  -- numeric columns only:
  MIN(CAST(`[col_name]` AS DOUBLE))     AS min_val,
  MAX(CAST(`[col_name]` AS DOUBLE))     AS max_val,
  ROUND(AVG(CAST(`[col_name]` AS DOUBLE)), 4) AS avg_val,
  ROUND(STDDEV(CAST(`[col_name]` AS DOUBLE)), 4) AS stddev_val,
  PERCENTILE_APPROX(CAST(`[col_name]` AS DOUBLE), 0.25) AS p25,
  PERCENTILE_APPROX(CAST(`[col_name]` AS DOUBLE), 0.5)  AS median_val,
  PERCENTILE_APPROX(CAST(`[col_name]` AS DOUBLE), 0.75) AS p75,
  NULL AS min_length, NULL AS max_length, NULL AS avg_length
  -- string columns only:
  -- NULL AS min_val, ... NULL AS p75,
  -- MIN(LENGTH(`[col]`)) AS min_length,
  -- MAX(LENGTH(`[col]`)) AS max_length,
  -- ROUND(AVG(LENGTH(`[col]`)), 1) AS avg_length
FROM [catalog].[schema].[table]
```

Use `UNION ALL` between blocks, `ORDER BY null_pct DESC` at the end.

#### Block 5 — Top values per low-cardinality column

For columns with class `identity`, `contact`, `financial`, or any status/type/category column:

```sql
-- ═══ TOP 20 VALUES: [catalog].[schema].[table].[col_name] ═══
SELECT
  `[col_name]`  AS value,
  COUNT(*)       AS frequency,
  ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER (), 2) AS pct_of_total
FROM [catalog].[schema].[table]
WHERE `[col_name]` IS NOT NULL
GROUP BY `[col_name]`
ORDER BY frequency DESC
LIMIT 20;
```

#### Block 6 — Temporal trend (if date/timestamp column exists)

```sql
-- ═══ TEMPORAL TREND: [catalog].[schema].[table] by month ═══
SELECT
  DATE_TRUNC('month', `[date_col]`)  AS period,
  COUNT(*)                            AS record_count,
  ROUND(COUNT(*) * 100.0
    / SUM(COUNT(*)) OVER (), 2)       AS pct_of_total
FROM [catalog].[schema].[table]
WHERE `[date_col]` IS NOT NULL
GROUP BY DATE_TRUNC('month', `[date_col]`)
ORDER BY period;
```

#### Block 7 — Data quality score

```sql
-- ═══ DATA QUALITY SCORE: [catalog].[schema].[table] ═══
WITH base AS (
  SELECT
    COUNT(*)                  AS total_rows,
    COUNT(DISTINCT `[pk]`)    AS distinct_pks,
    -- sum of: 1 for each required column that is NOT NULL
    ([col1] IS NOT NULL)::INT + ([col2] IS NOT NULL)::INT + ... AS completeness_sum
  FROM [catalog].[schema].[table]
)
SELECT
  total_rows,
  ROUND(completeness_sum * 100.0 / NULLIF(total_rows * [n_required_cols], 0), 1) AS completeness_score,
  ROUND(distinct_pks     * 100.0 / NULLIF(total_rows, 0), 1)                     AS uniqueness_score,
  ROUND(
    (completeness_sum * 100.0 / NULLIF(total_rows * [n_required_cols], 0)) * 0.6 +
    (distinct_pks     * 100.0 / NULLIF(total_rows, 0))                     * 0.4,
  1)                                                                               AS overall_quality_score,
  current_timestamp() AS scored_at
FROM base;
```

### Step 3 — Add domain-specific queries

Based on the detected domain, add 3-5 analytical queries at the end of the file:

**Retail / e-commerce:**
- Revenue by month and channel
- Top 10 customers by order value
- Average order value by loyalty tier
- Cancelled order rate by category

**Banking / fintech:**
- Transaction volume by channel and day of week
- High-value transaction outliers (>3σ from mean)
- Account status distribution over time

**Healthcare:**
- Patient visit frequency distribution
- Diagnosis code frequency
- Age group distribution (from DOB)

**HR:**
- Headcount by department over time
- Salary distribution by grade/level
- Tenure distribution

---

## Format rules

- File header: `-- ═══ PROFILING SUITE: [Project Name] ═══`
- Section separator: `-- ───────────────────────────────────────────────────────────────`
- All column names: backtick-quoted
- All percentages: `ROUND(..., 2)` or `ROUND(..., 1)`
- All divisions: wrapped in `NULLIF(denominator, 0)` to prevent divide-by-zero
- File ends with: `-- Generated by data_forge`

---

## Reference files

- `references/sql-patterns.md` — reusable SQL building blocks
- `assets/profile-templates.sql` — copy-paste SQL templates for each block type
