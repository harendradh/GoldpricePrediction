# SQL Profiling Patterns — Reusable Building Blocks

All SQL is Databricks Spark SQL. Follow these patterns exactly.

---

## 1. Table Summary Block

```sql
-- ─── TABLE SUMMARY ────────────────────────────────────────────────────────────
SELECT
    COUNT(*)                                             AS `total_rows`,
    COUNT(DISTINCT `{pk_column}`)                        AS `distinct_pks`,
    COUNT(*) - COUNT(DISTINCT `{pk_column}`)             AS `duplicate_pk_count`,
    MIN(`{date_column}`)                                 AS `earliest_record`,
    MAX(`{date_column}`)                                 AS `latest_record`,
    DATEDIFF(MAX(`{date_column}`), MIN(`{date_column}`)) AS `date_span_days`,
    COUNT_IF(`{date_column}` >= DATE_SUB(CURRENT_DATE(), 7)) AS `rows_last_7d`,
    COUNT_IF(`{date_column}` >= DATE_SUB(CURRENT_DATE(), 30)) AS `rows_last_30d`
FROM `{catalog}`.`{schema}`.`{table}`;
```

---

## 2. Fill Rate Block

```sql
-- ─── FILL RATES ───────────────────────────────────────────────────────────────
SELECT
    COUNT(*)                                      AS `total_rows`,

    -- Per column: COUNT non-null / total * 100
    ROUND(COUNT(`{col1}`) * 100.0 / NULLIF(COUNT(*), 0), 2)  AS `{col1}_fill_pct`,
    ROUND(COUNT(`{col2}`) * 100.0 / NULLIF(COUNT(*), 0), 2)  AS `{col2}_fill_pct`,
    ROUND(COUNT(`{col3}`) * 100.0 / NULLIF(COUNT(*), 0), 2)  AS `{col3}_fill_pct`
    -- ... repeat for each column

FROM `{catalog}`.`{schema}`.`{table}`;
```

**Fill rate interpretation:**
- ≥ 99% → PASS (excellent)
- 95–98% → WARN (acceptable for optional fields)
- 80–94% → FAIL (investigate data gaps)
- < 80% → CRITICAL (field may be abandoned or wrong source)

---

## 3. Duplicate Detection Block

```sql
-- ─── DUPLICATE DETECTION ──────────────────────────────────────────────────────
WITH dup_check AS (
    SELECT
        `{pk_column}`,
        COUNT(*) AS `row_count`
    FROM `{catalog}`.`{schema}`.`{table}`
    GROUP BY `{pk_column}`
    HAVING COUNT(*) > 1
)
SELECT
    COUNT(*)              AS `duplicate_pk_count`,
    SUM(`row_count`)      AS `total_affected_rows`,
    MAX(`row_count`)      AS `max_duplicates_per_key`
FROM dup_check;
```

**For composite PK:**
```sql
GROUP BY `{pk_col1}`, `{pk_col2}`
```

---

## 4. Column Profile — UNION ALL Pattern

Generate one row per column with type-appropriate stats. Use `UNION ALL` over pivoting for readability and correctness.

### String column profile
```sql
SELECT
    '{col_name}'                                                   AS `column_name`,
    'string'                                                       AS `data_type`,
    COUNT(`{col_name}`)                                            AS `non_null_count`,
    COUNT(*) - COUNT(`{col_name}`)                                 AS `null_count`,
    ROUND(COUNT(`{col_name}`) * 100.0 / NULLIF(COUNT(*), 0), 2)   AS `fill_pct`,
    APPROX_COUNT_DISTINCT(`{col_name}`)                            AS `approx_distinct`,
    MIN(LENGTH(`{col_name}`))                                      AS `min_length`,
    MAX(LENGTH(`{col_name}`))                                      AS `max_length`,
    ROUND(AVG(LENGTH(`{col_name}`)), 1)                            AS `avg_length`,
    NULL                                                           AS `min_value`,
    NULL                                                           AS `max_value`,
    NULL                                                           AS `mean_value`,
    NULL                                                           AS `stddev_value`
FROM `{catalog}`.`{schema}`.`{table}`
```

### Numeric column profile
```sql
SELECT
    '{col_name}'                                                   AS `column_name`,
    'numeric'                                                      AS `data_type`,
    COUNT(`{col_name}`)                                            AS `non_null_count`,
    COUNT(*) - COUNT(`{col_name}`)                                 AS `null_count`,
    ROUND(COUNT(`{col_name}`) * 100.0 / NULLIF(COUNT(*), 0), 2)   AS `fill_pct`,
    APPROX_COUNT_DISTINCT(`{col_name}`)                            AS `approx_distinct`,
    NULL                                                           AS `min_length`,
    NULL                                                           AS `max_length`,
    NULL                                                           AS `avg_length`,
    MIN(`{col_name}`)                                              AS `min_value`,
    MAX(`{col_name}`)                                              AS `max_value`,
    ROUND(AVG(`{col_name}`), 4)                                    AS `mean_value`,
    ROUND(STDDEV(`{col_name}`), 4)                                 AS `stddev_value`
FROM `{catalog}`.`{schema}`.`{table}`
```

### Date column profile
```sql
SELECT
    '{col_name}'                                                   AS `column_name`,
    'date'                                                         AS `data_type`,
    COUNT(`{col_name}`)                                            AS `non_null_count`,
    COUNT(*) - COUNT(`{col_name}`)                                 AS `null_count`,
    ROUND(COUNT(`{col_name}`) * 100.0 / NULLIF(COUNT(*), 0), 2)   AS `fill_pct`,
    APPROX_COUNT_DISTINCT(`{col_name}`)                            AS `approx_distinct`,
    NULL                                                           AS `min_length`,
    NULL                                                           AS `max_length`,
    NULL                                                           AS `avg_length`,
    CAST(MIN(`{col_name}`) AS STRING)                              AS `min_value`,
    CAST(MAX(`{col_name}`) AS STRING)                              AS `max_value`,
    NULL                                                           AS `mean_value`,
    NULL                                                           AS `stddev_value`
FROM `{catalog}`.`{schema}`.`{table}`
```

**Full profile: connect all blocks with `UNION ALL`**

---

## 5. Top Values Block

```sql
-- ─── TOP 10 VALUES ────────────────────────────────────────────────────────────
SELECT
    CAST(`{col_name}` AS STRING)                                   AS `value`,
    COUNT(*)                                                       AS `frequency`,
    ROUND(COUNT(*) * 100.0 / NULLIF(SUM(COUNT(*)) OVER (), 0), 2) AS `pct_of_total`
FROM `{catalog}`.`{schema}`.`{table}`
WHERE `{col_name}` IS NOT NULL
GROUP BY `{col_name}`
ORDER BY frequency DESC
LIMIT 10;
```

---

## 6. Numeric Distribution Block

```sql
-- ─── NUMERIC DISTRIBUTION ─────────────────────────────────────────────────────
SELECT
    ROUND(PERCENTILE_APPROX(`{col_name}`, 0.0),  2) AS `p0_min`,
    ROUND(PERCENTILE_APPROX(`{col_name}`, 0.25), 2) AS `p25`,
    ROUND(PERCENTILE_APPROX(`{col_name}`, 0.50), 2) AS `p50_median`,
    ROUND(PERCENTILE_APPROX(`{col_name}`, 0.75), 2) AS `p75`,
    ROUND(PERCENTILE_APPROX(`{col_name}`, 0.90), 2) AS `p90`,
    ROUND(PERCENTILE_APPROX(`{col_name}`, 0.95), 2) AS `p95`,
    ROUND(PERCENTILE_APPROX(`{col_name}`, 0.99), 2) AS `p99`,
    ROUND(PERCENTILE_APPROX(`{col_name}`, 1.0),  2) AS `p100_max`,
    ROUND(AVG(`{col_name}`),                     4) AS `mean`,
    ROUND(STDDEV(`{col_name}`),                  4) AS `stddev`
FROM `{catalog}`.`{schema}`.`{table}`
WHERE `{col_name}` IS NOT NULL;
```

---

## 7. Temporal Trend Block

```sql
-- ─── TEMPORAL TREND ───────────────────────────────────────────────────────────
SELECT
    DATE_TRUNC('month', `{date_column}`)           AS `month`,
    COUNT(*)                                        AS `row_count`,
    ROUND(AVG(`{metric_column}`), 2)               AS `avg_{metric_column}`,
    SUM(`{metric_column}`)                         AS `total_{metric_column}`,
    APPROX_COUNT_DISTINCT(`{pk_column}`)           AS `distinct_{pk_column}`
FROM `{catalog}`.`{schema}`.`{table}`
WHERE `{date_column}` >= DATE_SUB(CURRENT_DATE(), 365)
  AND `{date_column}` <  CURRENT_DATE()
GROUP BY DATE_TRUNC('month', `{date_column}`)
ORDER BY `month`;
```

---

## 8. DQ Score Block (inline, no separate table)

```sql
-- ─── DQ SCORECARD ─────────────────────────────────────────────────────────────
WITH metrics AS (
    SELECT
        COUNT(*)                                                          AS total,
        COUNT(`{pk_column}`)                                              AS non_null_pk,
        COUNT(DISTINCT `{pk_column}`)                                     AS distinct_pk,
        COUNT(`{required_col1}`)                                          AS non_null_req1,
        COUNT(`{required_col2}`)                                          AS non_null_req2,
        COUNT_IF(`{date_column}` <= CURRENT_TIMESTAMP())                  AS valid_dates,
        COUNT_IF(CAST(`{numeric_col}` AS DOUBLE) >= 0)                   AS non_negative_nums
    FROM `{catalog}`.`{schema}`.`{table}`
)
SELECT
    ROUND(non_null_pk   * 100.0 / NULLIF(total, 0), 1)    AS `pk_completeness_pct`,
    ROUND(distinct_pk   * 100.0 / NULLIF(total, 0), 1)    AS `pk_uniqueness_pct`,
    ROUND(non_null_req1 * 100.0 / NULLIF(total, 0), 1)    AS `req1_completeness_pct`,
    ROUND(non_null_req2 * 100.0 / NULLIF(total, 0), 1)    AS `req2_completeness_pct`,
    ROUND(valid_dates   * 100.0 / NULLIF(total, 0), 1)    AS `date_validity_pct`,
    ROUND(non_negative_nums * 100.0 / NULLIF(total, 0), 1) AS `numeric_validity_pct`
FROM metrics;
```

---

## Domain-Specific Analytical Queries

### Retail — Customer RFM (Recency, Frequency, Monetary)
```sql
WITH rfm_base AS (
    SELECT
        `customer_id`,
        DATEDIFF(CURRENT_DATE(), MAX(`order_date`))   AS `recency_days`,
        COUNT(DISTINCT `order_id`)                    AS `frequency`,
        ROUND(SUM(`total_amount`), 2)                 AS `monetary`
    FROM `{catalog}`.`{schema}`.`orders`
    GROUP BY `customer_id`
)
SELECT
    `customer_id`,
    `recency_days`,
    `frequency`,
    `monetary`,
    NTILE(5) OVER (ORDER BY `recency_days` ASC)  AS `r_score`,
    NTILE(5) OVER (ORDER BY `frequency` DESC)    AS `f_score`,
    NTILE(5) OVER (ORDER BY `monetary` DESC)     AS `m_score`
FROM rfm_base;
```

### Banking — Account Balance Distribution
```sql
SELECT
    CASE
        WHEN `balance` < 0      THEN 'Overdrawn'
        WHEN `balance` = 0      THEN 'Zero'
        WHEN `balance` < 1000   THEN '$0–$1k'
        WHEN `balance` < 10000  THEN '$1k–$10k'
        WHEN `balance` < 100000 THEN '$10k–$100k'
        ELSE '$100k+'
    END                    AS `balance_band`,
    COUNT(*)               AS `account_count`,
    ROUND(AVG(`balance`), 2) AS `avg_balance`,
    SUM(`balance`)         AS `total_balance`
FROM `{catalog}`.`{schema}`.`accounts`
GROUP BY 1
ORDER BY MIN(`balance`);
```

### Healthcare — Encounter Frequency
```sql
SELECT
    `provider_id`,
    COUNT(DISTINCT `encounter_id`)                          AS `total_encounters`,
    COUNT(DISTINCT `patient_id`)                           AS `unique_patients`,
    ROUND(COUNT(DISTINCT `encounter_id`) * 1.0
          / NULLIF(COUNT(DISTINCT `patient_id`), 0), 2)    AS `encounters_per_patient`,
    COUNT_IF(`status` = 'COMPLETED')                       AS `completed`,
    COUNT_IF(`status` = 'NO_SHOW')                         AS `no_shows`,
    ROUND(COUNT_IF(`status` = 'NO_SHOW') * 100.0
          / NULLIF(COUNT(*), 0), 2)                        AS `no_show_rate_pct`
FROM `{catalog}`.`{schema}`.`encounters`
GROUP BY `provider_id`
ORDER BY `total_encounters` DESC
LIMIT 20;
```

### HR — Headcount and Attrition
```sql
SELECT
    `department_id`,
    COUNT_IF(`employment_status` = 'ACTIVE')              AS `active_headcount`,
    COUNT_IF(`employment_status` = 'TERMINATED')          AS `terminated_ytd`,
    ROUND(COUNT_IF(`employment_status` = 'TERMINATED')
          * 100.0 / NULLIF(COUNT(*), 0), 2)               AS `attrition_rate_pct`,
    ROUND(AVG(DATEDIFF(CURRENT_DATE(), `hire_date`))
          / 365.25, 1)                                    AS `avg_tenure_years`
FROM `{catalog}`.`{schema}`.`employees`
WHERE YEAR(`hire_date`) >= YEAR(CURRENT_DATE()) - 1
   OR `employment_status` = 'ACTIVE'
GROUP BY `department_id`
ORDER BY `active_headcount` DESC;
```

---

## Formatting Rules

1. All column names in backticks: `` `column_name` ``
2. All table references fully qualified: `` `catalog`.`schema`.`table` ``
3. All division expressions wrapped: `NULLIF(denominator, 0)`
4. All percentages: `ROUND(... * 100.0 / NULLIF(total, 0), 2)`
5. Use `APPROX_COUNT_DISTINCT` (not `COUNT(DISTINCT)`) on large tables
6. Use `PERCENTILE_APPROX` (not `PERCENTILE`) for quartiles
7. Use CTEs (not subqueries) for multi-step logic
8. Alias all calculated columns with descriptive backtick names
