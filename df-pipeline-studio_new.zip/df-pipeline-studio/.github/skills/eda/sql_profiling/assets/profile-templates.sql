-- ─────────────────────────────────────────────────────────────────────────────
-- data_forge SQL Profiling Suite — Copy-Paste Templates
-- Replace: {catalog}, {schema}, {table}, {pk}, {date_col}, {metric_col}
-- All SQL: Databricks Spark SQL
-- ─────────────────────────────────────────────────────────────────────────────


-- ════════════════════════════════════════════════════════════════════════════
-- TEMPLATE 1: TABLE OVERVIEW
-- ════════════════════════════════════════════════════════════════════════════
SELECT
    COUNT(*)                                             AS `total_rows`,
    COUNT(DISTINCT `{pk}`)                               AS `distinct_pks`,
    COUNT(*) - COUNT(DISTINCT `{pk}`)                    AS `duplicate_count`,
    MIN(`{date_col}`)                                    AS `earliest_record`,
    MAX(`{date_col}`)                                    AS `latest_record`,
    DATEDIFF(MAX(`{date_col}`), MIN(`{date_col}`))       AS `date_span_days`,
    COUNT_IF(`{date_col}` >= DATE_SUB(CURRENT_DATE(), 7))  AS `rows_last_7d`,
    COUNT_IF(`{date_col}` >= DATE_SUB(CURRENT_DATE(), 30)) AS `rows_last_30d`,
    COUNT_IF(`{date_col}` >= DATE_SUB(CURRENT_DATE(), 90)) AS `rows_last_90d`
FROM `{catalog}`.`{schema}`.`{table}`;


-- ════════════════════════════════════════════════════════════════════════════
-- TEMPLATE 2: FILL RATE — add one line per column
-- ════════════════════════════════════════════════════════════════════════════
SELECT
    COUNT(*)                                                                AS `total_rows`,
    -- Repeat block below for every column:
    ROUND(COUNT(`{col1}`) * 100.0 / NULLIF(COUNT(*), 0), 2)               AS `{col1}_fill_pct`,
    ROUND(COUNT(`{col2}`) * 100.0 / NULLIF(COUNT(*), 0), 2)               AS `{col2}_fill_pct`,
    ROUND(COUNT(`{col3}`) * 100.0 / NULLIF(COUNT(*), 0), 2)               AS `{col3}_fill_pct`
FROM `{catalog}`.`{schema}`.`{table}`;


-- ════════════════════════════════════════════════════════════════════════════
-- TEMPLATE 3: DUPLICATE DETECTION
-- ════════════════════════════════════════════════════════════════════════════
WITH dup_check AS (
    SELECT
        `{pk}`,
        COUNT(*)  AS `row_count`
    FROM `{catalog}`.`{schema}`.`{table}`
    GROUP BY `{pk}`
    HAVING COUNT(*) > 1
)
SELECT
    COUNT(*)          AS `duplicate_key_count`,
    SUM(`row_count`)  AS `total_affected_rows`,
    MAX(`row_count`)  AS `max_copies_of_one_key`
FROM dup_check;


-- ════════════════════════════════════════════════════════════════════════════
-- TEMPLATE 4: COLUMN PROFILE — UNION ALL (add blocks per column)
-- ════════════════════════════════════════════════════════════════════════════
-- STRING column block
SELECT '{col_string}' AS `column_name`, 'string' AS `data_type`,
    COUNT(`{col_string}`)                                                   AS `non_null`,
    COUNT(*) - COUNT(`{col_string}`)                                        AS `null_count`,
    ROUND(COUNT(`{col_string}`) * 100.0 / NULLIF(COUNT(*), 0), 2)          AS `fill_pct`,
    APPROX_COUNT_DISTINCT(`{col_string}`)                                   AS `distinct_count`,
    MIN(LENGTH(`{col_string}`))                                             AS `min_len`,
    MAX(LENGTH(`{col_string}`))                                             AS `max_len`,
    ROUND(AVG(LENGTH(`{col_string}`)), 1)                                   AS `avg_len`,
    CAST(NULL AS STRING) AS `min_val`, CAST(NULL AS STRING) AS `max_val`,
    CAST(NULL AS DOUBLE) AS `mean`,    CAST(NULL AS DOUBLE) AS `stddev`
FROM `{catalog}`.`{schema}`.`{table}`
UNION ALL
-- NUMERIC column block
SELECT '{col_num}' AS `column_name`, 'numeric' AS `data_type`,
    COUNT(`{col_num}`)                                                      AS `non_null`,
    COUNT(*) - COUNT(`{col_num}`)                                           AS `null_count`,
    ROUND(COUNT(`{col_num}`) * 100.0 / NULLIF(COUNT(*), 0), 2)             AS `fill_pct`,
    APPROX_COUNT_DISTINCT(`{col_num}`)                                      AS `distinct_count`,
    CAST(NULL AS BIGINT) AS `min_len`, CAST(NULL AS BIGINT) AS `max_len`,
    CAST(NULL AS DOUBLE) AS `avg_len`,
    CAST(MIN(`{col_num}`) AS STRING)                                        AS `min_val`,
    CAST(MAX(`{col_num}`) AS STRING)                                        AS `max_val`,
    ROUND(AVG(`{col_num}`), 4)                                              AS `mean`,
    ROUND(STDDEV(`{col_num}`), 4)                                           AS `stddev`
FROM `{catalog}`.`{schema}`.`{table}`
UNION ALL
-- DATE column block
SELECT '{col_date}' AS `column_name`, 'date' AS `data_type`,
    COUNT(`{col_date}`)                                                     AS `non_null`,
    COUNT(*) - COUNT(`{col_date}`)                                          AS `null_count`,
    ROUND(COUNT(`{col_date}`) * 100.0 / NULLIF(COUNT(*), 0), 2)            AS `fill_pct`,
    APPROX_COUNT_DISTINCT(`{col_date}`)                                     AS `distinct_count`,
    CAST(NULL AS BIGINT) AS `min_len`, CAST(NULL AS BIGINT) AS `max_len`,
    CAST(NULL AS DOUBLE) AS `avg_len`,
    CAST(MIN(`{col_date}`) AS STRING)                                       AS `min_val`,
    CAST(MAX(`{col_date}`) AS STRING)                                       AS `max_val`,
    CAST(NULL AS DOUBLE) AS `mean`, CAST(NULL AS DOUBLE) AS `stddev`
FROM `{catalog}`.`{schema}`.`{table}`;


-- ════════════════════════════════════════════════════════════════════════════
-- TEMPLATE 5: TOP 10 VALUES PER COLUMN
-- ════════════════════════════════════════════════════════════════════════════
SELECT
    CAST(`{col_name}` AS STRING)                                            AS `value`,
    COUNT(*)                                                                AS `frequency`,
    ROUND(COUNT(*) * 100.0 / NULLIF(SUM(COUNT(*)) OVER (), 0), 2)          AS `pct_of_total`
FROM `{catalog}`.`{schema}`.`{table}`
WHERE `{col_name}` IS NOT NULL
GROUP BY `{col_name}`
ORDER BY `frequency` DESC
LIMIT 10;


-- ════════════════════════════════════════════════════════════════════════════
-- TEMPLATE 6: NUMERIC DISTRIBUTION (percentiles)
-- ════════════════════════════════════════════════════════════════════════════
SELECT
    ROUND(PERCENTILE_APPROX(`{col_num}`, 0.00), 2)   AS `p0_min`,
    ROUND(PERCENTILE_APPROX(`{col_num}`, 0.25), 2)   AS `p25`,
    ROUND(PERCENTILE_APPROX(`{col_num}`, 0.50), 2)   AS `p50_median`,
    ROUND(PERCENTILE_APPROX(`{col_num}`, 0.75), 2)   AS `p75`,
    ROUND(PERCENTILE_APPROX(`{col_num}`, 0.90), 2)   AS `p90`,
    ROUND(PERCENTILE_APPROX(`{col_num}`, 0.95), 2)   AS `p95`,
    ROUND(PERCENTILE_APPROX(`{col_num}`, 0.99), 2)   AS `p99`,
    ROUND(PERCENTILE_APPROX(`{col_num}`, 1.00), 2)   AS `p100_max`,
    ROUND(AVG(`{col_num}`),    4)                     AS `mean`,
    ROUND(STDDEV(`{col_num}`), 4)                     AS `stddev`
FROM `{catalog}`.`{schema}`.`{table}`
WHERE `{col_num}` IS NOT NULL;


-- ════════════════════════════════════════════════════════════════════════════
-- TEMPLATE 7: MONTHLY TREND
-- ════════════════════════════════════════════════════════════════════════════
SELECT
    DATE_TRUNC('month', `{date_col}`)               AS `month`,
    COUNT(*)                                         AS `row_count`,
    APPROX_COUNT_DISTINCT(`{pk}`)                    AS `distinct_records`,
    ROUND(SUM(`{metric_col}`), 2)                    AS `total_{metric_col}`,
    ROUND(AVG(`{metric_col}`), 2)                    AS `avg_{metric_col}`
FROM `{catalog}`.`{schema}`.`{table}`
WHERE `{date_col}` >= DATE_SUB(CURRENT_DATE(), 365)
  AND `{date_col}` <  CURRENT_DATE()
GROUP BY DATE_TRUNC('month', `{date_col}`)
ORDER BY `month`;


-- ════════════════════════════════════════════════════════════════════════════
-- TEMPLATE 8: DQ SCORECARD
-- ════════════════════════════════════════════════════════════════════════════
WITH raw AS (
    SELECT
        COUNT(*)                                                         AS `total`,
        COUNT(`{pk}`)                                                    AS `non_null_pk`,
        COUNT(DISTINCT `{pk}`)                                           AS `unique_pk`,
        COUNT(`{required_col}`)                                          AS `non_null_req`,
        COUNT_IF(`{date_col}` BETWEEN '2000-01-01' AND CURRENT_DATE())   AS `valid_date`,
        COUNT_IF(CAST(`{amount_col}` AS DOUBLE) >= 0)                    AS `non_negative`
    FROM `{catalog}`.`{schema}`.`{table}`
)
SELECT
    ROUND(`non_null_pk`   * 100.0 / NULLIF(`total`, 0), 1)  AS `pk_completeness_pct`,
    ROUND(`unique_pk`     * 100.0 / NULLIF(`total`, 0), 1)  AS `pk_uniqueness_pct`,
    ROUND(`non_null_req`  * 100.0 / NULLIF(`total`, 0), 1)  AS `required_fill_pct`,
    ROUND(`valid_date`    * 100.0 / NULLIF(`total`, 0), 1)  AS `date_validity_pct`,
    ROUND(`non_negative`  * 100.0 / NULLIF(`total`, 0), 1)  AS `amount_validity_pct`,
    -- Weighted overall: completeness 35%, uniqueness 30%, validity 35%
    ROUND(
        (`non_null_pk`  * 100.0 / NULLIF(`total`, 0)) * 0.35
      + (`unique_pk`    * 100.0 / NULLIF(`total`, 0)) * 0.30
      + (`valid_date`   * 100.0 / NULLIF(`total`, 0)) * 0.35,
    1)                                                       AS `overall_dq_score`
FROM raw;


-- ════════════════════════════════════════════════════════════════════════════
-- TEMPLATE 9: WRITE PROFILING RESULTS TO DELTA
-- ════════════════════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS `{catalog}`.`{schema}`.`profiling_results`
USING DELTA
TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true')
AS
SELECT
    '{table}'                AS `source_table`,
    CURRENT_TIMESTAMP()      AS `profiled_at`,
    `column_name`,
    `data_type`,
    `non_null`,
    `null_count`,
    `fill_pct`,
    `distinct_count`,
    `min_val`,
    `max_val`,
    `mean`,
    `stddev`
FROM (
    -- paste TEMPLATE 4 column profile UNION ALL here
    SELECT NULL AS `column_name`, NULL AS `data_type`,
           0 AS `non_null`, 0 AS `null_count`, 0.0 AS `fill_pct`,
           0 AS `distinct_count`, NULL AS `min_val`, NULL AS `max_val`,
           NULL AS `mean`, NULL AS `stddev`
    LIMIT 0  -- placeholder — replace with actual UNION ALL profile
);
