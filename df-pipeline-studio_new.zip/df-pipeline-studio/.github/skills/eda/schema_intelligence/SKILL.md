# Skill: Schema Intelligence

```
skill:    eda.schema_intelligence
version:  2.0
trigger:  "analyze schema", "classify columns", "detect PII", "governance", "tags"
outputs:  output/eda/{pipeline_name}/reports/schema_report.md, output/eda/{pipeline_name}/sql/unity_catalog_tags.sql
```

---

## Purpose

Read the table descriptions from `spec.md` and produce:
1. A semantic classification for every column
2. A zero-false-negative PII audit
3. A governance readiness score per table (0-100)
4. Unity Catalog SQL to tag and mask PII columns

---

## Step-by-step instructions

### Step 1 — Extract all columns from spec.md

For each table, list every column with its name and data type.
If data type is not stated, infer from the column name:
- `*_id`, `*_key`, `*_code` → STRING
- `*_date`, `*_at`, `*_time` → TIMESTAMP
- `*_amount`, `*_price`, `*_balance`, `*_score` → DECIMAL(18,2)
- `*_count`, `*_qty`, `*_num` → INT or BIGINT
- `is_*`, `has_*`, `*_flag`, `*_ind` → BOOLEAN
- Everything else → STRING

### Step 2 — Classify each column

Assign one semantic class from this taxonomy:

| Class | Column patterns | Examples |
|-------|----------------|---------|
| `key` | `*_id`, `*_pk`, `*_sk`, `*_key` that are primary/foreign keys | customer_id, order_id |
| `identity` | name, gender, date_of_birth, date_of_death | first_name, gender, dob |
| `contact` | email, phone, mobile, fax, contact_* | email, phone_number |
| `address` | address, street, city, state, zip, postcode, country | city, zip_code |
| `government` | ssn, passport, national_id, pan, tin, driving_license | ssn, passport_no |
| `financial` | balance, amount, price, credit_limit, account_no, card_no | account_balance |
| `transaction` | order_*, transaction_*, payment_*, shipment_* that are IDs or dates | order_date |
| `risk` | fraud_*, risk_*, sanctions_*, blacklist_* | fraud_score, risk_flag |
| `date` | created_at, updated_at, effective_date, expiry_date | created_at, expiry |
| `metric` | count, total, average, rate, ratio, pct, score | churn_score, revenue |
| `metadata` | source_*, batch_*, etl_*, load_*, _version, _hash | source_system |

### Step 3 — PII detection (zero-false-negative)

Flag a column as PII if it could contain personal data under GDPR/CCPA/HIPAA.
**When in doubt — flag it.**

For each PII column, record:
- `pii_type` — from the catalogue below
- `severity` — CRITICAL / HIGH / MEDIUM
- `regulation` — which laws apply
- `masking_sql` — the masking expression

| PII Type | Severity | Regulations | Column keywords |
|----------|----------|------------|----------------|
| ssn | CRITICAL | GDPR, CCPA, HIPAA | ssn, social_security, national_id |
| credit_card | CRITICAL | PCI-DSS | card_number, credit_card, card_no, pan |
| bank_account | CRITICAL | GDPR, PCI-DSS | account_number, iban, bsb, sort_code |
| passport | CRITICAL | GDPR, CCPA | passport, passport_number, passport_no |
| driving_license | CRITICAL | GDPR, CCPA | driving_license, dl_number, license_no |
| biometric | CRITICAL | GDPR, BIPA | fingerprint, face_id, biometric, iris |
| medical_record | CRITICAL | HIPAA | mrn, diagnosis, icd_code, patient_id, condition |
| email | HIGH | GDPR, CCPA, CAN-SPAM | email, email_address, e_mail |
| phone | HIGH | GDPR, CCPA, TCPA | phone, mobile, cell, telephone, contact_no |
| dob | HIGH | GDPR, CCPA, HIPAA | dob, date_of_birth, birth_date, birthdate |
| name | HIGH | GDPR, CCPA | first_name, last_name, full_name, name, preferred_name |
| address | MEDIUM | GDPR, CCPA | address, street, addr, residence, location |
| ip_address | MEDIUM | GDPR | ip_address, ip_addr, client_ip, remote_ip |
| national_id | MEDIUM | Country-specific | national_id, tax_id, tin, pan_number, vat |

### Step 4 — Governance scoring

Score each table 0–100 on two dimensions:

**Consumer Readiness Score** (how ready for golden record / analytics use):
- Has primary key → +20
- Has a date column for time-series → +15
- Has at least one contact field → +15
- Has identity fields (name, DOB) → +15
- No critical PII without masking → +20
- Has source system metadata → +15
- (cap at 100)

**Governance Risk Score** (how urgently access controls are needed):
- Has CRITICAL PII → +30 per type (cap at 60)
- Has HIGH PII → +10 per type (cap at 30)
- Has MEDIUM PII → +5 per type (cap at 10)
- (cap at 100)

### Step 5 — Generate output files

#### `output/eda/{pipeline_name}/reports/schema_report.md`

```markdown
# Schema Intelligence Report

## [Table Name]

**Domain:** [detected domain]
**Table type:** master | transaction | reference | bridge
**Consumer Readiness:** [N]/100
**Governance Risk:** [N]/100

### Column Intelligence

| Column | Type | Class | PII | Severity | AI Description |
|--------|------|-------|-----|----------|----------------|
| customer_id | STRING | key | - | - | Primary surrogate key |
| email | STRING | contact | email | HIGH | Contact email — GDPR, CCPA |
| ssn | STRING | government | ssn | CRITICAL | Social security number — HIPAA, CCPA |

### Missing recommended columns
[List any standard columns that are absent but expected for this domain/table type]

### Recommendations
[List optimization, partitioning, and governance recommendations]
```

#### `output/eda/{pipeline_name}/sql/unity_catalog_tags.sql`

```sql
-- Table-level tags
ALTER TABLE [catalog].[schema].[table]
SET TAGS ('domain' = '[domain]', 'primary_entity' = '[entity]', 'table_type' = '[type]');

-- Column PII tags (one per PII column)
ALTER TABLE [catalog].[schema].[table]
ALTER COLUMN `[pii_column]` SET TAGS ('pii' = 'true', 'pii_type' = '[type]', 'regulation' = '[reg]');
```

