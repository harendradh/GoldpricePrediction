# PII Catalogue — Complete Type Reference

## Zero-False-Negative Principle

Flag anything that _could_ contain personal data. A false positive costs a review. A false negative costs a GDPR fine.

---

## 14 PII Types — Full Detail

### 1. `ssn` — Social Security Number
**Severity:** CRITICAL  
**Regulations:** GDPR Art. 9, CCPA §1798.140, HIPAA  
**Column signals:** `ssn`, `social_security`, `sin`, `social_insurance`, `nino`, `national_insurance`  
**Value patterns:** `\d{3}-\d{2}-\d{4}`, `\d{9}`, `\d{3} \d{2} \d{4}`  
**Masking:** `CONCAT('***-**-', RIGHT(CAST(\`col\` AS STRING), 4))`  
**Retention:** 7 years after relationship end  
**Tags required:** `pii_type=ssn`, `pii_severity=critical`, `gdpr_article=9`

---

### 2. `credit_card` — Payment Card Number
**Severity:** CRITICAL  
**Regulations:** PCI-DSS v4, GDPR Art. 6  
**Column signals:** `card_number`, `card_no`, `pan`, `cc_number`, `credit_card`, `debit_card`, `payment_card`  
**Value patterns:** `\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{4}`, Luhn-valid 13–19 digit strings  
**Masking:** `CONCAT('****-****-****-', RIGHT(CAST(\`col\` AS STRING), 4))`  
**Retention:** Transaction duration + 1 year (PCI-DSS)  
**Tags required:** `pii_type=credit_card`, `pii_severity=critical`, `pci_dss=true`

---

### 3. `bank_account` — Bank Account Number
**Severity:** CRITICAL  
**Regulations:** GDPR Art. 9, PCI-DSS, GLBA  
**Column signals:** `account_number`, `bank_account`, `iban`, `bic`, `swift`, `routing_number`, `account_no`, `acct_no`  
**Value patterns:** IBAN: `[A-Z]{2}\d{2}[A-Z0-9]{4,30}`, BBAN: varies by country  
**Masking:** `SHA2(CAST(\`col\` AS STRING), 256)`  
**Retention:** 7 years (financial regulation)  
**Tags required:** `pii_type=bank_account`, `pii_severity=critical`

---

### 4. `passport` — Passport Number
**Severity:** CRITICAL  
**Regulations:** GDPR Art. 9, CCPA, EU Passport Regulation  
**Column signals:** `passport`, `passport_number`, `passport_no`, `travel_doc`  
**Value patterns:** Country-specific; typically 6–9 alphanumeric characters  
**Masking:** `SHA2(CAST(\`col\` AS STRING), 256)`  
**Retention:** Strictly purpose-limited; delete after verification  
**Tags required:** `pii_type=passport`, `pii_severity=critical`, `gdpr_article=9`

---

### 5. `driving_license` — Driver's License Number
**Severity:** CRITICAL  
**Regulations:** GDPR Art. 9, CCPA, DPPA (US)  
**Column signals:** `driving_license`, `drivers_license`, `license_number`, `licence_no`, `dl_number`, `driving_licence`  
**Value patterns:** Country/state-specific alphanumeric formats  
**Masking:** `SHA2(CAST(\`col\` AS STRING), 256)`  
**Retention:** Delete after identity verification complete  
**Tags required:** `pii_type=driving_license`, `pii_severity=critical`, `gdpr_article=9`

---

### 6. `biometric` — Biometric Data
**Severity:** CRITICAL  
**Regulations:** GDPR Art. 9, BIPA (Illinois), CCPA  
**Column signals:** `fingerprint`, `face_id`, `retina_scan`, `voice_print`, `biometric`, `facial_embedding`, `iris_scan`  
**Value patterns:** Usually binary blobs or base64 strings  
**Masking:** `SHA2(CAST(\`col\` AS STRING), 256)` (irreversible)  
**Retention:** Delete immediately after purpose; no retention  
**Tags required:** `pii_type=biometric`, `pii_severity=critical`, `gdpr_article=9`, `bipa=true`

---

### 7. `medical_record` — Health and Medical Data
**Severity:** CRITICAL  
**Regulations:** HIPAA, GDPR Art. 9, HiTECH  
**Column signals:** `diagnosis`, `medical_record`, `mrn`, `icd_code`, `condition`, `prescription`, `health_data`, `clinical_note`, `lab_result`, `medication`  
**Value patterns:** ICD-10: `[A-Z]\d{2}(\.\d{1,4})?`; MRN: varies by provider  
**Masking:** `SHA2(CAST(\`col\` AS STRING), 256)`  
**Retention:** 10 years (HIPAA minimum)  
**Tags required:** `pii_type=medical_record`, `pii_severity=critical`, `hipaa=true`, `gdpr_article=9`

---

### 8. `email` — Email Address
**Severity:** HIGH  
**Regulations:** GDPR Art. 6, CCPA, CAN-SPAM, CASL  
**Column signals:** `email`, `email_address`, `e_mail`, `mail`, `contact_email`, `work_email`, `personal_email`  
**Value patterns:** `[^@]+@[^@]+\.[^@]+`  
**Masking:** `CONCAT(LEFT(CAST(\`col\` AS STRING), 2), '***@', SPLIT(CAST(\`col\` AS STRING), '@')[1])`  
**Retention:** Duration of consent + 1 year  
**Tags required:** `pii_type=email`, `pii_severity=high`

---

### 9. `phone` — Phone Number
**Severity:** HIGH  
**Regulations:** GDPR Art. 6, CCPA, TCPA, CASL  
**Column signals:** `phone`, `phone_number`, `mobile`, `mobile_number`, `telephone`, `tel`, `contact_number`, `cell_phone`, `fax`  
**Value patterns:** E.164: `\+\d{7,15}`; local: `\d{3}[- .]\d{3}[- .]\d{4}`  
**Masking:** `CONCAT('***-***-', RIGHT(REGEXP_REPLACE(CAST(\`col\` AS STRING), '[^0-9]', ''), 4))`  
**Retention:** Duration of consent + 1 year  
**Tags required:** `pii_type=phone`, `pii_severity=high`

---

### 10. `dob` — Date of Birth
**Severity:** HIGH  
**Regulations:** GDPR Art. 9, CCPA, HIPAA (for patients)  
**Column signals:** `date_of_birth`, `dob`, `birth_date`, `birthdate`, `birthday`, `born_on`, `birth_year`  
**Value patterns:** ISO dates, epoch timestamps — any date column paired with `birth`/`dob` naming  
**Masking:** `DATE_TRUNC('year', \`col\`)` (preserves year, removes month/day)  
**Retention:** Duration of relationship + 2 years  
**Tags required:** `pii_type=dob`, `pii_severity=high`

---

### 11. `name` — Personal Name
**Severity:** HIGH  
**Regulations:** GDPR Art. 6, CCPA  
**Column signals:** `first_name`, `last_name`, `full_name`, `middle_name`, `surname`, `given_name`, `family_name`, `display_name`, `customer_name`, `user_name` (when it stores real names not handles)  
**Value patterns:** Alphabetic strings; may contain spaces, hyphens, apostrophes  
**Masking:** `CONCAT(LEFT(CAST(\`col\` AS STRING), 1), '***')`  
**Retention:** Duration of relationship + 1 year  
**Tags required:** `pii_type=name`, `pii_severity=high`

---

### 12. `address` — Physical Address
**Severity:** MEDIUM  
**Regulations:** GDPR Art. 6, CCPA  
**Column signals:** `address`, `address_line1`, `address_line2`, `street`, `street_address`, `postal_address`, `mailing_address`  
**Value patterns:** Free text with street numbers, names, suffixes  
**Masking:** `SHA2(CAST(\`col\` AS STRING), 256)`  
**Retention:** Duration of relationship + 2 years  
**Tags required:** `pii_type=address`, `pii_severity=medium`

---

### 13. `ip_address` — IP Address
**Severity:** MEDIUM  
**Regulations:** GDPR Art. 6 (classified as personal data in EU), CCPA  
**Column signals:** `ip_address`, `ip_addr`, `client_ip`, `source_ip`, `remote_addr`, `user_ip`  
**Value patterns:** IPv4: `\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}`; IPv6: `[0-9a-fA-F:]+`  
**Masking:** `REGEXP_REPLACE(CAST(\`col\` AS STRING), '\\d+$', '***')` (masks last octet)  
**Retention:** 2 years (session/audit logs)  
**Tags required:** `pii_type=ip_address`, `pii_severity=medium`

---

### 14. `national_id` — National Identification Number
**Severity:** MEDIUM  
**Regulations:** Country-specific; GDPR Art. 9 where applicable  
**Column signals:** `national_id`, `national_number`, `citizen_id`, `resident_id`, `id_number`, `tax_id`, `ein`, `vat_number`, `abn`, `nif`, `nif_number`  
**Value patterns:** Vary by country  
**Masking:** `SHA2(CAST(\`col\` AS STRING), 256)`  
**Retention:** Purpose-limited; typically 7 years  
**Tags required:** `pii_type=national_id`, `pii_severity=medium`

---

## Indirect PII — Flag These Too

Columns that are not PII alone but become PII through combination:

| Column type | Why flag | Action |
|-------------|----------|--------|
| `age` | Combined with other data identifies individuals | Tag as `indirect_pii=true` |
| `gender` | Combined with location/DOB → identifiable | Tag as `indirect_pii=true` |
| `postcode` / `zip` | 5-digit zip alone can identify small populations | Tag as `indirect_pii=true` |
| `job_title` | In small orgs → directly identifiable | Tag as `indirect_pii=true` |
| `salary` | Financial + identity risk | Tag as `indirect_pii=true` |
| `device_id` | Persistent device tracking | Tag as `indirect_pii=true` |
| `cookie_id` | Browser tracking | Tag as `indirect_pii=true` |
| `user_agent` | Combined with IP → identifiable | Tag as `indirect_pii=true` |

---

## Unity Catalog Tag Template

```sql
ALTER TABLE `catalog`.`schema`.`table`
  ALTER COLUMN `column_name`
  SET TAGS (
    'pii_type'     = 'email',
    'pii_severity' = 'high',
    'gdpr_basis'   = 'consent',
    'retention'    = '1_year_post_consent',
    'masking'      = 'partial_email'
  );
```
