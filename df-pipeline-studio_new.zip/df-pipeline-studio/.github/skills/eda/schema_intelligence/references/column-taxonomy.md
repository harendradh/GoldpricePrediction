# Column Semantic Class Taxonomy

## Decision Tree

Use this taxonomy to assign one semantic class to every column.

```
Is this column the table's unique row identifier?
├── YES → key
└── NO → continue

Does this column identify a real-world entity (person, org, account)?
├── YES and it is the primary ID → identity
└── NO → continue

Does this column contain contact information?
├── email / phone / fax / mobile → contact
└── NO → continue

Does this column contain a physical location?
├── address / street / city / state / postcode / country / lat / lng → address
└── NO → continue

Does this column contain a government-issued ID?
├── ssn / passport / driving_license / national_id / tax_id / ein → government
└── NO → continue

Does this column contain money, banking, or payment data?
├── account_number / card / iban / routing / balance / credit_limit → financial
└── NO → continue

Does this column record a business event?
├── order_id / invoice_id / transaction_id / status / amount / quantity → transaction
└── NO → continue

Does this column score, predict, or flag risk?
├── score / risk / fraud_flag / churn_flag / credit_grade → risk
└── NO → continue

Is this column a date or timestamp?
├── _at / _date / _ts / _time / created / updated / started / ended → date
└── NO → continue

Is this column a numeric measure or KPI?
├── count / total / revenue / rate / ratio / pct / avg / sum → metric
└── NO → fall back to metadata
```

---

## 11 Semantic Classes — Quick Reference

| Class | Description | Example columns |
|-------|-------------|-----------------|
| `key` | Unique row identifier, primary key | `id`, `customer_id`, `order_id` |
| `identity` | Entity identifier (name, alias, handle) | `full_name`, `username`, `org_name` |
| `contact` | Communication channel data | `email`, `phone`, `mobile`, `fax` |
| `address` | Physical location data | `street`, `city`, `state`, `postcode`, `lat`, `lng` |
| `government` | Government-issued identifiers | `ssn`, `passport_no`, `driving_license`, `tax_id` |
| `financial` | Financial account and payment data | `bank_account`, `card_number`, `iban`, `balance` |
| `transaction` | Business event records | `order_id`, `invoice_id`, `status`, `amount`, `qty` |
| `risk` | Scores, flags, predictions | `risk_score`, `fraud_flag`, `churn_probability` |
| `date` | Temporal markers | `created_at`, `order_date`, `birth_date`, `updated_ts` |
| `metric` | Quantitative KPIs and measures | `revenue`, `item_count`, `fill_rate`, `avg_spend` |
| `metadata` | Everything else — admin, config, lineage | `source_system`, `batch_id`, `record_hash`, `is_deleted` |

---

## Naming Signal Patterns

### `key`
Exact: `id`, `pk`, `row_id`, `surrogate_key`
Suffix: `_id`, `_key`, `_pk`, `_sk`, `_no`

### `identity`
Exact: `name`, `full_name`, `first_name`, `last_name`, `username`, `display_name`, `alias`, `handle`
Substring: `_name`, `company_name`, `org_name`, `customer_name`

### `contact`
Exact: `email`, `phone`, `mobile`, `telephone`, `fax`, `contact_no`
Substring: `_email`, `_phone`, `_mobile`, `email_address`, `phone_number`

### `address`
Exact: `address`, `street`, `city`, `state`, `province`, `postcode`, `zip`, `zip_code`, `country`, `region`, `latitude`, `longitude`
Substring: `_address`, `_city`, `_state`, `_zip`, `_country`, `addr_`

### `government`
Exact: `ssn`, `sin`, `nino`, `passport`, `driving_license`, `national_id`, `tax_id`, `ein`, `vat_number`
Substring: `_ssn`, `_passport`, `_license`, `gov_id`, `tax_no`

### `financial`
Exact: `account_number`, `card_number`, `iban`, `bic`, `swift`, `routing_number`, `balance`, `credit_limit`
Substring: `_account`, `_card`, `bank_`, `payment_`, `_balance`, `_limit`

### `transaction`
Exact: `order_id`, `invoice_id`, `transaction_id`, `receipt_id`, `status`, `amount`, `quantity`, `price`, `discount`
Substring: `_order`, `_invoice`, `_txn`, `_transaction`, `_status`, `_amount`, `_qty`

### `risk`
Exact: `risk_score`, `fraud_flag`, `churn_flag`, `credit_grade`, `anomaly_score`
Substring: `_score`, `_flag`, `_risk`, `_fraud`, `_churn`, `_grade`, `_probability`, `_pred`

### `date`
Exact: `created_at`, `updated_at`, `deleted_at`, `birth_date`, `date_of_birth`, `start_date`, `end_date`, `effective_date`, `expiry_date`
Suffix: `_at`, `_date`, `_ts`, `_time`, `_on`, `_datetime`, `_timestamp`

### `metric`
Exact: `revenue`, `cost`, `profit`, `count`, `total`, `sum`, `avg`, `rate`, `ratio`, `pct`, `percentage`
Substring: `_count`, `_total`, `_revenue`, `_rate`, `_ratio`, `_pct`, `_avg`, `_sum`, `_min`, `_max`

### `metadata`
Fallback if no other class matches. Also:
Exact: `source_system`, `source_file`, `batch_id`, `etl_run_id`, `record_hash`, `is_deleted`, `is_active`, `load_date`
Substring: `_flag` (non-risk), `_ind`, `_indicator`, `is_`, `has_`, `_hash`, `_checksum`, `_version`

---

## Type Override Rules

These override naming signals when the SQL type is definitive:

| SQL type | Forced class |
|----------|-------------|
| `BOOLEAN` | metadata (unless name contains `fraud`, `churn`, `risk` → risk) |
| `DECIMAL` / `FLOAT` with `_pct` or `_rate` suffix | metric |
| `TIMESTAMP` / `DATE` | date (always) |
| `BINARY` | metadata |
| `ARRAY` / `MAP` | metadata |
