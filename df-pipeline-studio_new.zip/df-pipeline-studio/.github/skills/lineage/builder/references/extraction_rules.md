# Extraction rules · `lineage.builder`

> Exactly what to extract from each spec.md + each output JSON, so the
> lineage graph is built deterministically.

---

## From every `spec.md` (any phase)

### Common metadata block (regex)

Every spec has a YAML-ish metadata block. Extract these keys:

| Key | Regex | Required? |
|-----|-------|-----------|
| `pipeline_name` | `^\s*pipeline_name:\s*(.+?)\s*$` | yes (else use folder slug) |
| `catalog` | `^\s*catalog:\s*(.+?)\s*$` | for table FQN construction |
| `schema` | `^\s*schema:\s*(.+?)\s*$` | for table FQN construction |
| `subdomain` | `^\s*subdomain:\s*(.+?)\s*$` | metadata only |
| `domain` | `^\s*domain:\s*(.+?)\s*$` | metadata only |
| `target_fqn` | `^\s*target_fqn:\s*(.+?)\s*$` | ingestion only |
| `source_system` | `^\s*source_system:\s*(.+?)\s*$` | ingestion only |
| `source_table` | `^\s*source_table:\s*(.+?)\s*$` | ingestion / dataprep |
| `source_mode` | `^\s*source_mode:\s*(.+?)\s*$` | dataprep only |
| `mode` | `^\s*mode:\s*(.+?)\s*$` | docs only |
| `entity` / `header` | same pattern | eda only |

Strip surrounding backticks / quotes from captured values.

### Columns block

Find the first fenced code block following one of these headings:

- `Source columns`
- `Schema contract`
- `Table Columns`

```regex
(?:Source columns|Schema contract|Table Columns)[^\n]*\n+(?:[^\n]+\n+)*?```[a-z]*\n([\s\S]+?)\n```
```

Pass the captured block to `parseColumns()` then `classifyColumns()` (both implemented in the studio's column-classifier — agent can reproduce or use the studio's logic).

Stored per pipeline as:
```
{ name: 'customer_id', type: 'BIGINT', nullable: false, tags: ['id','pk'] }
```

---

## Per-phase edge construction

### Ingestion (`specs/ingestion/<slug>/spec.md`)

```
Node: source     id = src_<source_system_slug>          label = source_system
Node: pipeline   id = pipe_ingestion_<slug>             label = pipeline_name
Node: bronze     id = tbl_<target_fqn_slug>             label = target_fqn

Edges:
  source   ─── read ───▶ pipeline
  pipeline ─── write ──▶ bronze
```

### EDA (`specs/eda/<slug>/spec.md`)

```
Node: bronze     id = tbl_<catalog>_<schema>_bronze     label = "<catalog>.<schema>.<bronze tables>"
                                                         (placeholder · EDA reads multiple bronzes)
Node: pipeline   id = pipe_eda_<slug>                   label = pipeline_name
Node: artifact   id = art_eda_<slug>_consumer_header_sql
                                                         label = "<slug>/consumer_header_query.sql"

Edges:
  bronze   ─── read ───▶ pipeline
  pipeline ─── emit ───▶ artifact
```

### Data Prep (`specs/dataprep/<slug>/spec.md`)

Source node selection depends on `source_mode`:

| `source_mode` | Source node |
|---|---|
| `table` | `tbl_<catalog>_<schema>_<source_table>` (kind=bronze) |
| `header_query` | `art_eda_<slug>_consumer_header_sql` (kind=artifact · re-uses EDA's emitted node) |
| `extract_query` | `q_<slug>` (kind=artifact) |

Then:

```
Node: pipeline   id = pipe_dataprep_<slug>              label = pipeline_name
Node: silver     id = tbl_<catalog>_<schema>_silver_<slug>_silver
Node: gold       id = tbl_<slug>_gold                   label = "<slug> (gold + KNL / Prep-Purp files)"

Edges:
  source   ─── read ─────▶ pipeline
  pipeline ─── transform ▶ silver
  silver   ─── convert ──▶ gold
```

### Docs (`specs/docs/<slug>/spec.md`)

```
Node: pipeline   id = pipe_docs_<slug>                  label = pipeline_name
Node: artifact   id = art_docs_<slug>                   label = "output/docs/<slug>/info_or_runbook.md"

Auto-link upstream:
  if node `pipe_ingestion_<slug>` exists  → ingestion ─── documents ──▶ docs
  if node `pipe_dataprep_<slug>` exists   → dataprep  ─── documents ──▶ docs

Edges:
  pipeline ─── emit ───▶ artifact
```

### Custom (`specs/<custom_phase>/<slug>/spec.md`)

Generic shape — custom pipelines don't have a canonical edge pattern:

```
Node: pipeline   id = pipe_<phase>_<slug>               label = pipeline_name (kind=custom)
Node: target     id = tbl_<phase>_<slug>_out            label = "<catalog>.<schema>.<slug>_out" (kind=gold)

Edges:
  pipeline ─── write ───▶ target
```

If the custom spec has a `source_table` or `source_system`, add an edge:
```
source ─── read ───▶ pipeline
```

---

## From output JSONs (when present — overrides spec.md)

`output/<phase>/<slug>/configs/manifest.json` is the authoritative stage chain:

```json
{
  "stages": [
    { "id": "extraction",      "depends_on": [],              "input_dataset": "...", "output_dataset": "..." },
    { "id": "extraction_profiler", "depends_on": ["extraction"], ... },
    ...
  ]
}
```

Use `input_dataset` + `output_dataset` (FQN strings) to build precise edges between stages within a pipeline (drives the Dependency chain section of lineage.md). When this file exists, ignore the regex-derived edges for that pipeline — these are authoritative.

`output/<phase>/<slug>/configs/<stage>.json` — read for each stage to extract:

| Stage | Field | What it provides |
|-------|-------|------------------|
| `bronze_load.json` | `source.options.db_system` | exact SRCTYPE (overrides spec) |
| `bronze_load.json` | `source.path` / `source.query` | exact source location |
| `bronze_load.json` | `target.catalog/schema/table` | exact target FQN |
| `bronze_load.json` | `schedule.cron` / `schedule.trigger` | runtime |
| `bronze_load.json` | `columns[]` | authoritative schema |
| `profiler.json` | `expectations[]` | DQ rules applied |
| `profiler.json` | `freshness.timestamp_column` | SLA driver |
| `preparation.json` | `transformations[]` | every column mutation (look for `op:'mask'` for PII tracking) |
| `preparation.json` | `dedupe.keys[]` | PK confirmation |
| `address_standardization.json` | `address_columns` | which columns are addresses |
| `conversion.json` | `target` + `post_actions[]` | gold layer FQN + table optimizations |

### Mask tracking for PII

In `preparation.json`, look for:

```json
{ "op": "mask", "columns": ["ssn"], "args": { "method": "sha2_256" }, "on_error": "fail" }
{ "op": "mask", "columns": ["dob"], "args": { "method": "truncate_date", "precision": "year" } }
```

Store as `appliedMasks[<pipelineId>][<columnName>] = '<method>'`. The PII inventory section in `lineage.md` reads this back to show what mask each PII column actually received.

---

## What to do when sources conflict

When the spec.md says X but the output JSON says Y, **output JSON wins** — it's the post-validation truth. Log to `_meta.gaps` as:

```yaml
_meta:
  gaps:
    - pipeline:  consumer_master
      conflict:  spec.target_fqn vs output.target.table
      spec:      cert_dcs_catalog.bankcore_dna.consumer_master
      output:    cert_dcs_catalog.bankcore_dna.consumer_master_v2
      resolved:  used output value
```

---

## Tag-vocabulary reference (for classification)

The classifier (`classifyColumns()`) attaches these tags. The agent uses them for the PII inventory + column index:

| Tag | Triggers when column name matches | Used by |
|-----|-----------------------------------|---------|
| `pk` | Detected primary key (id col, NOT NULL) | column_index, dependency_chain |
| `id` | `_id$` / `_key$` / `_uuid$` | column_index |
| `pii` | Multi-source (see below) | PII inventory |
| `email` | `email`, `_email`, `mail` | PII inventory |
| `phone` | `phone`, `mobile`, `cell`, `tel`, `fax` | PII inventory |
| `gov_id` | `ssn`, `social_security`, `tax_id`, `ein`, `itin` | PII inventory (high-sensitivity) |
| `financial_id` | `card_num`, `account_num`, `pan`, `iban`, `cvv` | PII inventory (PCI) |
| `dob` | `dob`, `date_of_birth`, `birthdate` | PII inventory |
| `address` | `address`, `street`, `line_1/2`, `city`, `state`, `zip`, `country` | column_index |
| `name` | `first_name`, `last_name`, `full_name`, `_name$` | column_index |
| `datetime` | `_at`, `_date`, `_ts`, `_time` + type TIMESTAMP/DATE | column_index |
| `money` | `amount`, `balance`, `price`, `salary`, etc. | column_index |

Every column with tags `email`, `phone`, `gov_id`, `financial_id`, `dob` is automatically also tagged `pii`.
