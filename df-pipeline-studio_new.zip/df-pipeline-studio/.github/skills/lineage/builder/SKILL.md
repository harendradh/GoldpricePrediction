# Skill · lineage.builder

> Skill used by **data_lineage** agent to scan a linked project, build a
> normalized lineage graph, and emit deterministic markdown + Mermaid output.

---

## Identity

| | |
|---|---|
| **Skill ID** | `lineage.builder` |
| **Owning agent** | `data_lineage` |
| **Purpose** | Build a complete lineage graph from on-disk specs + JSONs; emit human + machine artifacts |
| **Reads** | `specs/<phase>/*/spec.md` + `output/<phase>/*/configs/*.json` |
| **Writes** | `output/lineage/<scope>/{lineage.md, lineage_diagram.mmd, column_index.md, lineage.json, impact_*.md}` |

---

## The 6-step algorithm (run in this order, every time)

### Step 1 — Discover scope

Read the lineage spec to determine scope:

```yaml
# In specs/lineage/<scope>/spec.md
scope:           project | pipeline:<name> | column:<column_name>
include_phases:  [ingestion, eda, dataprep, docs, custom]   # default: all
include_customs: true                                        # default: true
column_impact:   <column_name>                               # optional
```

Set the output directory:
- `scope: project` → `output/lineage/project/`
- `scope: pipeline:<name>` → `output/lineage/<name>/`
- `scope: column:<col>` → `output/lineage/column_<col>/`

### Step 2 — Walk specs/

For each `<phase>` in `include_phases`:

```
walk specs/<phase>/
  for each subdir <slug>:
    read specs/<phase>/<slug>/spec.md
    if missing → skip + log to _meta.gaps
    parseSpec(content) → metadata   (see extraction_rules.md)
    extractColumns(content) → classified columns
    register pipeline node + columns
```

### Step 3 — Enrich with output JSONs (when present)

For each registered pipeline, try to read its manifest + stage JSONs:

```
output/<phase>/<slug>/configs/manifest.json                   → authoritative stage chain
output/<phase>/<slug>/configs/*.json                          → per-stage inputs/outputs/transforms (dataprep, eda, docs)
output/ingestion/<slug>/configs/<subdomain>/*.json            → per-subdomain stage configs (ingestion only)
```

For **ingestion**, walk every subdirectory under `configs/` — each is a
subdomain with its own `bronze_load.json` + optional `profiler.json`. Emit
one Bronze table node per subdomain.

When present, these override the spec.md regex-derived values
(they're the agent-canonical truth). When absent, fall back to spec.md.

### Step 4 — Build edges

Per phase, apply the edge logic from `extraction_rules.md`:

| Phase | Edge pattern |
|-------|--------------|
| ingestion | `Source → Pipeline → Bronze[<subdomain_1>], Bronze[<subdomain_2>], …` (fan-out · one Bronze node per subdomain) |
| eda | `Bronze → Pipeline → SQL artifact` |
| dataprep | `(Bronze OR SQL artifact OR custom-query) → Pipeline → Silver → Gold` |
| docs | `Upstream pipelines → Pipeline → info.md/runbook.md` |
| custom | `<source per pipeline definition> → Pipeline → <target>` |

### Step 5 — Apply scope filter

- `scope: project` → keep all nodes + edges
- `scope: pipeline:<name>` → keep only that pipeline + all directly-connected sources/tables (depth 1 in both directions)
- `scope: column:<col>` → keep only pipelines whose `pipelineColumns[id]` contains the column (case-insensitive substring)

### Step 6 — Emit artifacts

In this exact order:

```
1. output/lineage/<scope>/lineage.json         ← write first (machine-readable)
2. output/lineage/<scope>/lineage_diagram.mmd  ← Mermaid source (see mermaid_template.md)
3. output/lineage/<scope>/column_index.md      ← reverse index (alphabetized)
4. output/lineage/<scope>/lineage.md           ← human-readable (see output_template.md · 12 sections)
5. output/lineage/<scope>/impact_<col>.md      ← ONLY when spec.column_impact is set
```

After all five files are written, log a single console line:
```
✓ data_lineage · scope=<scope> · <N> pipelines · <M> tables · <K> edges · gaps=<G>
```

---

## Stable sort orders (idempotency)

Everything must be sorted so identical inputs produce byte-identical outputs (modulo the `generated_at` timestamp):

| Element | Sort key |
|---------|----------|
| Pipelines | `(phase, label)` |
| Tables | `FQN` |
| Sources | `label` |
| Artifacts | `path` |
| Columns | `name` (lowercased) |
| Edges | `(from, to, label)` |
| Pipeline-uses-column entries | `pipeline.phase, pipeline.label` |

---

## Validation before write

Before writing `lineage.md` or `lineage_diagram.mmd`, run these checks:

1. **Mermaid valid?** — every node referenced in an edge must be declared.
   If not, drop the edge + log to `_meta.gaps[]`.
2. **No duplicate node IDs.**
3. **No cycles** in pipeline-only subgraph (cycle = bug in spec — flag in gaps, don't crash).
4. **Every PII column has an applied-mask entry** — pull from `preparation.json` transformations. If missing, mark as `mask: <<MISSING>>` and add to gaps.
5. **`generated_at` is the only difference between two runs** with identical inputs. Test by running twice and diffing.

---

## What to do when something is missing

| Missing thing | Action |
|---------------|--------|
| `specs/<phase>/` doesn't exist | Skip that phase silently — not all projects use every phase |
| A `spec.md` exists but is empty | Add pipeline node with `label = slug`, no edges, log to gaps |
| Spec exists but missing required field (e.g. `target_fqn`) | Use `<<MISSING>>` as the FQN, still create the node, log to gaps |
| `output/<phase>/<slug>/configs/*.json` doesn't exist | Fall back to spec.md only — agent hasn't run yet |
| Pipeline references a column but the column block is missing | Skip column extraction, log to gaps |
| Mermaid render fails | Save the source anyway, log render error to gaps |

Never crash. Never silently drop a pipeline. Always log gaps.

---

## References (must read for full determinism)

1. **`references/extraction_rules.md`** — exactly what to extract from each spec type + each output JSON
2. **`references/mermaid_template.md`** — the standardized Mermaid format (subgraphs, shapes, edges, classes)
3. **`references/output_template.md`** — the canonical 12-section structure of `lineage.md`
