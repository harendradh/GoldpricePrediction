# Skill: DP-06 Data Conversion

```
skill:    dataprep.conversion
version:  1.0
trigger:  "conversion", "convert", "write", "sink", "final", "publish"
outputs:  output/dataprep/{pipeline_name}/configs/conversion.json
```

---

## Purpose

Write the final standardized dataset to the target sink in the requested
format, with the right partitioning, write mode, and any post-write actions
(table tags, OPTIMIZE, ZORDER, VACUUM).

This is the terminal stage — no `output_dataset` consumed downstream.

---

## Required keys

| Key | Type | Allowed values | Notes |
|-----|------|----------------|-------|
| `input_dataset` | string | matches stage 04 `output_dataset` (or stage 05 if you keep pass-through) | — |
| `target` | object | see below | The sink |
| `format` | string | `delta` `parquet` `csv` `json` `jdbc` `kafka` | Output format |
| `write_mode` | string | `overwrite` `append` `merge` `insert_only` | — |
| `merge_keys` | array | required when `write_mode == merge` | — |
| `partition_by` | array \| `[]` | column names | — |
| `zorder_by` | array \| `[]` | column names | Delta only |
| `post_actions` | array | objects `{ type, args }` | OPTIMIZE, VACUUM, tag UC, GRANT |
| `column_select` | array \| `"*"` | column allow-list | Drop interim cols |
| `enabled` | boolean | — | — |

### `target` shape

```json
{
  "type":     "delta_table",
  "catalog":  "main",
  "schema":   "gold",
  "table":    "customer_master",
  "location": "abfs://gold/customer_master"
}
```

### `post_actions` allowed types

| Type | Args |
|------|------|
| `optimize` | `{}` |
| `zorder` | `{ columns: [...] }` (alternative to top-level `zorder_by`) |
| `vacuum` | `{ retention_hours: 168 }` |
| `tag_uc` | `{ tags: { key: value, ... } }` |
| `grant` | `{ to: "group::analytics", privileges: ["SELECT"] }` |
| `analyze_statistics` | `{ columns: "*" }` |

---

## Validation rules

1. `write_mode == "merge"` ⇒ `merge_keys` is non-empty.
2. `zorder_by` requires `format == "delta"`.
3. `partition_by` columns are a subset of `column_select` (or `column_select == "*"`).
4. If `target.type == "delta_table"` then `target.catalog`, `target.schema`, `target.table` are all required.
5. `post_actions[].type` from the allowed list.
