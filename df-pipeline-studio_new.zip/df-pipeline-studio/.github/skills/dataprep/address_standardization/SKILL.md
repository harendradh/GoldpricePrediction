# Skill: DP-04 Address Standardization

```
skill:    dataprep.address_standardization
version:  1.0
trigger:  "address", "standardize", "USPS", "geocode", "parse address"
outputs:  output/dataprep/{pipeline_name}/configs/address_standardization.json
```

---

## Purpose

Parse and standardize address columns against reference dictionaries
(USPS for US, country dictionaries for international). Emits standardized
address fields and a per-row confidence score.

---

## Required keys

| Key | Type | Allowed values | Notes |
|-----|------|----------------|-------|
| `input_dataset` | string | matches stage 03 `output_dataset` | — |
| `output_dataset` | string | snake_case | — |
| `address_columns` | object | `{ line_1, line_2, city, state, postal_code, country }` | Map from input column names to canonical roles. Use `null` if missing |
| `country_routing` | object | `{ default_country, country_column }` | Country drives which dictionary is used |
| `reference_data` | object | see below | Dictionary refs |
| `parsing_engine` | string | `usps` `libpostal` `loquate` `internal` | Engine selector |
| `match_threshold` | number | 0.0–1.0 | Confidence floor |
| `unmatched_strategy` | string | `flag` `null_out` `pass_through` | What to do on miss |
| `output_columns` | array | canonical fields emitted | See defaults |
| `enabled` | boolean | — | If no address columns exist, set `false` + `skip_reason` |

### `reference_data` shape

```json
{
  "usps_zip_dictionary_path": "abfs://refdata/usps/zip4.parquet",
  "country_dictionary_path":  "abfs://refdata/iso/iso3166.parquet",
  "state_abbreviation_map":   "abfs://refdata/usps/states.json",
  "city_alias_map":           "abfs://refdata/usps/city_aliases.json"
}
```

### `output_columns` defaults

```json
[
  "std_line_1", "std_line_2", "std_city", "std_state",
  "std_postal_code", "std_country", "std_country_iso2",
  "std_confidence", "std_match_source"
]
```

---

## Validation rules

1. At least one of `address_columns.line_1` or `address_columns.postal_code` is non-null.
2. `match_threshold ∈ [0.0, 1.0]`.
3. `parsing_engine` ∈ allowed list.
4. Every column referenced in `address_columns` exists in the upstream
   prepared dataset (cross-check against stage 03 outputs).
5. If `country_routing.country_column` is null then `country_routing.default_country` must be set.
