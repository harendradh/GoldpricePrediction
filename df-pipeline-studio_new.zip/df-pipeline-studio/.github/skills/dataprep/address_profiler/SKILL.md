# Skill: DP-05 Address Standardization Profiler

```
skill:    dataprep.address_profiler
version:  1.0
trigger:  "address profile", "post-address", "match rate", "address quality"
outputs:  output/dataprep/{pipeline_name}/configs/address_profiler.json
```

---

## Purpose

Compare pre vs post address fields and emit a quality scorecard:

- Per-row confidence distribution
- Aggregate match rate
- Diff between original and standardized values
- Null/flag/unchanged counts per output column

Like stage 02, this is read-only — `output_dataset == input_dataset`.

---

## Required keys

| Key | Type | Allowed values | Notes |
|-----|------|----------------|-------|
| `input_dataset` | string | matches stage 04 `output_dataset` | — |
| `output_dataset` | string | same as input_dataset | Pass-through |
| `profile_report_dataset` | string | snake_case | Where rows are written |
| `compare_columns` | array | objects `{ original, standardized }` | Pairs to diff |
| `quality_thresholds` | object | `{ min_match_rate, min_confidence }` | Drives PASS/FAIL |
| `flags` | array | rule objects | Trigger investigation flags |
| `enabled` | boolean | — | — |

### `flags` rule object

```json
{
  "id": "f01_null_country",
  "where": "std_country IS NULL",
  "severity": "HIGH",
  "message": "Country could not be standardized"
}
```

---

## Validation rules

1. `input_dataset == stages[03].output_dataset_for_address` (the addr-std stage output).
2. Every `compare_columns[].original` exists in upstream input.
3. Every `compare_columns[].standardized` exists in stage 04 `output_columns`.
4. `quality_thresholds.min_match_rate ∈ [0.0, 1.0]`.
5. `quality_thresholds.min_confidence ∈ [0.0, 1.0]`.
6. Every `flags[].id` is unique within file.
