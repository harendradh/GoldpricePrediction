# Skill: DP-01 Data Extraction

```
skill:    dataprep.extraction
version:  1.0
trigger:  "extraction", "extract", "source", "ingest", "landing"
outputs:  output/dataprep/{pipeline_name}/configs/extraction.json
```

---

## Purpose

Produce the JSON config that tells the downstream engine **where to read raw
data from**, **what format it is in**, and **what dataset name** the rest of
the pipeline should use to refer to it.

This is the head of the chain — it has no `input_dataset`.

---

## Required keys

| Key | Type | Allowed values | Notes |
|-----|------|----------------|-------|
| `source.type` | string | `s3` `abfs` `gcs` `local` `jdbc` `rest_api` `kafka` `hive` `delta` | Connector class |
| `source.path` or `source.query` | string | — | Path for file/object stores, SQL for JDBC, topic for Kafka |
| `format` | string | `parquet` `csv` `json` `xml` `avro` `orc` `fixed_width` `delta` | File format |
| `schema_mode` | string | `infer` `strict` `evolve` | `strict` requires `columns[]` to be populated |
| `output_dataset` | string | snake_case identifier | Name used by stage 02+ |
| `columns` | array | — | Required when `schema_mode = strict` |
| `partition_filter` | string \| null | SQL predicate | Optional pushdown |
| `enabled` | boolean | `true` `false` | Set `false` only with `skip_reason` |

---

## Validation rules

1. If `schema_mode == "strict"` then `columns` must be a non-empty array.
2. `output_dataset` matches `^[a-z][a-z0-9_]{1,62}$`.
3. Exactly one of `source.path` or `source.query` is set (not both, not neither).
4. If `source.type == "jdbc"` then `source.query` is required (not `path`).
5. If `format == "fixed_width"` then every column needs `start` and `length`.

---

## Canonical shape

See `references/example.json`. The agent must mirror that key order in its output.

---

## Output to next stage

| Stage 02 input | Source |
|---------------|--------|
| `input_dataset` | this stage's `output_dataset` |
| `column_list` (optional) | this stage's `columns[]` if provided |
