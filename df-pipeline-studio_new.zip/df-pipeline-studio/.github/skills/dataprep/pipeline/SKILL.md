# Skill: DP Pipeline Orchestrator

```
skill:    dataprep.pipeline
version:  1.0
trigger:  "pipeline", "manifest", "chain stages", "end to end", "runner"
outputs:  output/dataprep/{pipeline_name}/configs/manifest.json
          output/dataprep/{pipeline_name}/reports/validation_report.md
```

---

## Purpose

Stitch the six stage JSON configs into one validated end-to-end pipeline:

1. Verify every stage's JSON is well-formed and matches its skill's keys.
2. Verify dataset continuity (stage N `output_dataset` == stage N+1 `input_dataset`).
3. Emit a `manifest.json` that lists stages in order with their config paths.

---

## Manifest shape

```json
{
  "$schema": "../../skills/dataprep/pipeline/manifest-schema.json",
  "pipeline_name": "<from spec>",
  "version": "1.0",
  "generated_at": "<ISO8601>",
  "stages": [
    {
      "id": "extraction",
      "skill": "dataprep.extraction",
      "config_path": "extraction.json",
      "input_dataset": null,
      "output_dataset": "<from stage JSON>",
      "enabled": true,
      "depends_on": []
    },
    {
      "id": "extraction_profiler",
      "skill": "dataprep.extraction_profiler",
      "config_path": "extraction_profiler.json",
      "input_dataset": "<must equal stage 01 output>",
      "output_dataset": "<from stage JSON>",
      "enabled": true,
      "depends_on": ["extraction"]
    },
    { "id": "preparation", "depends_on": ["extraction"], "...": "..." },
    { "id": "address_standardization", "depends_on": ["preparation"], "...": "..." },
    { "id": "address_profiler", "depends_on": ["address_standardization"], "...": "..." },
    { "id": "conversion", "depends_on": ["address_standardization"], "...": "..." }
  ],
  "_meta": {
    "unresolved": []
  }
}
```

---

## Validation rules (run in this order — stop on first failure)

| # | Rule | Failure mode |
|---|------|-------------|
| 1 | All six stage JSON files exist at `output/dataprep/{pipeline_name}/configs/*.json` | List missing files, halt |
| 2 | Each file is valid JSON | Print file + parser error, halt |
| 3 | Each file has a `_meta.stage` matching its expected stage id | Print mismatch, halt |
| 4 | For N in 2..6: `stages[N].input_dataset == stages[N-1].output_dataset` (skipping disabled stages) | List broken chain, halt |
| 5 | No `_meta.unresolved` entry contains a key marked `required` in the stage SKILL.md | List entries, halt |
| 6 | Manifest writes successfully | Print disk error, halt |

If validation passes, write `validation_report.md`. If any rule fails, still
write the report listing what passed before halting.

---

---

## Validation report shape

```markdown
# data_prep Validation Report — <pipeline_name>
Generated: <ISO8601>

| # | Stage | File | Required keys | Dataset chain | Unresolved | Status |
|---|-------|------|---------------|---------------|------------|--------|
| 1 | Extraction | extraction.json | OK | — | 0 | PASS |
| 2 | Profiler | extraction_profiler.json | OK | OK | 0 | PASS |
| 3 | Preparation | preparation.json | OK | OK | 2 | UNRESOLVED |
| 4 | Address Std | address_standardization.json | OK | OK | 1 | UNRESOLVED |
| 5 | Address Profiler | address_profiler.json | OK | OK | 0 | PASS |
| 6 | Conversion | conversion.json | OK | OK | 0 | PASS |

## Unresolved fields
- preparation.json → transformations[2].rule_args.threshold
- address_standardization.json → reference_data.country_dictionary_path

## Next steps
Open tools/json-studio.html to edit the unresolved fields, then re-run
data_prep pipeline validation.
```
