# Skill: DP-02 Data Extraction Profiler

```
skill:    dataprep.extraction_profiler
version:  1.0
trigger:  "extraction profile", "raw profile", "post-ingest profile"
outputs:  output/dataprep/{pipeline_name}/configs/extraction_profiler.json
```

---

## Purpose

Profile the **raw** data immediately after extraction — before any cleanup.
This catches ingest-side surprises: unexpected nulls, type drift, encoding
issues, row-count anomalies vs the previous run.

This is a profiler, not a transformer. Its `output_dataset` equals its
`input_dataset` (data flows through unchanged); it writes a separate
**profile report** dataset for analytics.

---

## Required keys

| Key | Type | Allowed values | Notes |
|-----|------|----------------|-------|
| `input_dataset` | string | matches stage 01 `output_dataset` | Mandatory |
| `output_dataset` | string | same as `input_dataset` | Profiler passes data through |
| `profile_report_dataset` | string | snake_case | Where the profile rows are written |
| `profile_columns` | array \| `"*"` | column names or `"*"` for all | Strict allow-list |
| `metrics` | array | `null_count` `distinct_count` `min` `max` `mean` `stddev` `top_n` `pattern_freq` `byte_length` | At least one |
| `top_n` | int | 1–100 | Required if `metrics` contains `top_n` |
| `expectations` | array | objects of `{column, rule, threshold, severity}` | Optional but recommended |
| `enabled` | boolean | — | — |

---

## Validation rules

1. `input_dataset` must equal the previous stage's `output_dataset`.
2. `output_dataset == input_dataset` (this is a read-only stage).
3. `metrics` is non-empty.
4. Every entry in `expectations[].column` exists in stage 01's `columns[]` (when stage 01 used `schema_mode = strict`).
5. `expectations[].severity` ∈ `{CRITICAL, HIGH, WARN, INFO}`.

---

## Canonical shape

See `references/example.json`.

---

## Output to next stage

The profile report itself is not consumed by stage 03. Stage 03 reads
`output_dataset` (the pass-through data) and `profile_report_dataset` for
context-aware preparation (e.g. dropping columns that profile as 100% null).
