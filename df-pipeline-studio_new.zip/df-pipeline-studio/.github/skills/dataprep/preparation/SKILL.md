# Skill: DP-03 Data Preparation

```
skill:    dataprep.preparation
version:  1.0
trigger:  "preparation", "prep", "transform", "clean", "cast", "derive"
outputs:  output/dataprep/{pipeline_name}/configs/preparation.json
```

---

## Purpose

Declarative transformations applied to the raw dataset: trim, cast, derive,
filter, dedupe, mask. Output is the cleaned dataset that feeds the address
stage.

---

## Required keys

| Key | Type | Allowed values | Notes |
|-----|------|----------------|-------|
| `input_dataset` | string | matches stage 02 `output_dataset` | — |
| `output_dataset` | string | snake_case | — |
| `transformations` | array | ordered list of rules | Order matters — applied top-down |
| `dedupe` | object \| null | `{ keys, keep }` | `keep ∈ {first, last, max_updated_at}` |
| `enabled` | boolean | — | — |

### Transformation rule shape

```json
{
  "id": "<unique within file>",
  "op": "<one of the ops below>",
  "columns": ["<col>", "..."],
  "args": { "...": "..." },
  "on_error": "fail | skip_row | null_out"
}
```

### Allowed `op` values

| Op | Args | Effect |
|----|------|--------|
| `trim` | `{ side: "both"\|"left"\|"right" }` | Strip whitespace |
| `lower` / `upper` | — | Case normalize |
| `cast` | `{ target_type }` | Change column type |
| `rename` | `{ to }` | Rename column |
| `drop_column` | — | Remove column |
| `derive` | `{ expression }` | Add column from SQL expr |
| `filter_rows` | `{ where }` | Keep rows matching SQL predicate |
| `drop_rows` | `{ where }` | Drop rows matching SQL predicate |
| `mask` | `{ method }` where method ∈ `sha2_256` `last4` `email_partial` `phone_partial` `truncate_date` | PII masking |
| `coalesce` | `{ sources: [col,...] }` | First non-null wins |
| `regex_replace` | `{ pattern, replacement }` | Inline replace |

---

## Validation rules

1. Every `op` is from the allowed list.
2. Every `transformations[i].id` is unique within this file.
3. Every column referenced by `columns` either exists in stage 01's
   `columns[]` OR is produced by an earlier transformation in this file.
4. `on_error` ∈ `{ fail, skip_row, null_out }`.
5. If `dedupe.keep == "max_updated_at"` then there must exist a TIMESTAMP
   column named `updated_at` (after transforms).

---

## Canonical shape

See `references/example.json`.
