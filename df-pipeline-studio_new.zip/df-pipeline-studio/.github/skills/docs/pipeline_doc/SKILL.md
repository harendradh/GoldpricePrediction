# Skill: Pipeline Documentation

```
skill:    docs.pipeline_doc
version:  2.1
trigger:  "document pipeline", "generate docs", "ingestion_info", "dataprep_info", "runbook"
outputs:  output/docs/{pipeline_name}/ingestion_info.md   (mode: ingest)
          output/docs/{pipeline_name}/dataprep_info.md    (mode: dataprep)
          output/docs/{dp_pipeline_name}/runbook.md       (mode: runbook)
```

---

## Purpose

Generate a Markdown reference for the pipeline. Three modes — **each emits a distinctly-named file** so all three can coexist in the same `output/docs/<name>/` directory without collision:

| Mode | Reads | Writes |
|------|-------|--------|
| **ingest** | ingestion configs + spec | `ingestion_info.md` (15 sections) |
| **dataprep** | data-prep configs + spec (+ upstream auto-link) | `dataprep_info.md` (15 sections) |
| **runbook** | BOTH ingestion + data-prep + skill references | `runbook.md` (16 sections · production-ready) |

The skill is read-only on the JSON artifacts — it does not modify any stage
configs.

---

## References (loaded in runbook mode)

`runbook` mode reads four sibling reference files BEFORE generating output:

| File | Purpose |
|------|---------|
| [`references/runbook-structure.md`](references/runbook-structure.md) | The canonical 16-section template |
| [`references/upstream-tech-stack.md`](references/upstream-tech-stack.md) | Driver classes / URL templates per SRCTYPE — populates Tech Stack section |
| [`references/downstream-tech-stack.md`](references/downstream-tech-stack.md) | KNL / Prep-Purp / Prep-Purp-header consumer contracts — populates Downstream SPOC + Conversion Outputs |
| [`references/sop-templates.md`](references/sop-templates.md) | 8 SOPs (deployment, monitoring, drift, PII spike, source outage, Anchor down, consumer complaint, DR) |

Single-pipeline modes (`ingest`, `dataprep`) do not need these references —
they produce the 15-section `ingestion_info.md` / `dataprep_info.md` respectively.

---

## Inputs

| Mode | Files read |
|------|-----------|
| `ingest` | `output/ingestion/{pipeline_name}/configs/manifest.json`<br>`output/ingestion/{pipeline_name}/configs/<subdomain_slug>/bronze_load.json` (one per subdomain — walk every subdir under `configs/`)<br>`output/ingestion/{pipeline_name}/configs/<subdomain_slug>/profiler.json` (one per subdomain · if enabled)<br>`specs/ingestion/{pipeline_name}/spec.md` (optional) |
| `dataprep` | `output/dataprep/{pipeline_name}/configs/manifest.json`<br>`output/dataprep/{pipeline_name}/configs/extraction.json`<br>`output/dataprep/{pipeline_name}/configs/extraction_profiler.json`<br>`output/dataprep/{pipeline_name}/configs/preparation.json`<br>`output/dataprep/{pipeline_name}/configs/address_standardization.json`<br>`output/dataprep/{pipeline_name}/configs/address_profiler.json`<br>`output/dataprep/{pipeline_name}/configs/conversion.json`<br>`specs/dataprep/{pipeline_name}/spec.md` (optional)<br>`output/eda/{pipeline_name}/sql/consumer_header_query.sql` (optional)<br>**Upstream `output/ingestion/{pipeline_name}/*` if FQN matches** |
| `runbook` | All of the above for BOTH `dp_pipeline_name` (required) + `ingest_pipeline_name` (optional — auto-detected from data-prep manifest if blank) + the 4 reference files above |

---

## Output sections (in fixed order)

1. **Header** — title, generated-at, pipeline type
2. **Overview** — pipeline_name, domain, subdomain, owner, schedule, trigger, status
3. **Source** — connector / SQL / table reference
4. **Target** — Bronze or Gold table FQN, location, write_mode, partition/zorder
5. **Pipeline stages** — table of stages with input/output/status
6. **Schema contract** — table of columns: name, type, nullable, classification tags
7. **Data Quality / Profiler** — expectations table + drift + freshness + quarantine
8. **Transformations** (dataprep only) — table of transforms
9. **Address standardization** (dataprep only) — column map + engine + threshold
10. **PII / sensitive columns**
11. **Lineage** — upstream and downstream pipeline references
12. **How to run** — Databricks upload + widget set + cell run instructions
13. **File index** — table of files read with their purpose
14. **Open items** — every `_meta.unresolved[]` across all read JSONs
15. **Document metadata** — YAML block with source files, gaps, generated_at

---

## Extraction map (JSON pointer → doc section)

| Section | Source field |
|---------|-------------|
| `pipeline_name` | `manifest.json` → `pipeline_name` |
| `domain` / `subdomain` | spec.md frontmatter (parse from leading code block) |
| Stage table | `manifest.json` → `stages[]` |
| Source connector | `<subdomain>/bronze_load.json` → `source.{type, db_schema, query_source, query, query_path, options}` |
| Bronze/Gold target | `<subdomain>/bronze_load.json` (per subdomain) or `conversion.json` → `target` |
| Schema contract | `<subdomain>/bronze_load.json` → `columns[]` |
| Expectations | `<subdomain>/profiler.json` → `expectations[]` |
| Drift | `profiler.json` → `drift_detection` |
| Freshness | `profiler.json` → `freshness` |
| Quarantine | `profiler.json` → `quarantine_target` |
| Transformations | `preparation.json` → `transformations[]` |
| Address map | `address_standardization.json` → `address_columns` |
| PII columns | `preparation.json` → `_meta.pii_columns_masked` and `conversion.json` → `pii_columns_masked` |
| Open items | every file's `_meta.unresolved[]` |

---

## Determinism rules

1. **Read each file in the input list before writing.** If a file is
   missing, mark it `n/a` in the File index and add to `gaps[]`.
2. **Sort all generated tables** by stage number ASC, then by column
   position ASC, then by alphabetical name.
3. **Format every table as proper Markdown** — pipe-separated, with header
   row + separator row.
4. **Never modify the read JSONs.** Read-only.
5. **Always include all 15 sections** — output `_(none)_` placeholder for
   sections with no data rather than omitting the heading.
6. **Idempotent** — running twice on the same artifacts produces an
   identical file (modulo `generated_at` timestamp).

---

## Validation

Before announcing completion:

1. The output file path exists.
2. The 15 section headings are all present.
3. At least one stage was documented (else fail loudly).
4. The Open items section enumerates every `_meta.unresolved` found.
