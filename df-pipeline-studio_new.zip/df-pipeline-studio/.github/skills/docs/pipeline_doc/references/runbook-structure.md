# Runbook structure · 16-section template

> Used by `data_doc` when generating `output/docs/<dataprep_name>/runbook.md` in **runbook mode**.
> Every section is mandatory. If data is missing, write `_(none)_` + add an entry to `gaps[]`.

---

## Part 1 — Identity & Ownership

### 1. Header
```
# Production Runbook · <pipeline_name>

| | |
|---|---|
| Pipeline | `<pipeline_name>` |
| Type | Ingestion + Data Prep (combined) |
| Domain · Subdomain | `<domain>` · `<subdomain>` |
| Generated | YYYY-MM-DD HH:MM UTC by data_doc |
| Runbook version | 1.0 |
| Last reviewed | YYYY-MM-DD (must be reviewed every 90 days) |
```

### 2. Overview
- 2–3 sentence business purpose
- Environment (cert / prod)
- Status (active / paused / deprecated)
- SLA (e.g. data available by 06:00 UTC daily)

### 3. Ownership & SPOC
| Role | Name / Team | Contact |
|------|-------------|---------|
| Upstream SPOC | (source system DBA / vendor) | (email, on-call) |
| Downstream SPOC | (KNL / Prep-Purp consumers) | (email, on-call) |
| Pipeline Owner | (engineering team) | (email · Slack channel) |
| On-call | (rotation reference URL) | (PagerDuty schedule ID) |

---

## Part 2 — Architecture

### 4. Technology stack
Read sibling reference: `upstream-tech-stack.md` + `downstream-tech-stack.md` and surface the relevant rows here.

| Layer | Technology | Version | Notes |
|-------|-----------|---------|-------|
| Source | Oracle 19c · SQL Server 2019 · ADLS Gen2 | — | from upstream-tech-stack.md |
| Compute | Databricks Runtime 14.3 LTS | spark 3.5.x | cluster: `<cluster_name>` |
| Storage | Unity Catalog managed Delta | — | catalog: `<catalog>` |
| Orchestration | Databricks Workflows | job_id: `<job_id>` | cron: `<cron>` |
| External | Anchor address standardization | v2 | driver-side invocation |
| Downstream | KNL · Prep-Purp · Prep-Purp-header | — | from downstream-tech-stack.md |

### 5. Lineage diagram
```mermaid
flowchart LR
  src[(Source: <src_system>)] --> bz[Bronze: <bronze_fqn>]
  bz --> prof[Profiler: <profile_fqn>]
  bz --> ch[Consumer Header: <ch_fqn>]
  ch --> std[Standardized: <std_fqn>]
  std --> anchor{Anchor}
  anchor --> addr[Address Std: <addr_fqn>]
  addr --> pii{PII Validation}
  pii -->|fail| err[Error Bucket: <err_fqn>]
  pii -->|pass| knl[KNL file]
  pii --> pp[Prep-Purp body]
  pii --> pph[Prep-Purp header]
```

---

## Part 3 — Ingestion details (skip section if no ingestion artifacts)

### 6. Ingestion tables
| Source FQN | Target FQN (Bronze) | Write mode | Partition | Avg rows/day | Last run |
|-----------|---------------------|-----------|-----------|--------------|----------|
| `<src>.<schema>.<table>` | `<catalog>.<schema>.<table>` | append/merge | `ingest_date` | <N> | <ts> |

### 7. Ingestion schedule + Job IDs
```yaml
workflow_job_id:        <job_id>
cron:                   '0 2 * * *'        # 02:00 UTC daily
trigger:                cron               # or file_arrival
expected_runtime_min:   15
upstream_dependency:    (none / job_id of preceding workflow)
retry_policy:
  max_retries:          3
  retry_delay_seconds:  60
on_failure:             quarantine
```

### 8. Profiler tables
For each profile table:
| Profile FQN | Source table | Metrics | Drift thresholds | Freshness max-age | Quarantine FQN | Objective |
|------------|--------------|---------|------------------|-------------------|----------------|-----------|
| `<table>_profile` | `<table>` | row/null/distinct/min/max/mean/stddev/top_n | row_count_change_pct=0.20, null_rate_change_pct=0.10 | 48h | `<table>_quarantine` | "Detect drift in customer demographics; surface PII column nulling" |

---

## Part 4 — Data Prep details

### 9. Data Prep stage chain
| # | Stage | Input | Output |
|---|-------|-------|--------|
| 1 | Extraction | `<bronze_fqn>` OR header_query OR extract_query | `<silver>.<subdomain>_consumer_header` |
| 2 | Extraction Profiler | `<silver>.<subdomain>_consumer_header` | `<silver>.<subdomain>_consumer_header_profile` |
| 3 | Preparation (standardization) | `<silver>.<subdomain>_consumer_header` | `<silver>.<subdomain>_consumer_header_std` |
| 4 | Address Standardization (Anchor) | `<silver>.<subdomain>_consumer_header_std` | `<silver>.<subdomain>_consumer_header_addr` |
| 5 | Address Std Profiler | `<silver>.<subdomain>_consumer_header_addr` | `<silver>.<subdomain>_consumer_header_addr_profile` |
| 6 | Conversion (+ PII gate) | `<silver>.<subdomain>_consumer_header_addr` | 3 files (KNL · Prep-Purp · Prep-Purp-header) + ERROR bucket |

### 10. Standardization rules applied
List rules from `.github/rules/categories/*.yaml` that fire on these columns:
| Rule ID | Column(s) | Severity | Action |
|---------|-----------|----------|--------|
| `pii_ssn_mask` | ssn | CRITICAL | hash sha2_256 |
| `pii_dob_truncate` | dob | HIGH | truncate to year |
| `contact_email_lower` | email | INFO | lowercase |
| `address_state_upper` | state | INFO | uppercase |
| ... | ... | ... | ... |

### 11. Address standardization (Anchor)
```yaml
parsing_engine:         libpostal              # OR usps / loquate / anchor-internal
match_threshold:        0.85
unmatched_strategy:     flag                   # flag | null_out | pass_through
input_file_path:        /Volumes/<cat>/<sch>/anchor/in/<run_id>.csv
output_file_path:       /Volumes/<cat>/<sch>/anchor/out/<run_id>.csv
invocation:             driver-side · synchronous · timeout 600s
default_country:        US
```

### 12. PII validation rules (PII_header_ID)
| Rule ID | Columns checked | Severity | Action on fail |
|---------|----------------|----------|----------------|
| `ssn_format` | ssn | CRITICAL | → ERROR bucket |
| `account_checksum` | account_number | CRITICAL | → ERROR bucket |
| `email_corp_domain` | email | WARN | record, allow through |
| ... | ... | ... | ... |

ERROR bucket: `<catalog>.<silver_schema>.<subdomain>_error` (append-only)
Schema: `original_pii_header_id`, `failing_rule_id`, `failed_columns`, `run_id`, `detected_ts`

### 13. Conversion outputs
| Output | Path | Format | Expected rows/run | Downstream consumer |
|--------|------|--------|-------------------|---------------------|
| KNL file | `/Volumes/<cat>/<sch>/<subdomain>/conversion/<run_id>/knl.<ext>` | <fmt> | <N> | `<consumer>` |
| Prep-Purp body | `/Volumes/<cat>/<sch>/<subdomain>/conversion/<run_id>/prep_purp.<ext>` | <fmt> | <N> | `<consumer>` |
| Prep-Purp header | `/Volumes/<cat>/<sch>/<subdomain>/conversion/<run_id>/prep_purp_header.<ext>` | <fmt> | <N> | `<consumer>` |

---

## Part 5 — Operations

### 14. Standard Operating Procedures
Reference sibling `sop-templates.md`. Materialize each SOP inline with this pipeline's actual values:
- SOP-01: First-time deployment checklist
- SOP-02: Daily run monitoring
- SOP-03: Schema drift response
- SOP-04: PII validation failure spike
- SOP-05: Source-system outage
- SOP-06: Anchor process down
- SOP-07: Downstream consumer complaint
- SOP-08: Disaster recovery (full-pipeline rerun from scratch)

### 15. Monitoring & alerting
```yaml
logs:
  databricks_job:       https://<workspace>/jobs/<job_id>/runs
  ingest_log:           <catalog>.<schema>.<subdomain>_ingest_log
  prep_log:             <catalog>.<silver_schema>.<subdomain>_prep_log
alerts:
  pagerduty_service_id: <service_id>
  slack_channel:        '#<channel>'
  email_distro:         <distro>@company.com
sla_breach:
  row_count_drop_pct:   30      # alert if drops > 30% vs 7-day avg
  duration_overrun_min: 30      # alert if job takes > expected + 30min
  freshness_breach_hr:  6       # alert if data older than freshness + 6h
```

### 16. Recovery procedures
- **Idempotent rerun**: re-trigger the workflow job; same run_id overwrites Silver tables 1–4; conversion files include run_id in path
- **Backfill**: change the partition_filter in extraction.json, rerun
- **Rollback**: `DESCRIBE HISTORY <fqn>` then `RESTORE TABLE <fqn> TO VERSION AS OF <n>`
- **Document metadata** (YAML footer):
  ```yaml
  runbook_version: 1.0
  last_reviewed:   YYYY-MM-DD
  next_review_due: YYYY-MM-DD (90 days out)
  reviewers:       [<team-email>]
  ```
