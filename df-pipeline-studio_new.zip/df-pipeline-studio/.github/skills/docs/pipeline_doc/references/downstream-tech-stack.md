# Downstream technology stack · reference

> Consumers of the pipeline's three output files (KNL, Prep-Purp body,
> Prep-Purp header). Used by `data_doc` to populate the **Downstream SPOC**
> + **Conversion outputs** sections of the runbook with concrete file
> formats, schemas, and consumer contracts.

## Output files (data-prep conversion stage)

| File | Default path | Format | Header? | Compression | Purpose |
|------|--------------|--------|---------|-------------|---------|
| KNL | `/Volumes/<cat>/<sch>/<subdomain>/conversion/<run_id>/knl.<ext>` | `<<FILL_IN: csv \| parquet \| fixed_width \| json>>` | yes/no | gzip/none | Downstream system that needs the curated consumer view |
| Prep-Purp body | `/Volumes/<cat>/<sch>/<subdomain>/conversion/<run_id>/prep_purp.<ext>` | `<<FILL_IN>>` | yes/no | gzip/none | Marketing / risk modeling input |
| Prep-Purp header | `/Volumes/<cat>/<sch>/<subdomain>/conversion/<run_id>/prep_purp_header.<ext>` | `<<FILL_IN>>` | yes | none | Manifest / control row count for the body file |

`<<FILL_IN: ...>>` fields require the runbook author to confirm with the
downstream team. Default assumption is CSV with header.

## Consumer contract template

For each downstream file, the runbook must record:

```yaml
file:                   knl                     # or prep_purp / prep_purp_header
consumer_team:          <<FILL_IN: team name>>
consumer_email:         <<FILL_IN: team email>>
consumer_slack:         '#<<FILL_IN>>'
sla:
  delivery_by:          '06:00 UTC daily'      # downstream pickup window
  retry_window:         '06:00 - 09:00 UTC'    # last possible reschedule
schema:
  columns:              [...]                  # ordered list
  delimiter:            '|'                    # or ',' / '\t'
  null_indicator:       ''                     # empty string vs NULL vs \N
  date_format:          'YYYY-MM-DD'
  decimal_format:       '0.00'
expected_row_count:
  min:                  10000
  max:                  500000
  alert_pct_drop:       30                     # alert if drop > 30% vs 7-day avg
ack_protocol:           sftp_done_file | email | none
on_failure:             escalate                # escalate / quiet-retry / skip
```

## Common downstream patterns

| Pattern | Description | When to use |
|---------|-------------|-------------|
| **Pull (sftp / mount)** | Downstream system mounts the volume + pulls on schedule | Default — minimal coupling |
| **Push (api / sftp upload)** | We push to their endpoint after write | When downstream can't pull from ADLS |
| **Event (kafka / event grid)** | We emit a "file ready" event to a topic / EG | When downstream is event-driven |
| **Done file** | We write `.done` next to the data file | Legacy systems that poll for completion |

## SPOC contact convention

For each downstream file, the runbook must list:
- Receiving team name + Slack channel
- Operational contact for ingestion failures (email)
- Business owner (who feels pain when data is wrong)
- SLA breach escalation path (PagerDuty service / ticket queue)
