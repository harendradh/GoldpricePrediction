# Upstream technology stack · reference

> Source systems the ingestion pipeline reads from. Used by `data_doc` to
> populate the **Technology stack** section of the runbook with concrete
> driver classes, URL templates, and operational quirks.

## Source systems

| SRCTYPE | Driver class | URL template | Default port | Notes |
|---------|--------------|--------------|--------------|-------|
| Oracle | `oracle.jdbc.OracleDriver` | `jdbc:oracle:thin:@//<host>:<port>/<service_name>` | 1521 | Often needs `sessionInitStatement` for NLS_DATE_FORMAT. Bare `NUMBER` → decimal(38,10). |
| MySQL | `com.mysql.cj.jdbc.Driver` | `jdbc:mysql://<host>:<port>/<db>?useSSL=true&serverTimezone=UTC` | 3306 | `TINYINT(1)` → byte; declare BOOLEAN explicitly. |
| Netezza | `org.netezza.Driver` | `jdbc:netezza://<host>:<port>/<db>` | 5480 | Bare `NUMERIC` → decimal(38,10). No `LIMIT` — use `FETCH FIRST n ROWS ONLY`. |
| Snowflake | `net.snowflake.spark.snowflake` (Spark connector, preferred over JDBC) | `sfURL=<account>.snowflakecomputing.com` | n/a | Requires `sfWarehouse`, `sfRole`, `sfDatabase`, `sfSchema`. Pushdown on by default. |
| SQL Server | `com.microsoft.sqlserver.jdbc.SQLServerDriver` | `jdbc:sqlserver://<host>:<port>;databaseName=<db>;encrypt=true;trustServerCertificate=false` | 1433 | Azure SQL: append `;loginTimeout=30`. `DATETIME2(7)` precision is lossy. |
| PostgreSQL | `org.postgresql.Driver` | `jdbc:postgresql://<host>:<port>/<db>?ssl=true` | 5432 | `JSONB` → STRING — parse with `from_json` post-load. |
| ADLS Gen2 | (native Spark reader) | `abfss://<container>@<storage>.dfs.core.windows.net/<path>/<file_glob>` | n/a | Set `fs.azure.account.*` configs on SparkSession. CSV: pass header/delimiter/quote in `format_options`. |

## Authentication patterns

| Source | Auth mode | Secret format |
|--------|-----------|---------------|
| JDBC (Oracle/MySQL/SQL Server/Postgres/Netezza) | username + password | `<scope>/<key>` (Databricks secret scope) |
| Snowflake | username + password OR OAuth + private key | `<scope>/<key>` |
| ADLS Gen2 | OAuth client credentials OR Managed Identity OR SAS | client_id + client_secret in secret scope |

## SPOC contact convention

For each source system, the upstream SPOC (Single Point of Contact) is the
team that owns the source data. The runbook must list:
- Team name + Slack channel
- DBA on-call rotation URL
- Vendor support ticket portal (for SaaS sources like Snowflake)
- Source change-control process (how schema changes are communicated)
