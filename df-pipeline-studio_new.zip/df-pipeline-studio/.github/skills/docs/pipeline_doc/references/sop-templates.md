# SOP templates · standard operating procedures

> Used by `data_doc` in runbook mode (Section 14). For each SOP below,
> the runbook should materialize it with the pipeline's **actual** values
> (table FQNs, cluster names, cron schedules) — not the placeholders.

---

## SOP-01 · First-time deployment checklist

When a new pipeline is being promoted to a new environment.

```
[ ] Source connection secret created in target env's secret scope
[ ] Catalog + schema + Silver schema exist in target Unity Catalog
[ ] Cluster pool / SQL warehouse provisioned with required size
[ ] Workflow job created with `--config-json` pointing to env-specific config
[ ] First run executed in DRY_RUN mode (set run_options.dry_run=true)
[ ] First real run scheduled at off-peak time with on-call monitoring
[ ] Downstream consumers notified of new delivery path + sample file shared
[ ] Runbook reviewed + signed off by Pipeline Owner + Downstream SPOCs
[ ] Alerts wired up in PagerDuty / Slack channel created
[ ] On-call rotation includes this pipeline
```

## SOP-02 · Daily run monitoring

Where to look + what to verify after each scheduled run.

1. Open Databricks Workflows → job `<job_id>` → latest run
2. Verify status = `SUCCESS`
3. Query the per-table audit log:
   ```sql
   SELECT table_fqn, status, rows_written, duration_ms
   FROM <catalog>.<schema>.<subdomain>_ingest_log
   WHERE _ingest_run_id = '<run_id>';
   ```
4. Query the prep stage log:
   ```sql
   SELECT stage, status, rows_in, rows_out, duration_ms
   FROM <catalog>.<silver_schema>.<subdomain>_prep_log
   WHERE run_id = '<run_id>';
   ```
5. Verify ERROR bucket row count vs 7-day baseline
6. Confirm 3 conversion files exist with row counts in expected range

## SOP-03 · Schema drift response

When `drift_signal_<table>` reports a change.

1. Identify the signal type: `new_column` / `removed_column` / `type_change` / `row_count_change_pct` / `null_rate_change_pct`
2. **For `new_column`**:
   - If benign (new optional field): add to `columns[]` in `bronze_load.json` with `nullable:true`, re-deploy
   - If suspicious: escalate to upstream SPOC, pause pipeline until clarified
3. **For `removed_column`**: BLOCK — upstream may have lost data, escalate immediately
4. **For `type_change`**: BLOCK — could indicate data corruption, escalate
5. **For `null_rate_change_pct > 0.10`**: check source-system release notes, may be a data-quality regression

## SOP-04 · PII validation failure spike

When ERROR bucket row count exceeds 10x baseline.

1. Top failing rule_id:
   ```sql
   SELECT failing_rule_id, count(*) AS n
   FROM <catalog>.<silver_schema>.<subdomain>_error
   WHERE run_id = '<run_id>'
   GROUP BY 1 ORDER BY 2 DESC;
   ```
2. For top rule, inspect failed_columns + sample of original_pii_header_id values
3. Join error rows to `<subdomain>_consumer_header_std` to see standardized values that failed
4. **Common causes**:
   - Stage 3 standardizer not applied (column missing from `major_columns[]`)
   - Source-system data quality regression (escalate upstream)
   - Rule misconfiguration (rule_id pointing to wrong column)
5. Don't re-process failed rows automatically — they require human review

## SOP-05 · Source-system outage

When ingestion can't reach the source.

1. Confirm the source is the issue (try `telnet <host> <port>` from cluster init script)
2. If JDBC source: check upstream DBA's outage channel
3. If ADLS source: check Azure portal for the storage account's status
4. **Decisions**:
   - Short outage (< 1h): let the job retry per `retry_policy`
   - Medium (1h–4h): manually pause the workflow, notify Downstream SPOCs of late delivery
   - Long (> 4h): escalate to vendor/DBA, prepare backfill plan
5. After source is back: trigger a one-off run with the missed `process_date`

## SOP-06 · Anchor process down

When stage-4 reports `ANCHOR_UNREACHABLE`.

1. Confirm Anchor service status (vendor status page or internal health check)
2. **Decision tree**:
   - If Anchor will return within 1h: wait + retry the job
   - If Anchor will be down > 1h: edit `stages.address.enabled = false`, rerun (output drops address-standardized columns; downstream gets a partial file with a known caveat — coordinate with Downstream SPOC)
3. **Never** bypass Anchor and ship raw addresses to KNL/Prep-Purp — addresses without standardization break the downstream matching keys

## SOP-07 · Downstream consumer complaint

"Data looks wrong."

1. Get from the consumer: file name + delivery date + sample row that looks wrong
2. Find the run_id from the file path: `/Volumes/.../conversion/<run_id>/...`
3. Trace back through:
   ```
   <silver>.<subdomain>_consumer_header_addr  ← addressed
   <silver>.<subdomain>_consumer_header_std   ← standardized
   <silver>.<subdomain>_consumer_header       ← extracted
   <catalog>.<schema>.<source_table>          ← Bronze
   ```
4. Use `original_pii_header_id` to match consumer's sample back to source
5. Determine whether issue is source data (escalate up), standardization (code fix), or PII validation (rule misconfig)

## SOP-08 · Disaster recovery (full-pipeline rerun)

Full rebuild from scratch.

1. **Confirm scope**: which `process_date` range to rebuild
2. **Pause** the scheduled workflow
3. **Snapshot** current Silver tables (use Delta time-travel — note current versions)
4. **Rerun ingestion** for the date range:
   ```bash
   databricks jobs run-now --job-id <ingest_job_id> --notebook-params '{"start_date":"...","end_date":"..."}'
   ```
5. **Rerun data-prep** with `stages.extraction.partition_filter` covering the same range
6. **Verify**: compare row counts vs snapshot, spot-check 10 random PII_header_IDs across all 6 stages
7. **Notify** Downstream SPOCs that backfilled files are available
8. **Resume** scheduled workflow
9. **If something went wrong**: `RESTORE TABLE <fqn> TO VERSION AS OF <pre-disaster-version>` for each Silver table
