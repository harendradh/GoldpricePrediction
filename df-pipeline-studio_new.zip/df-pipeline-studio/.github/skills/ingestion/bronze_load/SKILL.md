# Skill: ING-01 Bronze Load (sources → ADLS Delta)

```
skill:    ingestion.bronze_load
version:  1.1
trigger:  "ingest", "bronze", "load", "land", "source to delta"
outputs:  output/ingestion/{pipeline_name}/configs/{subdomain_slug}/bronze_load.json
```

---

## Purpose

Produce the JSON config that tells the ingestion runtime **where to read raw
data from**, **how to parse it**, **what schema contract to enforce**, and
**which ADLS Delta Bronze table to write into** — including audit columns
and write mode.

**Per-subdomain (v1.1)** — an ingestion pipeline can declare N subdomains
(Bronze target tables) under one shared source connection. This skill emits
one `bronze_load.json` PER subdomain at `configs/<subdomain_slug>/bronze_load.json`.
The shared source connection lives in the spec's "Stage 1 · shared" block; the
per-subdomain block provides this skill's input.

This is the head of the ingestion chain — it has no `input_dataset`.

---

## Required keys

| Key | Type | Allowed values | Notes |
|-----|------|----------------|-------|
| `enabled` | boolean | `true` `false` | Set `false` only with `skip_reason` |
| `subdomain` | string | snake_case identifier | **(v1.1)** Marker that ties this file to its `configs/<subdomain_slug>/` directory — MUST equal the slug |
| `source.type` | string | `s3` `abfs` `gcs` `local` `jdbc` `rest_api` `kafka` `file_drop` | Connector class |
| `source.db_schema` | string \| null | DB.SCHEMA qualifier or path prefix | **(v1.1)** READ-side qualifier shared by all subdomains (`BANK.DBO` for JDBC, `raw/bank/daily` for ADLS). Sourced from spec's `source_db_schema:`. |
| `source.query_source` | string | `table` `inline` `file` | **(v1.1)** Routes how the source SQL is supplied. `table` → agent generates `SELECT * FROM <db_schema>.<subdomain>`. `inline` → use embedded `source.query`. `file` → load SQL from `source.query_path` at runtime. |
| `source.query` | string \| null | SELECT statement | Required when `query_source == inline`. Treat `:high_watermark` as a runtime bind parameter. |
| `source.query_path` | string \| null | UC volume / DBFS / ADLS path to a `.sql` file | Required when `query_source == file`. Loader reads the file at runtime, then submits the SQL via JDBC pushdown. |
| `source.path` or `source.topic` | string | — | Used for non-JDBC sources (object-store path, Kafka topic) |
| `source.credentials_ref` | string \| null | Secret scope path | e.g. `secret/scope/vendor_drop_reader` |
| `source.options` | object \| null | Connector-specific (e.g. recursive, modified_after) | Optional |
| `format` | string | `csv` `parquet` `json` `xml` `avro` `orc` `fixed_width` `delta` `jdbc` | File / connector format |
| `format_options` | object | encoding/delimiter/header/quote_char | CSV-relevant or format-specific |
| `schema_mode` | string | `contract` `infer` `evolve` | `contract` requires `columns[]` |
| `columns` | array | — | Required when `schema_mode = contract` |
| `schedule` | object | `{ trigger, cron? , event? }` | Trigger ∈ `cron` `file_arrival` `webhook` `manual` |
| `target` | object | ADLS Delta target — see below | Required |
| `write_mode` | string | `append` `overwrite` `merge` | — |
| `merge_keys` | array | required when `write_mode = merge` | — |
| `partition_by` | array \| `[]` | column names | — |
| `audit_columns` | boolean | `true` `false` | Adds `_ingest_ts`, `_source_file`, `_ingest_run_id`, `_app_version`, `_subdomain` |
| `table_properties` | object \| null | Delta `TBLPROPERTIES` | e.g. `delta.enableChangeDataFeed = true` |
| `output_dataset` | string | snake_case identifier | Name used by stage 02 (same subdomain) |

### `target` shape

```json
{
  "type":     "delta_table",
  "catalog":  "main",
  "schema":   "bronze",
  "table":    "customers",
  "location": "abfs://bronze@<storage_account>.dfs.core.windows.net/customers"
}
```

The `location` must use the `abfs://` scheme (ADLS Gen2). For Unity Catalog
managed tables, set `location` to `null` and ensure the catalog is configured
with a managed storage location.

---

## Validation rules

1. **(v1.1)** `subdomain` matches the directory name (`configs/<subdomain_slug>/`) — exact match.
2. If `schema_mode == "contract"` then `columns[]` is non-empty.
3. **(v1.1)** For JDBC sources, `source.query_source ∈ {table, inline, file}`:
   - `table` → `source.db_schema` is non-null
   - `inline` → `source.query` is non-null
   - `file`  → `source.query_path` is non-null (must start with `/Volumes/`, `dbfs:/`, `abfss://`, `s3://`, `gs://`, or `file://`)
4. For non-JDBC sources, exactly one of `source.path`, `source.topic` is set.
5. If `source.type == "kafka"` then `source.topic` is required.
6. `target.type == "delta_table"` and `target.catalog`, `target.schema`, `target.table` are all set.
7. `target.table` MUST equal `subdomain` (the per-subdomain skill emits one Bronze table per subdomain).
8. If `target.location` is set, it must start with `abfs://` (or be `null` for UC-managed).
9. If `write_mode == "merge"` then `merge_keys[]` is non-empty.
10. `output_dataset` matches `^[a-z][a-z0-9_]{1,62}$`.

---

## Canonical shape

See `references/example.json`. The agent must mirror that key order.

---

## Output to next stage

| Stage 02 input | Source |
|---------------|--------|
| `input_dataset` | this stage's `output_dataset` |
| `bronze_table_fqn` | `<target.catalog>.<target.schema>.<target.table>` |
