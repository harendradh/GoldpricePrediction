# Skill: Ingestion Pipeline Orchestrator

```
skill:    ingestion.pipeline
version:  1.1
trigger:  "ingest pipeline", "manifest", "chain stages", "ingest runner"
outputs:  output/ingestion/{pipeline_name}/configs/manifest.json
          output/ingestion/{pipeline_name}/reports/validation_report.md
```

---

## Purpose

Stitch **all per-subdomain ingestion stage JSONs** into one validated pipeline.
A pipeline declares N subdomains; each subdomain contributes 2 stages
(`bronze_load` + `profiler`), so the manifest chains **2N stages** under a
single `pipeline_name`.

1. Walk `configs/<subdomain_slug>/` for every subdomain in the spec.
2. Verify each stage JSON is well-formed and matches its skill's keys.
3. Verify dataset continuity **per subdomain** (`<sub>_bronze_load.output_dataset`
   == `<sub>_profiler.input_dataset`).
4. Emit a single top-level `manifest.json` listing every subdomain's stages
   with their config paths and `depends_on` edges.

---

## Manifest shape (multi-subdomain)

```json
{
  "$schema": "../../skills/ingestion/pipeline/manifest-schema.json",
  "pipeline_name": "<from spec>",
  "version": "1.1",
  "generated_at": "<ISO8601>",
  "subdomains": ["consumer", "address", "account"],
  "stages": [
    {
      "id": "consumer_bronze_load",
      "skill": "ingestion.bronze_load",
      "subdomain": "consumer",
      "config_path": "consumer/bronze_load.json",
      "input_dataset": null,
      "output_dataset": "<from stage JSON>",
      "enabled": true,
      "depends_on": []
    },
    {
      "id": "consumer_profiler",
      "skill": "ingestion.profiler",
      "subdomain": "consumer",
      "config_path": "consumer/profiler.json",
      "input_dataset": "<must equal consumer_bronze_load output>",
      "output_dataset": "<from stage JSON>",
      "enabled": true,
      "depends_on": ["consumer_bronze_load"]
    },
    {
      "id": "address_bronze_load",
      "skill": "ingestion.bronze_load",
      "subdomain": "address",
      "config_path": "address/bronze_load.json",
      "input_dataset": null,
      "output_dataset": "<from stage JSON>",
      "enabled": true,
      "depends_on": []
    },
    {
      "id": "address_profiler",
      "skill": "ingestion.profiler",
      "subdomain": "address",
      "config_path": "address/profiler.json",
      "input_dataset": "<must equal address_bronze_load output>",
      "output_dataset": "<from stage JSON>",
      "enabled": false,
      "skip_reason": "no columns declared for this subdomain",
      "depends_on": ["address_bronze_load"]
    }
  ],
  "_meta": {
    "pipeline_name": "<from spec>",
    "generated_by": "data_ingest",
    "generated_at": "<ISO8601>",
    "unresolved": []
  }
}
```

> **Single-subdomain pipelines** still follow the same shape — there is just
> one entry in `subdomains[]` and 2 entries in `stages[]`.

---

## Validation rules (run in order — stop on first failure)

| # | Rule | Failure mode |
|---|------|-------------|
| 1 | Every subdomain in `spec.subdomains[]` has a `configs/<slug>/` directory with `bronze_load.json` (and `profiler.json` if columns were declared) | List missing files, halt |
| 2 | Each file is valid JSON | Print file + parser error, halt |
| 3 | Each file has `_meta.stage` matching its expected stage id AND `subdomain` matching its directory slug | Print mismatch, halt |
| 4 | For every subdomain: `<sub>_profiler.input_dataset == <sub>_bronze_load.output_dataset` | List broken chain, halt |
| 5 | No `_meta.unresolved` entry marks a `required` field | List entries, halt |
| 6 | Manifest writes successfully | Print disk error, halt |

If validation passes, write `validation_report.md`. If a rule fails, still
write the report listing what passed before halting.

---

## Validation report shape

```markdown
# data_ingest Validation Report — <pipeline_name>
Generated: <ISO8601>
Subdomains: 3 (consumer, address, account)

| # | Subdomain | Stage | File | Required keys | Dataset chain | Unresolved | Status |
|---|-----------|-------|------|---------------|---------------|------------|--------|
| 1 | consumer  | Bronze Load     | consumer/bronze_load.json     | OK | — | 0 | PASS |
| 2 | consumer  | Bronze Profiler | consumer/profiler.json        | OK | OK | 1 | UNRESOLVED |
| 3 | address   | Bronze Load     | address/bronze_load.json      | OK | — | 0 | PASS |
| 4 | address   | Bronze Profiler | address/profiler.json         | — | — | — | SKIPPED (enabled:false) |
| 5 | account   | Bronze Load     | account/bronze_load.json      | OK | — | 0 | PASS |
| 6 | account   | Bronze Profiler | account/profiler.json         | OK | OK | 0 | PASS |

## Unresolved fields
- consumer/profiler.json → expectations[2].args.threshold

## Next steps
Open tools/json-studio.html → fix unresolved fields → re-run validation.
```
