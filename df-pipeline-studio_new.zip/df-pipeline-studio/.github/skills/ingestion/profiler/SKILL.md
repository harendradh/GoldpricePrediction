# Skill: ING-02 Bronze Profiler

```
skill:    ingestion.profiler
version:  1.1
trigger:  "ingest profile", "bronze profile", "post-load profile", "data profiler"
outputs:  output/ingestion/{pipeline_name}/configs/{subdomain_slug}/profiler.json
```

> **Per-subdomain (v1.1):** one `profiler.json` per subdomain · co-located with its
> sibling `bronze_load.json` under `configs/<subdomain_slug>/`. If a subdomain
> declared no columns in the spec, emit this file with `enabled: false` +
> `skip_reason: "no columns declared for this subdomain"`.

---

## Purpose

Profile the **Bronze** Delta table immediately after the ingest run — before
any cleanup or transformation. This catches ingest-side surprises:
unexpected nulls, type drift, encoding issues, row-count anomalies vs the
previous run, freshness violations, and schema drift.

This is a profiler, not a transformer — its `output_dataset` equals its
`input_dataset` (data flows through unchanged). It writes a separate
**profile report** dataset for analytics and downstream DQ dashboards.

---

## Required keys

| Key | Type | Allowed values | Notes |
|-----|------|----------------|-------|
| `enabled` | boolean | — | — |
| `subdomain` | string | snake_case identifier | **(v1.1)** Marker that ties this file to its `configs/<subdomain_slug>/` directory — MUST equal the slug AND match the sibling `bronze_load.json` `subdomain` field |
| `input_dataset` | string | matches stage 01 `output_dataset` (same subdomain) | Mandatory |
| `output_dataset` | string | same as `input_dataset` | Profiler passes through |
| `bronze_table_fqn` | string | `<catalog>.<schema>.<table>` | The actual Delta table being profiled |
| `profile_report_dataset` | string | snake_case | Where profile rows are written |
| `profile_report_target` | object | catalog/schema/table for the report | Optional — defaults to `<bronze_schema>_profile` |
| `profile_columns` | array \| `"*"` | column names or `"*"` for all | — |
| `metrics` | array | `null_count` `distinct_count` `min` `max` `mean` `stddev` `top_n` `pattern_freq` `byte_length` `row_count` `latest_record` | At least one |
| `top_n` | integer \| null | 1–100 | Required when `metrics` contains `top_n` |
| `expectations` | array | per-rule objects `{id, column, rule, threshold, severity, args, action}` | Recommended |
| `drift_detection` | object \| null | compare current run vs previous | See shape below |
| `freshness` | object \| null | `{ max_age_hours, timestamp_column }` | Optional |
| `on_failure` | string | `continue` `quarantine` `fail` | Action when expectations fail |
| `quarantine_target` | object \| null | catalog/schema/table for rejected rows | Required if `on_failure = quarantine` |

### `expectations[]` entry

```json
{
  "id": "e01_pk_not_null",
  "column": "customer_id",
  "rule": "not_null",
  "threshold": 1.0,
  "severity": "CRITICAL",
  "args": {},
  "action": "fail"
}
```

Allowed `rule` values: `not_null`, `unique`, `regex`, `in_set`,
`length_between`, `value_between`, `not_in_future`, `row_count_min`,
`row_count_change_pct`.

Allowed `severity`: `CRITICAL`, `HIGH`, `WARN`, `INFO`.
Allowed `action`: `fail`, `quarantine`, `warn_only`.

### `drift_detection` shape

```json
{
  "enabled": true,
  "baseline_strategy": "previous_run",
  "thresholds": {
    "row_count_change_pct": 0.20,
    "null_rate_change_pct": 0.10,
    "new_columns_alert": true,
    "removed_columns_alert": true,
    "type_change_alert": true
  }
}
```

---

## Validation rules

1. `input_dataset` must equal stage 01's `output_dataset`.
2. `output_dataset == input_dataset` (read-only stage).
3. `metrics` is non-empty.
4. Every `expectations[].column` exists in stage 01's `columns[]` (when contract mode).
5. `severity ∈ {CRITICAL, HIGH, WARN, INFO}`.
6. `action ∈ {fail, quarantine, warn_only}`.
7. If `on_failure == "quarantine"` then `quarantine_target` is set.
8. If `freshness` is set, `freshness.timestamp_column` must exist in stage 01's columns.

---

## Canonical shape

See `references/example.json`.

---

## Hand-off

After this stage, the Bronze table at `bronze_table_fqn` is ready for
data_forge EDA. The `profile_report_dataset` can be loaded into a dashboard
for trend tracking across ingestion runs.
