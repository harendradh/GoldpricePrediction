# Dropping these context files into your monorepo

Phase-1 scope: 1 repo-root instructions file + 3 path-scoped instructions +
1 glossary. That's it.

## Assumed monorepo layout

```
<monorepo>/
├── .github/
│   ├── copilot-instructions.md       ← root · auto-loaded every prompt
│   └── instructions/                 ← path-scoped · auto-loaded via applyTo:
├── apps/
│   ├── data-ingestion/
│   ├── data-profiler/
│   └── data-prep/
└── docs/
    └── glossary.md
```

## Copy commands (run from monorepo root)

Replace `$STUDIO` with the studio path, e.g. `~/df-pipeline-studio`.

```bash
mkdir -p .github/instructions docs

# Repo-root + shared
cp $STUDIO/.github/apps/copilot-instructions.md   .github/copilot-instructions.md
cp $STUDIO/.github/apps/_shared/glossary.md       docs/glossary.md

# Per-app instructions
cp $STUDIO/.github/apps/data-ingestion/instructions.md  .github/instructions/data-ingestion.instructions.md
cp $STUDIO/.github/apps/data-profiler/instructions.md   .github/instructions/data-profiler.instructions.md
cp $STUDIO/.github/apps/data-prep/instructions.md       .github/instructions/data-prep.instructions.md
```

## PowerShell equivalent

```powershell
$STUDIO = "C:\Users\<your-username>\df-pipeline-studio"

New-Item -ItemType Directory -Force .github\instructions, docs | Out-Null

Copy-Item "$STUDIO\.github\apps\copilot-instructions.md"   .github\copilot-instructions.md
Copy-Item "$STUDIO\.github\apps\_shared\glossary.md"       docs\glossary.md

Copy-Item "$STUDIO\.github\apps\data-ingestion\instructions.md" .github\instructions\data-ingestion.instructions.md
Copy-Item "$STUDIO\.github\apps\data-profiler\instructions.md"  .github\instructions\data-profiler.instructions.md
Copy-Item "$STUDIO\.github\apps\data-prep\instructions.md"      .github\instructions\data-prep.instructions.md
```

## Verifying it worked

After copying, in VS Code with GitHub Copilot installed:

1. Open the monorepo
2. `Ctrl+Shift+P` → "Developer: Reload Window"
3. Open Copilot Chat → ask: `What apps does this repo contain?`
   → Should name all three from `copilot-instructions.md`.
4. Open a file under `apps/data-ingestion/` → ask: `How do I add a new source connector?`
   → Copilot should pull in `data-ingestion.instructions.md`.
