# Glossary · Data Factory domain vocabulary

> Destination in monorepo: `docs/glossary.md`
> Copilot reads this when `@workspace` references it.

## Pipeline structure

| Term | Meaning |
|------|---------|
| **domain** | Top-level business area (e.g. `consumer`, `commercial`, `cards`). Drives target schema naming. |
| **subdomain** | Sub-area within a domain (e.g. `consumer.dna`, `consumer.deposits`). Maps 1:1 with a job-config JSON. One job run = one subdomain. |
| **SRCTYPE** | Source system identifier: `ORACLE` · `MYSQL` · `NETEZZA` · `SNOWFLAKE` · `SQLSERVER` · `POSTGRES` · `ADLS`. |
| **TGTTYPE** | Target system. Always `DELTA` today (UC managed Delta tables). |
| **table** | A single physical entity within a subdomain. Ingestion config lists tables under each subdomain. |
| **step** | An action on a table (e.g. `INGEST`, `PROFILE`, `STANDARDIZE`, `CONVERT`). |
| **batch / run_id** | One workflow job run on one subdomain. Databricks-assigned run_id is in audit columns. |

## Storage

| Term | Meaning |
|------|---------|
| **volume** | Unity Catalog volume — holds the JAR and intermediate files. Path: `/Volumes/<catalog>/<schema>/<volume>/...` |
| **Bronze** | Raw landing — direct output of data-ingestion. One table per source table. |
| **Silver** | Cleaned / standardized — output of data-prep stages 1–4. |
| **Gold** | Final downstream output — the 3 files from data-prep stage 5. |
| **ERROR bucket** | `<silver>.<subdomain>_error` — quarantine for records that fail PII validation. Append-only. |

## Data-prep specific

| Term | Meaning |
|------|---------|
| **consumer header** | Wide denormalized record built by joining all subdomain tables. One row per `consumer_id`. Input to standardization. |
| **major columns** | The columns subject to standardization: SSN, account number, address (line_1/2/city/state/zip/country), name (first/last/full), phone, email, DOB. |
| **PII_header_ID** | The primary key column on the consumer header. PII validation rules quarantine by this ID. |
| **Anchor** | External address-standardization process invoked driver-side in stage 4. |
| **KNL file** | Downstream output #1. `<<FILL_IN: consumer / format>>` |
| **Prep-Purp file** | Downstream output #2 — body records. `<<FILL_IN: format / consumer>>` |
| **Prep-Purp header file** | Downstream output #3 — header / manifest for the Prep-Purp body. |

## Job config

| Term | Meaning |
|------|---------|
| **job-config JSON** | The single long JSON passed as a workflow-job parameter. Contains domain, subdomain, connection details, per-table step instructions. |
| **credentials_ref** | Reference to a Databricks secret. Form: `<scope>/<key>`. Never a literal password. |
| **audit columns** | `_ingest_ts`, `_source_file`, `_ingest_run_id`, `_app_version` — added to every Bronze row. |

## Naming conventions

- **Table FQN**: `<catalog>.<schema>.<table>` — three-part UC name.
- **Catalog**: per-env — `<<FILL_IN: e.g. cert_dna_catalog / prod_dna_catalog>>`
- **Schema (Bronze)**: `<domain>_<subdomain>` — e.g. `consumer_dna`.
- **Schema (Silver)**: `<domain>_<subdomain>_silver`.
- **Profile table**: `<source_table>_profile` — sibling to source.
- **Error table**: `<subdomain>_error` — one per subdomain.

## What never to call it

- Don't say "table" when you mean "subdomain".
- Don't call profile rows "Bronze profile" — they live in `<table>_profile`.
- `SRCTYPE` ≠ `TGTTYPE`. Target is always `DELTA` today.
- "Anchor" is a product name (not an acronym). Don't write ANCHOR.
