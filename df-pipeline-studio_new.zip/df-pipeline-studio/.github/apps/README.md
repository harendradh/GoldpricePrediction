# .github/apps/ · Copilot context for the 3 monorepo apps

Source of truth for Copilot Chat / Copilot Code instructions for the three
Spark-Java apps in your data-factory monorepo.

| App | Purpose | Stack |
|-----|---------|-------|
| **data-ingestion** | Pull from Oracle / MySQL / Netezza / Snowflake / SQLServer / PostgreSQL / ADLS → Bronze Delta | Spark Java · JAR-on-volume · workflow job |
| **data-profiler** | Profile Bronze tables → `<table>_profile` Delta | Spark Java · same deploy pattern |
| **data-prep** | 6-stage pipeline (extraction → extraction_profiler → preparation → address_standardization → address_profiler → conversion) → 3 downstream files (KNL · Prep-Purp · Prep-Purp-header) | Spark Java · same deploy pattern |

## Phase-1 scope

Each app gets exactly **one auto-loaded instructions file**. That's it.
Detailed config schemas, per-source quirks, metric definitions, PII rule
catalog, etc. will land in Skill docs later — don't add them here yet.

```
.github/apps/
├── README.md                          ← you are here
├── _monorepo-layout.md                ← exact drop-in copy commands
├── _shared/glossary.md                ← domain vocabulary
├── copilot-instructions.md            ← repo-root template (mentions all 3 apps)
├── data-ingestion/instructions.md     → MONOREPO: .github/instructions/data-ingestion.instructions.md
├── data-profiler/instructions.md      → MONOREPO: .github/instructions/data-profiler.instructions.md
└── data-prep/instructions.md          → MONOREPO: .github/instructions/data-prep.instructions.md
```

See [`_monorepo-layout.md`](./_monorepo-layout.md) for the copy commands.

## Why this shape works for Copilot

- **`copilot-instructions.md` at the monorepo root** → auto-injected into every Copilot Chat prompt. Concise (~70 lines).
- **`.github/instructions/*.instructions.md` with `applyTo:` glob** → auto-loaded ONLY when editing files in that app. Concise (~70 lines each).
- **`docs/glossary.md`** → referenced when you `@workspace` ask about domain terms.

## Workflow

1. Edit context here (in studio) → review → commit.
2. Run the copy commands in `_monorepo-layout.md` to sync into the monorepo.
3. Push the monorepo → Copilot Chat picks up the new instructions on next session.

Studio = source. Monorepo = deploy target.

## `<<FILL_IN: ...>>` placeholders

Where I don't know specifics (Java 11 vs 17, Maven vs Gradle, the actual
catalog name), it's marked `<<FILL_IN: short description>>`. Search-and-replace
before shipping.
