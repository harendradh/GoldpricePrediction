---
applyTo: "apps/data-prep/**"
description: "Spark Java app — 5-stage consumer pipeline: extract → profile → standardize → address (Anchor) → convert+PII"
---

# Copilot · Data Prep app

> Loaded automatically when editing files under `apps/data-prep/`.
> Per-stage detail (config blocks, standardizer rules, PII rule list) will live in Skills later — keep edits high-level here.

## What it is

A Spark Java application that runs a 5-stage pipeline over all ingested
Bronze tables of a subdomain to produce three downstream files (KNL,
Prep-Purp, Prep-Purp-header). Failing PII records go to an ERROR bucket.

Same deployment as the other apps: JAR on UC volume + Databricks workflow
job + single long JSON config.

## The 5 stages

```
Bronze (from data-ingestion)
        │
        ▼
[1] EXTRACTION              · build wide consumer header by joining subdomain tables
        │                     → <silver>.<subdomain>_consumer_header
        ▼
[2] PROFILER                · metrics on every major column (drift vs previous run)
        │                     → <silver>.<subdomain>_consumer_header_profile
        ▼
[3] STANDARDIZATION         · per-major-column standardizers (SSN, account, name,
        │                     phone, email, DOB, address pre-format)
        │                     → <silver>.<subdomain>_consumer_header_std
        ▼
[4] ADDRESS (Anchor)        · external standardizer · driver-side file handoff
        │                     → <silver>.<subdomain>_consumer_header_addr
        ▼
[5] CONVERSION + PII        · PII_header_ID validation → ERROR bucket OR pass
                              · convert passed rows → 3 files in one pass:
                                  • KNL file
                                  • Prep-Purp file
                                  • Prep-Purp-header file
                              → <volume>/<subdomain>/conversion/<run_id>/
```

## Package layout (expected)

```
apps/data-prep/src/main/java/com/fiserv/dataforge/prep/
├── DataPrepApp.java                            // orchestrates the 5 stages
├── config/                                     // each stage has a typed sub-config
├── stage1_extraction/   ExtractionStage, ExtractQueryBuilder
├── stage2_profiler/     ProfilerStage
├── stage3_standardization/
│   ├── StandardizationStage, Standardizer (iface), StandardizerRegistry
│   └── <Type>Standardizer  (SSN, Account, Name, Phone, Email, Dob, AddressPre)
├── stage4_address/      AddressStage, AnchorClient, AnchorInputBuilder, AnchorOutputParser
├── stage5_conversion/
│   ├── ConversionStage
│   ├── pii/   PiiValidator, PiiRule (iface), PiiRuleRegistry, rules/<Rule>.java
│   └── output/   KnlFileWriter, PrepPurpFileWriter, PrepPurpHeaderWriter
├── error/   ErrorBucketWriter   // appends to <subdomain>_error (never truncates)
└── log/     PrepLog              // one row per (stage, run_id)
```

## Job-config JSON shape (high level)

```
{
  domain, subdomain,
  stages: {
    extraction:      { enabled, consumer_key, source_tables: [...], partition_filter, output_table },
    profiler:        { enabled, metrics, profile_columns: "major_only", drift: {...} },
    standardization: { enabled, major_columns: [ {name, type: SSN|ACCOUNT|NAME|PHONE|EMAIL|DOB|ADDRESS_LINE|CITY|STATE|POSTAL|COUNTRY, options} ] },
    address:         { enabled, anchor: { input_path, output_path, invoke_cmd, timeout_sec } },
    conversion:      { enabled, pii_rules: [...], outputs: { knl, prep_purp, prep_purp_header } }
  },
  run_options: { fail_fast }
}
```

Full per-stage schemas will live in future Skill docs.

## Conventions (this app)

- **Each stage is one class** with one entry point: `Stage.run(StageContext ctx, Dataset<Row> in) → Dataset<Row>`. `DataPrepApp` chains them.
- **Stages are sequential** — each writes a Silver table the next reads. Don't pipe `Dataset` between stages in memory.
- **Major columns are config-driven** — never hard-code column names in standardizers. The standardizer receives a `MajorColumn(name, type, options)`.
- **PII rules are pluggable** — one class per rule implementing `PiiRule`, registered in `PiiRuleRegistry`. Rules carry a `priority`.
- **Anchor is driver-side** — write input file → invoke process → read output file → DataFrame. Never call Anchor from a Spark worker.
- **Error bucket is append-only** — `<silver>.<subdomain>_error`. Each failed row carries `failing_rule_id`, `failed_columns`, `original_pii_header_id`, `run_id`.
- **PII columns are hashed** by their standardizer in stage 3 (SSN, ACCOUNT) — except address, which goes plaintext to Anchor in stage 4 and is hashed by stage 5 writers afterward.
- **Stage 5 writes 3 files in one pass** — cache the standardized DF, branch into 3 writers. Don't re-read.

## Anti-patterns

- ❌ Adding standardization logic inline in a stage — extend the `Standardizer` registry
- ❌ Calling Anchor from inside a Spark `mapPartitions` (driver-side only)
- ❌ Letting a row reach the conversion writers without going through `PiiValidator`
- ❌ Truncating the error bucket
- ❌ Hard-coding column names in PII rules — accept `column_name` from rule config
- ❌ Re-hashing a value the stage-3 standardizer already hashed
- ❌ Failing one stage and continuing — stages are sequential, abort on failure (except profiler, which is informational)
