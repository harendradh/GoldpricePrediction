---
applyTo: "apps/data-ingestion/**"
description: "Spark Java app — extract from JDBC/ADLS sources to Bronze Delta managed tables"
---

# Copilot · Data Ingestion app

> Loaded automatically when editing files under `apps/data-ingestion/`.
> Detailed config schema, per-source quirks, and runbook will live in Skills later — keep edits high-level here.

## What it is

A Spark Java application packaged as a JAR, uploaded to a UC volume, invoked
by a Databricks workflow job with a single long JSON config. Reads from one
of seven source types and writes a Bronze Delta managed table per source
table.

| Reads | Writes |
|-------|--------|
| Oracle · MySQL · Netezza · Snowflake · SQL Server · PostgreSQL · ADLS files | Bronze Delta managed tables in Unity Catalog |

## Job-config JSON shape (high level)

```
{
  domain, subdomain,
  src_connection: { type: SRCTYPE, host, port, database, credentials_ref, ... },
  tgt_connection: { type: "DELTA", catalog, schema, default_write_mode },   // OMIT for ADLS→ADLS in same catalog
  subdomain_tables: [ { name, source_table, target_table, write_mode, merge_keys, columns, schema_mode } ],
  steps: [ { step: "INGEST", enabled: true } ],
  run_options: { parallel, fail_fast, dry_run }
}
```

The full field-by-field schema will live in a future Skill doc.

## Package layout (expected)

```
apps/data-ingestion/src/main/java/com/fiserv/dataforge/ingestion/
├── DataIngestionApp.java                  // main entry
├── config/      ConfigParser, IngestionConfig, ConnectionConfig, TableConfig
├── reader/      SourceReader (iface), SourceReaderFactory, <Type>SourceReader (one per SRCTYPE)
├── writer/      BronzeWriter, AuditColumns
├── log/         IngestLog, RunContext
└── util/        Secrets, JdbcOptions
```

## Conventions (this app)

- **One class per SRCTYPE** implementing `SourceReader`. Add a source = add one class + one `SourceReaderFactory` case. Never branch on SRCTYPE outside the factory.
- **ADLS → ADLS skips `tgt_connection`** when target is the same UC catalog.
- **Audit columns** (`_ingest_ts`, `_source_file`, `_ingest_run_id`, `_app_version`) added to every Bronze row via `AuditColumns.add(df, ctx)`.
- **Write modes**: `APPEND` (default, partition by `ingest_date`) · `OVERWRITE` (full snapshot) · `MERGE` (needs `merge_keys[]`).
- **Schema modes**: `contract` (DDL declared in config; mismatch = fail) · `infer` · `evolve` (new columns allowed; type changes fail).
- **Secrets** via `Secrets.get(scope, key)` — wraps `dbutils.secrets.get`. Never log values. Reference in config as `credentials_ref: "<scope>/<key>"`.
- **Per-table parallelism**: when `run_options.parallel > 1`, driver runs a fixed thread pool — one Spark write per table concurrently.
- **Per-table audit row** appended to `<catalog>.<schema>.<subdomain>_ingest_log` (`status`, `rows_written`, `duration_ms`).

## Anti-patterns

- ❌ `if (SRCTYPE.equals("ORACLE"))` outside `SourceReaderFactory`
- ❌ Building JDBC URLs with string concatenation — use `JdbcOptions.builder()`
- ❌ Writing without audit columns
- ❌ Catching `SQLException` and silently continuing — fail the table, log status=`FAILED`
- ❌ Hard-coding the catalog name — read from `config.target.catalog`
- ❌ `printStackTrace()` — use SLF4J with `run_id` in MDC
