# GitHub Copilot · repo-wide instructions

> Copy to **`.github/copilot-instructions.md`** in the monorepo root.
> Copilot Chat auto-loads it on every prompt — keep it concise.

## What this repo is

A monorepo of three Spark-Java applications forming a data factory pipeline
that writes to Databricks Unity Catalog Delta tables.

| App folder | Purpose | Reads | Writes |
|-----------|---------|-------|--------|
| `apps/data-ingestion/` | Pull from JDBC/ADLS sources | Oracle · MySQL · Netezza · Snowflake · SQL Server · PostgreSQL · ADLS files | Bronze Delta tables |
| `apps/data-profiler/` | Compute profile stats on ingested tables | Bronze tables | `<table>_profile` Delta tables |
| `apps/data-prep/` | 5-stage consumer pipeline (extract → profile → standardize → address Anchor → convert + PII) | Bronze + profile tables | Silver tables + 3 downstream files (KNL · Prep-Purp · Prep-Purp-header) |

All three share the same shape: **Spark Java JAR on a UC volume, invoked by
a Databricks workflow job, parameterized with a single long JSON config**.

## Tech stack

- **Java**: `<<FILL_IN: 11 or 17>>`
- **Build**: `<<FILL_IN: Maven or Gradle>>`
- **Spark**: `<<FILL_IN: 3.5.x>>` on Databricks Runtime `<<FILL_IN: 14.3 LTS or 15.x>>`
- **Delta Lake**: managed tables only (no external locations)
- **Secrets**: Databricks secret scopes — referenced as `credentials_ref: "<scope>/<key>"`
- **Logging**: SLF4J + Log4j2

## Path-scoped instructions (auto-loaded)

| When editing… | Auto-loads |
|--------------|------------|
| `apps/data-ingestion/**` | `.github/instructions/data-ingestion.instructions.md` |
| `apps/data-profiler/**`  | `.github/instructions/data-profiler.instructions.md` |
| `apps/data-prep/**`      | `.github/instructions/data-prep.instructions.md` |

Each one is self-contained and includes the relevant config shape, package
layout, conventions, and anti-patterns for that app. Detailed schemas
(config keys, metrics catalog, PII rules) will live in future Skill docs.

## Cross-cutting rules (apply to all 3 apps)

1. **Never hard-code credentials.** Resolve via `Secrets.get(scope, key)` from `credentials_ref`.
2. **Never write to external locations.** Managed Delta under Unity Catalog only.
3. **Always include audit columns** in Bronze: `_ingest_ts`, `_source_file`, `_ingest_run_id`, `_app_version`.
4. **Use three-part FQN** for every table reference: `<catalog>.<schema>.<table>`.
5. **Validate the job-config JSON eagerly** — fail fast with a clear message before any Spark job runs.
6. **One subdomain = one job run.** Never multiplex.
7. **Idempotency**: re-running the same config with the same `run_id` must produce the same output.
8. **PII** (SSN · account · card · DOB · email · phone · address) is hashed (`sha2_256`) or truncated before leaving data-prep. The Anchor address step is the only PII-plaintext exception.

## What never to do

- ❌ `printStackTrace()` — use SLF4J with `run_id` in MDC
- ❌ Catch `Throwable` — catch the specific exception
- ❌ Add a new source type by branching `if (SRCTYPE.equals(...))` outside the factory
- ❌ Bypass stage-5 PII validation in data-prep
- ❌ Call the Anchor process from a Spark worker — driver-side only
- ❌ Add a dependency without checking it against the Databricks Runtime classpath

## Style

- Lines ≤ 120 chars · 2-space indent · `final` on locals not reassigned
- `verbNoun` methods, `NounImpl`/`Noun` for class/interface pairs
- Package layout per app: `com.fiserv.dataforge.<app>.{config,reader,writer,transform,validate,util}`

Reference: `docs/glossary.md` for domain vocabulary (domain, subdomain, SRCTYPE, consumer header, Anchor, KNL, Prep-Purp, ERROR bucket).
