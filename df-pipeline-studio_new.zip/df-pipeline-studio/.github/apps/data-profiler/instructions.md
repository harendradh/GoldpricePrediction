---
applyTo: "apps/data-profiler/**"
description: "Spark Java app — compute profile stats on Bronze tables, write to <table>_profile"
---

# Copilot · Data Profiler app

> Loaded automatically when editing files under `apps/data-profiler/`.
> Detailed metrics catalog + drift specifics will live in Skills later — keep edits high-level here.

## What it is

A Spark Java application that reads Bronze tables (produced by
data-ingestion) and writes profile statistics into sibling `<table>_profile`
Delta tables. Detects drift against the previous run.

Same deployment as data-ingestion: JAR on UC volume + Databricks workflow
job + single long JSON config.

| Reads | Writes |
|-------|--------|
| `<catalog>.<schema>.<table>` (Bronze) | `<catalog>.<schema>.<table>_profile` (sibling) · `drift_signal_<table>` (when drift fires) |

## Job-config JSON shape (high level)

```
{
  domain, subdomain,
  target_catalog, target_schema,
  subdomain_tables: [
    {
      name, fqn, profile_fqn,
      metrics: ["row_count","null_count","distinct_count","min","max","mean","stddev","top_n","pattern_freq"],
      profile_columns: "*" | ["col1","col2"],
      top_n: 20,
      drift: { enabled, baseline_strategy: "previous_run", thresholds: { ... } }
    }
  ],
  run_options: { parallel, fail_fast }
}
```

Field-by-field schema and metric definitions will live in a future Skill doc.

## Package layout (expected)

```
apps/data-profiler/src/main/java/com/fiserv/dataforge/profiler/
├── DataProfilerApp.java
├── config/   ConfigParser, ProfilerConfig, TableProfileConfig
├── metric/   Metric (iface), MetricsRunner, <Name>Metric (one per metric)
├── drift/    DriftDetector, DriftThresholds
├── writer/   ProfileWriter, ProfileShaper
└── log/      ProfileLog
```

## Profile-row shape (one row per column×metric×run)

```
table_fqn, column_name, metric,
value_numeric, value_string, value_struct,    // sparse — populate only the matching type
run_id, computed_ts
```

`value_struct` is JSON for multi-value metrics like `top_n` and `pattern_freq`.

## Conventions (this app)

- **One class per metric** implementing the `Metric` interface. Adding a metric = adding one class + one `MetricsRunner` dispatch entry.
- **Fuse aggregations** — `MetricsRunner.batch(...)` combines metrics that can share a single Spark action (e.g. count/min/max/mean/stddev all in one pass).
- **Drift compares against `previous_run`** by default — pulls latest prior profile rows for the same table and deltas the metrics.
- **No baseline = graceful no-op**: log "no baseline, drift skipped" and continue.
- **Source-missing = skip**: if Bronze table doesn't exist, log `status=SKIPPED` in `<subdomain>_profile_log`, continue.

## Anti-patterns

- ❌ Adding metric logic inline in `MetricsRunner` — extend the dispatch table
- ❌ Separate Spark actions for metrics that could trivially fuse with `Basic`
- ❌ Hard-coding metric names — read from `table.metrics[]`
- ❌ Writing profile rows outside `ProfileWriter`
