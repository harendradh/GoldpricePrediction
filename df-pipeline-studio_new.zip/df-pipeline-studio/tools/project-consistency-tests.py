#!/usr/bin/env python3
"""
Project-wide consistency tests for the DCS Data Factory Pipeline Studio.

Validates that:
  - Every agent referenced from copilot-instructions.md exists on disk
  - Every skill referenced from any agent.md exists on disk
  - Every reference doc inside a skill exists
  - Output paths declared by agents match what the studio claims to write
  - No stale references to removed features (info.md w/o per-mode prefix · runner notebooks)
  - File counts / structural invariants hold

Run from the project root:
  python tools/project-consistency-tests.py
"""

import sys
import re
import os
from pathlib import Path

# Force UTF-8 stdout on Windows (cp1252 default chokes on ✓ / →)
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')

ROOT = Path(__file__).resolve().parent.parent
PASS = 0
FAIL = 0
SUITES = 0


def suite(name: str) -> None:
    global SUITES
    SUITES += 1
    print(f"\n{'━' * 70}")
    print(f"━━ {name}")
    print('━' * 70)


def check(label: str, ok: bool, detail: str = '') -> None:
    """Print a single assertion result, accumulate pass/fail counts."""
    global PASS, FAIL
    if ok:
        PASS += 1
        print(f"  ✓ {label}")
    else:
        FAIL += 1
        print(f"  ✗ {label}" + (f' — {detail}' if detail else ''))


def read(path: Path) -> str:
    try:
        return path.read_text(encoding='utf-8')
    except Exception:
        return ''


def exists(rel: str) -> bool:
    return (ROOT / rel).exists()


# ─────────────────────────────────────────────────────────────────────────
# Suite 1 · Top-level structure
# ─────────────────────────────────────────────────────────────────────────
suite('1 · Top-level structure')
check('README.md exists',            exists('README.md'))
check('agents/ exists',              (ROOT / 'agents').is_dir())
check('.github/skills/ exists',      (ROOT / '.github' / 'skills').is_dir())
check('.github/instructions/ exists',(ROOT / '.github' / 'instructions').is_dir())
check('.github/rules/ exists',       (ROOT / '.github' / 'rules').is_dir())
check('.github/apps/ exists',        (ROOT / '.github' / 'apps').is_dir())
check('tools/ exists',               (ROOT / 'tools').is_dir())
check('output/ exists',              (ROOT / 'output').is_dir())
check('specs/ exists',               (ROOT / 'specs').is_dir())
check('docs/ exists',                (ROOT / 'docs').is_dir())

# ─────────────────────────────────────────────────────────────────────────
# Suite 2 · Agent inventory
# ─────────────────────────────────────────────────────────────────────────
suite('2 · Agent inventory')
expected_agents = ['data_ingest', 'data_forge', 'data_prep', 'data_doc', 'data_lineage']
expected_orchestrators = ['data_pipeline_master']   # multi-agent orchestrators (composed FROM expected_agents)
for a in expected_agents + expected_orchestrators:
    check(f'agents/{a}.md exists', exists(f'agents/{a}.md'))

agent_files = sorted([p.name for p in (ROOT / 'agents').glob('*.md')])
expected_files = sorted(f'{n}.md' for n in expected_agents + expected_orchestrators)
check(f'exactly {len(expected_files)} agent files (5 phase + {len(expected_orchestrators)} orchestrator) — no orphans',
      agent_files == expected_files,
      f'found: {agent_files} · expected: {expected_files}')

# Every agent file must have YAML frontmatter with type:agent (for IDE slash-command discoverability)
# + a fallback_models list (so frontmatter-aware tools can swap models if the primary is unavailable)
for a in expected_agents + expected_orchestrators:
    txt = read(ROOT / 'agents' / f'{a}.md')
    # Frontmatter window can be large for orchestrators (many skills listed) — search first 1500 chars
    head = txt[:1500]
    has_frontmatter = head.startswith('---\n') and '\n---\n' in head
    check(f'  agents/{a}.md has YAML frontmatter (type:agent)',
          has_frontmatter and 'type: agent' in head and f'name: {a}' in head)
    check(f'  agents/{a}.md declares fallback_models list',
          'fallback_models:' in head and 'claude-3.5-sonnet' in head)

# ─────────────────────────────────────────────────────────────────────────
# Suite 3 · Skill inventory (every agent has the skills it references)
# ─────────────────────────────────────────────────────────────────────────
suite('3 · Skill references resolve')
for agent in expected_agents:
    text = read(ROOT / 'agents' / f'{agent}.md')
    refs = re.findall(r'\.github/skills/[A-Za-z0-9_/]+/(?:SKILL\.md|references/[A-Za-z0-9_-]+\.md)', text)
    for ref in set(refs):
        check(f'  {agent} → {ref}', exists(ref))

# ─────────────────────────────────────────────────────────────────────────
# Suite 4 · Stale "info.md" cleanup (mode-specific naming standard)
# ─────────────────────────────────────────────────────────────────────────
suite('4 · No stale info.md references in agent / instruction docs')
allowed = {'ingestion_info.md', 'dataprep_info.md', 'runbook.md'}

def check_no_bare_info_md(rel: str) -> None:
    txt = read(ROOT / rel)
    # Find any "info.md" not preceded by ingestion_ or dataprep_
    hits = []
    for m in re.finditer(r'(?<![a-z_])info\.md', txt):
        # OK if preceded by 'ingestion_' or 'dataprep_'
        start = max(0, m.start() - 10)
        prefix = txt[start:m.start()]
        if prefix.endswith('ingestion_') or prefix.endswith('dataprep_'):
            continue
        # OK if it's inside an explicit "<...|...>.md" template like {ingestion_info|...|runbook}.md
        end_window = txt[m.start():m.end()+40]
        if '|' in txt[max(0,m.start()-50):m.start()]:
            continue
        # OK if it's a pedagogical "old `info.md`" / "stale info.md" mention describing what was REMOVED
        # (look back further for words that mark it as a retrospective reference)
        ctx_back = txt[max(0, m.start()-30):m.start()].lower()
        if any(w in ctx_back for w in ['old `', 'old ', 'stale ', 'legacy ', 'deprecated ', 'no bare ', 'no longer ']):
            continue
        hits.append(m.start())
    check(f'  {rel} — no bare "info.md"', len(hits) == 0,
          f'{len(hits)} occurrences')

for f in [
    'agents/data_doc.md', 'agents/data_ingest.md', 'agents/data_prep.md',
    'agents/data_forge.md', 'agents/data_lineage.md',
    '.github/copilot-instructions.md',
    'README.md', 'output/README.md', 'tools/README.md',
]:
    if exists(f):
        check_no_bare_info_md(f)

# ─────────────────────────────────────────────────────────────────────────
# Suite 5 · No stale runner-notebook references
# ─────────────────────────────────────────────────────────────────────────
suite('5 · No stale runner-notebook references')
def check_no_runner(rel: str) -> None:
    txt = read(ROOT / rel).lower()
    # 'runner' is OK in compound words; flag only ACTIVE references to runner notebooks
    # (not pedagogical "no runner notebook" / "runner notebooks were removed" sentences).
    # Strategy: tokenise into sentences, drop any sentence that explicitly negates
    # or describes the removal, then look for "runner notebook" / "/runners/" in what's left.
    sentences = re.split(r'[\.\n]', txt)
    leftovers = []
    for s in sentences:
        if 'runner notebook' not in s and '/runners/' not in s and 'runners ←' not in s:
            continue
        # Skip retrospective / negation contexts
        if any(p in s for p in ['no separate runner', 'no runner', 'runner notebook was', 'runner notebooks were',
                                'runners/` directory', 'runners/ directory', 'were removed', 'are gone',
                                'no longer', 'removed (', 'no `runners', 'stale `runners',
                                'old runner', 'previously wrote', 'legacy', 'deprecated',
                                'leftovers', 'pedagogical']):
            continue
        leftovers.append(s.strip()[:60])
    bad = len(leftovers) > 0
    detail = '; '.join(leftovers[:3]) if bad else ''
    check(f'  {rel} — no runner-notebook leftovers', not bad, detail)

for f in [
    'agents/data_doc.md', 'agents/data_ingest.md', 'agents/data_prep.md',
    'agents/data_forge.md',
    '.github/copilot-instructions.md',
    'output/README.md', 'tools/README.md',
    'tools/data-factory-pipeline-studio.html',
]:
    if exists(f):
        check_no_runner(f)

# ─────────────────────────────────────────────────────────────────────────
# Suite 6 · Studio registry consistency
# ─────────────────────────────────────────────────────────────────────────
suite('6 · Studio · PIPELINES registry has 5 entries + matches agents/')
studio = read(ROOT / 'tools' / 'data-factory-pipeline-studio.html')
for k in ['home', 'ingest', 'eda', 'dataprep', 'docs', 'onboard']:
    check(f'  PIPELINES.{k} entry exists',
          re.search(rf"\b{k}:\s*\{{[^{{}}]*?id:\s*['\"]{k}['\"]", studio, re.DOTALL) is not None)

# Each registered agent in PIPELINES corresponds to an agents/*.md.
# Skip `data_prepurpose.md` — it's an intentional example used by
# `loadOnboardExample()` to demonstrate how a team would onboard a NEW pipeline
# (i.e. the agent file doesn't have to exist yet — the example is teaching the
# pattern).
KNOWN_EXAMPLES = {'agents/data_prepurpose.md'}
for agent_path in set(re.findall(r"agent:\s*'(agents/[a-z_]+\.md)'", studio)):
    if agent_path in KNOWN_EXAMPLES:
        check(f'  Studio agent ref: {agent_path} (example · skipped)', True)
    else:
        check(f'  Studio agent ref: {agent_path}', exists(agent_path))

# ─────────────────────────────────────────────────────────────────────────
# Suite 7 · Rule catalog integrity
# ─────────────────────────────────────────────────────────────────────────
suite('7 · Rule catalog · 10 categories present')
expected_categories = [
    'address','always_on','boolean','categorical','contact',
    'datetime','identity','monetary','name','pii_masking'
]
for cat in expected_categories:
    check(f'  rules/categories/{cat}.yaml exists',
          exists(f'.github/rules/categories/{cat}.yaml'))
check('  catalog.yaml master index exists',
      exists('.github/rules/catalog.yaml'))
check('  rule_schema.yaml meta-schema exists',
      exists('.github/rules/rule_schema.yaml'))

# ─────────────────────────────────────────────────────────────────────────
# Suite 8 · Apps context (monorepo Copilot)
# ─────────────────────────────────────────────────────────────────────────
suite('8 · Apps context (.github/apps/)')
for f in ['README.md', '_monorepo-layout.md', '_shared/glossary.md',
          'copilot-instructions.md',
          'data-ingestion/instructions.md',
          'data-profiler/instructions.md',
          'data-prep/instructions.md']:
    check(f'  .github/apps/{f}',
          exists(f'.github/apps/{f}'))

# ─────────────────────────────────────────────────────────────────────────
# Suite 9 · data_lineage agent + skill end-to-end
# ─────────────────────────────────────────────────────────────────────────
suite('9 · data_lineage agent + skill complete')
check('agents/data_lineage.md exists',
      exists('agents/data_lineage.md'))
check('.github/skills/lineage/builder/SKILL.md exists',
      exists('.github/skills/lineage/builder/SKILL.md'))
for ref in ['extraction_rules.md', 'mermaid_template.md', 'output_template.md']:
    check(f'  references/{ref}',
          exists(f'.github/skills/lineage/builder/references/{ref}'))

# ─────────────────────────────────────────────────────────────────────────
# Suite 10 · Per-mode doc output names referenced in studio
# ─────────────────────────────────────────────────────────────────────────
suite('10 · Studio uses the 3 standardized doc filenames')
for fname in ['ingestion_info.md', 'dataprep_info.md', 'runbook.md']:
    check(f'  studio HTML references {fname}', fname in studio)

# ─────────────────────────────────────────────────────────────────────────
# Suite 11 · Test files self-consistency
# ─────────────────────────────────────────────────────────────────────────
suite('11 · Test files exist + runnable')
for f in ['tools/studio-tests.py', 'tools/json-studio-tests.py']:
    check(f'  {f}', exists(f))

# ─────────────────────────────────────────────────────────────────────────
# Suite 12 · Architecture HTML reflects current framework state
# ─────────────────────────────────────────────────────────────────────────
suite('12 · Architecture slide reflects current framework')
arch = read(ROOT / 'docs' / 'data-factory-pipeline-architecture.html')
check('arch HTML exists',                exists('docs/data-factory-pipeline-architecture.html'))
check('no rocket emoji 🚀 left',         '🚀' not in arch)
check('uses inline Fiserv SVG (brandlogo)','class="brandlogo"' in arch and 'archlogo-grad' in arch)
check('Fiserv → DCS in brandmark',       'DCS · Data Factory' in arch)
check('Fiserv → DCS in footer',          'DCS Data Factory · Pipeline Studio' in arch)
check('data_lineage agent in Tier 3',    'data_lineage' in arch)
# Lineage Graph deliverable was REMOVED · out of scope per v1.0 narrative (not the Fiserv usage pattern)
check('Lineage Graph deliverable removed','Lineage Graph' not in arch)
check('Runner Notebooks REMOVED',        'Runner Notebooks' not in arch)
check('5 specialized agents in props',   '5 specialized agents' in arch)

# ── Master orchestrator + E2E "Run All" wiring ──
check('data_pipeline_master agent exists',   exists('agents/data_pipeline_master.md'))
master_md = read(ROOT / 'agents' / 'data_pipeline_master.md')
check('  master delegates to all 4 phase agents',
      'data_ingest' in master_md and 'data_forge' in master_md
      and 'data_prep' in master_md and 'data_doc' in master_md)
check('  master describes 4-phase strict order',
      'Phase 1' in master_md and 'Phase 4' in master_md)
check('  master has YAML frontmatter (type:agent)',
      master_md.startswith('---\n') and 'type: agent' in master_md[:500]
      and 'name: data_pipeline_master' in master_md[:500])
studio = read(ROOT / 'tools' / 'data-factory-pipeline-studio.html')
check('Studio: docs included in E2E (Run All) flow',
      "includeInE2E:true,    // included in Run-All" in studio)
check('Studio: e2eBuildCombinedInvocation emits master invocation',
      'data_pipeline_master.md' in studio and 'Run the full pipeline end-to-end' in studio)
check('Studio: per-step invocation kept as fallback (e2eBuildPerStepInvocation)',
      'function e2eBuildPerStepInvocation(' in studio)
# Always-master invocation: regardless of how many specs were saved, the wizard
# emits the master orchestrator + every saved spec. The master agent handles
# partial spec sets explicitly (NOT_ATTEMPTED for missing phases).
check('Studio: invocation builder returns {text, mode, savedCount, skippedCount}',
      "return { text:" in studio
      and "mode: 'master'" in studio
      and "savedCount: saved.length" in studio
      and "skippedCount: skipped.length" in studio)
check('Studio: ALWAYS uses master invocation (no per-step fallback in main path)',
      'ALWAYS build the MASTER invocation' in studio)
check('Studio: per-step builder kept as legacy helper only',
      'function e2eBuildPerStepInvocation(' in studio and 'Legacy helper' in studio)
check('Studio: final-step header chip shows skipped count + NOT_ATTEMPTED note',
      'id="e2eInvMode"' in studio and 'NOT_ATTEMPTED' in studio)
check('Studio: master-mode CSS variant present',
      '.e2e-inv-mode.master{' in studio)

# Render toggle is available on all 4 spec-producing tabs (was: docs only)
check('Studio: render toggle available on ingest/eda/dataprep/docs',
      "RENDER_TABS = ['ingest', 'eda', 'dataprep', 'docs']" in studio
      and 'supportsRender' in studio)
check('Studio: render branch checks supportsRender (not just docs)',
      "if (supportsRender && STATE._previewMode==='render')" in studio)

# Absolute-path input + persistence + use in launch
check('Studio: folderAbsPath in STATE init',
      'folderAbsPath:\'\'' in studio)
check('Studio: folderAbsPath persisted to localStorage',
      'folderAbsPath: STATE.folderAbsPath' in studio
      and 'STATE.folderAbsPath = slim.folderAbsPath' in studio)
check('Studio: workspace-path input row + clear button',
      'id="absPathRow"' in studio
      and 'id="folderAbsPath"' in studio
      and 'id="btnClearAbsPath"' in studio)
check('Studio: resolveAbsFolderPath() helper exists',
      'function resolveAbsFolderPath(' in studio)
check('Studio: launchAgent uses resolveAbsFolderPath',
      'const folder = resolveAbsFolderPath()' in studio)
check('Studio: vscode:// URL preserves path slashes (vscodeUrlPath helper)',
      'function vscodeUrlPath(' in studio
      and 'encodeURIComponent(seg)' in studio)
check('Studio: warns when only leaf name available (no abs path set)',
      "VS Code can't open just" in studio
      or 'Set the Workspace path' in studio)
check('Studio: pickFolder prompts user to set abs path on first link',
      'paste the FULL workspace path' in studio
      or 'showAbsPathRow()' in studio)

# Editable spec preview · per-tab override
check('Studio: spec-editor textarea present',     'id="specEditor"' in studio)
check('Studio: edit-toggle button group',
      'id="btnEditSpec"' in studio
      and 'id="btnApplyEdit"' in studio
      and 'id="btnCancelEdit"' in studio
      and 'id="btnResetEdit"' in studio)
check('Studio: "✎ edited" pill markup',           'id="editedPill"' in studio and 'edited-pill' in studio)
check('Studio: STATE._specOverrides initialised', '_specOverrides: {}' in studio)
check('Studio: overrides persisted to localStorage',
      '_specOverrides: STATE._specOverrides' in studio
      and 'STATE._specOverrides =' in studio)
check('Studio: buildSpec returns override when set',
      'STATE._specOverrides && STATE._specOverrides[STATE.active]' in studio
      and "typeof override === 'string'" in studio)
check('Studio: edit-mode helpers exist (enter/apply/cancel/reset)',
      'function enterEditMode(' in studio
      and 'function applyEdit(' in studio
      and 'function cancelEdit(' in studio
      and 'function resetEdit(' in studio)
check('Studio: keyboard shortcuts (Ctrl+Enter apply · Esc cancel)',
      "(e.ctrlKey || e.metaKey) && e.key === 'Enter'" in studio
      and "e.key === 'Escape'" in studio)
check('Studio: editor CSS (orange ring + min-height)',
      '#specEditor{' in studio and 'min-height:480px' in studio)
check('Studio: edit-toggle visibility tied to supportsRender',
      "RENDER_TABS = ['ingest', 'eda', 'dataprep', 'docs']" in studio
      and "editToggle.style.display = supportsRender" in studio)

# Regression: refresh() must have AT MOST ONE `const p = pipelineById(STATE.active)`
# at its top level (the long-standing one near `btn.className = 'huge'`). A second
# declaration in the SAME block scope is a SyntaxError that silently bricks the entire
# <script> on parse → no tabs, no preview, nothing works. Don't let this regress.
def _refresh_body() -> str:
    m = re.search(r'^function refresh\(\)\s*\{', studio, re.MULTILINE)
    if not m:
        return ''
    start = m.end()
    depth = 1
    i = start
    while i < len(studio) and depth > 0:
        c = studio[i]
        if c == '{': depth += 1
        elif c == '}': depth -= 1
        i += 1
    return studio[start:i]
_refresh = _refresh_body()
check('Studio: refresh() has ≤ 1 top-level `const p =` (no SyntaxError regression)',
      _refresh.count('const p = pipelineById(STATE.active)') <= 1,
      f'found {_refresh.count("const p = pipelineById(STATE.active)")} occurrences — duplicate `const p` in same scope is a SyntaxError')
check('Studio: refresh() uses _activeP for the new edit-mode lookup (avoids `p` collision)',
      'const _activeP = pipelineById(STATE.active)' in studio)
# Master agent prompt must explicitly document partial-spec-set handling
master_md = read(ROOT / 'agents' / 'data_pipeline_master.md')
check('master agent · documents partial-spec-set handling',
      'Partial spec sets are normal' in master_md
      and 'NOT_ATTEMPTED' in master_md
      and 'fewer than 4' in master_md
      and 'specs attached' in master_md)
check('master agent · NOT_ATTEMPTED row in end-of-run summary template',
      'NOT_ATTEMPTED' in master_md and 'no spec was attached for that phase' in master_md)
# Modal scroll fix: max-height + overflow-y so submit buttons can't clip below viewport
check('Studio: modal capped at 92vh + scroll body internally',
      'max-height:92vh' in studio and 'overflow-y:auto' in studio)
check('Studio: modal action row sticky at bottom (always reachable)',
      '.modal > .modal-actions{' in studio and 'position:sticky' in studio)

# ── DP source-mode pane uniform sizing ──
check('DP source panes uniform min-height',
      '#tablePane, #hqPane, #eqPane{' in studio and 'min-height:240px' in studio)
check('DP pane fade-in animation present',
      '@keyframes paneFadeIn' in studio)
check('DP radio-pill cards stretch to equal height',
      'align-items:stretch' in studio and 'min-height:64px' in studio)
check('DP textareas/inputs have orange focus ring',
      '#hqPane textarea:focus' in studio and 'box-shadow:0 0 0 3px rgba(255,98,0,.15)' in studio)

# ── Tier-4 Deliverables · 5 tiles · uniform sizing · no "solves" chips ──
# (chips were removed for visual cleanliness · titles are self-explanatory)
check('Deliverable · One-form Job Profiles', 'One-form Job Profiles' in arch)
check('Deliverable · Auto-tuned Profiling',  'Auto-tuned Profiling' in arch)
check('Deliverable · Reusable EDA + Golden Record',
                                             'Reusable EDA + Golden Record' in arch)
check('Deliverable · Auto-generated Docs + Runbooks',
                                             'Auto-generated Docs + Runbooks' in arch)
check('Deliverable · Shared Spec Format & Catalog',
                                             'Shared Spec Format' in arch and '&amp; Catalog' in arch)
check('5 deliv tiles with new color classes',
      'deliv prof' in arch and 'deliv eda' in arch and 'deliv std' in arch)

# "solves …" chips MUST be removed everywhere (visual cleanliness · removed by user request)
check('  no "solves complex onboarding" chip','solves complex onboarding' not in arch)
check('  no "solves manual profiling" chip',  'solves manual profiling' not in arch)
check('  no "solves EDA done twice" chip',    'solves EDA done twice' not in arch)
check('  no "solves late ... runbooks" chip', 'solves late hand-typed' not in arch)
check('  no "solves every-team-reinvents" chip','solves every-team-reinvents' not in arch)

# Uniform sizing — t4-uniform tier class + flex:1 layout
check('t4-uniform tier class wired',          't4-uniform' in arch)
check('  uniform tile flex:1 layout',         'flex:1 1 0' in arch)
check('  uniform tile min-height',            'min-height:118px' in arch or 'min-height: 118px' in arch)

# Value-prop row no longer claims PII auto-masking (Fiserv Protector covers that)
check('value prop · no PII auto-masked claim',
      'PII auto-detected · auto-masked · auto-tagged' not in arch)
check('value prop · DQ-focused (drift + freshness + quarantine)',
      'drift · freshness · quarantine' in arch)
check('38-rule catalog mentioned',       '38-rule catalog' in arch)
# UI Layer (Tier 2) was simplified · single centered "Pipeline Studio" hero tile.
# Onboard / Home Dashboard / Lineage / Team-filter all still ship in the studio
# itself — just not enumerated as separate tiles on the architecture slide.
check('UI Layer · single Pipeline Studio hero tile', 'studio-hero' in arch and 'Pipeline Studio' in arch)
check('UI Layer · exactly one .tile.studio in tier-2 area',
      arch.count('tile studio studio-hero') == 1
      and arch.count('class="tile studio"') == 0)
check('UI Layer · old enumeration tiles dropped',
      'Home Dashboard</b>' not in arch
      and 'Team filter</b>' not in arch
      and 'Lineage · Review · Run-All' not in arch)
check('current version label in footer', 'v1.0' in arch or 'v1.1' in arch)
check('arch HTML mentions multi-subdomain',  'multi-subdomain' in arch or 'multi-Subdomain' in arch or 'subdomain' in arch.lower())
check('arch HTML mentions sticky toolbar / collapsible', 'sticky toolbar' in arch or 'collapsible' in arch)
check('arch HTML data_ingest card mentions N subdomain',
      'N Bronze' in arch or 'multi-subdomain' in arch)
check('standalone logo file present',    exists('docs/architecture/fiserv-logo.svg'))
# v3 redesign · master-detail (no flip · no overlap · shared details panel)
check('Static agent-card tiles (no flip)',    'class="agent-card' in arch and 'class="flip-card' not in arch)
check('  5 agent cards (one per agent)',      arch.count('class="agent-card') == 5)
check('  stage pill on each card',            arch.count('class="stage-pill') == 5)
check('  cross-badge on lineage card',        'class="cross-badge"' in arch)
check('  data-* attributes for details',      'data-reads=' in arch and 'data-writes=' in arch and 'data-spec=' in arch and 'data-agent-file=' in arch)
check('Shared details panel #agentDetails',   'id="agentDetails"' in arch and 'class="agent-details"' in arch)
check('  selectAgent() handler script',       'function selectAgent(card)' in arch)
check('  click → selectAgent wired',          'onclick="selectAgent(this)"' in arch)
check('  active card highlighting CSS',       '.agent-card.active{' in arch and '.agent-row:has(.agent-card.active)' in arch)
check('Animated lifecycle strip',             'class="lifecycle-strip"' in arch and 'class="strip-pulse"' in arch)
# ── PROBLEM panel (above the solution flow) — v1.0 narrative framing ──
# Focused on: complex onboarding · manual data profiling · EDA done twice ·
# runbooks hand-typed late · every team reinvents. PII compliance is NOT in
# this list (Fiserv Protector handles it). Lineage is NOT in this list either.
check('Problem panel exists above flow',      'class="problem-panel"' in arch and 'class="problem-badge"' in arch)
check('  problem title is gradient text',     'class="problem-title"' in arch)
check('  5 problem cards listing pain points',arch.count('class="problem-card"') == 5)
check('  problem-card icons + titles + descs',
      'class="pc-ico"' in arch and 'class="pc-title"' in arch and 'class="pc-desc"' in arch)
check('  warning stripe animation present',   '@keyframes stripeBreathe' in arch)
check('  badge pulse animation present',      '@keyframes badgePulse' in arch)
check('  solution-divider transitions to flow','class="solution-divider"' in arch and 'sd-pill' in arch)
check('  problem panel uses red accent',      'rgba(229,57,53' in arch)
check('  responsive grid breakpoints',        'grid-template-columns:repeat(3,1fr)' in arch and 'grid-template-columns:repeat(2,1fr)' in arch)

# Lock in the 5 specific pain-points covered (titles)
check('  pain · complex job-profile onboarding',
      'Complex job-profile onboarding' in arch)
check('  pain · manual data profiling',
      'Data profiling is manual guesswork' in arch)
check('  pain · EDA done twice',
      'EDA done twice' in arch)
check('  pain · runbooks last-minute / hand-typed',
      'Runbooks are last-minute' in arch)
check('  pain · every team reinvents',
      'Every team reinvents' in arch)

# OUT-OF-SCOPE pains MUST stay removed (Fiserv Protector handles PII · lineage skipped)
check('  PII-compliance card removed (Fiserv Protector covers it)',
      'PII compliance is ad-hoc' not in arch)
check('  Lineage pain-card removed (out of scope)',
      'No end-to-end lineage' not in arch)
check('  no "Specs live in heads" / stale phrasing in title',
      'Pipelines are built differently by every team' not in arch)

# Premium-card visual upgrade (v1.0 polish)
check('  each card has pulsing alert-dot indicator',
      arch.count('class="pc-dot"') == 5)
check('  cards 1-4 have animated connector elements',
      arch.count('class="pc-connector"') == 4)
check('  card-breathe stagger animation present',
      '@keyframes cardBreathe' in arch and '--bd:' in arch)
check('  connector pulse cascade animation present',
      '@keyframes connectorPulse' in arch and '--cp:' in arch)
check('  alert-dot pulse animation present',
      '@keyframes dotPulse' in arch)
check('  glowing top accent line on every card',
      '.problem-card::before' in arch)
check('  chevron arrow between cards (::after)',
      '.problem-card:not(:last-child)::after' in arch)
check('  icon-in-halo badge styling',
      'radial-gradient(circle at 35% 30%' in arch
      and 'border-radius:50%' in arch)
check('  connectors hidden on wrapped layouts',
      '.problem-card .pc-connector{display:none}' in arch or '.pc-connector{display:none}' in arch)
check('  prefers-reduced-motion stops card animations',
      '.problem-card                    { animation:none }' in arch
      or '.problem-card { animation:none }' in arch.replace('  ',' ').replace('   ',' '))
# Animated 4-step Read → Spec → Agent → Write flow chart (v1.0 polish · yellow circle + rectangle)
check('Agent flow chart container',           'class="agent-flow"' in arch and 'id="agentFlow"' in arch)
check('  4 flow-step nodes · Read/Spec/Agent/Write',
      'class="flow-step fn-read"' in arch and 'class="flow-step fn-spec"' in arch
      and 'class="flow-step fn-agent"' in arch and 'class="flow-step fn-write"' in arch)
check('  3 arrows between the 4 steps',       arch.count('class="flow-arrow"') >= 3)
check('  flow-pulse dot inside every arrow',  arch.count('class="flow-pulse"') >= 3)
check('  yellow CIRCLE per step',             arch.count('class="flow-circle"') >= 4)
check('  numbered badge on every circle',     arch.count('class="circle-num"') >= 4)
check('  step icons present (📖 📄 🤖 📦)',
      '"circle-ico">📖' in arch and '"circle-ico">📄' in arch
      and '"circle-ico">🤖' in arch and '"circle-ico">📦' in arch)
check('  rectangle bullet card per step',     arch.count('class="flow-rect"') >= 4)
check('  step label uppercase chrome',        'class="flow-step-label"' in arch)
check('  CSS yellow gradient on circles',     '#ffd54f' in arch and 'radial-gradient' in arch)
check('  @keyframes pulseTravel animation',   '@keyframes pulseTravel' in arch)
check('  is-active stepper class on flow-step','.flow-step.is-active' in arch or 'flow-step is-active' in arch)
check('  startFlowSequence() JS scheduler',   'function startFlowSequence(' in arch)
check('  _bullets() helper splits · separator',
      'function _bullets(' in arch and "split(/\\s+·\\s+" in arch)
check('  AGENT step pulls phase-specific skills bullet',
      'consults .github/skills/' in arch and '_phaseFromCard' in arch)
check('  prefers-reduced-motion fallback',    'prefers-reduced-motion' in arch)
check('  vertical stack on narrow screens',   '@keyframes pulseTravelV' in arch)

# Vertical scroll fix · the slide grew past viewport (Problem panel + agent flow +
# Deliverables) — body MUST be scrollable + scrollbar MUST be visible/styled.
# Was: html,body{overflow:hidden} — locked single-screen pitch deck. Now: scrollable
# with custom Fiserv-orange scrollbar so reviewers can clearly see they can scroll.
check('arch HTML body is scrollable',        'overflow-y:auto' in arch and 'min-height:100%' in arch)
check('arch HTML drops the old overflow:hidden body',
      'html,body{height:100%;width:100%;overflow:hidden' not in arch)
check('arch HTML has custom orange scrollbar (webkit + firefox)',
      'body::-webkit-scrollbar' in arch and 'scrollbar-color:var(--fiserv-orange)' in arch)
check('arch HTML slide uses min-height (was height:100%)',
      'min-height:100vh' in arch)
check('arch HTML stage is non-interactive backdrop (pointer-events:none)',
      'pointer-events:none' in arch and 'position:fixed;inset:0;overflow:hidden' in arch)
check('  selectAgent() calls startFlowSequence',
      'selectAgent' in arch and 'startFlowSequence();' in arch)
# v1.0 polish: auto-cycling is intentionally OFF · all 4 steps stay lit so
# presenters can talk about Data Ingestion without the spotlight moving.
check('  no setInterval rotation in startFlowSequence',
      'setInterval(tick' not in arch and 'setInterval(_tick' not in arch)
check('  all 4 steps get .is-active simultaneously (static-lit mode)',
      'nodes.forEach(n => n.classList.add(\'is-active\'))' in arch)
check('  static-lit intent documented (no auto-spotlight rotation)',
      'auto-cycling is intentionally OFF' in arch
      or 'auto-cycling' in arch.lower()
      or 'Static-lit mode' in arch)
check('  5 numbered ticks',                   arch.count('class="strip-tick') == 5)  # 4 plain + 1 cross
check('CSS responsive grid (5→3→2)',          '@media (max-width:1100px)' in arch and '@media (max-width:760px)' in arch)

# ─────────────────────────────────────────────────────────────────────────
# Suite 13 · Studio Home Dashboard — structure + wiring
# ─────────────────────────────────────────────────────────────────────────
suite('13 · Studio Home Dashboard wired correctly')
studio = read(ROOT / 'tools' / 'data-factory-pipeline-studio.html')

# Dashboard HTML structure
check('panel-home contains dashboard scope',     'id="dashboardScope"' in studio)
check('KPI row container present',               'class="kpi-row" id="kpiRow"' in studio)
check('  5 KPI cards',                           studio.count('class="kpi-num"') == 5)
check('  kpiPipelines KPI present',              'id="kpiPipelines"' in studio)
check('  kpiActiveWeek KPI present',             'id="kpiActiveWeek"' in studio)
check('  kpiCoverage KPI present',               'id="kpiCoverage"' in studio)
check('  kpiGaps KPI present',                   'id="kpiGaps"' in studio)
check('  kpiPii KPI present',                    'id="kpiPii"' in studio)

# Main grid layout
check('dash-grid responsive layout',             'class="dash-grid"' in studio)
check('dash-main pipeline-health column',        'class="dash-main"' in studio)
check('dash-side sidebar widgets',               'class="dash-side"' in studio)

# Pipeline health table
check('health table anchor (#healthTable)',      'id="healthTable"' in studio)
check('health-table CSS rules present',          '.health-table{' in studio or '.health-table ' in studio)
check('  h-row hover state',                     '.health-table .h-row:hover' in studio)
check('  h-dot score indicator CSS',             '.health-table .h-score .h-dot' in studio)

# Sidebar widgets
check('Recent activity widget anchor',           'id="dashActivity"' in studio)
check('Governance widget anchor',                'id="dashGovernance"' in studio)
check('Quick lineage stats anchor',              'id="dashLineageStats"' in studio)
check('dash-widget styling',                     '.dash-widget{' in studio)

# Governance widget CSS
check('governance progress bars (green/amber/red)',
      '.dash-gov .g-bar.green' in studio and '.dash-gov .g-bar.amber' in studio and '.dash-gov .g-bar.red' in studio)

# JavaScript wiring
check('renderDashboard() function exists',       'function renderDashboard(' in studio)
check('computeDashboardHealth() function exists','function computeDashboardHealth(' in studio)
check('renderDashboard() called from scanPortfolio',
      'renderDashboard();' in studio)
check('btnDashLineage wired to openLineage',
      "$('#btnDashLineage')?.addEventListener('click', openLineage)" in studio)
check('btnPfRescan triggers rescan',
      "$('#btnPfRescan')?.addEventListener('click'" in studio)

# Health scorer — 5 categories of 20 points each
check('health scoring · 5 categories doc-comment',
      '5 categories' in studio and '20 pts each' in studio)
check('health scorer checks runbook variants',
      "arts['runbook.md']" in studio and "arts['ingestion_info.md']" in studio and "arts['dataprep_info.md']" in studio)

# Mobile responsiveness for KPI row
check('KPI row reflows on narrow screens',       '.kpi-row{grid-template-columns:repeat(3,1fr)}' in studio)

# ─────────────────────────────────────────────────────────────────────────
# Suite 14 · Ingestion multi-subdomain redesign
# ─────────────────────────────────────────────────────────────────────────
suite('14 · Ingestion · multi-subdomain support')

# HTML form — new section + button + hint
check('ingestSubdomains list anchor',         'id="ingestSubdomains"' in studio)
check('btnAddIngestSubdomain present',        'id="btnAddIngestSubdomain"' in studio)
check('subdomain-as-table hint visible',      'subdomain</b> is the target table name' in studio)
check('single-Subdomain field removed',       'data-k="ingest.subdomain"' not in studio)
check('top-level ingest.columns textarea removed',
                                              'data-k="ingest.columns"' not in studio)

# STATE shape + migration
check('STATE.ingest.subdomains[] array',      'subdomains:[ blankSubdomain() ]' in studio)
check('blankSubdomain() factory exists',      'function blankSubdomain(' in studio)
check('migrateIngestShape() helper exists',   'function migrateIngestShape(' in studio)
check('restoreState calls migration',         'migrateIngestShape(STATE.ingest)' in studio)

# Renderer + wiring
check('renderIngestSubdomains() function',    'function renderIngestSubdomains(' in studio)
check('initial render wired',                 'renderIngestSubdomains();' in studio)
check('add-button → push blank + re-render',
      "btnAddIngestSubdomain')?.addEventListener('click'" in studio and 'STATE.ingest.subdomains.push(blankSubdomain())' in studio)
check('reseedInputs(ingest) re-renders cards','if (tabPrefix === \'ingest\') renderIngestSubdomains()' in studio)

# Spec generator — per-subdomain emission
check('genIngestSpec iterates subdomains',    'sdAnalysis.map((a, i) => buildSubdomainBlock(a, i+1))' in studio)
check('per-subdomain output dirs',            'configs/${sdSlug}/' in studio)
check('manifest enumerates per-subdomain stages',
                                              'chains all ${sdCount} subdomain stages' in studio)
check('audit columns include _subdomain marker',
                                              '_subdomain          STRING' in studio)
check('shared connection block label',        'Source connection (' in studio and '— shared' in studio)

# Validation
check('validation · at least one subdomain',  'Add at least one subdomain' in studio)
check('validation · unique subdomain names',  'Subdomain names must be unique' in studio)

# Profiler status counter (per-subdomain aware)
check('profiler pill counts subdomains',      'PROFILER ENABLED · ${withCols}/${sds.length}' in studio)

# Templates seed subdomains[]
check('consumer_master template has 3 subdomains',
      "STATE.ingest.subdomains = [" in studio and "name:'Consumer'" in studio and "name:'Address'" in studio and "name:'Account'" in studio)
check('templates no longer set legacy subdomain string',
      "subdomain:'Consumer', source_type:'Oracle'" not in studio)

# ── Source database & schema field + per-subdomain load_query ──
check('source_db_schema field on form',       'data-k="ingest.source_db_schema"' in studio)
check('sourceDbSchemaOptions datalist',       'id="sourceDbSchemaOptions"' in studio and 'BANK.DBO' in studio)
check('Schema label clarifies Bronze target', '(Bronze target' in studio)
check('STATE.ingest.source_db_schema default','source_db_schema:\'\'' in studio)
check('blankSubdomain() has load_query',      "load_query:''" in studio)
check('subdomain card renders load_query input',
                                              '${i}.load_query' in studio)
check('load-query label adapts to ADLS',      "Load path / glob" in studio and 'isAdls' in studio)
check('JDBC label: SQL inline OR volume path','Load query or Query Volume Path' in studio)
check('genIngestSpec uses source_db_schema',  'srcDbSchema' in studio and 'source_db_schema:' in studio)
check('per-subdomain load_query override emitted',
                                              'hasLoadOverride' in studio and 'overrides default \\`SELECT' in studio)
check('pipeline metadata exposes load_overrides count',
                                              'load_overrides:' in studio)
check('hint-tag CSS class for ⓘ chip',        '.hint-tag{' in studio)
check('source_db_schema warning in validation',
                                              'Source database & schema empty' in studio)
check('source-type change re-renders subdomain cards',
                                              "if (key === 'ingest.source_type') renderIngestSubdomains()" in studio)
check('templates seed source_db_schema',      "source_db_schema:'BANKCORE.CUSTOMER'" in studio)

# ── classifyLoadQuery() router + path-mode spec emission ──
check('classifyLoadQuery() helper exists',    'function classifyLoadQuery(' in studio)
check('classifier returns path|inline|empty',
      "return 'path'" in studio and "return 'inline'" in studio and "return 'empty'" in studio)
check('path heuristic covers UC volumes',     '/Volumes/' in studio)
check('path heuristic covers DBFS',           'dbfs:\\/' in studio)
check('path heuristic covers ADLS abfss',     'abfss:\\/\\/' in studio)
check('spec emits query_source: file for paths',
      "query_source:           file" in studio)
check('spec emits query_path for path mode',  'query_path:' in studio)
check('spec emits query_source: inline for SQL paste',
      "query_source:           inline" in studio)
check('spec emits query_source: table for default',
      "query_source:           table" in studio)
check('metadata exposes inline_sql vs volume_path counts',
      'inline_sql:' in studio and 'volume_path:' in studio)
check('hint mentions both modes in JDBC label',
      'paste the <b>SELECT</b> inline' in studio and '.sql</code> file' in studio)

# ─────────────────────────────────────────────────────────────────────────
# Suite 15 · De-congestion pilot — sticky stage toolbar + collapsible sections
# ─────────────────────────────────────────────────────────────────────────
suite('15 · Sticky toolbar + collapsible sections (Ingestion pilot)')

# Sticky toolbar markup
check('stageToolbar element present',         'id="stageToolbar"' in studio)
check('stb-icon anchor',                      'id="stbIcon"' in studio)
check('stb-title anchor',                     'id="stbTitle"' in studio)
check('stb-name pipeline echo anchor',        'id="stbName"' in studio)
check('stb-validation badge anchor',          'id="stbValidation"' in studio)
check('stb-expand-all button',                'id="stbExpandAll"' in studio)
check('stb-collapse-all button',              'id="stbCollapseAll"' in studio)
check('toolbar CSS (.stage-toolbar)',         '.stage-toolbar{' in studio and 'position:sticky' in studio)
check('toolbar hidden on Home (display:none default)',
      'id="stageToolbar" class="stage-toolbar" style="display:none"' in studio)

# Collapsible <details> CSS + markup
check('details.sect CSS rules present',       'details.sect{' in studio)
check('sect-num · sect-title · sect-status CSS',
      '.sect-num{' in studio and '.sect-title{' in studio and '.sect-status{' in studio)
check('chevron rotates on open',              'details.sect[open] .sect-chev{transform:rotate(90deg)}' in studio)
check('Ingestion: connection section markup', 'data-sect="ingest.connection"' in studio)
check('Ingestion: subdomains section markup', 'data-sect="ingest.subdomains"' in studio)
check('section number "1" present',           '<span class="sect-num">1</span>' in studio)
check('section number "2" present',           '<span class="sect-num">2</span>' in studio)
check('connection status chip anchor',        'id="sectStatusIngestConnection"' in studio)
check('subdomains status chip anchor',        'id="sectStatusIngestSubdomains"' in studio)

# JS wiring
check('renderStageToolbar() function',        'function renderStageToolbar(' in studio)
check('renderSectionStatuses() function',     'function renderSectionStatuses(' in studio)
check('wireSectionToggles() function',        'function wireSectionToggles(' in studio)
check('openSectionsWithErrors() auto-opens errors',
      'function openSectionsWithErrors(' in studio)
check('SECT_LS_KEY persistence constant',     "SECT_LS_KEY = 'df_section_state_v1'" in studio)
check('LS_KEY uses df_ prefix (post-rename)', "LS_KEY      = 'df_pipeline_studio_v1'" in studio)
check('legacy dcs_ migration shim present',   'function migrateLegacyStorageKeys(' in studio and 'dcs_pipeline_studio_v1' in studio)
check('migration runs before restoreState()', 'migrateLegacyStorageKeys();' in studio)
check('refresh() calls renderStageToolbar',   'renderStageToolbar();' in studio)
check('refresh() calls renderSectionStatuses','renderSectionStatuses();' in studio)
check('refresh() calls openSectionsWithErrors',
                                              'openSectionsWithErrors();' in studio)
check('init calls wireSectionToggles',        'wireSectionToggles();' in studio)
check('bulk Expand-all wired',                'bulkToggleSections(true)' in studio)
check('bulk Collapse-all wired',              'bulkToggleSections(false)' in studio)
check('error→section map covers ingest fields',
      "'ingest.pipeline_name'" in studio and "'ingest.subdomains'" in studio)

# Backwards compatibility — old anchors still exist (so renderers don't break)
check('#ingestSubdomains anchor still inside section body',
      '<div id="ingestSubdomains"></div>' in studio)
check('#btnAddIngestSubdomain still inside section body',
      '<button class="add-btn" id="btnAddIngestSubdomain">' in studio)
check('#profileStatus pill still rendered',   'id="profileStatus"' in studio)

# ── EDA panel · 3 collapsible sections ──
check('EDA: setup section markup',            'data-sect="eda.setup"' in studio)
check('EDA: tables section markup',           'data-sect="eda.tables"' in studio)
check('EDA: header-query section markup',     'data-sect="eda.header"' in studio)
check('EDA: setup status chip anchor',        'id="sectStatusEdaSetup"' in studio)
check('EDA: tables status chip anchor',       'id="sectStatusEdaTables"' in studio)
check('EDA: header status chip anchor',       'id="sectStatusEdaHeader"' in studio)
check('EDA: #edaTables anchor preserved',     '<div id="edaTables"></div>' in studio)
check('EDA: #btnAddTable preserved',          'id="btnAddTable"' in studio)
check('EDA: #entityEcho preserved',           'id="entityEcho"' in studio)

# ── Data Prep panel · 3 collapsible sections ──
check('DP: setup section markup',             'data-sect="dp.setup"' in studio)
check('DP: columns section markup',           'data-sect="dp.columns"' in studio)
check('DP: source section markup',            'data-sect="dp.source"' in studio)
check('DP: setup status chip anchor',         'id="sectStatusDpSetup"' in studio)
check('DP: columns status chip anchor',       'id="sectStatusDpColumns"' in studio)
check('DP: source status chip anchor',        'id="sectStatusDpSource"' in studio)
check('DP: PII banner above sections',        'id="piiBanner"' in studio)
check('DP: #colIntel anchor preserved',       'id="colIntel"' in studio)
check('DP: #hqPane preserved',                'id="hqPane"' in studio)
check('DP: #eqPane preserved',                'id="eqPane"' in studio)
check('DP: #tablePane preserved',             'id="tablePane"' in studio)
check('DP: source-mode radio still wired',    'name="dp_source_mode"' in studio)

# ── Error-to-section mapping extends to EDA + DP fields ──
check('error map covers EDA project_name',    "'eda.project_name'" in studio and "'eda.setup'" in studio)
check('error map covers EDA tables',          "'eda.tables':              'eda.tables'" in studio)
check('error map covers DP pipeline_name',    "'dp.pipeline_name'" in studio and "'dp.setup'" in studio)
check('error map covers DP columns / pk',     "'dp.columns':" in studio and "'dp.pk':" in studio)
check('error map covers DP source modes',     "'dp.header_query'" in studio and "'dp.extract_query'" in studio and "'dp.t_extract_in'" in studio)

# ── Status chip renderers · all 6 sections present in render fn ──
check('render: EDA setup chip computed',      "#sectStatusEdaSetup" in studio)
check('render: EDA tables chip computed',     "#sectStatusEdaTables" in studio)
check('render: DP columns chip uses classifier',
      "effectiveDpClassified" in studio and 'sectStatusDpColumns' in studio)
check('render: DP source chip handles all 3 modes',
      "m === 'table'" in studio and "m === 'header_query'" in studio and "m === 'extract_query'" in studio)

# ─────────────────────────────────────────────────────────────────────────
# Suite 16 · Doc / instruction freshness — catches drift we just fixed
# ─────────────────────────────────────────────────────────────────────────
suite('16 · Doc + instruction freshness · no stale phrasing')

# Load the docs/instructions we expect to stay in sync
top_readme         = read(ROOT / 'README.md')
quickstart         = read(ROOT / 'docs' / 'QUICKSTART.md')
tools_readme       = read(ROOT / 'tools' / 'README.md')
output_readme      = read(ROOT / 'output' / 'README.md')
apps_readme        = read(ROOT / '.github' / 'apps' / 'README.md')
copilot_instr      = read(ROOT / '.github' / 'copilot-instructions.md')
data_ingest_md     = read(ROOT / 'agents' / 'data_ingest.md')
data_prep_md       = read(ROOT / 'agents' / 'data_prep.md')
data_doc_md        = read(ROOT / 'agents' / 'data_doc.md')
bronze_skill       = read(ROOT / '.github' / 'skills' / 'ingestion' / 'bronze_load' / 'SKILL.md')
profiler_skill     = read(ROOT / '.github' / 'skills' / 'ingestion' / 'profiler' / 'SKILL.md')
pipeline_skill     = read(ROOT / '.github' / 'skills' / 'ingestion' / 'pipeline' / 'SKILL.md')
pipeline_doc_skill = read(ROOT / '.github' / 'skills' / 'docs' / 'pipeline_doc' / 'SKILL.md')
lineage_skill      = read(ROOT / '.github' / 'skills' / 'lineage' / 'builder' / 'SKILL.md')
db_standards       = read(ROOT / '.github' / 'instructions' / 'databricks-standards.md')

# ── Counts / cardinality drift (the easy stuff to get wrong) ──
check('top README · "Five agents" (not Four)',
      'Five' in top_readme or '**five**' in top_readme.lower() or '**Five**' in top_readme)
check('top README · 6 tabs (not 4 / 5)',
      '**Six tabs**' in top_readme or '6-tab' in top_readme or 'Six tabs' in top_readme)
check('top README · lists data_lineage.md in agents/',
      'data_lineage.md' in top_readme)
check('top README · drops stale "101 tests"',
      '101 tests' not in top_readme)
check('top README · drops stale "100 tests"',
      '100 tests' not in top_readme)
check('tools/README · 6-tab console (not 5-tab)',
      '6-tab console' in tools_readme or '6 tabs' in tools_readme)
check('tools/README · references project-consistency-tests.py',
      'project-consistency-tests.py' in tools_readme)
check('tools/README · current 630-test total',
      '630' in tools_readme)
check('apps/README · 6-stage data-prep (not 5-stage)',
      '6-stage' in apps_readme and '5-stage pipeline' not in apps_readme)

# ── Path contract drift · ingestion now uses per-subdomain configs/<slug>/ ──
def has_subdomain_slug(text: str) -> bool:
    return '<subdomain_slug>' in text or '/<subdomain' in text

check('output/README mentions per-subdomain ingestion path',
      has_subdomain_slug(output_readme))
check('output/README · "No runners/ directory" callout',
      'No `runners/` directory' in output_readme or 'Runner notebooks were removed' in output_readme)
check('copilot-instructions · ingestion path uses <subdomain_slug>',
      has_subdomain_slug(copilot_instr))
check('copilot-instructions · runners/ removed from path contract',
      '{configs,runners,reports' not in copilot_instr)
check('copilot-instructions · current 630-test total mentioned',
      '630' in copilot_instr or '99 tests' in copilot_instr)
check('data_ingest.md · output contract uses <subdomain_slug>',
      has_subdomain_slug(data_ingest_md))
check('data_ingest.md · no contradictory flat output block',
      'output/ingestion/{pipeline_name}/\n├── manifest.json' not in data_ingest_md
      and '├── bronze_load.json\n├── profiler.json' not in data_ingest_md)
check('data_doc.md · ingest mode walks per-subdomain dirs',
      '<subdomain_slug>' in data_doc_md)
check('pipeline_doc skill · ingest read list uses <subdomain_slug>',
      '<subdomain_slug>' in pipeline_doc_skill)
check('lineage builder skill · per-subdomain Bronze nodes',
      'Bronze[' in lineage_skill or 'per subdomain' in lineage_skill.lower())

# ── Runner notebook removal · double-check it's gone everywhere ──
# (use the same retrospective-sentence skip logic as Suite 5 to avoid false positives
#  on text that explicitly describes the absence/removal of runner notebooks)
def has_active_runner_lang(text: str) -> bool:
    t = text.lower()
    sentences = re.split(r'[\.\n]', t)
    for s in sentences:
        if not any(p in s for p in ['and runner.', 'runner notebook', '`runners/`', 'runners/<stage>', 'output/notebooks/{notebook}.py']):
            continue
        # skip retrospective / negation contexts
        if any(p in s for p in ['no separate runner', 'no runner', 'runner notebook was', 'runner notebooks were',
                                'were removed', 'are gone', 'no longer', 'removed (', 'no `runners',
                                'old runner', 'previously wrote', 'legacy', 'deprecated']):
            continue
        return True
    return False

check('data_prep.md · no active runner-notebook language',     not has_active_runner_lang(data_prep_md))
check('data_ingest.md · no active runner-notebook language',   not has_active_runner_lang(data_ingest_md))
check('output/README · no active runner-notebook language',    not has_active_runner_lang(output_readme))
check('databricks-standards.md · old flat notebook path gone', 'output/notebooks/{notebook}.py' not in db_standards)

# ── Multi-subdomain spec keys present in skill docs (drives agent behavior) ──
check('bronze_load SKILL · documents subdomain key',
      '`subdomain`' in bronze_skill)
check('bronze_load SKILL · documents source.db_schema',
      'source.db_schema' in bronze_skill or '`source.db_schema`' in bronze_skill)
check('bronze_load SKILL · documents source.query_source modes',
      'query_source' in bronze_skill and 'inline' in bronze_skill and 'file' in bronze_skill)
check('bronze_load SKILL · documents source.query_path',
      'query_path' in bronze_skill)
check('bronze_load SKILL · audit_columns mention _subdomain',
      '_subdomain' in bronze_skill)
check('profiler SKILL · documents subdomain key',
      '`subdomain`' in profiler_skill)
check('pipeline SKILL · multi-subdomain manifest shape',
      'subdomains' in pipeline_skill and '2N stages' in pipeline_skill)
check('pipeline SKILL · per-subdomain config_path example',
      'consumer/bronze_load.json' in pipeline_skill)

# ── Per-subdomain example.json files have new markers ──
bronze_example = read(ROOT / '.github' / 'skills' / 'ingestion' / 'bronze_load' / 'references' / 'example.json')
profiler_example = read(ROOT / '.github' / 'skills' / 'ingestion' / 'profiler' / 'references' / 'example.json')
manifest_template = read(ROOT / '.github' / 'skills' / 'ingestion' / 'pipeline' / 'references' / 'manifest.template.json')
spec_example = read(ROOT / '.github' / 'skills' / 'ingestion' / 'pipeline' / 'references' / 'spec.md.example')
check('bronze_load example.json has "subdomain" key',
      '"subdomain":' in bronze_example)
check('bronze_load example.json has "db_schema" key',
      '"db_schema":' in bronze_example)
check('bronze_load example.json has "query_source" key',
      '"query_source":' in bronze_example)
check('profiler example.json has "subdomain" key',
      '"subdomain":' in profiler_example)
check('manifest.template.json has subdomains array',
      '"subdomains":' in manifest_template)
check('manifest.template.json per-subdomain config_path',
      'consumer/bronze_load.json' in manifest_template)
check('spec.md.example demonstrates multi-subdomain shape',
      'Subdomain 1' in spec_example and 'Subdomain 2' in spec_example)
check('spec.md.example demonstrates source_db_schema',
      'source_db_schema:' in spec_example)
check('spec.md.example demonstrates query_source: file (UC volume)',
      '/Volumes/' in spec_example and 'query_source: file' in spec_example)

# ── Specs hygiene · no fat-finger typos in checked-in fixtures ──
dp_spec = read(ROOT / 'specs' / 'dataprep' / 'consumer_master_prep' / 'spec.md')
check('canonical dp spec · subdomain typo fixed',
      'Consumer111111' not in dp_spec)

# ─────────────────────────────────────────────────────────────────────────
# Summary
# ─────────────────────────────────────────────────────────────────────────
print('\n' + '━' * 70)
print(f'Suites:  {SUITES}')
print(f'Passed:  {PASS}')
print(f'Failed:  {FAIL}')
if FAIL == 0:
    print('\n  All project-consistency checks passed ✓\n')
    sys.exit(0)
else:
    print(f'\n  {FAIL} check(s) failed — see above\n')
    sys.exit(1)
