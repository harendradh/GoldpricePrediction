#!/usr/bin/env python3
"""
json-studio-tests.py
====================
Tests the Rule Composer logic from tools/json-studio.html.

These tests port the key JS functions to Python and exercise every catalog
rule end-to-end: column matching, gap analysis (suggestion), apply for
each emit type (transformations / expectations / post_actions / block),
remove, and edit (remove + re-apply with overrides).

Run:  python tools/json-studio-tests.py
Exit:  0 = all pass, 1 = any fail
"""
import sys, re, json, copy

# Make Windows consoles happy with the unicode glyphs we print.
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')

# ──────────────────────────────────────────────────────────────────────────
# CATALOG (Python mirror of CATALOG in json-studio.html — 38 rules)
# ──────────────────────────────────────────────────────────────────────────
CATALOG = [
    # identity
    dict(rule_id="identity_pk_not_null", name="Primary Key NOT NULL", category="identity", priority=10,
         description="...", applicable_phases=["ingestion","dataprep"],
         applicable_stages=["profiler","extraction_profiler","preparation"],
         column_match={"classifier_tags":["pk"]},
         emits={"expectations":[{"rule":"not_null","threshold":1.0,"severity":"CRITICAL","action":"fail"}],
                "transformations":[{"op":"drop_rows","args":{"where":"{COLUMN} IS NULL"},"on_error":"fail"}]}),
    dict(rule_id="identity_pk_unique", name="Primary Key UNIQUE", category="identity", priority=11,
         description="...", applicable_phases=["ingestion","dataprep"],
         applicable_stages=["profiler","extraction_profiler"],
         column_match={"classifier_tags":["pk"]},
         emits={"expectations":[{"rule":"unique","threshold":1.0,"severity":"CRITICAL","action":"fail"}]}),
    dict(rule_id="identity_id_not_null", name="FK ID NOT NULL", category="identity", priority=30,
         description="...", applicable_phases=["ingestion","dataprep"],
         applicable_stages=["profiler","extraction_profiler"],
         column_match={"classifier_tags":["id"],"exclude_patterns":["^id$"]},
         emits={"expectations":[{"rule":"not_null","threshold":0.99,"severity":"HIGH","action":"warn_only"}]}),

    # pii_masking
    dict(rule_id="pii_ssn_mask", name="SSN Mask", category="pii_masking", priority=20,
         description="...", applicable_phases=["dataprep"], applicable_stages=["preparation"],
         column_match={"classifier_tags":["gov_id"],"patterns":["^ssn$","social_security","^sin$","nat_id$","national_id"]},
         emits={"transformations":[{"op":"mask","args":{"method":"sha2_256"},"on_error":"fail"}]}),
    dict(rule_id="pii_tax_id_mask", name="Tax ID Mask", category="pii_masking", priority=20,
         description="...", applicable_phases=["dataprep"], applicable_stages=["preparation"],
         column_match={"classifier_tags":["gov_id"],"patterns":["tax_id","^ein$","^itin$","^tin$"]},
         emits={"transformations":[{"op":"mask","args":{"method":"sha2_256"},"on_error":"fail"}]}),
    dict(rule_id="pii_card_number_mask", name="Card Mask", category="pii_masking", priority=20,
         description="...", applicable_phases=["dataprep"], applicable_stages=["preparation"],
         column_match={"classifier_tags":["financial_id"],"patterns":["card_num","cc_num","card_number","^pan$","^iban$","^cvv$","^cvc$"]},
         emits={"transformations":[{"op":"mask","args":{"method":"sha2_256"},"on_error":"fail"}]}),
    dict(rule_id="pii_account_number_mask", name="Account Mask", category="pii_masking", priority=20,
         description="...", applicable_phases=["dataprep"], applicable_stages=["preparation"],
         column_match={"classifier_tags":["financial_id"],"patterns":["account_num","acct_num","^routing$","routing_num","^aba$","^swift$"]},
         emits={"transformations":[{"op":"mask","args":{"method":"sha2_256"},"on_error":"fail"}]}),
    dict(rule_id="pii_dob_truncate", name="DOB Truncate", category="pii_masking", priority=25,
         description="...", applicable_phases=["dataprep"], applicable_stages=["preparation"],
         column_match={"classifier_tags":["dob"],"patterns":["^dob$","date_of_birth","^birth_date$","^birthdate$"]},
         emits={"transformations":[{"op":"mask","args":{"method":"truncate_date","precision":"year"},"on_error":"fail"}],
                "expectations":[{"rule":"value_between","args":{"min":"1900-01-01","max":"CURRENT_DATE"},"threshold":1.0,"severity":"HIGH","action":"warn_only"}]}),
    dict(rule_id="pii_passport_mask", name="Passport Mask", category="pii_masking", priority=20,
         description="...", applicable_phases=["dataprep"], applicable_stages=["preparation"],
         column_match={"classifier_tags":["doc_id"],"patterns":["passport","driver_lic","drivers_lic","drivers_license","license_num"]},
         emits={"transformations":[{"op":"mask","args":{"method":"sha2_256"},"on_error":"fail"}]}),
    dict(rule_id="pii_uc_tag", name="UC Tag", category="pii_masking", priority=90,
         description="...", applicable_phases=["dataprep"], applicable_stages=["conversion"],
         column_match={"classifier_tags":["pii"]},
         emits={"post_actions":[{"type":"tag_uc","args":{"tags":{"data_class":"pii","pii_columns":"{LIST_OF_MATCHED_COLUMNS}","compliance_review":"required"}}}]}),

    # contact
    dict(rule_id="contact_email_lower", name="Email Lower", category="contact", priority=40,
         description="...", applicable_phases=["dataprep"], applicable_stages=["preparation"],
         column_match={"classifier_tags":["email"],"patterns":["^email$","_email$","^email_","^e_mail$","^mail$"],"data_types":["STRING","VARCHAR","TEXT"]},
         emits={"transformations":[{"op":"lower","on_error":"null_out"}]}),
    dict(rule_id="contact_email_trim", name="Email Trim", category="contact", priority=30,
         description="...", applicable_phases=["dataprep"], applicable_stages=["preparation"],
         column_match={"classifier_tags":["email"],"patterns":["^email$","_email$","^email_","^e_mail$"]},
         emits={"transformations":[{"op":"trim","args":{"side":"both"},"on_error":"skip_row"}]}),
    dict(rule_id="contact_email_regex", name="Email Regex", category="contact", priority=60,
         description="...", applicable_phases=["dataprep","ingestion"], applicable_stages=["extraction_profiler","profiler"],
         column_match={"classifier_tags":["email"],"patterns":["^email$","_email$","^email_","^e_mail$"]},
         emits={"expectations":[{"rule":"regex","args":{"pattern":"^[^@]+@[^@]+\\.[^@]+$"},"threshold":0.95,"severity":"HIGH","action":"warn_only"}]}),
    dict(rule_id="contact_phone_digits_only", name="Phone Digits", category="contact", priority=40,
         description="...", applicable_phases=["dataprep"], applicable_stages=["preparation"],
         column_match={"classifier_tags":["phone"],"patterns":["^phone$","_phone$","^mobile$","_mobile$","^cell$","_cell$","^telephone$","telephone_number$","_tel$","^fax$","_fax$"],"data_types":["STRING","VARCHAR","TEXT"]},
         emits={"transformations":[{"op":"regex_replace","args":{"pattern":"[^0-9+]","replacement":""},"on_error":"null_out"}]}),
    dict(rule_id="contact_phone_length", name="Phone Length", category="contact", priority=60,
         description="...", applicable_phases=["dataprep","ingestion"], applicable_stages=["extraction_profiler","profiler"],
         column_match={"classifier_tags":["phone"],"patterns":["phone","mobile","cell","telephone"]},
         emits={"expectations":[{"rule":"length_between","args":{"min":7,"max":15},"threshold":0.90,"severity":"HIGH","action":"warn_only"}]}),

    # name
    dict(rule_id="name_trim", name="Name Trim", category="name", priority=30,
         description="...", applicable_phases=["dataprep"], applicable_stages=["preparation"],
         column_match={"classifier_tags":["name"],"patterns":["^first_name$","^last_name$","^middle_name$","^middle_initial$","^mi$","^full_name$","^display_name$","^business_name$","^company_name$","^legal_name$","^given_name$","^family_name$","^surname$","_name$"],"data_types":["STRING","VARCHAR","TEXT"]},
         emits={"transformations":[{"op":"trim","args":{"side":"both"},"on_error":"skip_row"}]}),
    dict(rule_id="name_title_case", name="Name TitleCase", category="name", priority=50, default_enabled=False,
         description="...", applicable_phases=["dataprep"], applicable_stages=["preparation"],
         column_match={"classifier_tags":["name"],"patterns":["^first_name$","^last_name$","^middle_name$","^full_name$"]},
         emits={"transformations":[{"op":"derive","args":{"expression":"INITCAP({COLUMN})"},"on_error":"null_out"}]}),

    # address
    dict(rule_id="address_trim", name="Address Trim", category="address", priority=30,
         description="...", applicable_phases=["dataprep"], applicable_stages=["preparation"],
         column_match={"classifier_tags":["address"],"patterns":["address","addr","^street$","street_","^line_1$","^line_2$","^city$","^town$","^locality$","^state$","^province$","^region$","state_code","^zip$","postal","postcode","^country$","country_code","country_name"],"data_types":["STRING","VARCHAR","TEXT"]},
         emits={"transformations":[{"op":"trim","args":{"side":"both"},"on_error":"skip_row"}]}),
    dict(rule_id="address_state_upper", name="State Upper", category="address", priority=40,
         description="...", applicable_phases=["dataprep"], applicable_stages=["preparation"],
         column_match={"classifier_tags":["state"],"patterns":["^state$","^state_code$","^province$"]},
         emits={"transformations":[{"op":"upper","on_error":"null_out"}],
                "expectations":[{"rule":"length_between","args":{"min":2,"max":40},"threshold":0.95,"severity":"INFO","action":"warn_only"}]}),
    dict(rule_id="address_country_upper", name="Country Upper", category="address", priority=40,
         description="...", applicable_phases=["dataprep"], applicable_stages=["preparation"],
         column_match={"classifier_tags":["country"],"patterns":["^country$","^country_code$","^country_name$","^nation$"]},
         emits={"transformations":[{"op":"upper","on_error":"null_out"}]}),
    dict(rule_id="address_country_in_set", name="Country InSet", category="address", priority=60,
         description="...", applicable_phases=["dataprep","ingestion"], applicable_stages=["extraction_profiler","profiler"],
         column_match={"classifier_tags":["country"],"patterns":["^country$","^country_code$"]},
         emits={"expectations":[{"rule":"in_set","args":{"values":["US","CA","GB","IN","AU","MX","DE","FR","JP","CN","BR","IT","ES","NL","SG"]},"threshold":0.99,"severity":"WARN","action":"warn_only"}]}),
    dict(rule_id="address_postal_length", name="Postal Len", category="address", priority=60,
         description="...", applicable_phases=["dataprep","ingestion"], applicable_stages=["extraction_profiler","profiler"],
         column_match={"classifier_tags":["postal"],"patterns":["^zip$","^zip_code$","postal","^postcode$","^pincode$"]},
         emits={"expectations":[{"rule":"length_between","args":{"min":3,"max":10},"threshold":0.95,"severity":"INFO","action":"warn_only"}]}),
    dict(rule_id="address_standardize_handoff", name="Addr Std Handoff", category="address", priority=5,
         description="...", applicable_phases=["dataprep"], applicable_stages=["address_standardization"],
         column_match={"classifier_tags":["address"]},
         emits={"transformations":[]}),

    # datetime
    dict(rule_id="datetime_cast_timestamp", name="Cast TS", category="datetime", priority=20,
         description="...", applicable_phases=["dataprep"], applicable_stages=["preparation"],
         column_match={"classifier_tags":["datetime"]},
         emits={"transformations":[{"op":"cast","args":{"target_type":"TIMESTAMP"},"on_error":"null_out"}]}),
    dict(rule_id="datetime_not_in_future", name="Not in Future", category="datetime", priority=60,
         description="...", applicable_phases=["dataprep","ingestion"], applicable_stages=["extraction_profiler","profiler"],
         column_match={"classifier_tags":["datetime"],"exclude_patterns":["expir","end_date","closed_"]},
         emits={"expectations":[{"rule":"not_in_future","threshold":1.0,"severity":"HIGH","action":"warn_only"}]}),
    dict(rule_id="datetime_updated_ts_freshness", name="Updated TS Fresh", category="datetime", priority=50,
         description="...", applicable_phases=["ingestion"], applicable_stages=["profiler"],
         column_match={"classifier_tags":["updated_ts"],"patterns":["^updated_at$","^modified_at$","^last_update$","^last_modified$","^refresh_ts$"]},
         emits={"block":{"target":"freshness","value":{"max_age_hours":48,"timestamp_column":"{COLUMN}"}}}),

    # monetary
    dict(rule_id="monetary_non_negative", name="Money>=0", category="monetary", priority=60,
         description="...", applicable_phases=["dataprep","ingestion"], applicable_stages=["extraction_profiler","profiler"],
         column_match={"classifier_tags":["money"],"patterns":["amount","_amt$","price","total","salary","cost","fee","payment","charge","premium","revenue","income","deposit"],"exclude_patterns":["balance","pnl","change"],"data_types":["DECIMAL","NUMERIC","MONEY","FLOAT","DOUBLE","REAL","INT","BIGINT"]},
         emits={"expectations":[{"rule":"value_between","args":{"min":0,"max":1e12},"threshold":0.99,"severity":"HIGH","action":"warn_only"}]}),
    dict(rule_id="monetary_value_range", name="Money Range", category="monetary", priority=70,
         description="...", applicable_phases=["dataprep","ingestion"], applicable_stages=["extraction_profiler","profiler"],
         column_match={"classifier_tags":["money"],"patterns":["balance","pnl"],"data_types":["DECIMAL","NUMERIC","MONEY","FLOAT","DOUBLE"]},
         emits={"expectations":[{"rule":"value_between","args":{"min":-1e12,"max":1e12},"threshold":0.99,"severity":"WARN","action":"warn_only"}]}),

    # categorical
    dict(rule_id="categorical_distinct_bound", name="Categ Distinct", category="categorical", priority=70,
         description="...", applicable_phases=["dataprep","ingestion"], applicable_stages=["extraction_profiler","profiler"],
         column_match={"classifier_tags":["categorical"],"patterns":["^status$","_status$","^code$","_code$","^type$","_type$","^kind$","^category$","_category$","^class$","_class$","^tier$","_tier$","^grade$","_grade$","^segment$","_segment$"]},
         emits={"expectations":[{"rule":"distinct_count_less_than","args":{"max":200},"threshold":1.0,"severity":"INFO","action":"warn_only"}]}),
    dict(rule_id="categorical_status_in_set", name="Status Whitelist", category="categorical", priority=65,
         description="...", applicable_phases=["dataprep","ingestion"], applicable_stages=["extraction_profiler","profiler"],
         column_match={"patterns":["^account_status$","^kyc_status$","^transaction_status$","^txn_status$","^payment_status$"]},
         emits={"expectations":[{"rule":"in_set","args":{"values":["ACTIVE","INACTIVE","SUSPENDED","CLOSED","PENDING","APPROVED","REJECTED","DECLINED","SETTLED","FAILED"]},"threshold":0.99,"severity":"WARN","action":"warn_only"}]}),

    # boolean
    dict(rule_id="boolean_in_set", name="Bool In Set", category="boolean", priority=60,
         description="...", applicable_phases=["dataprep","ingestion"], applicable_stages=["extraction_profiler","profiler"],
         column_match={"classifier_tags":["boolean"],"patterns":["^is_","^has_","^can_","^should_","^will_","_flag$","_ind$","_indicator$","_y_n$","_yn$"]},
         emits={"expectations":[{"rule":"in_set","args":{"values":[True,False,"true","false","TRUE","FALSE","Y","N","y","n","0","1",1,0]},"threshold":1.0,"severity":"INFO","action":"warn_only"}]}),
    dict(rule_id="boolean_normalize", name="Bool Normalize", category="boolean", priority=40, default_enabled=False,
         description="...", applicable_phases=["dataprep"], applicable_stages=["preparation"],
         column_match={"classifier_tags":["boolean"],"data_types":["STRING","VARCHAR","INT","BIGINT","TINYINT"]},
         emits={"transformations":[{"op":"derive","args":{"expression":"CASE WHEN LOWER(CAST({COLUMN} AS STRING)) IN ('y','true','1') THEN TRUE WHEN LOWER(CAST({COLUMN} AS STRING)) IN ('n','false','0') THEN FALSE ELSE NULL END"},"on_error":"null_out"}]}),

    # always_on (no column_match — pipeline-level)
    dict(rule_id="always_row_count_min", name="Row Count Min", category="always_on", priority=1,
         description="...", applicable_phases=["ingestion","dataprep"], applicable_stages=["profiler","extraction_profiler"],
         emits={"expectations":[{"rule":"row_count_min","args":{"min":1},"threshold":1.0,"severity":"CRITICAL","action":"fail"}]}),
    dict(rule_id="always_schema_drift", name="Schema Drift", category="always_on", priority=10,
         description="...", applicable_phases=["ingestion"], applicable_stages=["profiler"],
         emits={"block":{"target":"drift_detection","value":{"enabled":True,"baseline_strategy":"previous_run","thresholds":{"row_count_change_pct":0.20,"null_rate_change_pct":0.10,"new_columns_alert":True,"removed_columns_alert":True,"type_change_alert":True}}}}),
    dict(rule_id="always_freshness", name="Freshness 48h", category="always_on", priority=15,
         description="...", applicable_phases=["ingestion"], applicable_stages=["profiler"],
         emits={"block":{"target":"freshness","value":{"max_age_hours":48,"timestamp_column":"{AUTO_DETECTED}"}}}),
    dict(rule_id="always_audit_columns", name="Audit Cols", category="always_on", priority=20,
         description="...", applicable_phases=["ingestion"], applicable_stages=["bronze_load"],
         emits={"block":{"target":"audit_columns","value":True}}),
    dict(rule_id="always_optimize_post_write", name="Optimize", category="always_on", priority=90,
         description="...", applicable_phases=["dataprep"], applicable_stages=["conversion"],
         emits={"post_actions":[{"type":"optimize","args":{}},{"type":"analyze_statistics","args":{"columns":"*"}}]}),
    dict(rule_id="always_vacuum_retention", name="Vacuum 168h", category="always_on", priority=95,
         description="...", applicable_phases=["dataprep"], applicable_stages=["conversion"],
         emits={"post_actions":[{"type":"vacuum","args":{"retention_hours":168}}]}),
]

# ──────────────────────────────────────────────────────────────────────────
# CLASSIFIER (mirrors json-studio.html · classifyColumns)
# ──────────────────────────────────────────────────────────────────────────
def classify_columns(cols):
    out = []
    for c in cols:
        n = (c.get("name") or "").lower()
        t = (c.get("type") or "STRING").upper()
        tags = set()
        if re.search(r'^id$', n) or re.search(r'(_id|_key|_uuid|_guid)$', n) or re.search(r'^(uuid|guid)$', n):
            tags.add('id')
        if re.search(r'^(first[_ ]?name|fname|given[_ ]?name|forename)$', n): tags.update(['name','first_name'])
        elif re.search(r'^(last[_ ]?name|lname|surname|family[_ ]?name)$', n): tags.update(['name','last_name'])
        elif re.search(r'^(middle[_ ]?name|mname|middle[_ ]?initial|mi)$', n): tags.update(['name','middle_name'])
        elif re.search(r'^(full[_ ]?name|display[_ ]?name|business[_ ]?name|company[_ ]?name|legal[_ ]?name)$', n): tags.update(['name','full_name'])
        elif re.search(r'(_name$|^name$)', n): tags.add('name')
        if 'email' in n: tags.update(['email','contact','pii'])
        if re.search(r'(phone|mobile|cell|telephone|^tel$|fax|whatsapp)', n): tags.update(['phone','contact','pii'])
        if re.search(r'(address|addr|street|line_?\d|premise)', n): tags.update(['address','street'])
        if re.search(r'^(city|town|locality|municipality)$', n): tags.update(['address','city'])
        if re.search(r'^(state|province|region|state_code|administrative_area)$', n): tags.update(['address','state'])
        if re.search(r'(zip|postal|postcode|pincode|pin_code)', n): tags.update(['address','postal'])
        if re.search(r'(^country|nation|country_code|country_name)', n): tags.update(['address','country'])
        if re.search(r'^(lat|latitude)$', n): tags.update(['geo','lat'])
        if re.search(r'^(lon|lng|longitude)$', n): tags.update(['geo','lng'])
        if re.search(r'(TIMESTAMP|DATETIME|^DATE$|^TIME$)', t): tags.add('datetime')
        if re.search(r'(_at|_date|_ts|_time|_dt|_dttm)$', n) or re.search(r'^(date|time|timestamp)$', n): tags.add('datetime')
        if re.search(r'(created|inserted|added|opened|start)', n) and 'datetime' in tags: tags.add('created_ts')
        if re.search(r'(updated|modified|changed|last_update|last_modified|refresh)', n) and 'datetime' in tags: tags.add('updated_ts')
        if re.search(r'(closed|terminated|ended|expir)', n) and 'datetime' in tags: tags.add('end_ts')
        if re.search(r'(dob|date_of_birth|birth_date|birthdate)', n): tags.update(['datetime','dob','pii'])
        if re.search(r'(DECIMAL|NUMERIC|MONEY|FLOAT|DOUBLE|REAL)', t): tags.add('numeric')
        if re.search(r'(^INT|BIGINT|SMALLINT|TINYINT|LONG|^INTEGER)', t): tags.add('numeric')
        if re.search(r'(amount|amt|balance|price|total|salary|cost|fee|payment|charge|premium|value|revenue|income|debit|credit|deposit|withdrawal)', n):
            tags.update(['money','numeric'])
        if re.search(r'^(status|state|type|kind|category|class|code|tier|rank|grade|level|segment)$', n) \
            or re.search(r'(_status|_code|_type|_class|_category|_tier|_grade|_segment)$', n):
            tags.add('categorical')
        if re.search(r'(BOOLEAN|BOOL|BIT)', t): tags.add('boolean')
        if re.search(r'^(is_|has_|can_|should_|will_)', n) or re.search(r'(_flag|_ind|_indicator|_y_n|_yn)$', n): tags.add('boolean')
        if re.search(r'(^ssn$|social_security|^sin$|nat_id|national_id)', n): tags.update(['pii','gov_id'])
        if re.search(r'(tax_id|ein|^itin$|tin)', n): tags.update(['pii','gov_id'])
        if re.search(r'(card_num|cc_num|^pan$|^iban$|^cvv$|cvc|card_number)', n): tags.update(['pii','financial_id'])
        if re.search(r'(account_num|acct_num|routing|aba|swift)', n): tags.update(['pii','financial_id'])
        if re.search(r'(passport|driver_lic|drivers_lic|drivers_license|license_num)', n): tags.update(['pii','doc_id'])
        out.append({**c, "tags": sorted(tags)})

    # PK detection
    pk = next((c for c in out if 'id' in c['tags'] and c.get('nullable') is False), None) \
         or next((c for c in out if 'id' in c['tags']), None) \
         or next((c for c in out if c.get('nullable') is False), None) \
         or (out[0] if out else None)
    if pk:
        pk['tags'] = sorted(set(pk['tags']) | {'pk'})
    return out

# ──────────────────────────────────────────────────────────────────────────
# MATCHING (mirrors columnMatches / matchedColumns / ruleAppliesToStage)
# ──────────────────────────────────────────────────────────────────────────
def column_matches(rule, col):
    m = rule.get("column_match")
    if not m: return True
    n = (col.get("name") or "").lower()
    t = (col.get("type") or "").upper()
    if m.get("exclude_patterns") and any(re.search(p, n, re.I) for p in m["exclude_patterns"]):
        return False
    # OR semantics: tag-match OR pattern-match. Missing filter contributes nothing.
    tag_match = any(tag in col.get("tags", []) for tag in m["classifier_tags"]) if m.get("classifier_tags") else False
    pat_match = any(re.search(p, n, re.I) for p in m["patterns"]) if m.get("patterns") else False
    if m.get("classifier_tags") or m.get("patterns"):
        if not tag_match and not pat_match: return False
    if m.get("data_types") and t and not any(t.startswith(dt) for dt in m["data_types"]):
        return False
    return True

def matched_columns(rule, classified):
    if not rule.get("column_match"): return []
    return [c for c in classified if column_matches(rule, c)]

def rule_applies_to_stage(rule, stage):
    if not stage: return True
    return stage in (rule.get("applicable_stages") or [])

# ──────────────────────────────────────────────────────────────────────────
# APPLIED-RULE EXTRACTION (mirrors extractAppliedRules)
# ──────────────────────────────────────────────────────────────────────────
def guess_rule_id_for_tx(tx):
    op = tx.get("op")
    a = tx.get("args") or {}
    if op == "mask" and a.get("method") == "sha2_256": return "pii_mask_*"
    if op == "mask" and a.get("method") == "truncate_date": return "pii_dob_truncate"
    if op == "lower": return "contact_email_lower"
    if op == "upper": return "address_*_upper"
    if op == "trim": return "trim_*"
    if op == "cast" and (a.get("target_type") or "").upper() == "TIMESTAMP": return "datetime_cast_timestamp"
    if op == "regex_replace": return "contact_phone_digits_only"
    if op == "drop_rows": return "identity_pk_not_null"
    if op == "derive": return "name_title_case|boolean_normalize"
    return op

def guess_rule_id_for_exp(ex):
    r = ex.get("rule")
    if r == "not_null" and ex.get("threshold") == 1.0: return "identity_pk_not_null"
    if r == "unique": return "identity_pk_unique"
    if r == "regex": return "contact_email_regex"
    if r == "in_set": return "*_in_set"
    if r == "length_between": return "*_length_*"
    if r == "value_between": return "monetary_*"
    if r == "not_in_future": return "datetime_not_in_future"
    if r == "row_count_min": return "always_row_count_min"
    if r == "distinct_count_less_than": return "categorical_distinct_bound"
    return r

def guess_rule_id_for_post(pa):
    if pa.get("type") in ("optimize","analyze_statistics"): return "always_optimize_post_write"
    if pa.get("type") == "vacuum": return "always_vacuum_retention"
    if pa.get("type") == "tag_uc": return "pii_uc_tag"
    return pa.get("type")

def extract_applied_rules(data):
    out = []
    if not data: return out
    applied_ids = (data.get("_meta") or {}).get("applied_rules") or []
    stage = (data.get("_meta") or {}).get("stage")

    for idx, tx in enumerate(data.get("transformations") or []):
        rid = tx.get("_rule_id") or guess_rule_id_for_tx(tx)
        out.append({"ruleId": rid, "kind": "transformation", "idx": idx, "item": tx})
    for idx, ex in enumerate(data.get("expectations") or []):
        rid = ex.get("_rule_id") or guess_rule_id_for_exp(ex)
        out.append({"ruleId": rid, "kind": "expectation", "idx": idx, "item": ex})
    for idx, pa in enumerate(data.get("post_actions") or []):
        rid = pa.get("_rule_id") or guess_rule_id_for_post(pa)
        out.append({"ruleId": rid, "kind": "post_action", "idx": idx, "item": pa})
    if data.get("drift_detection"):
        out.append({"ruleId":"always_schema_drift","kind":"block","idx":0,"item":data["drift_detection"],"blockKey":"drift_detection"})
    if data.get("freshness"):
        rid = (data.get("_meta") or {}).get("freshness_source") or "always_freshness"
        out.append({"ruleId":rid,"kind":"block","idx":0,"item":data["freshness"],"blockKey":"freshness"})
    if data.get("audit_columns") is True and stage == "bronze_load":
        out.append({"ruleId":"always_audit_columns","kind":"block","idx":0,"item":True,"blockKey":"audit_columns"})
    for rid in applied_ids:
        if not any(r["ruleId"] == rid for r in out):
            out.append({"ruleId":rid,"kind":"meta","idx":-1,"item":None})
    return out

# ──────────────────────────────────────────────────────────────────────────
# SUGGESTION (mirrors suggestRules)
# ──────────────────────────────────────────────────────────────────────────
def suggest_rules(data, classified):
    stage = (data.get("_meta") or {}).get("stage")
    if not stage: return []
    applied_ids = set((data.get("_meta") or {}).get("applied_rules") or [])
    for r in extract_applied_rules(data):
        rid = r["ruleId"]
        if rid and "*" not in rid and "|" not in rid:
            applied_ids.add(rid)
    out = []
    for r in CATALOG:
        if not rule_applies_to_stage(r, stage): continue
        if r["rule_id"] in applied_ids: continue
        cols = matched_columns(r, classified)
        if r.get("column_match") and not cols: continue
        out.append({"rule": r, "cols": cols})
    out.sort(key=lambda s: s["rule"]["priority"])
    return out

# ──────────────────────────────────────────────────────────────────────────
# APPLY (mirrors applyRule)
# ──────────────────────────────────────────────────────────────────────────
def merge_args(base, overrides):
    out = copy.deepcopy(base or {})
    if overrides:
        out.update(overrides)
    return out

def substitute_col(obj, col):
    if not isinstance(obj, dict): return
    for k, v in list(obj.items()):
        if isinstance(v, str):
            obj[k] = v.replace("{COLUMN}", col)
        elif isinstance(v, dict):
            substitute_col(v, col)

STAGE_KINDS = {
    "bronze_load":             ["block"],
    "profiler":                ["expectations","block"],
    "extraction":              [],
    "extraction_profiler":     ["expectations"],
    "preparation":             ["transformations"],
    "address_standardization": [],
    "address_profiler":        ["expectations"],
    "conversion":              ["post_actions","block"],
}
def stage_accepts_kind(stage, kind):
    if not stage: return True
    k = STAGE_KINDS.get(stage)
    if k is None: return True
    return kind in k

def apply_rule(data, rule, columns_selected=None, arg_overrides=None, sev_override=None, act_override=None, thr_override=None, err_override=None):
    columns_selected = columns_selected or []
    arg_overrides = arg_overrides or {}
    data["_meta"] = data.get("_meta") or {}
    data["_meta"]["applied_rules"] = data["_meta"].get("applied_rules") or []
    stage = data["_meta"].get("stage")

    # apply per-call overrides to the rule clone first (mirrors the JS clone)
    rule_clone = copy.deepcopy(rule)
    e_clone = rule_clone.get("emits") or {}
    if e_clone.get("expectations"):
        for x in e_clone["expectations"]:
            if sev_override is not None: x["severity"] = sev_override
            if act_override is not None: x["action"] = act_override
            if thr_override is not None: x["threshold"] = thr_override
    if e_clone.get("transformations"):
        for x in e_clone["transformations"]:
            if err_override is not None: x["on_error"] = err_override
    e = e_clone

    if e.get("transformations") and stage_accepts_kind(stage, "transformations"):
        data["transformations"] = data.get("transformations") or []
        for tpl in e["transformations"]:
            use_cols = columns_selected if columns_selected else ["*"]
            for col in use_cols:
                item = copy.deepcopy(tpl)
                item["args"] = merge_args(item.get("args") or {}, arg_overrides)
                substitute_col(item["args"], col)
                item["columns"] = [col]
                item["_rule_id"] = rule["rule_id"]
                data["transformations"].append(item)

    if e.get("expectations") and stage_accepts_kind(stage, "expectations"):
        data["expectations"] = data.get("expectations") or []
        for tpl in e["expectations"]:
            use_cols = columns_selected if (rule.get("column_match") and columns_selected) else ["*"]
            for col in use_cols:
                item = copy.deepcopy(tpl)
                item["args"] = merge_args(item.get("args") or {}, arg_overrides)
                substitute_col(item["args"], col)
                item["column"] = col
                safe = re.sub(r'[^A-Za-z0-9_]', '_', f"e_{rule['rule_id']}_{col}")[:80]
                item["id"] = safe
                item["_rule_id"] = rule["rule_id"]
                data["expectations"].append(item)

    if e.get("post_actions") and stage_accepts_kind(stage, "post_actions"):
        data["post_actions"] = data.get("post_actions") or []
        for tpl in e["post_actions"]:
            item = copy.deepcopy(tpl)
            item["args"] = merge_args(item.get("args") or {}, arg_overrides)
            if rule["rule_id"] == "pii_uc_tag" and columns_selected:
                if isinstance(item.get("args"), dict) and isinstance(item["args"].get("tags"), dict):
                    item["args"]["tags"]["pii_columns"] = columns_selected
            item["_rule_id"] = rule["rule_id"]
            data["post_actions"].append(item)

    if e.get("block") and stage in (rule.get("applicable_stages") or []):
        target = e["block"]["target"]
        value = copy.deepcopy(e["block"]["value"])
        if target == "freshness" and columns_selected:
            value["timestamp_column"] = columns_selected[0]
            data["_meta"]["freshness_source"] = rule["rule_id"]
        if isinstance(value, dict) and arg_overrides:
            for k, v in arg_overrides.items():
                if k in value: value[k] = v
        data[target] = value

    if rule["rule_id"] not in data["_meta"]["applied_rules"]:
        data["_meta"]["applied_rules"].append(rule["rule_id"])
    return data

def remove_applied(data, applied):
    kind = applied["kind"]
    if kind == "transformation":
        data["transformations"].pop(applied["idx"])
    elif kind == "expectation":
        data["expectations"].pop(applied["idx"])
    elif kind == "post_action":
        data["post_actions"].pop(applied["idx"])
    elif kind == "block":
        if applied["blockKey"] == "audit_columns":
            data["audit_columns"] = False
        else:
            data[applied["blockKey"]] = None
    # Meta-only entries don't count — they ARE the marker we'd be cleaning up.
    still = any(r["ruleId"] == applied["ruleId"] and r["kind"] != "meta" for r in extract_applied_rules(data))
    if not still and "applied_rules" in (data.get("_meta") or {}):
        data["_meta"]["applied_rules"] = [x for x in data["_meta"]["applied_rules"] if x != applied["ruleId"]]
    return data

# ──────────────────────────────────────────────────────────────────────────
# TEMPLATES (subset · mirrors json-studio.html TEMPLATES)
# ──────────────────────────────────────────────────────────────────────────
def tpl(name):
    T = {
        "profiler": {"enabled":True,"input_dataset":"","output_dataset":"","bronze_table_fqn":"","profile_report_dataset":"",
            "profile_columns":"*","metrics":["row_count","null_count"],"top_n":20,"expectations":[],
            "drift_detection":None,"freshness":None,"on_failure":"quarantine",
            "_meta":{"stage":"profiler","pipeline":"","applied_rules":[]}},
        "bronze_load":{"enabled":True,"source":{"type":"abfs","path":""},"format":"csv","schema_mode":"contract","columns":[],
            "target":{"type":"delta_table","catalog":"main","schema":"bronze","table":""},"write_mode":"append",
            "audit_columns":False,"output_dataset":"",
            "_meta":{"stage":"bronze_load","pipeline":"","applied_rules":[]}},
        "preparation":{"enabled":True,"input_dataset":"","output_dataset":"","transformations":[],"dedupe":None,
            "_meta":{"stage":"preparation","pipeline":"","applied_rules":[]}},
        "conversion":{"enabled":True,"input_dataset":"","target":{"type":"delta_table","catalog":"main","schema":"gold","table":""},
            "format":"delta","write_mode":"merge","partition_by":[],"zorder_by":[],"post_actions":[],
            "_meta":{"stage":"conversion","pipeline":"","applied_rules":[]}},
        "extraction_profiler":{"enabled":True,"input_dataset":"","output_dataset":"","profile_report_dataset":"",
            "profile_columns":"*","metrics":["null_count"],"top_n":20,"expectations":[],
            "_meta":{"stage":"extraction_profiler","pipeline":"","applied_rules":[]}},
    }
    return copy.deepcopy(T[name])

def rule(rid):
    r = next((x for x in CATALOG if x["rule_id"] == rid), None)
    if not r: raise KeyError(f"unknown rule: {rid}")
    return copy.deepcopy(r)

# ──────────────────────────────────────────────────────────────────────────
# TEST HARNESS
# ──────────────────────────────────────────────────────────────────────────
class C:
    R = '\033[31m'; G = '\033[32m'; Y = '\033[33m'; B = '\033[34m'
    DIM = '\033[2m'; BOLD = '\033[1m'; X = '\033[0m'

results = []
current_suite = None

def suite(name):
    global current_suite
    current_suite = name
    print(f"\n{C.BOLD}━━ {name} ━━{C.X}")

def test(name, fn):
    try:
        fn()
        results.append((current_suite, name, None))
        print(f"  {C.G}✓{C.X} {name}")
    except AssertionError as e:
        results.append((current_suite, name, str(e)))
        print(f"  {C.R}✗{C.X} {name}\n    {C.R}{e}{C.X}")
    except Exception as e:
        results.append((current_suite, name, f"{type(e).__name__}: {e}"))
        print(f"  {C.R}✗{C.X} {name}\n    {C.R}{type(e).__name__}: {e}{C.X}")

def eq(actual, expected, msg=""):
    if actual != expected:
        prefix = (msg + "\n") if msg else ""
        raise AssertionError(f"{prefix}expected: {expected!r}\n     got: {actual!r}")

def ok(cond, msg="expected truthy"):
    if not cond: raise AssertionError(msg)

# ──────────────────────────────────────────────────────────────────────────
# COMMON FIXTURES
# ──────────────────────────────────────────────────────────────────────────
BANKING_COLS = classify_columns([
    {"name":"customer_id","type":"BIGINT","nullable":False,"position":1},
    {"name":"first_name","type":"STRING","nullable":True,"position":2},
    {"name":"last_name","type":"STRING","nullable":True,"position":3},
    {"name":"email","type":"STRING","nullable":True,"position":4},
    {"name":"phone","type":"STRING","nullable":True,"position":5},
    {"name":"ssn","type":"STRING","nullable":True,"position":6},
    {"name":"dob","type":"DATE","nullable":True,"position":7},
    {"name":"address_line_1","type":"STRING","nullable":True,"position":8},
    {"name":"city","type":"STRING","nullable":True,"position":9},
    {"name":"state","type":"STRING","nullable":True,"position":10},
    {"name":"zip_code","type":"STRING","nullable":True,"position":11},
    {"name":"country","type":"STRING","nullable":True,"position":12},
    {"name":"account_balance","type":"DECIMAL","nullable":True,"position":13},
    {"name":"account_status","type":"STRING","nullable":True,"position":14},
    {"name":"is_active","type":"BOOLEAN","nullable":True,"position":15},
    {"name":"created_at","type":"TIMESTAMP","nullable":True,"position":16},
    {"name":"updated_at","type":"TIMESTAMP","nullable":True,"position":17},
])

# ════════════════════════════════════════════════════════════════════════════
# SUITE 1 · catalog integrity
# ════════════════════════════════════════════════════════════════════════════
suite("catalog integrity")

test("38 rules total", lambda: eq(len(CATALOG), 38))
test("all rule_ids unique", lambda: eq(len({r["rule_id"] for r in CATALOG}), 38))
test("all have category", lambda: ok(all(r.get("category") for r in CATALOG)))
test("all have applicable_stages", lambda: ok(all(r.get("applicable_stages") for r in CATALOG)))
test("all have priority 1-100", lambda: ok(all(1 <= r.get("priority", 50) <= 100 for r in CATALOG)))
test("all have emits", lambda: ok(all(r.get("emits") for r in CATALOG)))
test("always_on rules have no column_match", lambda: ok(all(not r.get("column_match") for r in CATALOG if r["category"] == "always_on" and r["rule_id"] not in ())))
test("non always_on rules have column_match", lambda: ok(all(r.get("column_match") for r in CATALOG if r["category"] != "always_on")))

# ════════════════════════════════════════════════════════════════════════════
# SUITE 2 · column matching · per-rule
# ════════════════════════════════════════════════════════════════════════════
suite("column matching · per-rule")

def find(name): return next(c for c in BANKING_COLS if c["name"] == name)

test("pk_not_null matches customer_id (pk)", lambda: ok(column_matches(rule("identity_pk_not_null"), find("customer_id"))))
test("pk_not_null does NOT match email", lambda: ok(not column_matches(rule("identity_pk_not_null"), find("email"))))
test("ssn_mask matches ssn", lambda: ok(column_matches(rule("pii_ssn_mask"), find("ssn"))))
test("ssn_mask does NOT match email", lambda: ok(not column_matches(rule("pii_ssn_mask"), find("email"))))
test("email_lower matches email", lambda: ok(column_matches(rule("contact_email_lower"), find("email"))))
test("email_lower does NOT match phone", lambda: ok(not column_matches(rule("contact_email_lower"), find("phone"))))
test("phone_length matches phone", lambda: ok(column_matches(rule("contact_phone_length"), find("phone"))))
test("name_trim matches first_name", lambda: ok(column_matches(rule("name_trim"), find("first_name"))))
test("address_trim matches address_line_1", lambda: ok(column_matches(rule("address_trim"), find("address_line_1"))))
test("address_state_upper matches state", lambda: ok(column_matches(rule("address_state_upper"), find("state"))))
test("address_country_in_set matches country", lambda: ok(column_matches(rule("address_country_in_set"), find("country"))))
test("address_postal_length matches zip_code", lambda: ok(column_matches(rule("address_postal_length"), find("zip_code"))))
test("datetime_not_in_future matches created_at", lambda: ok(column_matches(rule("datetime_not_in_future"), find("created_at"))))
test("datetime_not_in_future excludes expir patterns",
     lambda: ok(not column_matches(rule("datetime_not_in_future"), classify_columns([{"name":"card_expir_date","type":"TIMESTAMP"}])[0])))
test("monetary_non_negative excludes balance", lambda: ok(not column_matches(rule("monetary_non_negative"), find("account_balance"))))
test("monetary_value_range matches balance", lambda: ok(column_matches(rule("monetary_value_range"), find("account_balance"))))
test("categorical_distinct_bound matches account_status", lambda: ok(column_matches(rule("categorical_distinct_bound"), find("account_status"))))
test("categorical_status_in_set matches account_status by pattern only", lambda: ok(column_matches(rule("categorical_status_in_set"), find("account_status"))))
test("boolean_in_set matches is_active", lambda: ok(column_matches(rule("boolean_in_set"), find("is_active"))))
test("updated_ts_freshness matches updated_at", lambda: ok(column_matches(rule("datetime_updated_ts_freshness"), find("updated_at"))))

# ════════════════════════════════════════════════════════════════════════════
# SUITE 3 · matched_columns helper
# ════════════════════════════════════════════════════════════════════════════
suite("matched_columns")

test("ssn_mask matches 1 col (ssn)",
     lambda: eq([c["name"] for c in matched_columns(rule("pii_ssn_mask"), BANKING_COLS)], ["ssn"]))
test("address_trim matches 5 cols",
     lambda: eq(len(matched_columns(rule("address_trim"), BANKING_COLS)), 5))  # address_line_1, city, state, zip_code, country
test("pk_not_null matches 1 col (customer_id)",
     lambda: eq([c["name"] for c in matched_columns(rule("identity_pk_not_null"), BANKING_COLS)], ["customer_id"]))
test("pii_uc_tag matches all PII cols",
     lambda: eq(sorted(c["name"] for c in matched_columns(rule("pii_uc_tag"), BANKING_COLS)),
                sorted(["email","phone","ssn","dob"])))
test("always_row_count_min returns [] (no column_match)",
     lambda: eq(matched_columns(rule("always_row_count_min"), BANKING_COLS), []))

# ════════════════════════════════════════════════════════════════════════════
# SUITE 4 · suggest_rules · gap analysis
# ════════════════════════════════════════════════════════════════════════════
suite("suggest_rules · gap analysis")

def test_suggest_clean_profiler():
    d = tpl("profiler")
    s = suggest_rules(d, BANKING_COLS)
    # all profiler-applicable rules with matches should appear
    ids = {x["rule"]["rule_id"] for x in s}
    ok("always_row_count_min" in ids, "row_count_min missing")
    ok("identity_pk_not_null" in ids, "pk_not_null missing")
    ok("identity_pk_unique" in ids, "pk_unique missing")
    ok("contact_email_regex" in ids, "email_regex missing")
    ok("address_country_in_set" in ids, "country_in_set missing")
    ok("always_schema_drift" in ids, "schema_drift missing")
    ok("always_freshness" in ids, "freshness missing")

def test_suggest_sorted_by_priority():
    d = tpl("profiler")
    s = suggest_rules(d, BANKING_COLS)
    pri = [x["rule"]["priority"] for x in s]
    eq(pri, sorted(pri))

def test_suggest_skips_applied():
    d = tpl("profiler")
    apply_rule(d, rule("always_row_count_min"))
    s = suggest_rules(d, BANKING_COLS)
    ids = {x["rule"]["rule_id"] for x in s}
    ok("always_row_count_min" not in ids, "row_count_min should be removed from suggestions")

def test_suggest_excludes_wrong_stage():
    d = tpl("profiler")
    s = suggest_rules(d, BANKING_COLS)
    ids = {x["rule"]["rule_id"] for x in s}
    # mask rules apply to preparation, not profiler
    ok("pii_ssn_mask" not in ids, "ssn_mask shouldn't appear in profiler suggestions")
    ok("contact_email_lower" not in ids, "email_lower shouldn't appear in profiler")

def test_suggest_preparation_includes_pii():
    d = tpl("preparation")
    s = suggest_rules(d, BANKING_COLS)
    ids = {x["rule"]["rule_id"] for x in s}
    ok("pii_ssn_mask" in ids)
    ok("pii_dob_truncate" in ids)
    ok("contact_email_lower" in ids)

def test_suggest_returns_empty_when_no_stage():
    d = {"_meta":{}}
    eq(suggest_rules(d, BANKING_COLS), [])

def test_suggest_empty_when_no_cols_matched():
    d = tpl("profiler")
    s = suggest_rules(d, [])
    ids = {x["rule"]["rule_id"] for x in s}
    # only pipeline-level (no column_match) rules survive
    ok("always_row_count_min" in ids)
    ok("always_schema_drift" in ids)
    ok("always_freshness" in ids)
    ok("identity_pk_not_null" not in ids)

test("clean profiler suggests expected rules", test_suggest_clean_profiler)
test("suggestions sorted by priority", test_suggest_sorted_by_priority)
test("applied rules dropped from suggestions", test_suggest_skips_applied)
test("wrong-stage rules excluded", test_suggest_excludes_wrong_stage)
test("preparation includes PII rules", test_suggest_preparation_includes_pii)
test("no stage → empty suggestions", test_suggest_returns_empty_when_no_stage)
test("no cols → only pipeline-level survives", test_suggest_empty_when_no_cols_matched)

# ════════════════════════════════════════════════════════════════════════════
# SUITE 5 · apply_rule · transformations
# ════════════════════════════════════════════════════════════════════════════
suite("apply_rule · transformations")

def test_apply_email_lower_one_col():
    d = tpl("preparation")
    apply_rule(d, rule("contact_email_lower"), columns_selected=["email"])
    eq(len(d["transformations"]), 1)
    tx = d["transformations"][0]
    eq(tx["op"], "lower")
    eq(tx["columns"], ["email"])
    eq(tx["_rule_id"], "contact_email_lower")
    eq(tx["on_error"], "null_out")

def test_apply_email_lower_multi_col():
    d = tpl("preparation")
    apply_rule(d, rule("contact_email_lower"), columns_selected=["email", "alt_email"])
    eq(len(d["transformations"]), 2)
    eq(d["transformations"][0]["columns"], ["email"])
    eq(d["transformations"][1]["columns"], ["alt_email"])

def test_apply_ssn_mask():
    d = tpl("preparation")
    apply_rule(d, rule("pii_ssn_mask"), columns_selected=["ssn"])
    tx = d["transformations"][0]
    eq(tx["op"], "mask")
    eq(tx["args"]["method"], "sha2_256")
    eq(tx["on_error"], "fail")

def test_apply_dob_truncate_emits_tx_in_preparation():
    # pii_dob_truncate emits BOTH transformations and expectations in YAML,
    # but preparation stage only accepts transformations — expectations get filtered out.
    d = tpl("preparation")
    apply_rule(d, rule("pii_dob_truncate"), columns_selected=["dob"])
    eq(len(d["transformations"]), 1)
    eq(d["transformations"][0]["args"]["precision"], "year")
    ok("expectations" not in d, "expectations should NOT land in preparation stage")

def test_apply_drop_rows_substitutes_column():
    d = tpl("preparation")
    apply_rule(d, rule("identity_pk_not_null"), columns_selected=["customer_id"])
    drop = next(t for t in d["transformations"] if t["op"] == "drop_rows")
    eq(drop["args"]["where"], "customer_id IS NULL")

def test_apply_pk_not_null_to_preparation_only_emits_tx():
    d = tpl("preparation")
    apply_rule(d, rule("identity_pk_not_null"), columns_selected=["customer_id"])
    # preparation only accepts transformations — expectations slot is filtered out
    ok(any(t["op"] == "drop_rows" for t in d["transformations"]))
    ok("expectations" not in d, "preparation should NOT gain an expectations array")

def test_apply_pk_not_null_to_profiler_only_emits_exp():
    d = tpl("profiler")
    apply_rule(d, rule("identity_pk_not_null"), columns_selected=["customer_id"])
    # profiler only accepts expectations — transformations slot is filtered out
    ok(any(e["rule"] == "not_null" for e in d["expectations"]))
    ok("transformations" not in d, "profiler should NOT gain a transformations array")

def test_apply_arg_override_renames_value():
    d = tpl("preparation")
    apply_rule(d, rule("pii_dob_truncate"), columns_selected=["dob"],
               arg_overrides={"precision":"month"})
    tx = d["transformations"][0]
    eq(tx["args"]["precision"], "month")  # overrode the default 'year'

def test_apply_arg_override_adds_new_key():
    d = tpl("preparation")
    apply_rule(d, rule("contact_phone_digits_only"), columns_selected=["phone"],
               arg_overrides={"preserve_leading_plus": True})
    tx = d["transformations"][0]
    eq(tx["args"]["preserve_leading_plus"], True)
    eq(tx["args"]["pattern"], "[^0-9+]")  # original args preserved

def test_apply_err_override():
    d = tpl("preparation")
    apply_rule(d, rule("contact_email_lower"), columns_selected=["email"], err_override="fail")
    eq(d["transformations"][0]["on_error"], "fail")

def test_apply_appends_rule_id_to_meta():
    d = tpl("preparation")
    apply_rule(d, rule("contact_email_lower"), columns_selected=["email"])
    apply_rule(d, rule("pii_ssn_mask"), columns_selected=["ssn"])
    eq(d["_meta"]["applied_rules"], ["contact_email_lower","pii_ssn_mask"])

def test_apply_does_not_duplicate_meta_rule_id():
    d = tpl("preparation")
    apply_rule(d, rule("contact_email_lower"), columns_selected=["email"])
    apply_rule(d, rule("contact_email_lower"), columns_selected=["alt_email"])
    eq(d["_meta"]["applied_rules"], ["contact_email_lower"])

test("email_lower · single column", test_apply_email_lower_one_col)
test("email_lower · two columns → two rows", test_apply_email_lower_multi_col)
test("ssn_mask emits sha2_256", test_apply_ssn_mask)
test("dob_truncate on preparation → only tx (exp filtered)", test_apply_dob_truncate_emits_tx_in_preparation)
test("drop_rows substitutes {COLUMN}", test_apply_drop_rows_substitutes_column)
test("pk_not_null on preparation → only transformations", test_apply_pk_not_null_to_preparation_only_emits_tx)
test("pk_not_null on profiler → only expectations", test_apply_pk_not_null_to_profiler_only_emits_exp)
test("arg override renames default value", test_apply_arg_override_renames_value)
test("arg override adds new key (keeps originals)", test_apply_arg_override_adds_new_key)
test("on_error override applied", test_apply_err_override)
test("applied_rules meta list appended", test_apply_appends_rule_id_to_meta)
test("applied_rules meta de-duplicated", test_apply_does_not_duplicate_meta_rule_id)

# ════════════════════════════════════════════════════════════════════════════
# SUITE 6 · apply_rule · expectations
# ════════════════════════════════════════════════════════════════════════════
suite("apply_rule · expectations")

def test_apply_email_regex_to_profiler():
    d = tpl("profiler")
    apply_rule(d, rule("contact_email_regex"), columns_selected=["email"])
    eq(len(d["expectations"]), 1)
    e = d["expectations"][0]
    eq(e["rule"], "regex")
    eq(e["column"], "email")
    eq(e["severity"], "HIGH")
    eq(e["action"], "warn_only")
    eq(e["args"]["pattern"], "^[^@]+@[^@]+\\.[^@]+$")
    eq(e["_rule_id"], "contact_email_regex")

def test_apply_with_sev_override():
    d = tpl("profiler")
    apply_rule(d, rule("contact_email_regex"), columns_selected=["email"], sev_override="CRITICAL")
    eq(d["expectations"][0]["severity"], "CRITICAL")

def test_apply_with_act_override():
    d = tpl("profiler")
    apply_rule(d, rule("contact_email_regex"), columns_selected=["email"], act_override="fail")
    eq(d["expectations"][0]["action"], "fail")

def test_apply_with_thr_override():
    d = tpl("profiler")
    apply_rule(d, rule("contact_email_regex"), columns_selected=["email"], thr_override=0.80)
    eq(d["expectations"][0]["threshold"], 0.80)

def test_apply_pipeline_level_uses_star():
    d = tpl("profiler")
    apply_rule(d, rule("always_row_count_min"))
    eq(len(d["expectations"]), 1)
    eq(d["expectations"][0]["column"], "*")
    eq(d["expectations"][0]["args"]["min"], 1)

def test_apply_pipeline_level_arg_override():
    d = tpl("profiler")
    apply_rule(d, rule("always_row_count_min"), arg_overrides={"min": 1000})
    eq(d["expectations"][0]["args"]["min"], 1000)

def test_apply_country_in_set_to_multiple_cols():
    d = tpl("profiler")
    apply_rule(d, rule("address_country_in_set"), columns_selected=["country", "billing_country"])
    eq(len(d["expectations"]), 2)
    eq([e["column"] for e in d["expectations"]], ["country", "billing_country"])

def test_apply_exp_id_is_safe():
    d = tpl("profiler")
    apply_rule(d, rule("always_row_count_min"))
    # id should not contain '*' literally
    eq("*" in d["expectations"][0]["id"], False)

test("email_regex to profiler", test_apply_email_regex_to_profiler)
test("sev override applied", test_apply_with_sev_override)
test("action override applied", test_apply_with_act_override)
test("threshold override applied", test_apply_with_thr_override)
test("pipeline-level → column = '*'", test_apply_pipeline_level_uses_star)
test("pipeline-level arg override (min:1 → 1000)", test_apply_pipeline_level_arg_override)
test("country_in_set per multi col", test_apply_country_in_set_to_multiple_cols)
test("expectation id sanitized (no '*' chars)", test_apply_exp_id_is_safe)

# ════════════════════════════════════════════════════════════════════════════
# SUITE 7 · apply_rule · post_actions
# ════════════════════════════════════════════════════════════════════════════
suite("apply_rule · post_actions")

def test_apply_optimize():
    d = tpl("conversion")
    apply_rule(d, rule("always_optimize_post_write"))
    eq(len(d["post_actions"]), 2)
    eq(d["post_actions"][0]["type"], "optimize")
    eq(d["post_actions"][1]["type"], "analyze_statistics")

def test_apply_vacuum_default():
    d = tpl("conversion")
    apply_rule(d, rule("always_vacuum_retention"))
    eq(d["post_actions"][0]["args"]["retention_hours"], 168)

def test_apply_vacuum_override():
    d = tpl("conversion")
    apply_rule(d, rule("always_vacuum_retention"), arg_overrides={"retention_hours": 720})
    eq(d["post_actions"][0]["args"]["retention_hours"], 720)

def test_apply_uc_tag_with_pii_cols():
    d = tpl("conversion")
    apply_rule(d, rule("pii_uc_tag"), columns_selected=["ssn","email","phone","dob"])
    pa = d["post_actions"][0]
    eq(pa["type"], "tag_uc")
    eq(pa["args"]["tags"]["pii_columns"], ["ssn","email","phone","dob"])

test("optimize emits 2 post_actions", test_apply_optimize)
test("vacuum default retention_hours=168", test_apply_vacuum_default)
test("vacuum override → 720", test_apply_vacuum_override)
test("uc_tag fills pii_columns from selected", test_apply_uc_tag_with_pii_cols)

# ════════════════════════════════════════════════════════════════════════════
# SUITE 8 · apply_rule · block targets
# ════════════════════════════════════════════════════════════════════════════
suite("apply_rule · block targets")

def test_apply_drift_detection():
    d = tpl("profiler")
    apply_rule(d, rule("always_schema_drift"))
    ok(d["drift_detection"] is not None)
    eq(d["drift_detection"]["baseline_strategy"], "previous_run")

def test_apply_freshness_with_col():
    d = tpl("profiler")
    apply_rule(d, rule("always_freshness"), columns_selected=["updated_at"])
    eq(d["freshness"]["timestamp_column"], "updated_at")
    eq(d["freshness"]["max_age_hours"], 48)
    eq(d["_meta"]["freshness_source"], "always_freshness")

def test_apply_freshness_override():
    d = tpl("profiler")
    apply_rule(d, rule("always_freshness"), columns_selected=["updated_at"], arg_overrides={"max_age_hours": 24})
    eq(d["freshness"]["max_age_hours"], 24)

def test_apply_audit_columns_block():
    d = tpl("bronze_load")
    apply_rule(d, rule("always_audit_columns"))
    eq(d["audit_columns"], True)

def test_apply_updated_ts_freshness_substitutes_col():
    d = tpl("profiler")
    apply_rule(d, rule("datetime_updated_ts_freshness"), columns_selected=["updated_at"])
    eq(d["freshness"]["timestamp_column"], "updated_at")

test("drift_detection block set", test_apply_drift_detection)
test("freshness with col + default 48h", test_apply_freshness_with_col)
test("freshness override max_age_hours", test_apply_freshness_override)
test("audit_columns = True after apply", test_apply_audit_columns_block)
test("updated_ts_freshness → col substituted", test_apply_updated_ts_freshness_substitutes_col)

# ════════════════════════════════════════════════════════════════════════════
# SUITE 9 · remove_applied
# ════════════════════════════════════════════════════════════════════════════
suite("remove_applied")

def test_remove_transformation():
    d = tpl("preparation")
    apply_rule(d, rule("contact_email_lower"), columns_selected=["email"])
    eq(len(d["transformations"]), 1)
    applied = extract_applied_rules(d)
    eq(len(applied), 1)
    remove_applied(d, applied[0])
    eq(len(d["transformations"]), 0)
    eq(d["_meta"]["applied_rules"], [])  # also removed from meta

def test_remove_expectation():
    d = tpl("profiler")
    apply_rule(d, rule("always_row_count_min"))
    eq(len(d["expectations"]), 1)
    applied = extract_applied_rules(d)
    remove_applied(d, applied[0])
    eq(len(d["expectations"]), 0)

def test_remove_post_action():
    d = tpl("conversion")
    apply_rule(d, rule("always_vacuum_retention"))
    applied = extract_applied_rules(d)
    remove_applied(d, applied[0])
    eq(len(d["post_actions"]), 0)

def test_remove_drift_block():
    d = tpl("profiler")
    apply_rule(d, rule("always_schema_drift"))
    applied = [r for r in extract_applied_rules(d) if r["kind"] == "block"]
    eq(len(applied), 1)
    remove_applied(d, applied[0])
    ok(d["drift_detection"] is None)

def test_remove_audit_columns_block():
    d = tpl("bronze_load")
    apply_rule(d, rule("always_audit_columns"))
    applied = [r for r in extract_applied_rules(d) if r["kind"] == "block"]
    remove_applied(d, applied[0])
    eq(d["audit_columns"], False)

def test_remove_keeps_other_instances():
    d = tpl("preparation")
    apply_rule(d, rule("contact_email_lower"), columns_selected=["email"])
    apply_rule(d, rule("contact_email_lower"), columns_selected=["alt_email"])
    eq(len(d["transformations"]), 2)
    eq(d["_meta"]["applied_rules"], ["contact_email_lower"])
    applied = extract_applied_rules(d)
    remove_applied(d, applied[0])
    eq(len(d["transformations"]), 1)
    eq(d["_meta"]["applied_rules"], ["contact_email_lower"])  # still applied (other instance remains)

test("remove transformation → array empty + meta cleared", test_remove_transformation)
test("remove expectation", test_remove_expectation)
test("remove post_action", test_remove_post_action)
test("remove drift_detection block → null", test_remove_drift_block)
test("remove audit_columns block → false", test_remove_audit_columns_block)
test("removing 1 of 2 keeps meta entry", test_remove_keeps_other_instances)

# ════════════════════════════════════════════════════════════════════════════
# SUITE 10 · edit flow (remove + re-apply with overrides)
# ════════════════════════════════════════════════════════════════════════════
suite("edit flow (remove + re-apply)")

def test_edit_changes_severity():
    d = tpl("profiler")
    apply_rule(d, rule("contact_email_regex"), columns_selected=["email"])
    eq(d["expectations"][0]["severity"], "HIGH")
    # edit: remove then re-apply with new severity
    applied = extract_applied_rules(d)
    remove_applied(d, applied[0])
    apply_rule(d, rule("contact_email_regex"), columns_selected=["email"], sev_override="CRITICAL")
    eq(d["expectations"][0]["severity"], "CRITICAL")
    eq(len(d["expectations"]), 1)  # not duplicated

def test_edit_changes_threshold():
    d = tpl("profiler")
    apply_rule(d, rule("contact_phone_length"), columns_selected=["phone"])
    eq(d["expectations"][0]["threshold"], 0.90)
    applied = extract_applied_rules(d)
    remove_applied(d, applied[0])
    apply_rule(d, rule("contact_phone_length"), columns_selected=["phone"], thr_override=0.99)
    eq(d["expectations"][0]["threshold"], 0.99)

def test_edit_changes_column():
    d = tpl("preparation")
    apply_rule(d, rule("contact_email_lower"), columns_selected=["email"])
    eq(d["transformations"][0]["columns"], ["email"])
    applied = extract_applied_rules(d)
    remove_applied(d, applied[0])
    apply_rule(d, rule("contact_email_lower"), columns_selected=["secondary_email"])
    eq(d["transformations"][0]["columns"], ["secondary_email"])

def test_edit_changes_args():
    d = tpl("profiler")
    apply_rule(d, rule("always_row_count_min"))
    eq(d["expectations"][0]["args"]["min"], 1)
    applied = extract_applied_rules(d)
    remove_applied(d, applied[0])
    apply_rule(d, rule("always_row_count_min"), arg_overrides={"min": 10000})
    eq(d["expectations"][0]["args"]["min"], 10000)

test("edit · change severity", test_edit_changes_severity)
test("edit · change threshold", test_edit_changes_threshold)
test("edit · change target column", test_edit_changes_column)
test("edit · change args (row_count min)", test_edit_changes_args)

# ════════════════════════════════════════════════════════════════════════════
# SUITE 11 · E2E: banking profiler full workflow
# ════════════════════════════════════════════════════════════════════════════
suite("E2E · banking profiler workflow")

def test_e2e_profiler_full():
    d = tpl("profiler")
    # User pastes columns → 17 banking columns classified
    cls = BANKING_COLS
    eq(len(cls), 17)
    # Initial suggestions
    s = suggest_rules(d, cls)
    initial_count = len(s)
    ok(initial_count >= 7, f"expected at least 7 suggestions, got {initial_count}")
    # User applies the 3 always-on rules
    apply_rule(d, rule("always_row_count_min"))
    apply_rule(d, rule("always_schema_drift"))
    apply_rule(d, rule("always_freshness"), columns_selected=["updated_at"])
    # Then PK rules
    apply_rule(d, rule("identity_pk_not_null"), columns_selected=["customer_id"])
    apply_rule(d, rule("identity_pk_unique"), columns_selected=["customer_id"])
    # Then column-specific
    apply_rule(d, rule("contact_email_regex"), columns_selected=["email"])
    apply_rule(d, rule("address_country_in_set"), columns_selected=["country"])
    # Verify state
    eq(d["drift_detection"] is not None, True)
    eq(d["freshness"]["timestamp_column"], "updated_at")
    eq(len(d["expectations"]), 5)  # row_count + pk_not_null + pk_unique + email_regex + country_in_set
    # Suggestions should shrink
    s2 = suggest_rules(d, cls)
    ok(len(s2) < initial_count, "suggestions should shrink after applying")

def test_e2e_preparation_pii_workflow():
    d = tpl("preparation")
    cls = BANKING_COLS
    # Apply masks for all PII
    apply_rule(d, rule("pii_ssn_mask"), columns_selected=["ssn"])
    apply_rule(d, rule("pii_dob_truncate"), columns_selected=["dob"])
    apply_rule(d, rule("contact_email_lower"), columns_selected=["email"])
    apply_rule(d, rule("contact_email_trim"), columns_selected=["email"])
    apply_rule(d, rule("contact_phone_digits_only"), columns_selected=["phone"])
    apply_rule(d, rule("address_trim"), columns_selected=["address_line_1","city","state","zip_code","country"])
    apply_rule(d, rule("address_state_upper"), columns_selected=["state"])
    apply_rule(d, rule("address_country_upper"), columns_selected=["country"])
    apply_rule(d, rule("identity_pk_not_null"), columns_selected=["customer_id"])
    # Count
    ops = [t["op"] for t in d["transformations"]]
    eq(ops.count("mask"), 2)              # ssn + dob
    eq(ops.count("lower"), 1)             # email
    eq(ops.count("trim"), 6)              # email + 5 address (line_1/city/state/zip/country)
    eq(ops.count("regex_replace"), 1)     # phone
    eq(ops.count("upper"), 2)             # state + country
    eq(ops.count("drop_rows"), 1)         # pk not null
    eq(len(d["_meta"]["applied_rules"]), 9)

def test_e2e_conversion_post_actions():
    d = tpl("conversion")
    apply_rule(d, rule("always_optimize_post_write"))
    apply_rule(d, rule("always_vacuum_retention"))
    apply_rule(d, rule("pii_uc_tag"), columns_selected=["ssn","email","phone","dob"])
    eq(len(d["post_actions"]), 4)  # optimize + analyze_stats + vacuum + tag_uc
    types = [p["type"] for p in d["post_actions"]]
    eq(types, ["optimize","analyze_statistics","vacuum","tag_uc"])

test("E2E · profiler full applied + verified", test_e2e_profiler_full)
test("E2E · preparation PII + address workflow", test_e2e_preparation_pii_workflow)
test("E2E · conversion post_actions", test_e2e_conversion_post_actions)

# ════════════════════════════════════════════════════════════════════════════
# SUITE 12 · safety / boundary
# ════════════════════════════════════════════════════════════════════════════
suite("safety / boundary")

def test_apply_without_columns_does_not_crash():
    d = tpl("preparation")
    apply_rule(d, rule("contact_email_lower"), columns_selected=[])  # nothing
    eq(d["transformations"][0]["columns"], ["*"])  # falls back to *

def test_apply_unknown_arg_override_is_appended():
    d = tpl("profiler")
    apply_rule(d, rule("always_row_count_min"), arg_overrides={"custom_check": "yes"})
    eq(d["expectations"][0]["args"]["custom_check"], "yes")

def test_apply_does_not_pollute_other_arrays():
    d = tpl("profiler")
    apply_rule(d, rule("always_row_count_min"))
    ok("transformations" not in d, "profiler should not gain a transformations key")
    ok("post_actions" not in d, "profiler should not gain a post_actions key")

def test_remove_then_extract_consistent():
    d = tpl("profiler")
    apply_rule(d, rule("always_row_count_min"))
    apply_rule(d, rule("identity_pk_not_null"), columns_selected=["customer_id"])
    applied = extract_applied_rules(d)
    eq(len(applied), 2)
    remove_applied(d, applied[0])
    applied2 = extract_applied_rules(d)
    eq(len(applied2), 1)

def test_classify_finds_pk():
    cls = classify_columns([{"name":"customer_id","type":"BIGINT","nullable":False}])
    ok("pk" in cls[0]["tags"])

def test_classify_email_is_pii():
    cls = classify_columns([{"name":"email","type":"STRING"}])
    ok("pii" in cls[0]["tags"])
    ok("email" in cls[0]["tags"])

test("apply with no columns → falls back to '*'", test_apply_without_columns_does_not_crash)
test("unknown arg key is appended", test_apply_unknown_arg_override_is_appended)
test("apply only touches expected arrays", test_apply_does_not_pollute_other_arrays)
test("remove then re-extract is consistent", test_remove_then_extract_consistent)
test("classify · pk detected", test_classify_finds_pk)
test("classify · email tagged pii", test_classify_email_is_pii)

# ════════════════════════════════════════════════════════════════════════════
# SUITE 13 · HTML wiring sanity (greps the actual file)
# ════════════════════════════════════════════════════════════════════════════
suite("HTML wiring sanity")

import pathlib
HTML = pathlib.Path(__file__).parent / "json-studio.html"

def test_html_exists():
    ok(HTML.exists(), f"json-studio.html not found at {HTML}")

def test_html_has_add_button():
    html = HTML.read_text(encoding="utf-8")
    ok('id="btnAddRule"' in html, "+ Add rule button missing")

def test_html_add_button_wired():
    html = HTML.read_text(encoding="utf-8")
    ok('btnAddRule").onclick' in html, "btnAddRule onclick not wired")
    ok('onAddRuleClick' in html, "onAddRuleClick handler missing")

def test_html_applyRule_function_exists():
    html = HTML.read_text(encoding="utf-8")
    ok('function applyRule(' in html, "applyRule function missing")

def test_html_removeApplied_function_exists():
    html = HTML.read_text(encoding="utf-8")
    ok('function removeApplied(' in html, "removeApplied function missing")

def test_html_onRemove_is_global():
    html = HTML.read_text(encoding="utf-8")
    ok('window.onRemove' in html, "onRemove must be on window for inline onclick")

def test_html_save_button_wired():
    html = HTML.read_text(encoding="utf-8")
    ok('btnSave").onclick = saveActive' in html, "Save button must call saveActive")

def test_html_38_rules():
    html = HTML.read_text(encoding="utf-8")
    rids = re.findall(r'rule_id:\s*"(\w+)"', html)
    eq(len(rids), 38)

def test_html_add_handler_calls_applyRule():
    html = HTML.read_text(encoding="utf-8")
    m = re.search(r'function onAddRuleClick\s*\(\)\s*\{([\s\S]*?)\n\}', html)
    ok(m is not None, "could not locate onAddRuleClick body")
    body = m.group(1)
    ok("applyRule(" in body, "onAddRuleClick must call applyRule()")

def test_html_param_editor_present():
    html = HTML.read_text(encoding="utf-8")
    ok('function renderParamEditor(' in html, "param editor missing")
    ok('function commitParam(' in html, "commitParam missing")

def test_html_simplified_no_modal():
    # phase-1 simplification should have removed the modal layer
    html = HTML.read_text(encoding="utf-8")
    ok('id="modalApply"' not in html, "modal Apply button should be gone in phase-1")
    ok('class="modal-back"' not in html, "modal backdrop should be gone in phase-1")

test("HTML file exists", test_html_exists)
test("+ Add rule button present", test_html_has_add_button)
test("+ Add button onclick wired", test_html_add_button_wired)
test("applyRule function defined", test_html_applyRule_function_exists)
test("removeApplied function defined", test_html_removeApplied_function_exists)
test("onRemove is on window", test_html_onRemove_is_global)
test("Save button wired to saveActive", test_html_save_button_wired)
test("38 rule_ids embedded", test_html_38_rules)
test("Add handler calls applyRule", test_html_add_handler_calls_applyRule)
test("inline param editor present", test_html_param_editor_present)
test("phase-1: modal layer removed", test_html_simplified_no_modal)

# ════════════════════════════════════════════════════════════════════════════
# SUMMARY
# ════════════════════════════════════════════════════════════════════════════
print()
print(f"{C.BOLD}━━ Summary ━━{C.X}")
total = len(results)
fails = [r for r in results if r[2]]
suites = len({r[0] for r in results})
print(f"  Suites:  {suites}")
print(f"  Passed:  {C.G}{total - len(fails)}{C.X}")
print(f"  Failed:  {C.R if fails else C.DIM}{len(fails)}{C.X}")
print()
if fails:
    print(f"{C.R}{C.BOLD}Failures:{C.X}")
    for s, n, e in fails:
        print(f"  {C.R}✗{C.X} [{s}] {n}\n     {e}")
    sys.exit(1)
print(f"  {C.G}{C.BOLD}All tests passed ✓{C.X}")
sys.exit(0)
