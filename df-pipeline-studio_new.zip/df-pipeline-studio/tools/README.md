# tools/

Browser apps + utilities + tests that drive the studio.

| File | Purpose |
|------|---------|
| `data-factory-pipeline-studio.html` | **The Studio** — main 6-tab console (Portfolio · Ingestion · EDA · Data Prep · Document · Onboard). Form-driven spec authoring, sticky toolbar + collapsible sections per panel, Home Dashboard with KPIs, auto-launch into VS Code + Copilot Chat. Writes `specs/<phase>/<pipeline_name>/spec.md` — the Copilot agent creates everything under `output/`. |
| `json-studio.html` | **The Rule Editor** (phase 1) — open any stage JSON, pick a rule + column from a dropdown, click `+ Add`. Applied rules render as a clean list; click any row to inline-edit its parameters. Toggle `Show raw JSON` for direct edits. Built on the 38-rule catalog. |
| `00_extract_schema.py` | Databricks notebook helper — extracts live UC table schemas into a paste-ready spec block. |
| `studio-tests.py` | **Python test suite** for the studio's pure logic (15 suites · 99 tests). |
| `studio-tests.js` | Same suite in JavaScript for Node users. Kept in sync manually with the `.py` version (not part of CI). |
| `json-studio-tests.py` | **Python test suite for the Rule Editor** (13 suites · 99 tests · ports the JS catalog + classifier + applyRule and verifies end-to-end). |
| `project-consistency-tests.py` | **Cross-project drift detector** (16 suites · 432 tests) — catches stale references (`runners/`, old `info.md`, missing `<subdomain_slug>/` path segment, mismatched test counts in READMEs, etc.) and verifies every agent/skill/instruction cross-reference resolves. |

---

## Running the test suite

The studio's deterministic logic — column classifier, expectation builder,
transform builder, address detector, SQL parser, path helpers — plus the
Rule Editor + the cross-project drift detector — totals **630 tests across
44 suites**, including end-to-end fixtures for a realistic banking pipeline
(`consumer_master` ingestion + `consumer_master_prep` data-prep) and full
ingestion + dashboard + sticky-toolbar regression checks.

### Python (stdlib only — no install)

```bash
python tools/studio-tests.py              # 15 suites ·  99 tests (Studio logic)
python tools/json-studio-tests.py         # 13 suites ·  99 tests (Rule Editor)
python tools/project-consistency-tests.py # 16 suites · 432 tests (project-wide drift)
```

Expected (all three): `Failed: 0` · `All tests passed ✓`. Total **630 / 630** pass · exit code `0` (CI-friendly) on full pass, `1` on any failure.

### Node.js (optional)

```bash
node tools/studio-tests.js
```

Same assertions, same fixtures — but the `.js` port is maintained manually
and is NOT part of automated CI. If your team has no Node users, the `.py`
suite is the source of truth.

---

## What the tests cover

| Suite | Tests | Validates |
|-------|-------|-----------|
| `slugify` | 8 | Pipeline name → safe directory slug |
| `path helpers` | 8 | `specs/<phase>/<name>/` + `output/<phase>/<name>/<configs\|reports\|sql\|notebooks>/` |
| `parseColumns` | 7 | DDL / JSON / CREATE TABLE → column array |
| `parseColumnsFromQuery` | 8 | SQL SELECT parsing (joins, aliases, function calls, comments, DISTINCT) |
| `detectPK` | 5 | Primary key detection (id → NOT NULL → first column) |
| `classifyColumns` | 9 | Semantic tagging (PII, address, datetime, money, boolean, gov_id, etc.) |
| `detectAddressMap` | 3 | Address column auto-mapping (line_1/line_2/city/state/postal/country) |
| `buildExpectations` | 7 | DQ rule generation per column tag |
| `buildTransforms` | 8 | Data-prep transformation generation per column tag |
| `detectDomain` | 5 | banking / healthcare / HR / retail / generic classification |
| `simpleDiff` | 3 | Spec-diff computation |
| **E2E: consumer_master ingestion** | 8 | Full ingestion bootstrap for a 9-column banking customer table |
| **E2E: consumer_master_prep data-prep** | 17 | Full 6-stage data-prep bootstrap for an 18-column table — PII masking, address standardization, configs/ reports/ path resolution |
| **E2E: header_query EDA→DataPrep bridge** | 4 | EDA-generated SQL flowing into data-prep stage 1 |
| **E2E: ingestion without columns** | 2 | Profiler auto-skipped when no schema contract provided |

---

## Adding a new pipeline type — Two paths

### Path A · UI self-serve (recommended for any team)

The **🧩 Onboard New Pipeline** tab lets any team register a new pipeline
type without writing a line of code.

1. Click the **🧩 Onboard New Pipeline** tab.
2. Fill the form:
   - **Pipeline ID** — auto-derived from name (slug, immutable after creation)
   - **Pipeline name** — display label (e.g. *Data Pre-Purposing*)
   - **Icon** — single emoji (default `✨`)
   - **Domain** / **Subdomain**
   - **Team** — controls who sees the tab (`All` = visible to admin only,
     or pick a specific team: Ingestion / EDA / Data Prep / Documentation)
   - **What does this pipeline do?** — one paragraph
   - **Agent path** — optional (defaults to `agents/<id>.md`)
   - **Columns** — optional DDL / JSON / comma-list
   - **Spec template** — optional markdown body (wrapped with standard sections)
3. Click **+ Create Pipeline Tab**.

A new tab appears with the chosen icon and a **standardized Data-Prep-style form**:
- Pipeline name (read-only badge) · subdomain · catalog · schema
- Description editor
- **Table Columns** textarea with **live Column Intelligence chips** (PK · PII · address · datetime · money · etc.)
- **🎯 Source for Stage 1** picker — *Input table* / *Consumer Header Query* / *Custom Extraction Query*
- Conditional source fields
- Advanced: spec template + per-run notes

Pipelines persist in `localStorage` so they survive page reloads. Three ways to delete:
- × button that appears on hover over the tab in the nav
- × Remove this pipeline button at the bottom of the pipeline's form
- × button next to each pipeline in the Onboard tab's **Existing custom pipelines** list

A starter example is one click away — **Load example (Prepurposing)**
button on the Onboard form.

### Team-based journeys (the `stages` model)

Each team declares its own **ordered journey** of tabs in the `TEAMS`
registry. Switching teams via the header **Viewing as** chip re-renders the
tab nav with EXACTLY that journey, in EXACTLY that order. Custom pipelines
owned by the team are appended after the built-in stages.

| Team | Journey (built-in stages, in order) |
|------|-------------------------------------|
| **All Pipelines (admin)** | every tab in registry order |
| **Ingestion** | Portfolio → Ingestion → EDA → Data Prep → Document → Onboard |
| **EDA** | Portfolio → EDA → Data Prep → Document → Onboard |
| **Data Prep** | Portfolio → EDA → Data Prep → Document → Onboard |
| **Documentation** | Portfolio → Document → Onboard |
| **Prepurposing** | Portfolio → Data Prep → Onboard (+ their custom pipelines) |

**Adding a new team** = add one entry to the `TEAMS` constant:

```js
prepurpose: {
  id:'prepurpose', label:'Prepurposing Team', short:'Prepurp',
  color:'#3dd9c4',
  stages:['home','dataprep','onboard']    // their journey
}
```

The team auto-appears in the header chip dropdown AND in the Onboard form's
"Owning team" picker — no other code edits.

**Custom pipelines** declare which team owns them via the Onboard form's
**Owning team** picker. They auto-append to that team's journey.

Selection persists in `localStorage`. Switching teams shows a toast with the
team's journey (e.g. `Ingestion Team · Portfolio → Ingestion → EDA → Data
Prep → Document → Onboard`). The header chip also shows the live stage
count (`· 6 stages`).

### Path B · Hard-coded built-in (only if you need a custom form)

If your pipeline needs a richer form than the generic one (multiple
sub-records, conditional sections, custom widgets), add it as a built-in:

1. Add an entry to the `PIPELINES` registry in `data-factory-pipeline-studio.html`
2. Add an HTML `<div class="panel" id="panel-<id>">` with your form
3. Add a default `STATE.<id>` slice + persistence
4. Implement `genXxxSpec()` using the standardized wrappers
   (`specHeader / specOverviewBlock / specRuntimeBlock / specGovernanceBlock /
    specOpenItemsBlock / specFooter`)

The tab nav, Generate button, modal, file paths, and E2E wizard auto-pick
up the new entry — same as Path A.

---

## When you change data-factory-pipeline-studio.html

The two test files (`.js` and `.py`) contain copies of the studio's pure
functions. When you modify `data-factory-pipeline-studio.html`, mirror the change in both:

- `studio-tests.js` — lines 1–200 (pure functions section)
- `studio-tests.py` — lines 30–230 (Python port)

The tests are the contract. They catch drift before it ships.

**TDD workflow:**
1. Update the test expectation for the new behavior
2. Run the suite → watch it fail
3. Update the production function in data-factory-pipeline-studio.html (and both test files)
4. Re-run → all green

---

## The Rule Editor (`json-studio.html`)

The Studio (`data-factory-pipeline-studio.html`) writes specs; the Copilot agent
materializes JSON configs under `output/<phase>/<pipeline>/configs/`. The
**Rule Editor** is the bridge between the two — open any of those JSONs and
add/edit/remove rules without touching raw JSON.

### Workflow (3 steps)

1. **Open or pick a template** — top toolbar has a templates dropdown
   (Bronze Load · Profiler · Extraction · Preparation · Conversion) and an
   `Open…` button for existing files from `output/`.
2. **+ Add a rule** — single inline form: pick a rule from a categorized
   dropdown, pick (or type) a column, click `+ Add`. The rule lands in the
   right slot of the JSON (transformation / expectation / post-action / block).
3. **Click an applied rule to edit** — every row in the Applied list expands
   on click and shows its parameters as editable key→value pairs. Edit a
   value, blur to save, or `Enter` to confirm. `+ Add param` adds a new key.

`Save` downloads the updated JSON.

### What's the dropdown rule list?

The 38 catalog rules from `.github/rules/categories/*.yaml`, filtered to those
applicable to the current stage (e.g., a `preparation.json` only shows rules
whose `applicable_stages` includes `preparation`). Grouped by category in
`<optgroup>`s. The column picker auto-suggests the first column matching the
selected rule's `column_match`.

### Raw JSON toggle

Top-right checkbox `Show raw JSON` reveals a textarea showing the live JSON.
Edits there flow back into the model — handy for advanced tweaks the form
doesn't expose.

---

## Pre-data_forge helper

### `00_extract_schema.py` — Schema Extractor

Upload to Databricks and run to pull schema definitions from Unity Catalog
tables directly into a data_forge-compatible spec section.

**What it does:**
1. Queries `{catalog}.information_schema.columns` for all selected tables
2. Detects primary keys from `information_schema.table_constraints` (infers from naming if unavailable)
3. Infers foreign keys from column naming patterns (e.g. `customer_id` → `customers`)
4. Queries row counts per table
5. Outputs a ready-to-paste markdown section
6. Saves outputs to DBFS at `/tmp/dataforge_schema_{catalog}_{schema}_{timestamp}/`

**Widgets:**

| Widget | Required | Description |
|--------|----------|-------------|
| `catalog` | yes | Unity Catalog name (e.g. `cert_dcs_catalog`) |
| `schema` | yes | Schema name (e.g. `bankcore_dna`) |
| `tables` | no | Comma-separated list. Blank = all tables in schema |
| `output_format` | no | `spec_md` (default), `ddl_sql`, or `both` |

**Output paste target:** `specs/eda/<pipeline_name>/spec.md`

**Permissions required:**
- `USE CATALOG` on the catalog
- `USE SCHEMA` on the schema
- `SELECT` on target tables (for row counts)
- Read on `information_schema.columns` + `information_schema.tables`
