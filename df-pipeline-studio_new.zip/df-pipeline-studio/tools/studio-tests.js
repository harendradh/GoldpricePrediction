#!/usr/bin/env node
/**
 * Data Factory Pipeline Studio · test suite
 * ────────────────────────────────
 * Runs the studio's pure deterministic logic against fixtures + asserts.
 *
 * Usage:
 *   node tools/studio-tests.js
 *
 * The functions below are copies of the same definitions in tools/data-factory-pipeline-studio.html.
 * When you change data-factory-pipeline-studio.html, mirror the change here. The tests are the
 * contract — they catch unintended drift.
 *
 * Exit code: 0 on full pass, 1 on any failure (CI-friendly).
 */
'use strict';

// ══════════════════════════════════════════════════════════════════════════
// PURE FUNCTIONS (mirror of data-factory-pipeline-studio.html)
// ══════════════════════════════════════════════════════════════════════════

function slugify(s){
  return String(s||'unnamed').toLowerCase().trim()
    .replace(/[^a-z0-9_]+/g,'_')
    .replace(/_+/g,'_')
    .replace(/^_+|_+$/g,'')
    || 'unnamed';
}
function specPath(phase, pipelineName){ return `specs/${phase}/${slugify(pipelineName)}/spec.md`; }
function outputDir(phase, pipelineName){ return `output/${phase}/${slugify(pipelineName)}/`; }
function outputConfigsDir(phase, name)  { return outputDir(phase, name) + 'configs/';   }
// outputRunnersDir removed — runners/ dir is no longer produced by any agent
function outputReportsDir(phase, name)  { return outputDir(phase, name) + 'reports/';   }
function outputSqlDir(phase, name)      { return outputDir(phase, name) + 'sql/';       }
function outputNotebooksDir(phase, name){ return outputDir(phase, name) + 'notebooks/'; }

function parseColumns(text){
  if (!text || !text.trim()) return [];
  try {
    const j = JSON.parse(text);
    if (Array.isArray(j)) return j.map((c,i)=>({
      name: c.name||c.column||c.col||`col_${i+1}`,
      type: (c.type||c.dtype||'STRING').toUpperCase(),
      nullable: c.nullable!==false && !c.notnull && !c.not_null,
      position: i+1
    }));
    if (j.columns && Array.isArray(j.columns)) return parseColumns(JSON.stringify(j.columns));
  } catch(e){}
  const lines = text.split(/[\n;]/).map(l=>l.trim()).filter(Boolean);
  const cols = [];
  lines.forEach(line => {
    if (/^create\s+table/i.test(line)) return;
    if (/^[()]+$/.test(line)) return;
    line = line.replace(/^\(+|\)+,?$/g, '').trim();
    if (!line) return;
    const parts = line.split(/\s+/);
    if (parts.length < 1) return;
    const name = parts[0].replace(/[`",]/g, '');
    if (!/^[A-Za-z_][\w]*$/.test(name)) return;
    let type = 'STRING';
    if (parts[1]) type = parts[1].replace(/[(),]/g,'').toUpperCase();
    const notNull = /not\s*null/i.test(line);
    cols.push({ name, type, nullable: !notNull, position: cols.length+1 });
  });
  return cols;
}

function parseColumnsFromQuery(sql){
  if (!sql || !sql.trim()) return [];
  let s = sql.replace(/\/\*[\s\S]*?\*\//g, ' ').replace(/--[^\n]*/g, ' ');
  const m = s.match(/SELECT\s+(?:DISTINCT\s+|TOP\s+\d+\s+)?([\s\S]+?)\s+FROM\s/i);
  if (!m) return [];
  const list = m[1];
  const parts = []; let buf = ''; let depth = 0;
  for (const ch of list){
    if (ch === '(') depth++;
    else if (ch === ')') depth--;
    if (ch === ',' && depth === 0){ parts.push(buf); buf = ''; continue; }
    buf += ch;
  }
  if (buf.trim()) parts.push(buf);
  return parts.map((raw, i) => {
    let p = raw.trim();
    if (!p || p === '*') return null;
    let alias = null;
    const as = p.match(/\s+AS\s+(["`]?)([A-Za-z_][\w]*)\1\s*$/i);
    if (as) { alias = as[2]; p = p.slice(0, as.index); }
    else {
      const trail = p.match(/\s+(["`]?)([A-Za-z_][\w]*)\1\s*$/);
      if (trail && /[()+\-*/]/.test(p.slice(0, trail.index))){
        alias = trail[2]; p = p.slice(0, trail.index);
      }
    }
    let name = alias;
    if (!name){
      const dot = p.match(/([A-Za-z_][\w]*)\s*$/);
      name = dot ? dot[1] : `col_${i+1}`;
    }
    return { name, type:'STRING', nullable:true, position:i+1 };
  }).filter(Boolean);
}

function detectPK(cols){
  const exactPk = cols.find(c => /(^|_)id$/i.test(c.name) || /^id$/i.test(c.name));
  if (exactPk) return exactPk.name;
  const nn = cols.find(c => c.nullable===false);
  if (nn) return nn.name;
  return cols.length ? cols[0].name : null;
}

function classifyColumns(cols){
  const classified = cols.map((c) => {
    const n = (c.name||'').toLowerCase();
    const t = (c.type||'STRING').toUpperCase();
    const tags = new Set();
    if (/^id$/.test(n) || /(_id|_key|_uuid|_guid)$/.test(n) || /^(uuid|guid)$/.test(n)) tags.add('id');
    if (/^(first[_ ]?name|fname|given[_ ]?name|forename)$/.test(n)) { tags.add('name'); tags.add('first_name'); }
    else if (/^(last[_ ]?name|lname|surname|family[_ ]?name)$/.test(n)) { tags.add('name'); tags.add('last_name'); }
    else if (/^(middle[_ ]?name|mname|middle[_ ]?initial|mi)$/.test(n)) { tags.add('name'); tags.add('middle_name'); }
    else if (/^(full[_ ]?name|display[_ ]?name|business[_ ]?name|company[_ ]?name|legal[_ ]?name)$/.test(n)) { tags.add('name'); tags.add('full_name'); }
    else if (/(_name$|^name$)/.test(n)) tags.add('name');
    if (/email/.test(n))                                            { tags.add('email'); tags.add('contact'); tags.add('pii'); }
    if (/(phone|mobile|cell|telephone|^tel$|fax|whatsapp)/.test(n)) { tags.add('phone'); tags.add('contact'); tags.add('pii'); }
    if (/(address|addr|street|line_?\d|premise)/.test(n))    { tags.add('address'); tags.add('street'); }
    if (/^(city|town|locality|municipality)$/.test(n))       { tags.add('address'); tags.add('city'); }
    if (/^(state|province|region|state_code|administrative_area)$/.test(n)) { tags.add('address'); tags.add('state'); }
    if (/(zip|postal|postcode|pincode|pin_code)/.test(n))    { tags.add('address'); tags.add('postal'); }
    if (/(^country|nation|country_code|country_name)/.test(n)) { tags.add('address'); tags.add('country'); }
    if (/^(lat|latitude)$/.test(n))                            { tags.add('geo'); tags.add('lat'); }
    if (/^(lon|lng|longitude)$/.test(n))                       { tags.add('geo'); tags.add('lng'); }
    if (/(TIMESTAMP|DATETIME|^DATE$|^TIME$)/.test(t)) tags.add('datetime');
    if (/(_at|_date|_ts|_time|_dt|_dttm)$/.test(n) || /^(date|time|timestamp)$/.test(n)) tags.add('datetime');
    if (/(created|inserted|added|opened|start)/.test(n) && tags.has('datetime'))    tags.add('created_ts');
    if (/(updated|modified|changed|last_update|last_modified|refresh)/.test(n) && tags.has('datetime')) tags.add('updated_ts');
    if (/(closed|terminated|ended|expir)/.test(n) && tags.has('datetime')) tags.add('end_ts');
    if (/(dob|date_of_birth|birth_date|birthdate)/.test(n))    { tags.add('datetime'); tags.add('dob'); tags.add('pii'); }
    if (/(DECIMAL|NUMERIC|MONEY|FLOAT|DOUBLE|REAL)/.test(t)) tags.add('numeric');
    if (/(^INT|BIGINT|SMALLINT|TINYINT|LONG|^INTEGER)/.test(t)) tags.add('numeric');
    if (/(amount|amt|balance|price|total|salary|cost|fee|payment|charge|premium|value|revenue|income|debit|credit|deposit|withdrawal)/.test(n)) {
      tags.add('money'); tags.add('numeric');
    }
    if (/^(status|state|type|kind|category|class|code|tier|rank|grade|level|segment)$/.test(n)
        || /(_status|_code|_type|_class|_category|_tier|_grade|_segment)$/.test(n)) tags.add('categorical');
    if (/(BOOLEAN|BOOL|BIT)/.test(t)) tags.add('boolean');
    if (/^(is_|has_|can_|should_|will_)/.test(n) || /(_flag|_ind|_indicator|_y_n|_yn)$/.test(n)) tags.add('boolean');
    if (/(^ssn$|social_security|^sin$|nat_id|national_id)/.test(n)) { tags.add('pii'); tags.add('gov_id'); }
    if (/(tax_id|ein|^itin$|tin)/.test(n))                          { tags.add('pii'); tags.add('gov_id'); }
    if (/(card_num|cc_num|^pan$|^iban$|^cvv$|cvc|card_number)/.test(n)) { tags.add('pii'); tags.add('financial_id'); }
    if (/(account_num|acct_num|routing|aba|swift)/.test(n))         { tags.add('pii'); tags.add('financial_id'); }
    if (/(passport|driver_lic|drivers_lic|drivers_license|license_num)/.test(n)) { tags.add('pii'); tags.add('doc_id'); }
    if (/(gender|race|ethnic|marital|nationality)/.test(n))         tags.add('demographic');
    if (/(salary|income|wage|net_worth)/.test(n))                   tags.add('sensitive_financial');
    if (/(description|^desc$|notes?|comments?|remarks?|summary|memo|message|narrative)/.test(n)) {
      tags.add('text'); tags.add('freetext');
    }
    return { ...c, tags: Array.from(tags) };
  });
  let pk = classified.find(c => c.tags.includes('id') && c.nullable===false)
        || classified.find(c => c.tags.includes('id'))
        || classified.find(c => c.nullable===false)
        || classified[0];
  if (pk) pk.tags.push('pk');
  return classified;
}

function detectAddressMap(classified){
  const findOne  = (sub) => { const c = classified.find(c=>c.tags.includes(sub)); return c?c.name:null; };
  const findMany = (sub) => classified.filter(c=>c.tags.includes(sub)).map(c=>c.name);
  const streets = findMany('street');
  return {
    line_1:      streets[0] || null,
    line_2:      streets[1] || null,
    city:        findOne('city'),
    state:       findOne('state'),
    postal_code: findOne('postal'),
    country:     findOne('country')
  };
}

function buildExpectations(classified){
  const exp = []; let n = 1;
  const id = (rule, col) => `e${String(n++).padStart(2,'0')}_${rule}_${col}`.slice(0,80);
  const pk = classified.find(c => c.tags.includes('pk'));
  if (pk){
    exp.push({ id:id('not_null',pk.name), column:pk.name, rule:'not_null', threshold:1.0, severity:'CRITICAL', args:{}, action:'fail' });
    exp.push({ id:id('unique',pk.name),   column:pk.name, rule:'unique',   threshold:1.0, severity:'CRITICAL', args:{}, action:'fail' });
  }
  classified.forEach(c => {
    const t = c.tags;
    if (t.includes('email'))       exp.push({ id:id('regex',c.name), column:c.name, rule:'regex', threshold:0.95, args:{ pattern:'^[^@]+@[^@]+\\.[^@]+$' }, severity:'HIGH', action:'warn_only' });
    if (t.includes('phone'))       exp.push({ id:id('length',c.name), column:c.name, rule:'length_between', threshold:0.90, args:{ min:7, max:15 }, severity:'HIGH', action:'warn_only' });
    if (t.includes('country'))     exp.push({ id:id('in_set',c.name), column:c.name, rule:'in_set', threshold:0.99, args:{ values:['US','CA','GB','IN','AU','MX','DE','FR'] }, severity:'WARN', action:'warn_only' });
    if (t.includes('postal'))      exp.push({ id:id('length',c.name), column:c.name, rule:'length_between', threshold:0.95, args:{ min:3, max:10 }, severity:'INFO', action:'warn_only' });
    if (t.includes('state'))       exp.push({ id:id('length',c.name), column:c.name, rule:'length_between', threshold:0.95, args:{ min:2, max:40 }, severity:'INFO', action:'warn_only' });
    if (t.includes('money'))       exp.push({ id:id('value',c.name), column:c.name, rule:'value_between', threshold:0.99, args:{ min:0, max:1e12 }, severity:'HIGH', action:'warn_only' });
    if (t.includes('boolean'))     exp.push({ id:id('boolset',c.name), column:c.name, rule:'in_set', threshold:1.0, args:{ values:[true,false,'true','false','Y','N','0','1'] }, severity:'INFO', action:'warn_only' });
    if (t.includes('categorical')) exp.push({ id:id('distinct',c.name), column:c.name, rule:'distinct_count_less_than', threshold:1.0, args:{ max:200 }, severity:'INFO', action:'warn_only' });
    if (t.includes('datetime') && !t.includes('end_ts')) exp.push({ id:id('not_future',c.name), column:c.name, rule:'not_in_future', threshold:1.0, args:{}, severity:'HIGH', action:'warn_only' });
    if (t.includes('dob'))         exp.push({ id:id('dob_range',c.name), column:c.name, rule:'value_between', threshold:1.0, args:{ min:'1900-01-01', max:'CURRENT_DATE' }, severity:'HIGH', action:'warn_only' });
    if (t.includes('lat'))         exp.push({ id:id('lat',c.name), column:c.name, rule:'value_between', threshold:1.0, args:{ min:-90, max:90 }, severity:'WARN', action:'warn_only' });
    if (t.includes('lng'))         exp.push({ id:id('lng',c.name), column:c.name, rule:'value_between', threshold:1.0, args:{ min:-180, max:180 }, severity:'WARN', action:'warn_only' });
  });
  exp.push({ id:`e${String(n++).padStart(2,'0')}_row_count_min`, column:'*', rule:'row_count_min', threshold:1.0, args:{ min:1 }, severity:'CRITICAL', action:'fail' });
  return exp;
}

function buildTransforms(classified){
  const tx = []; let n = 1;
  const id = (op, col) => `t${String(n++).padStart(2,'0')}_${op}_${col}`.slice(0,80);
  classified.forEach(c => {
    const t = c.tags;
    if (t.includes('name') || t.includes('street') || t.includes('city') || t.includes('state')
        || t.includes('country') || t.includes('postal') || t.includes('freetext') || t.includes('categorical')){
      tx.push({ id:id('trim',c.name), op:'trim', columns:[c.name], args:{ side:'both' }, on_error:'skip_row' });
    }
    if (t.includes('email'))   tx.push({ id:id('lower',c.name), op:'lower', columns:[c.name], args:{}, on_error:'null_out' });
    if (t.includes('country') || t.includes('state'))
                                tx.push({ id:id('upper',c.name), op:'upper', columns:[c.name], args:{}, on_error:'null_out' });
    if (t.includes('phone'))   tx.push({ id:id('regex',c.name), op:'regex_replace', columns:[c.name], args:{ pattern:'[^0-9+]', replacement:'' }, on_error:'null_out' });
    if (t.includes('datetime') && !/TIMESTAMP/.test((c.type||'').toUpperCase()))
                                tx.push({ id:id('cast',c.name), op:'cast', columns:[c.name], args:{ target_type:'TIMESTAMP' }, on_error:'null_out' });
    if (t.includes('gov_id') || t.includes('financial_id') || t.includes('doc_id'))
                                tx.push({ id:id('mask',c.name), op:'mask', columns:[c.name], args:{ method:'sha2_256' }, on_error:'fail' });
    if (t.includes('dob'))      tx.push({ id:id('mask',c.name), op:'mask', columns:[c.name], args:{ method:'truncate_date', precision:'year' }, on_error:'fail' });
  });
  const pk = classified.find(c => c.tags.includes('pk'));
  if (pk) tx.push({ id:id('drop_null_pk',pk.name), op:'drop_rows', columns:[pk.name], args:{ where:`${pk.name} IS NULL` }, on_error:'fail' });
  return tx;
}

function classifySummary(classified){
  if (!classified || !classified.length) return null;
  const has = (tag) => classified.filter(c=>c.tags.includes(tag)).length;
  return {
    total: classified.length, pk: has('pk'), id: has('id'), pii: has('pii'),
    address: has('address'), datetime: has('datetime'), money: has('money'),
    categorical: has('categorical'), boolean: has('boolean'), name: has('name'),
    contact: has('contact'), numeric: has('numeric'), freetext: has('freetext')
  };
}

function detectDomain(classified){
  if (!classified || !classified.length) return null;
  const names = classified.map(c=>c.name.toLowerCase()).join(' ');
  if (/(kyc|aml|customer|account|balance|txn|merchant|premium|policy|claim|loan|card_num|routing|iban)/.test(names)) return 'banking';
  if (/(patient|mrn|diagnosis|icd|provider|prescription|insurance)/.test(names)) return 'healthcare';
  if (/(employee|salary|hire_date|department|payroll|benefit)/.test(names)) return 'HR';
  if (/(order|product|sku|cart|inventory|warehouse|shipment)/.test(names)) return 'retail';
  return 'generic';
}

function simpleDiff(a, b){
  const aLines = (a||'').split('\n'); const bLines = (b||'').split('\n');
  const aSet = new Set(aLines); const bSet = new Set(bLines);
  const added = bLines.filter(l=>!aSet.has(l) && l.trim());
  const removed = aLines.filter(l=>!bSet.has(l) && l.trim());
  return { added: added.length, removed: removed.length };
}

// ══════════════════════════════════════════════════════════════════════════
// TEST FRAMEWORK
// ══════════════════════════════════════════════════════════════════════════

const C = { red:'\x1b[31m', green:'\x1b[32m', yellow:'\x1b[33m', dim:'\x1b[2m', bold:'\x1b[1m', reset:'\x1b[0m' };
const results = { pass: 0, fail: 0, suites: 0, failures: [] };
let currentSuite = '';

function suite(name, fn){
  currentSuite = name; results.suites++;
  console.log(`\n${C.bold}━━ ${name} ━━${C.reset}`);
  fn();
}
function test(name, fn){
  try { fn(); results.pass++; console.log(`  ${C.green}✓${C.reset} ${name}`); }
  catch(e){
    results.fail++; results.failures.push({ suite: currentSuite, test: name, err: e.message });
    console.log(`  ${C.red}✗${C.reset} ${name}\n    ${C.red}${e.message.replace(/\n/g, '\n    ')}${C.reset}`);
  }
}
function eq(actual, expected, msg){
  const a = JSON.stringify(actual), e = JSON.stringify(expected);
  if (a !== e) throw new Error(`${msg ? msg+'\n' : ''}expected: ${e}\n     got: ${a}`);
}
function ok(cond, msg){ if (!cond) throw new Error(msg || 'expected truthy'); }
function contains(haystack, needle, msg){
  const s = typeof haystack === 'string' ? haystack : JSON.stringify(haystack);
  if (!s.includes(needle)) throw new Error(`${msg||''}\n  expected to contain: ${needle}\n             in: ${s.slice(0,200)}`);
}

// ══════════════════════════════════════════════════════════════════════════
// TEST SUITES
// ══════════════════════════════════════════════════════════════════════════

suite('slugify', () => {
  test('lowercases',                   () => eq(slugify('Customer'),           'customer'));
  test('replaces spaces with _',       () => eq(slugify('customer master'),    'customer_master'));
  test('replaces dashes with _',       () => eq(slugify('customer-master'),    'customer_master'));
  test('strips special chars',         () => eq(slugify('Customer/Master 2!'), 'customer_master_2'));
  test('handles empty → unnamed',      () => eq(slugify(''),                   'unnamed'));
  test('handles null → unnamed',       () => eq(slugify(null),                 'unnamed'));
  test('trims leading/trailing _',     () => eq(slugify('  __weird__  '),      'weird'));
  test('collapses consecutive _',      () => eq(slugify('a___b---c'),          'a_b_c'));
});

suite('path helpers', () => {
  test('specPath dataprep',            () => eq(specPath('dataprep','Cust Master'),     'specs/dataprep/cust_master/spec.md'));
  test('specPath ingestion',           () => eq(specPath('ingestion','customer_v2'),    'specs/ingestion/customer_v2/spec.md'));
  test('outputDir',                    () => eq(outputDir('dataprep','x'),               'output/dataprep/x/'));
  test('outputConfigsDir',             () => eq(outputConfigsDir('dataprep','x'),        'output/dataprep/x/configs/'));
  test('outputReportsDir',             () => eq(outputReportsDir('eda','z'),             'output/eda/z/reports/'));
  test('outputSqlDir',                 () => eq(outputSqlDir('eda','z'),                 'output/eda/z/sql/'));
  test('outputNotebooksDir',           () => eq(outputNotebooksDir('eda','z'),           'output/eda/z/notebooks/'));
});

suite('parseColumns', () => {
  test('parses DDL with NOT NULL', () => {
    const cols = parseColumns('customer_id  STRING  NOT NULL\nemail  STRING');
    eq(cols.length, 2);
    eq(cols[0], { name:'customer_id', type:'STRING', nullable:false, position:1 });
    eq(cols[1], { name:'email',       type:'STRING', nullable:true,  position:2 });
  });
  test('parses JSON array',                () => {
    const cols = parseColumns('[{"name":"id","type":"BIGINT","nullable":false}]');
    eq(cols.length, 1);
    eq(cols[0].name, 'id');
    eq(cols[0].nullable, false);
  });
  test('parses JSON object with columns',  () => {
    const cols = parseColumns('{"columns":[{"name":"a"},{"name":"b"}]}');
    eq(cols.length, 2);
  });
  test('skips CREATE TABLE wrapper',       () => {
    const cols = parseColumns('CREATE TABLE foo (\n  a STRING,\n  b INT\n)');
    eq(cols.length, 2);
    eq(cols[0].name, 'a');
    eq(cols[1].name, 'b');
  });
  test('handles empty input',              () => eq(parseColumns(''), []));
  test('handles whitespace-only input',    () => eq(parseColumns('   \n   '), []));
  test('skips lines without identifiers',  () => eq(parseColumns('  ;  ').length, 0));
  test('uppercase the type',               () => eq(parseColumns('a string').map(c=>c.type), ['STRING']));
});

suite('parseColumnsFromQuery', () => {
  test('simple SELECT',                () => {
    const cols = parseColumnsFromQuery('SELECT a, b, c FROM t');
    eq(cols.map(c=>c.name), ['a','b','c']);
  });
  test('SELECT with table prefix',     () => {
    const cols = parseColumnsFromQuery('SELECT t.a, t.b FROM t');
    eq(cols.map(c=>c.name), ['a','b']);
  });
  test('SELECT with AS alias',         () => {
    const cols = parseColumnsFromQuery('SELECT TRIM(name) AS clean_name, LOWER(email) AS email FROM t');
    eq(cols.map(c=>c.name), ['clean_name','email']);
  });
  test('SELECT with JOIN',             () => {
    const cols = parseColumnsFromQuery('SELECT c.id, c.name, a.city FROM customers c JOIN addresses a ON c.id = a.cid');
    eq(cols.map(c=>c.name), ['id','name','city']);
  });
  test('handles function calls with commas in args', () => {
    const cols = parseColumnsFromQuery('SELECT COALESCE(a, b, c) AS final, x FROM t');
    eq(cols.map(c=>c.name), ['final','x']);
  });
  test('strips line + block comments', () => {
    const cols = parseColumnsFromQuery('SELECT a, /* comment */ b, -- inline\n c FROM t');
    eq(cols.map(c=>c.name), ['a','b','c']);
  });
  test('handles DISTINCT',             () => {
    const cols = parseColumnsFromQuery('SELECT DISTINCT a, b FROM t');
    eq(cols.map(c=>c.name), ['a','b']);
  });
  test('returns empty for missing FROM',() => eq(parseColumnsFromQuery('SELECT a, b'), []));
});

suite('detectPK', () => {
  test('picks *_id column',                  () => eq(detectPK([{name:'name'},{name:'customer_id'},{name:'email'}]), 'customer_id'));
  test('picks bare "id"',                    () => eq(detectPK([{name:'id'},{name:'x'}]), 'id'));
  test('falls back to NOT NULL column',      () => eq(detectPK([{name:'a',nullable:true},{name:'b',nullable:false}]), 'b'));
  test('falls back to first column',         () => eq(detectPK([{name:'a',nullable:true},{name:'b',nullable:true}]), 'a'));
  test('returns null for empty',             () => eq(detectPK([]), null));
});

suite('classifyColumns', () => {
  const cols = parseColumns(`customer_id    STRING   NOT NULL
first_name     STRING
last_name      STRING
email          STRING
phone          STRING
address_line_1 STRING
city           STRING
state          STRING
zip            STRING
country        STRING
ssn            STRING
date_of_birth  DATE
account_balance DECIMAL
account_status STRING
is_active      BOOLEAN
created_at     TIMESTAMP
updated_at     TIMESTAMP`);
  const classified = classifyColumns(cols);
  const summary   = classifySummary(classified);

  test('tags customer_id as pk + id',            () => ok(classified.find(c=>c.name==='customer_id').tags.includes('pk')));
  test('tags email as pii + email + contact',    () => {
    const t = classified.find(c=>c.name==='email').tags;
    ok(t.includes('email') && t.includes('pii') && t.includes('contact'));
  });
  test('tags ssn as pii + gov_id',               () => {
    const t = classified.find(c=>c.name==='ssn').tags;
    ok(t.includes('pii') && t.includes('gov_id'));
  });
  test('tags account_balance as money + numeric',() => {
    const t = classified.find(c=>c.name==='account_balance').tags;
    ok(t.includes('money') && t.includes('numeric'));
  });
  test('tags is_active as boolean',              () => ok(classified.find(c=>c.name==='is_active').tags.includes('boolean')));
  test('tags created_at as datetime + created_ts',() => {
    const t = classified.find(c=>c.name==='created_at').tags;
    ok(t.includes('datetime') && t.includes('created_ts'));
  });
  test('tags date_of_birth as dob + pii',        () => {
    const t = classified.find(c=>c.name==='date_of_birth').tags;
    ok(t.includes('dob') && t.includes('pii'));
  });
  test('tags address columns correctly',         () => {
    const get = n => classified.find(c=>c.name===n).tags;
    ok(get('address_line_1').includes('street'));
    ok(get('city').includes('city'));
    ok(get('state').includes('state'));
    ok(get('zip').includes('postal'));
    ok(get('country').includes('country'));
  });
  test('classifySummary counts',                 () => {
    ok(summary.total === 17);
    ok(summary.pk === 1);
    ok(summary.pii >= 3,  `pii count was ${summary.pii}`);
    ok(summary.address === 5);
    ok(summary.datetime >= 3, `datetime count was ${summary.datetime}`);
  });
});

suite('detectAddressMap', () => {
  test('full address set', () => {
    const c = classifyColumns(parseColumns('address_line_1 STRING\naddress_line_2 STRING\ncity STRING\nstate STRING\nzip STRING\ncountry STRING'));
    eq(detectAddressMap(c), { line_1:'address_line_1', line_2:'address_line_2', city:'city', state:'state', postal_code:'zip', country:'country' });
  });
  test('partial address (no line_2 or country)', () => {
    const c = classifyColumns(parseColumns('street STRING\ncity STRING\nstate STRING\nzip STRING'));
    const m = detectAddressMap(c);
    ok(m.line_1 === 'street');
    eq(m.line_2, null);
    eq(m.country, null);
  });
  test('no address columns', () => {
    const c = classifyColumns(parseColumns('id STRING\nname STRING'));
    eq(detectAddressMap(c), { line_1:null, line_2:null, city:null, state:null, postal_code:null, country:null });
  });
});

suite('buildExpectations', () => {
  const c = classifyColumns(parseColumns('customer_id STRING NOT NULL\nemail STRING\ncountry STRING\namount DECIMAL\ncreated_at TIMESTAMP'));
  const exp = buildExpectations(c);
  test('generates not_null + unique for PK',  () => {
    ok(exp.find(e => e.column==='customer_id' && e.rule==='not_null'));
    ok(exp.find(e => e.column==='customer_id' && e.rule==='unique'));
  });
  test('regex rule for email',                () => ok(exp.find(e => e.column==='email' && e.rule==='regex')));
  test('in_set rule for country',             () => ok(exp.find(e => e.column==='country' && e.rule==='in_set')));
  test('value_between for money',             () => ok(exp.find(e => e.column==='amount' && e.rule==='value_between')));
  test('not_in_future for datetime',          () => ok(exp.find(e => e.column==='created_at' && e.rule==='not_in_future')));
  test('row_count_min sentinel always added', () => ok(exp.find(e => e.rule==='row_count_min')));
  test('every expectation has required fields', () => {
    exp.forEach(e => {
      ok(typeof e.id === 'string');
      ok(typeof e.column === 'string');
      ok(typeof e.rule === 'string');
      ok(['CRITICAL','HIGH','WARN','INFO'].includes(e.severity));
      ok(['fail','quarantine','warn_only'].includes(e.action));
    });
  });
});

suite('buildTransforms', () => {
  const c = classifyColumns(parseColumns('id STRING NOT NULL\nfirst_name STRING\nemail STRING\nphone STRING\ncountry STRING\nssn STRING\ndate_of_birth DATE\ncreated_at TIMESTAMP'));
  const tx = buildTransforms(c);
  test('trim for name columns',               () => ok(tx.find(t => t.op==='trim' && t.columns.includes('first_name'))));
  test('lower for email',                     () => ok(tx.find(t => t.op==='lower' && t.columns.includes('email'))));
  test('regex_replace for phone',             () => ok(tx.find(t => t.op==='regex_replace' && t.columns.includes('phone'))));
  test('upper for country',                   () => ok(tx.find(t => t.op==='upper' && t.columns.includes('country'))));
  test('sha2_256 mask for ssn',               () => ok(tx.find(t => t.op==='mask' && t.columns.includes('ssn') && t.args.method==='sha2_256')));
  test('truncate_date mask for DOB',          () => ok(tx.find(t => t.op==='mask' && t.columns.includes('date_of_birth') && t.args.method==='truncate_date')));
  test('drop null PK row',                    () => ok(tx.find(t => t.op==='drop_rows' && t.columns.includes('id'))));
  test('no cast for existing TIMESTAMP col',  () => ok(!tx.find(t => t.op==='cast' && t.columns.includes('created_at'))));
});

suite('detectDomain', () => {
  test('banking',    () => eq(detectDomain(classifyColumns(parseColumns('customer_id STRING\nkyc_status STRING\nbalance DECIMAL'))), 'banking'));
  test('healthcare', () => eq(detectDomain(classifyColumns(parseColumns('patient_id STRING\nmrn STRING\ndiagnosis STRING'))), 'healthcare'));
  test('HR',         () => eq(detectDomain(classifyColumns(parseColumns('employee_id STRING\nsalary DECIMAL\ndepartment STRING'))), 'HR'));
  test('retail',     () => eq(detectDomain(classifyColumns(parseColumns('order_id STRING\nproduct_id STRING\nsku STRING'))), 'retail'));
  test('generic',    () => eq(detectDomain(classifyColumns(parseColumns('foo STRING\nbar STRING'))), 'generic'));
});

suite('simpleDiff', () => {
  test('detects added lines',   () => eq(simpleDiff('a\nb',     'a\nb\nc'),  { added:1, removed:0 }));
  test('detects removed lines', () => eq(simpleDiff('a\nb\nc',  'a\nb'),     { added:0, removed:1 }));
  test('no diff',                () => eq(simpleDiff('a\nb',    'a\nb'),     { added:0, removed:0 }));
});

// ══════════════════════════════════════════════════════════════════════════
// END-TO-END · realistic pipeline fixtures
// ══════════════════════════════════════════════════════════════════════════

suite('E2E · consumer_master ingestion bootstrap', () => {
  const STATE = {
    ingest: {
      pipeline_name: 'consumer_master', domain: 'banking', subdomain: 'Consumer',
      source_type: 'Oracle', catalog: 'cert_dcs_catalog', schema: 'bankcore_dna',
      columns: `customer_id    STRING   NOT NULL
first_name     STRING
last_name      STRING
email          STRING
phone          STRING
ssn            STRING
date_of_birth  DATE
created_at     TIMESTAMP
updated_at     TIMESTAMP`
    }
  };
  const cols = classifyColumns(parseColumns(STATE.ingest.columns));
  const sum  = classifySummary(cols);
  const expect = buildExpectations(cols);
  const dir = outputConfigsDir('ingestion', STATE.ingest.pipeline_name);

  test('parses 9 columns',                 () => eq(cols.length, 9));
  test('detects 3 PII (email, phone, ssn, dob)', () => ok(sum.pii >= 3));
  test('detects PK = customer_id',         () => ok(cols.find(c=>c.name==='customer_id').tags.includes('pk')));
  test('bootstrap dir is configs/',        () => eq(dir, 'output/ingestion/consumer_master/configs/'));
  test('PK expectations generated',        () => {
    ok(expect.find(e => e.column==='customer_id' && e.rule==='not_null' && e.severity==='CRITICAL'));
    ok(expect.find(e => e.column==='customer_id' && e.rule==='unique'));
  });
  test('email regex expectation generated',() => ok(expect.find(e => e.column==='email' && e.rule==='regex')));
  test('manifest file path correct',       () => eq(dir + 'manifest.json', 'output/ingestion/consumer_master/configs/manifest.json'));
  test('spec path correct',                () => eq(specPath('ingestion', STATE.ingest.pipeline_name), 'specs/ingestion/consumer_master/spec.md'));
});

suite('E2E · consumer_master_prep data-prep bootstrap', () => {
  const STATE = {
    dp: {
      pipeline_name: 'consumer_master_prep', subdomain: 'Consumer',
      catalog: 'cert_dcs_catalog', schema: 'bankcore_dna',
      source_mode: 'table', t_extract_in: 'consumer_master',
      columns: `customer_id     STRING   NOT NULL
first_name      STRING
last_name       STRING
email           STRING
phone           STRING
address_line_1  STRING
address_line_2  STRING
city            STRING
state           STRING
zip             STRING
country         STRING
ssn             STRING
date_of_birth   DATE
account_balance DECIMAL
account_status  STRING
is_active       BOOLEAN
created_at      TIMESTAMP
updated_at      TIMESTAMP`
    }
  };
  const cols = classifyColumns(parseColumns(STATE.dp.columns));
  const sum = classifySummary(cols);
  const addr = detectAddressMap(cols);
  const expect = buildExpectations(cols);
  const transforms = buildTransforms(cols);
  const cfgDir = outputConfigsDir('dataprep', STATE.dp.pipeline_name);
  const reportsDir = outputReportsDir('dataprep', STATE.dp.pipeline_name);

  test('parses 18 columns',                () => eq(cols.length, 18));
  test('detects 6 address columns',        () => eq(sum.address, 6));
  test('detects address map fully',        () => {
    eq(addr.line_1, 'address_line_1');
    eq(addr.line_2, 'address_line_2');
    eq(addr.city, 'city');
    eq(addr.state, 'state');
    eq(addr.postal_code, 'zip');
    eq(addr.country, 'country');
  });
  test('detects PII (email, phone, ssn, dob, account_balance is not pii)', () => ok(sum.pii >= 4));
  test('configs go to configs/ subdir',    () => eq(cfgDir, 'output/dataprep/consumer_master_prep/configs/'));
  test('reports go to reports/ subdir',    () => eq(reportsDir, 'output/dataprep/consumer_master_prep/reports/'));
  test('extraction config path',           () => eq(cfgDir + 'extraction.json', 'output/dataprep/consumer_master_prep/configs/extraction.json'));
  test('conversion config path',           () => eq(cfgDir + 'conversion.json', 'output/dataprep/consumer_master_prep/configs/conversion.json'));
  test('manifest config path',             () => eq(cfgDir + 'manifest.json', 'output/dataprep/consumer_master_prep/configs/manifest.json'));
  test('SSN is masked sha2_256',           () => ok(transforms.find(t => t.op==='mask' && t.columns.includes('ssn') && t.args.method==='sha2_256')));
  test('DOB is truncate_date masked',      () => ok(transforms.find(t => t.op==='mask' && t.columns.includes('date_of_birth') && t.args.method==='truncate_date')));
  test('email is lowered',                 () => ok(transforms.find(t => t.op==='lower' && t.columns.includes('email'))));
  test('phone is regex_replaced',          () => ok(transforms.find(t => t.op==='regex_replace' && t.columns.includes('phone'))));
  test('null PK rows are dropped',         () => ok(transforms.find(t => t.op==='drop_rows' && t.columns.includes('customer_id'))));
  test('domain detected = banking',        () => eq(detectDomain(cols), 'banking'));
});

suite('E2E · header_query source mode (EDA → DataPrep bridge)', () => {
  const headerSql = `SELECT
  c.customer_id,
  c.first_name,
  c.last_name,
  LOWER(c.email) AS email,
  c.phone,
  a.address_line_1, a.city, a.state, a.zip, a.country,
  c.created_at, c.updated_at
FROM main.bronze.customers c
LEFT JOIN main.bronze.addresses a ON c.customer_id = a.customer_id AND a.is_primary = true`;
  const cols = classifyColumns(parseColumnsFromQuery(headerSql));
  test('parses 12 columns from SQL',       () => eq(cols.length, 12));
  test('email alias picked correctly',     () => ok(cols.find(c => c.name === 'email')));
  test('address columns flow through',     () => {
    const addr = detectAddressMap(cols);
    eq(addr.line_1, 'address_line_1');
    eq(addr.country, 'country');
  });
  test('PK detected from SQL columns',     () => ok(cols.find(c=>c.name==='customer_id').tags.includes('pk')));
});

suite('E2E · ingestion without columns → profiler skipped', () => {
  const STATE = { ingest: { pipeline_name: 'orphan_feed', source_type:'Oracle', catalog:'cert_dcs_catalog', schema:'IDW', columns: '' } };
  const cols = parseColumns(STATE.ingest.columns);
  test('no columns parsed',                () => eq(cols.length, 0));
  test('profiler stage 2 would be disabled (hasCols=false)', () => ok(cols.length === 0));
});

// ══════════════════════════════════════════════════════════════════════════
// SUMMARY
// ══════════════════════════════════════════════════════════════════════════

console.log(`\n${C.bold}━━ Summary ━━${C.reset}`);
console.log(`  Suites:  ${results.suites}`);
console.log(`  Passed:  ${C.green}${results.pass}${C.reset}`);
console.log(`  Failed:  ${results.fail > 0 ? C.red : C.dim}${results.fail}${C.reset}`);
if (results.failures.length){
  console.log(`\n${C.bold}Failures:${C.reset}`);
  results.failures.forEach(f => console.log(`  ${C.red}✗${C.reset} ${f.suite} › ${f.test}\n    ${C.dim}${f.err.split('\n')[0]}${C.reset}`));
  process.exit(1);
} else {
  console.log(`\n  ${C.green}${C.bold}All tests passed ✓${C.reset}\n`);
  process.exit(0);
}
