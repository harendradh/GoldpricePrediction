# Databricks notebook source
# MAGIC %md
# MAGIC # data_forge — Schema Extractor
# MAGIC
# MAGIC **Run this notebook BEFORE creating your spec.md.**
# MAGIC
# MAGIC It reads your Unity Catalog tables and outputs a ready-to-paste `spec.md` section
# MAGIC with all column names, types, nullability, and detected primary keys.
# MAGIC
# MAGIC ### How to use
# MAGIC 1. Set the widgets below (catalog, schema, and optionally a table list)
# MAGIC 2. Run all cells
# MAGIC 3. Copy the output from the last cell into your `spec.md`
# MAGIC 4. Add any context sentences ("This table contains...", "Joins to...")
# MAGIC 5. Run data_forge

# COMMAND ----------
# ── Widgets ─────────────────────────────────────────────────────────────────
dbutils.widgets.text(
    "catalog", "",
    "Unity Catalog name  (e.g. main)"
)
dbutils.widgets.text(
    "schema", "",
    "Schema name  (e.g. silver, retail)"
)
dbutils.widgets.text(
    "tables", "",
    "Tables to extract  (comma-separated, blank = all tables in schema)"
)
dbutils.widgets.dropdown(
    "output_format", "spec_md",
    ["spec_md", "ddl_sql", "both"],
    "Output format"
)

CATALOG       = dbutils.widgets.get("catalog").strip()
SCHEMA        = dbutils.widgets.get("schema").strip()
TABLES_INPUT  = dbutils.widgets.get("tables").strip()
OUTPUT_FORMAT = dbutils.widgets.get("output_format")

if not CATALOG or not SCHEMA:
    raise ValueError("Set both 'catalog' and 'schema' widgets before running.")

TABLE_FILTER = [t.strip() for t in TABLES_INPUT.split(",") if t.strip()] if TABLES_INPUT else []
print(f"Catalog : {CATALOG}")
print(f"Schema  : {SCHEMA}")
print(f"Tables  : {TABLE_FILTER if TABLE_FILTER else 'ALL'}")
print(f"Format  : {OUTPUT_FORMAT}")

# COMMAND ----------
# ── Step 1: Discover tables in the schema ───────────────────────────────────
# MAGIC %md ## Step 1 — Discover tables

tables_df = spark.sql(f"""
    SELECT
        table_name,
        table_type,
        comment
    FROM `{CATALOG}`.information_schema.tables
    WHERE table_schema = '{SCHEMA}'
      AND table_type IN ('BASE TABLE', 'MANAGED', 'EXTERNAL')
    ORDER BY table_name
""")

all_tables = [row.table_name for row in tables_df.collect()]

if TABLE_FILTER:
    missing = [t for t in TABLE_FILTER if t not in all_tables]
    if missing:
        print(f"WARNING: Tables not found in {CATALOG}.{SCHEMA}: {missing}")
    selected_tables = [t for t in TABLE_FILTER if t in all_tables]
else:
    selected_tables = all_tables

print(f"\nFound {len(all_tables)} tables in {CATALOG}.{SCHEMA}")
print(f"Extracting schema for: {selected_tables}")
display(tables_df.filter(tables_df.table_name.isin(selected_tables)))

# COMMAND ----------
# ── Step 2: Extract columns from information_schema ─────────────────────────
# MAGIC %md ## Step 2 — Extract column definitions

table_list_sql = "','".join(selected_tables)

columns_df = spark.sql(f"""
    SELECT
        c.table_name,
        c.column_name,
        c.ordinal_position,
        c.data_type,
        c.is_nullable,
        c.column_default,
        c.comment
    FROM `{CATALOG}`.information_schema.columns c
    WHERE c.table_schema = '{SCHEMA}'
      AND c.table_name   IN ('{table_list_sql}')
    ORDER BY c.table_name, c.ordinal_position
""")

display(columns_df)

# COMMAND ----------
# ── Step 3: Detect primary keys from constraints ─────────────────────────────
# MAGIC %md ## Step 3 — Detect primary keys and foreign keys

try:
    pk_df = spark.sql(f"""
        SELECT
            tc.table_name,
            kcu.column_name,
            tc.constraint_type
        FROM `{CATALOG}`.information_schema.table_constraints tc
        JOIN `{CATALOG}`.information_schema.key_column_usage kcu
            ON  tc.constraint_name = kcu.constraint_name
            AND tc.table_schema    = kcu.table_schema
            AND tc.table_name      = kcu.table_name
        WHERE tc.table_schema = '{SCHEMA}'
          AND tc.table_name   IN ('{table_list_sql}')
          AND tc.constraint_type IN ('PRIMARY KEY', 'FOREIGN KEY')
        ORDER BY tc.table_name, tc.constraint_type, kcu.ordinal_position
    """)
    pk_rows = pk_df.collect()
    display(pk_df)
except Exception:
    # information_schema.table_constraints may not exist on older runtimes
    pk_rows = []
    print("Note: constraint metadata not available — PK/FK will be inferred from column names.")

# Build lookup: table → set of PK columns
pk_map = {}
fk_map = {}
for row in pk_rows:
    tbl = row.table_name
    col = row.column_name
    ctype = row.constraint_type
    if ctype == "PRIMARY KEY":
        pk_map.setdefault(tbl, set()).add(col)
    elif ctype == "FOREIGN KEY":
        fk_map.setdefault(tbl, set()).add(col)

# Fallback: infer PK from column name patterns when no constraint metadata
def infer_pk(table_name, col_name, is_nullable, ordinal_position):
    """Return True if column looks like a primary key."""
    if is_nullable == "NO" and ordinal_position == 1:
        # First non-nullable column is very likely a PK
        if col_name.endswith("_id") or col_name == "id":
            return True
        # Exact match: column name = table_name + '_id'  (singular form)
        singular = table_name.rstrip("s")
        if col_name in (f"{table_name}_id", f"{singular}_id", "id"):
            return True
    return False

def infer_fk(table_name, col_name, all_table_names):
    """Return True if column looks like a foreign key to another table."""
    if not col_name.endswith("_id"):
        return False
    # Check if the prefix matches another table name
    prefix = col_name[:-3]  # strip '_id'
    for other in all_table_names:
        if other == table_name:
            continue
        if other == prefix or other.rstrip("s") == prefix or prefix == other.rstrip("s"):
            return True
    return False

# COMMAND ----------
# ── Step 4: Build per-table summaries ────────────────────────────────────────
# MAGIC %md ## Step 4 — Gather row counts and sample stats

table_stats = {}
for tbl in selected_tables:
    try:
        stats = spark.sql(f"""
            SELECT
                COUNT(*) AS row_count,
                COUNT(DISTINCT *) AS approx_distinct
            FROM `{CATALOG}`.`{SCHEMA}`.`{tbl}`
        """).collect()[0]
        table_stats[tbl] = {"row_count": stats.row_count}
    except Exception as e:
        table_stats[tbl] = {"row_count": "N/A (no SELECT access)"}

for tbl, stats in table_stats.items():
    print(f"  {tbl}: {stats['row_count']:,} rows" if isinstance(stats['row_count'], int) else f"  {tbl}: {stats['row_count']}")

# COMMAND ----------
# ── Step 5: Generate spec.md output ──────────────────────────────────────────
# MAGIC %md ## Step 5 — Generated spec.md

import pandas as pd

col_rows = columns_df.toPandas()

def type_label(data_type, col_default, is_nullable):
    """Build a compact type string."""
    parts = [data_type.upper()]
    if col_default:
        parts.append(f"DEFAULT {col_default}")
    if is_nullable == "NO":
        parts.append("NOT NULL")
    return " ".join(parts)

def note_label(tbl, col, is_nullable, ordinal, all_tables, pk_map_local, fk_map_local):
    """Build annotation: PK, FK, nullable."""
    notes = []
    # Check explicit constraints first, then infer
    if col in pk_map_local.get(tbl, set()):
        notes.append("PK")
    elif not pk_map_local and infer_pk(tbl, col, is_nullable, ordinal):
        notes.append("PK (inferred)")

    if col in fk_map_local.get(tbl, set()):
        notes.append("FK")
    elif infer_fk(tbl, col, all_tables):
        notes.append("FK (inferred)")

    if is_nullable == "YES":
        notes.append("nullable")
    return ", ".join(notes) if notes else ""

spec_lines = []
spec_lines.append(f"# data_forge Spec — {CATALOG}.{SCHEMA}")
spec_lines.append("")
spec_lines.append("## Project")
spec_lines.append(f"- **Catalog:** {CATALOG}")
spec_lines.append(f"- **Schema:** {SCHEMA}")
spec_lines.append(f"- **Domain:** (describe your business domain here)")
spec_lines.append(f"- **Golden record entity:** (which table is your primary entity?)")
spec_lines.append("")
spec_lines.append("## What I need")
spec_lines.append("- Detect all PII and sensitive columns")
spec_lines.append("- Find how all tables join together")
spec_lines.append("- Generate full profiling SQL")
spec_lines.append("- Score data quality")
spec_lines.append("- Generate a data catalog")
spec_lines.append("")
spec_lines.append("---")
spec_lines.append("")
spec_lines.append("## Tables")
spec_lines.append("")

for tbl in selected_tables:
    tbl_cols = col_rows[col_rows["table_name"] == tbl].sort_values("ordinal_position")
    row_count = table_stats.get(tbl, {}).get("row_count", "unknown")
    count_str = f"{row_count:,}" if isinstance(row_count, int) else str(row_count)

    spec_lines.append(f"### {tbl}")
    spec_lines.append(f"Source table `{CATALOG}`.`{SCHEMA}`.`{tbl}` — approximately {count_str} rows.")
    spec_lines.append("(Add a description: what does this table contain? Where does the data come from?)")
    spec_lines.append("")
    spec_lines.append("| Column | Type | Notes |")
    spec_lines.append("|--------|------|-------|")

    for _, row in tbl_cols.iterrows():
        col  = row["column_name"]
        dtype = type_label(row["data_type"], row["column_default"], row["is_nullable"])
        note  = note_label(tbl, col, row["is_nullable"], row["ordinal_position"],
                           selected_tables, pk_map, fk_map)
        comment = row["comment"] if row["comment"] and str(row["comment"]) != "None" else ""
        note_full = " | ".join(filter(None, [note, comment]))
        spec_lines.append(f"| `{col}` | {dtype} | {note_full} |")

    spec_lines.append("")

spec_output = "\n".join(spec_lines)
print(spec_output)

# COMMAND ----------
# ── Step 6: Generate DDL SQL output (optional) ───────────────────────────────
# MAGIC %md ## Step 6 — Generated DDL SQL

if OUTPUT_FORMAT in ("ddl_sql", "both"):
    ddl_lines = []
    for tbl in selected_tables:
        tbl_cols = col_rows[col_rows["table_name"] == tbl].sort_values("ordinal_position")

        ddl_lines.append(f"-- ── {tbl} ──────────────────────────────────────────────────────────────")
        ddl_lines.append(f"CREATE TABLE `{CATALOG}`.`{SCHEMA}`.`{tbl}`")
        ddl_lines.append("(")

        col_defs = []
        pk_cols  = []
        for _, row in tbl_cols.iterrows():
            col   = row["column_name"]
            dtype = row["data_type"].upper()
            null  = "" if row["is_nullable"] == "YES" else " NOT NULL"
            dflt  = f" DEFAULT {row['column_default']}" if row["column_default"] else ""
            comment = f"  -- {row['comment']}" if row["comment"] and str(row["comment"]) != "None" else ""
            col_defs.append(f"    `{col}` {dtype}{null}{dflt}{comment}")

            if col in pk_map.get(tbl, set()) or (not pk_map and infer_pk(tbl, col, row["is_nullable"], row["ordinal_position"])):
                pk_cols.append(col)

        if pk_cols:
            col_defs.append(f"    PRIMARY KEY ({', '.join('`'+c+'`' for c in pk_cols)})")

        ddl_lines.append(",\n".join(col_defs))
        ddl_lines.append(")")
        ddl_lines.append("USING DELTA;")
        ddl_lines.append("")

    ddl_output = "\n".join(ddl_lines)
    print(ddl_output)

# COMMAND ----------
# ── Step 7: Save spec section to DBFS for download ───────────────────────────
# MAGIC %md ## Step 7 — Save outputs

import json
from datetime import datetime

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
output_path = f"/tmp/dataforge_schema_{CATALOG}_{SCHEMA}_{timestamp}"

# Save spec.md section
dbutils.fs.put(f"{output_path}/spec_section.md", spec_output, overwrite=True)
print(f"spec.md section saved to: {output_path}/spec_section.md")

# Save column metadata as JSON (useful for debugging)
schema_json = {}
for tbl in selected_tables:
    tbl_cols = col_rows[col_rows["table_name"] == tbl].sort_values("ordinal_position")
    schema_json[tbl] = {
        "row_count": table_stats.get(tbl, {}).get("row_count"),
        "columns": [
            {
                "name":       row["column_name"],
                "type":       row["data_type"],
                "nullable":   row["is_nullable"] == "YES",
                "default":    row["column_default"],
                "comment":    row["comment"],
                "is_pk":      row["column_name"] in pk_map.get(tbl, set()),
                "is_fk":      row["column_name"] in fk_map.get(tbl, set()),
            }
            for _, row in tbl_cols.iterrows()
        ]
    }
dbutils.fs.put(f"{output_path}/schema.json", json.dumps(schema_json, indent=2, default=str), overwrite=True)
print(f"Schema JSON saved to:     {output_path}/schema.json")

if OUTPUT_FORMAT in ("ddl_sql", "both"):
    dbutils.fs.put(f"{output_path}/schema.sql", ddl_output, overwrite=True)
    print(f"DDL SQL saved to:         {output_path}/schema.sql")

print(f"\nDownload files:")
print(f"  %sh cp /dbfs{output_path}/spec_section.md /databricks/driver/spec_section.md")
print(f"  Then: Files → Download from driver node")

# COMMAND ----------
# MAGIC %md
# MAGIC ---
# MAGIC ## Next steps
# MAGIC
# MAGIC 1. **Copy** the output from Step 5 above into `spec.md` in your VS Code project
# MAGIC 2. **Add context** to each table description (what it contains, where it comes from)
# MAGIC 3. **Note any joins** you know about (e.g. "orders.customer_id → customers.customer_id")
# MAGIC 4. **Open Copilot Chat** in VS Code and run:
# MAGIC    ```
# MAGIC    #file:agents/data_forge.md  #file:specs/eda/{pipeline_name}/spec.md
# MAGIC    Run data_forge on my spec
# MAGIC    ```
