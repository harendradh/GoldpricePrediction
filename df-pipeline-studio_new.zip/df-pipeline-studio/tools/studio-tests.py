#!/usr/bin/env python3
"""
Data Factory Pipeline Studio · test suite (Python port)
──────────────────────────────────────────────
Runs the studio's pure deterministic logic against fixtures + asserts.

Usage:
    python tools/studio-tests.py

The functions below are Python ports of the same logic in tools/data-factory-pipeline-studio.html.
They share regex patterns + string algorithms verbatim. If both this suite
and studio-tests.js (Node port) agree, the studio's algorithms are correct.

Exit code: 0 on full pass, 1 on any failure.
"""

import json
import re
import sys
from typing import List, Dict, Optional

# Force UTF-8 stdout (Windows cp1252 can't render the suite banners otherwise).
try:
    sys.stdout.reconfigure(encoding='utf-8')
except Exception:
    pass

# ══════════════════════════════════════════════════════════════════════════
# PURE FUNCTIONS (port of data-factory-pipeline-studio.html)
# ══════════════════════════════════════════════════════════════════════════

def slugify(s) -> str:
    s = str(s if s is not None else 'unnamed').lower().strip()
    s = re.sub(r'[^a-z0-9_]+', '_', s)   # non-alphanumeric → _
    s = re.sub(r'_+', '_', s)            # collapse consecutive underscores
    s = re.sub(r'^_+|_+$', '', s)        # trim
    return s or 'unnamed'

def spec_path(phase, name):                return f'specs/{phase}/{slugify(name)}/spec.md'
def output_dir(phase, name):               return f'output/{phase}/{slugify(name)}/'
def output_configs_dir(phase, name):       return output_dir(phase, name) + 'configs/'
# output_runners_dir removed — runners/ dir is no longer produced by any agent
def output_reports_dir(phase, name):       return output_dir(phase, name) + 'reports/'
def output_sql_dir(phase, name):           return output_dir(phase, name) + 'sql/'
def output_notebooks_dir(phase, name):     return output_dir(phase, name) + 'notebooks/'


def parse_columns(text: str) -> List[Dict]:
    if not text or not text.strip():
        return []
    # Try JSON first
    try:
        j = json.loads(text)
        if isinstance(j, list):
            out = []
            for i, c in enumerate(j):
                out.append({
                    'name': c.get('name') or c.get('column') or c.get('col') or f'col_{i+1}',
                    'type': (c.get('type') or c.get('dtype') or 'STRING').upper(),
                    'nullable': c.get('nullable') is not False and not c.get('notnull') and not c.get('not_null'),
                    'position': i + 1,
                })
            return out
        if isinstance(j, dict) and isinstance(j.get('columns'), list):
            return parse_columns(json.dumps(j['columns']))
    except Exception:
        pass
    lines = [l.strip() for l in re.split(r'[\n;]', text) if l.strip()]
    cols = []
    for line in lines:
        if re.match(r'^create\s+table', line, re.I):
            continue
        if re.match(r'^[()]+$', line):
            continue
        line = re.sub(r'^\(+|\)+,?$', '', line).strip()
        if not line:
            continue
        parts = line.split()
        if not parts:
            continue
        name = re.sub(r'[`",]', '', parts[0])
        if not re.match(r'^[A-Za-z_][\w]*$', name):
            continue
        col_type = 'STRING'
        if len(parts) > 1:
            col_type = re.sub(r'[(),]', '', parts[1]).upper()
        not_null = bool(re.search(r'not\s*null', line, re.I))
        cols.append({
            'name': name, 'type': col_type,
            'nullable': not not_null, 'position': len(cols) + 1
        })
    return cols


def parse_columns_from_query(sql: str) -> List[Dict]:
    if not sql or not sql.strip():
        return []
    s = re.sub(r'/\*[\s\S]*?\*/', ' ', sql)
    s = re.sub(r'--[^\n]*', ' ', s)
    m = re.search(r'SELECT\s+(?:DISTINCT\s+|TOP\s+\d+\s+)?([\s\S]+?)\s+FROM\s', s, re.I)
    if not m:
        return []
    list_str = m.group(1)
    parts, buf, depth = [], '', 0
    for ch in list_str:
        if ch == '(':
            depth += 1
        elif ch == ')':
            depth -= 1
        if ch == ',' and depth == 0:
            parts.append(buf)
            buf = ''
            continue
        buf += ch
    if buf.strip():
        parts.append(buf)
    out = []
    for i, raw in enumerate(parts):
        p = raw.strip()
        if not p or p == '*':
            continue
        alias = None
        as_match = re.search(r'\s+AS\s+(["`]?)([A-Za-z_][\w]*)\1\s*$', p, re.I)
        if as_match:
            alias = as_match.group(2)
            p = p[:as_match.start()]
        else:
            trail = re.search(r'\s+(["`]?)([A-Za-z_][\w]*)\1\s*$', p)
            if trail and re.search(r'[()+\-*/]', p[:trail.start()]):
                alias = trail.group(2)
                p = p[:trail.start()]
        name = alias
        if not name:
            dot = re.search(r'([A-Za-z_][\w]*)\s*$', p)
            name = dot.group(1) if dot else f'col_{i+1}'
        out.append({'name': name, 'type': 'STRING', 'nullable': True, 'position': i + 1})
    return out


def detect_pk(cols: List[Dict]) -> Optional[str]:
    exact = next((c for c in cols if re.search(r'(^|_)id$', c['name'], re.I) or re.match(r'^id$', c['name'], re.I)), None)
    if exact:
        return exact['name']
    nn = next((c for c in cols if c.get('nullable') is False), None)
    if nn:
        return nn['name']
    return cols[0]['name'] if cols else None


def classify_columns(cols: List[Dict]) -> List[Dict]:
    classified = []
    for c in cols:
        n = (c.get('name') or '').lower()
        t = (c.get('type') or 'STRING').upper()
        tags = set()
        if re.match(r'^id$', n) or re.search(r'(_id|_key|_uuid|_guid)$', n) or re.match(r'^(uuid|guid)$', n):
            tags.add('id')
        if re.match(r'^(first[_ ]?name|fname|given[_ ]?name|forename)$', n):    tags.update({'name','first_name'})
        elif re.match(r'^(last[_ ]?name|lname|surname|family[_ ]?name)$', n):   tags.update({'name','last_name'})
        elif re.match(r'^(middle[_ ]?name|mname|middle[_ ]?initial|mi)$', n):   tags.update({'name','middle_name'})
        elif re.match(r'^(full[_ ]?name|display[_ ]?name|business[_ ]?name|company[_ ]?name|legal[_ ]?name)$', n): tags.update({'name','full_name'})
        elif re.search(r'(_name$|^name$)', n):                                  tags.add('name')
        if re.search(r'email', n):                                                tags.update({'email','contact','pii'})
        if re.search(r'(phone|mobile|cell|telephone|^tel$|fax|whatsapp)', n):     tags.update({'phone','contact','pii'})
        if re.search(r'(address|addr|street|line_?\d|premise)', n):               tags.update({'address','street'})
        if re.match(r'^(city|town|locality|municipality)$', n):                   tags.update({'address','city'})
        if re.match(r'^(state|province|region|state_code|administrative_area)$', n): tags.update({'address','state'})
        if re.search(r'(zip|postal|postcode|pincode|pin_code)', n):               tags.update({'address','postal'})
        if re.search(r'(^country|nation|country_code|country_name)', n):          tags.update({'address','country'})
        if re.match(r'^(lat|latitude)$', n):                                      tags.update({'geo','lat'})
        if re.match(r'^(lon|lng|longitude)$', n):                                 tags.update({'geo','lng'})
        if re.search(r'(TIMESTAMP|DATETIME|^DATE$|^TIME$)', t):                   tags.add('datetime')
        if re.search(r'(_at|_date|_ts|_time|_dt|_dttm)$', n) or re.match(r'^(date|time|timestamp)$', n): tags.add('datetime')
        if re.search(r'(created|inserted|added|opened|start)', n) and 'datetime' in tags:                tags.add('created_ts')
        if re.search(r'(updated|modified|changed|last_update|last_modified|refresh)', n) and 'datetime' in tags: tags.add('updated_ts')
        if re.search(r'(closed|terminated|ended|expir)', n) and 'datetime' in tags:                      tags.add('end_ts')
        if re.search(r'(dob|date_of_birth|birth_date|birthdate)', n):             tags.update({'datetime','dob','pii'})
        if re.search(r'(DECIMAL|NUMERIC|MONEY|FLOAT|DOUBLE|REAL)', t):            tags.add('numeric')
        if re.search(r'(^INT|BIGINT|SMALLINT|TINYINT|LONG|^INTEGER)', t):         tags.add('numeric')
        if re.search(r'(amount|amt|balance|price|total|salary|cost|fee|payment|charge|premium|value|revenue|income|debit|credit|deposit|withdrawal)', n):
            tags.update({'money','numeric'})
        if re.match(r'^(status|state|type|kind|category|class|code|tier|rank|grade|level|segment)$', n) \
           or re.search(r'(_status|_code|_type|_class|_category|_tier|_grade|_segment)$', n):
            tags.add('categorical')
        if re.search(r'(BOOLEAN|BOOL|BIT)', t):                                   tags.add('boolean')
        if re.match(r'^(is_|has_|can_|should_|will_)', n) or re.search(r'(_flag|_ind|_indicator|_y_n|_yn)$', n): tags.add('boolean')
        if re.search(r'(^ssn$|social_security|^sin$|nat_id|national_id)', n):     tags.update({'pii','gov_id'})
        if re.search(r'(tax_id|ein|^itin$|tin)', n):                              tags.update({'pii','gov_id'})
        if re.search(r'(card_num|cc_num|^pan$|^iban$|^cvv$|cvc|card_number)', n): tags.update({'pii','financial_id'})
        if re.search(r'(account_num|acct_num|routing|aba|swift)', n):             tags.update({'pii','financial_id'})
        if re.search(r'(passport|driver_lic|drivers_lic|drivers_license|license_num)', n): tags.update({'pii','doc_id'})
        if re.search(r'(gender|race|ethnic|marital|nationality)', n):             tags.add('demographic')
        if re.search(r'(salary|income|wage|net_worth)', n):                       tags.add('sensitive_financial')
        if re.search(r'(description|^desc$|notes?|comments?|remarks?|summary|memo|message|narrative)', n):
            tags.update({'text','freetext'})
        classified.append({**c, 'tags': sorted(tags)})
    # Mark PK
    pk = next((c for c in classified if 'id' in c['tags'] and c.get('nullable') is False), None) \
       or next((c for c in classified if 'id' in c['tags']), None) \
       or next((c for c in classified if c.get('nullable') is False), None) \
       or (classified[0] if classified else None)
    if pk:
        pk['tags'] = sorted(set(pk['tags']) | {'pk'})
    return classified


def detect_address_map(classified):
    streets = [c['name'] for c in classified if 'street' in c['tags']]
    def find_one(tag):
        c = next((c for c in classified if tag in c['tags']), None)
        return c['name'] if c else None
    return {
        'line_1': streets[0] if streets else None,
        'line_2': streets[1] if len(streets) > 1 else None,
        'city': find_one('city'),
        'state': find_one('state'),
        'postal_code': find_one('postal'),
        'country': find_one('country'),
    }


def build_expectations(classified):
    exp, n = [], 1
    def gid(rule, col):
        nonlocal n
        s = f'e{n:02d}_{rule}_{col}'[:80]
        n += 1
        return s
    pk = next((c for c in classified if 'pk' in c['tags']), None)
    if pk:
        exp.append({'id': gid('not_null', pk['name']), 'column': pk['name'], 'rule': 'not_null', 'threshold': 1.0, 'severity': 'CRITICAL', 'args': {}, 'action': 'fail'})
        exp.append({'id': gid('unique',   pk['name']), 'column': pk['name'], 'rule': 'unique',   'threshold': 1.0, 'severity': 'CRITICAL', 'args': {}, 'action': 'fail'})
    for c in classified:
        t = c['tags']
        if 'email' in t:       exp.append({'id': gid('regex', c['name']), 'column': c['name'], 'rule': 'regex', 'threshold': 0.95, 'args': {'pattern': r'^[^@]+@[^@]+\.[^@]+$'}, 'severity': 'HIGH', 'action': 'warn_only'})
        if 'phone' in t:       exp.append({'id': gid('length', c['name']), 'column': c['name'], 'rule': 'length_between', 'threshold': 0.90, 'args': {'min': 7, 'max': 15}, 'severity': 'HIGH', 'action': 'warn_only'})
        if 'country' in t:     exp.append({'id': gid('in_set', c['name']), 'column': c['name'], 'rule': 'in_set', 'threshold': 0.99, 'args': {'values': ['US','CA','GB','IN','AU','MX','DE','FR']}, 'severity': 'WARN', 'action': 'warn_only'})
        if 'postal' in t:      exp.append({'id': gid('length', c['name']), 'column': c['name'], 'rule': 'length_between', 'threshold': 0.95, 'args': {'min': 3, 'max': 10}, 'severity': 'INFO', 'action': 'warn_only'})
        if 'state' in t:       exp.append({'id': gid('length', c['name']), 'column': c['name'], 'rule': 'length_between', 'threshold': 0.95, 'args': {'min': 2, 'max': 40}, 'severity': 'INFO', 'action': 'warn_only'})
        if 'money' in t:       exp.append({'id': gid('value',  c['name']), 'column': c['name'], 'rule': 'value_between', 'threshold': 0.99, 'args': {'min': 0, 'max': 1e12}, 'severity': 'HIGH', 'action': 'warn_only'})
        if 'boolean' in t:     exp.append({'id': gid('boolset',c['name']), 'column': c['name'], 'rule': 'in_set', 'threshold': 1.0, 'args': {'values': [True, False, 'true', 'false', 'Y', 'N', '0', '1']}, 'severity': 'INFO', 'action': 'warn_only'})
        if 'categorical' in t: exp.append({'id': gid('distinct',c['name']),'column': c['name'], 'rule': 'distinct_count_less_than', 'threshold': 1.0, 'args': {'max': 200}, 'severity': 'INFO', 'action': 'warn_only'})
        if 'datetime' in t and 'end_ts' not in t: exp.append({'id': gid('not_future', c['name']), 'column': c['name'], 'rule': 'not_in_future', 'threshold': 1.0, 'args': {}, 'severity': 'HIGH', 'action': 'warn_only'})
        if 'dob' in t:         exp.append({'id': gid('dob_range', c['name']), 'column': c['name'], 'rule': 'value_between', 'threshold': 1.0, 'args': {'min': '1900-01-01', 'max': 'CURRENT_DATE'}, 'severity': 'HIGH', 'action': 'warn_only'})
    exp.append({'id': f'e{n:02d}_row_count_min', 'column': '*', 'rule': 'row_count_min', 'threshold': 1.0, 'args': {'min': 1}, 'severity': 'CRITICAL', 'action': 'fail'})
    return exp


def build_transforms(classified):
    tx, n = [], 1
    def tid(op, col):
        nonlocal n
        s = f't{n:02d}_{op}_{col}'[:80]
        n += 1
        return s
    for c in classified:
        t = c['tags']
        if any(x in t for x in ('name','street','city','state','country','postal','freetext','categorical')):
            tx.append({'id': tid('trim', c['name']), 'op': 'trim', 'columns': [c['name']], 'args': {'side': 'both'}, 'on_error': 'skip_row'})
        if 'email' in t:
            tx.append({'id': tid('lower', c['name']), 'op': 'lower', 'columns': [c['name']], 'args': {}, 'on_error': 'null_out'})
        if 'country' in t or 'state' in t:
            tx.append({'id': tid('upper', c['name']), 'op': 'upper', 'columns': [c['name']], 'args': {}, 'on_error': 'null_out'})
        if 'phone' in t:
            tx.append({'id': tid('regex', c['name']), 'op': 'regex_replace', 'columns': [c['name']], 'args': {'pattern': '[^0-9+]', 'replacement': ''}, 'on_error': 'null_out'})
        if 'datetime' in t and 'TIMESTAMP' not in (c.get('type') or '').upper():
            tx.append({'id': tid('cast', c['name']), 'op': 'cast', 'columns': [c['name']], 'args': {'target_type': 'TIMESTAMP'}, 'on_error': 'null_out'})
        if any(x in t for x in ('gov_id','financial_id','doc_id')):
            tx.append({'id': tid('mask', c['name']), 'op': 'mask', 'columns': [c['name']], 'args': {'method': 'sha2_256'}, 'on_error': 'fail'})
        if 'dob' in t:
            tx.append({'id': tid('mask', c['name']), 'op': 'mask', 'columns': [c['name']], 'args': {'method': 'truncate_date', 'precision': 'year'}, 'on_error': 'fail'})
    pk = next((c for c in classified if 'pk' in c['tags']), None)
    if pk:
        tx.append({'id': tid('drop_null_pk', pk['name']), 'op': 'drop_rows', 'columns': [pk['name']], 'args': {'where': f"{pk['name']} IS NULL"}, 'on_error': 'fail'})
    return tx


def classify_summary(classified):
    if not classified:
        return None
    def has(tag): return sum(1 for c in classified if tag in c['tags'])
    return {
        'total': len(classified), 'pk': has('pk'), 'id': has('id'), 'pii': has('pii'),
        'address': has('address'), 'datetime': has('datetime'), 'money': has('money'),
        'categorical': has('categorical'), 'boolean': has('boolean'), 'name': has('name'),
        'contact': has('contact'), 'numeric': has('numeric'), 'freetext': has('freetext'),
    }


def detect_domain(classified):
    if not classified:
        return None
    names = ' '.join(c['name'].lower() for c in classified)
    if re.search(r'(kyc|aml|customer|account|balance|txn|merchant|premium|policy|claim|loan|card_num|routing|iban)', names): return 'banking'
    if re.search(r'(patient|mrn|diagnosis|icd|provider|prescription|insurance)', names): return 'healthcare'
    if re.search(r'(employee|salary|hire_date|department|payroll|benefit)', names): return 'HR'
    if re.search(r'(order|product|sku|cart|inventory|warehouse|shipment)', names): return 'retail'
    return 'generic'


def simple_diff(a, b):
    aL, bL = (a or '').split('\n'), (b or '').split('\n')
    aS, bS = set(aL), set(bL)
    added = sum(1 for l in bL if l not in aS and l.strip())
    removed = sum(1 for l in aL if l not in bS and l.strip())
    return {'added': added, 'removed': removed}


# ══════════════════════════════════════════════════════════════════════════
# TEST FRAMEWORK
# ══════════════════════════════════════════════════════════════════════════

class C:
    R = '\x1b[31m'; G = '\x1b[32m'; Y = '\x1b[33m'; D = '\x1b[2m'; B = '\x1b[1m'; X = '\x1b[0m'

passed = 0
failed = 0
suite_count = 0
failures = []
current_suite = ''

def suite(name):
    global current_suite, suite_count
    current_suite = name
    suite_count += 1
    print(f'\n{C.B}━━ {name} ━━{C.X}')

def test(name, fn):
    global passed, failed
    try:
        fn()
        passed += 1
        print(f'  {C.G}✓{C.X} {name}')
    except AssertionError as e:
        failed += 1
        failures.append((current_suite, name, str(e)))
        print(f'  {C.R}✗{C.X} {name}\n    {C.R}{e}{C.X}')
    except Exception as e:
        failed += 1
        failures.append((current_suite, name, f'{type(e).__name__}: {e}'))
        print(f'  {C.R}✗{C.X} {name}\n    {C.R}{type(e).__name__}: {e}{C.X}')

def eq(actual, expected, msg=''):
    if actual != expected:
        prefix = (msg + '\n') if msg else ''
        raise AssertionError(f'{prefix}expected: {expected!r}\n     got: {actual!r}')

def ok(cond, msg='expected truthy'):
    if not cond:
        raise AssertionError(msg)

# ══════════════════════════════════════════════════════════════════════════
# TEST SUITES
# ══════════════════════════════════════════════════════════════════════════

suite('slugify')
test('lowercases',                 lambda: eq(slugify('Customer'),           'customer'))
test('replaces spaces with _',     lambda: eq(slugify('customer master'),    'customer_master'))
test('replaces dashes with _',     lambda: eq(slugify('customer-master'),    'customer_master'))
test('strips special chars',       lambda: eq(slugify('Customer/Master 2!'), 'customer_master_2'))
test('handles empty → unnamed',    lambda: eq(slugify(''),                   'unnamed'))
test('handles None → unnamed',     lambda: eq(slugify(None),                 'unnamed'))
test('trims leading/trailing _',   lambda: eq(slugify('  __weird__  '),      'weird'))
test('collapses consecutive _',    lambda: eq(slugify('a___b---c'),          'a_b_c'))

suite('path helpers')
test('specPath dataprep',          lambda: eq(spec_path('dataprep','Cust Master'),  'specs/dataprep/cust_master/spec.md'))
test('specPath ingestion',         lambda: eq(spec_path('ingestion','customer_v2'), 'specs/ingestion/customer_v2/spec.md'))
test('outputDir',                  lambda: eq(output_dir('dataprep','x'),            'output/dataprep/x/'))
test('outputConfigsDir',           lambda: eq(output_configs_dir('dataprep','x'),    'output/dataprep/x/configs/'))
test('outputReportsDir',           lambda: eq(output_reports_dir('eda','z'),         'output/eda/z/reports/'))
test('outputSqlDir',               lambda: eq(output_sql_dir('eda','z'),             'output/eda/z/sql/'))
test('outputNotebooksDir',         lambda: eq(output_notebooks_dir('eda','z'),       'output/eda/z/notebooks/'))

suite('parseColumns')
def t_ddl():
    cols = parse_columns('customer_id  STRING  NOT NULL\nemail  STRING')
    eq(len(cols), 2)
    eq(cols[0], {'name':'customer_id','type':'STRING','nullable':False,'position':1})
    eq(cols[1], {'name':'email','type':'STRING','nullable':True,'position':2})
test('parses DDL with NOT NULL',   t_ddl)
def t_json():
    cols = parse_columns('[{"name":"id","type":"BIGINT","nullable":false}]')
    eq(len(cols), 1); eq(cols[0]['name'], 'id'); eq(cols[0]['nullable'], False)
test('parses JSON array',          t_json)
def t_json_wrap():
    cols = parse_columns('{"columns":[{"name":"a"},{"name":"b"}]}')
    eq(len(cols), 2)
test('parses JSON object with columns', t_json_wrap)
def t_ct():
    cols = parse_columns('CREATE TABLE foo (\n  a STRING,\n  b INT\n)')
    eq(len(cols), 2); eq(cols[0]['name'], 'a'); eq(cols[1]['name'], 'b')
test('skips CREATE TABLE wrapper', t_ct)
test('handles empty input',        lambda: eq(parse_columns(''), []))
test('handles whitespace-only',    lambda: eq(parse_columns('   \n   '), []))
test('uppercase the type',         lambda: eq([c['type'] for c in parse_columns('a string')], ['STRING']))

suite('parseColumnsFromQuery')
test('simple SELECT',              lambda: eq([c['name'] for c in parse_columns_from_query('SELECT a, b, c FROM t')], ['a','b','c']))
test('SELECT with table prefix',   lambda: eq([c['name'] for c in parse_columns_from_query('SELECT t.a, t.b FROM t')], ['a','b']))
test('SELECT with AS alias',       lambda: eq([c['name'] for c in parse_columns_from_query('SELECT TRIM(name) AS clean_name, LOWER(email) AS email FROM t')], ['clean_name','email']))
test('SELECT with JOIN',           lambda: eq([c['name'] for c in parse_columns_from_query('SELECT c.id, c.name, a.city FROM customers c JOIN addresses a ON c.id = a.cid')], ['id','name','city']))
test('handles function commas',    lambda: eq([c['name'] for c in parse_columns_from_query('SELECT COALESCE(a, b, c) AS final, x FROM t')], ['final','x']))
test('strips line + block comments', lambda: eq([c['name'] for c in parse_columns_from_query('SELECT a, /* comment */ b, -- inline\n c FROM t')], ['a','b','c']))
test('handles DISTINCT',           lambda: eq([c['name'] for c in parse_columns_from_query('SELECT DISTINCT a, b FROM t')], ['a','b']))
test('empty for missing FROM',     lambda: eq(parse_columns_from_query('SELECT a, b'), []))

suite('detectPK')
test('picks *_id column',          lambda: eq(detect_pk([{'name':'name'},{'name':'customer_id'},{'name':'email'}]), 'customer_id'))
test('picks bare "id"',            lambda: eq(detect_pk([{'name':'id'},{'name':'x'}]), 'id'))
test('falls back to NOT NULL',     lambda: eq(detect_pk([{'name':'a','nullable':True},{'name':'b','nullable':False}]), 'b'))
test('falls back to first column', lambda: eq(detect_pk([{'name':'a','nullable':True},{'name':'b','nullable':True}]), 'a'))
test('returns None for empty',     lambda: eq(detect_pk([]), None))

# === classifyColumns === #
suite('classifyColumns')
ddl = """customer_id    STRING   NOT NULL
first_name     STRING
last_name      STRING
email          STRING
phone          STRING
address_line_1 STRING
city           STRING
state          STRING
zip            STRING
country        STRING
ssn            STRING
date_of_birth  DATE
account_balance DECIMAL
account_status STRING
is_active      BOOLEAN
created_at     TIMESTAMP
updated_at     TIMESTAMP"""
cls = classify_columns(parse_columns(ddl))
summary = classify_summary(cls)

def find_tags(name): return next(c for c in cls if c['name'] == name)['tags']

test('tags customer_id as pk + id',         lambda: ok('pk' in find_tags('customer_id') and 'id' in find_tags('customer_id')))
test('tags email as pii + email + contact', lambda: ok({'email','pii','contact'}.issubset(set(find_tags('email')))))
test('tags ssn as pii + gov_id',            lambda: ok({'pii','gov_id'}.issubset(set(find_tags('ssn')))))
test('tags account_balance as money',       lambda: ok({'money','numeric'}.issubset(set(find_tags('account_balance')))))
test('tags is_active as boolean',           lambda: ok('boolean' in find_tags('is_active')))
test('tags created_at as datetime+created_ts', lambda: ok({'datetime','created_ts'}.issubset(set(find_tags('created_at')))))
test('tags date_of_birth as dob + pii',     lambda: ok({'dob','pii'}.issubset(set(find_tags('date_of_birth')))))
test('tags address columns correctly',      lambda: ok(
    'street'  in find_tags('address_line_1') and
    'city'    in find_tags('city') and
    'state'   in find_tags('state') and
    'postal'  in find_tags('zip') and
    'country' in find_tags('country')
))
def t_summary():
    ok(summary['total'] == 17, f'total was {summary["total"]}')
    ok(summary['pk'] == 1)
    ok(summary['pii'] >= 3, f'pii was {summary["pii"]}')
    ok(summary['address'] == 5, f'address was {summary["address"]}')
    ok(summary['datetime'] >= 3, f'datetime was {summary["datetime"]}')
test('classifySummary counts',               t_summary)

suite('detectAddressMap')
def t_addr_full():
    c = classify_columns(parse_columns('address_line_1 STRING\naddress_line_2 STRING\ncity STRING\nstate STRING\nzip STRING\ncountry STRING'))
    eq(detect_address_map(c), {'line_1':'address_line_1','line_2':'address_line_2','city':'city','state':'state','postal_code':'zip','country':'country'})
test('full address set',  t_addr_full)
def t_addr_partial():
    c = classify_columns(parse_columns('street STRING\ncity STRING\nstate STRING\nzip STRING'))
    m = detect_address_map(c)
    ok(m['line_1'] == 'street'); eq(m['line_2'], None); eq(m['country'], None)
test('partial address',   t_addr_partial)
def t_addr_none():
    c = classify_columns(parse_columns('id STRING\nname STRING'))
    eq(detect_address_map(c), {'line_1':None,'line_2':None,'city':None,'state':None,'postal_code':None,'country':None})
test('no address',        t_addr_none)

suite('buildExpectations')
exp_cls = classify_columns(parse_columns('customer_id STRING NOT NULL\nemail STRING\ncountry STRING\namount DECIMAL\ncreated_at TIMESTAMP'))
exp = build_expectations(exp_cls)
test('PK not_null + unique',           lambda: ok(any(e['column']=='customer_id' and e['rule']=='not_null' for e in exp) and any(e['column']=='customer_id' and e['rule']=='unique' for e in exp)))
test('regex rule for email',           lambda: ok(any(e['column']=='email' and e['rule']=='regex' for e in exp)))
test('in_set rule for country',        lambda: ok(any(e['column']=='country' and e['rule']=='in_set' for e in exp)))
test('value_between for money',        lambda: ok(any(e['column']=='amount' and e['rule']=='value_between' for e in exp)))
test('not_in_future for datetime',     lambda: ok(any(e['column']=='created_at' and e['rule']=='not_in_future' for e in exp)))
test('row_count_min sentinel added',   lambda: ok(any(e['rule']=='row_count_min' for e in exp)))
def t_exp_shape():
    for e in exp:
        ok(isinstance(e['id'], str))
        ok(e['severity'] in ('CRITICAL','HIGH','WARN','INFO'))
        ok(e['action']   in ('fail','quarantine','warn_only'))
test('every expectation has required fields', t_exp_shape)

suite('buildTransforms')
tx_cls = classify_columns(parse_columns('id STRING NOT NULL\nfirst_name STRING\nemail STRING\nphone STRING\ncountry STRING\nssn STRING\ndate_of_birth DATE\ncreated_at TIMESTAMP'))
tx = build_transforms(tx_cls)
test('trim for name columns',          lambda: ok(any(t['op']=='trim' and 'first_name' in t['columns'] for t in tx)))
test('lower for email',                lambda: ok(any(t['op']=='lower' and 'email' in t['columns'] for t in tx)))
test('regex_replace for phone',        lambda: ok(any(t['op']=='regex_replace' and 'phone' in t['columns'] for t in tx)))
test('upper for country',              lambda: ok(any(t['op']=='upper' and 'country' in t['columns'] for t in tx)))
test('sha2_256 mask for ssn',          lambda: ok(any(t['op']=='mask' and 'ssn' in t['columns'] and t['args'].get('method')=='sha2_256' for t in tx)))
test('truncate_date mask for DOB',     lambda: ok(any(t['op']=='mask' and 'date_of_birth' in t['columns'] and t['args'].get('method')=='truncate_date' for t in tx)))
test('drop null PK row',               lambda: ok(any(t['op']=='drop_rows' and 'id' in t['columns'] for t in tx)))
test('no cast for existing TIMESTAMP', lambda: ok(not any(t['op']=='cast' and 'created_at' in t['columns'] for t in tx)))

suite('detectDomain')
test('banking',    lambda: eq(detect_domain(classify_columns(parse_columns('customer_id STRING\nkyc_status STRING\nbalance DECIMAL'))), 'banking'))
test('healthcare', lambda: eq(detect_domain(classify_columns(parse_columns('patient_id STRING\nmrn STRING\ndiagnosis STRING'))), 'healthcare'))
test('HR',         lambda: eq(detect_domain(classify_columns(parse_columns('employee_id STRING\nsalary DECIMAL\ndepartment STRING'))), 'HR'))
test('retail',     lambda: eq(detect_domain(classify_columns(parse_columns('order_id STRING\nproduct_id STRING\nsku STRING'))), 'retail'))
test('generic',    lambda: eq(detect_domain(classify_columns(parse_columns('foo STRING\nbar STRING'))), 'generic'))

suite('simpleDiff')
test('detects added lines',    lambda: eq(simple_diff('a\nb',     'a\nb\nc'),  {'added':1,'removed':0}))
test('detects removed lines',  lambda: eq(simple_diff('a\nb\nc',  'a\nb'),     {'added':0,'removed':1}))
test('no diff',                lambda: eq(simple_diff('a\nb',     'a\nb'),     {'added':0,'removed':0}))

# ══════════════════════════════════════════════════════════════════════════
# END-TO-END · realistic pipelines
# ══════════════════════════════════════════════════════════════════════════

def find_tags_in(classified, name):
    return next(c for c in classified if c['name'] == name)['tags']


suite('E2E · consumer_master ingestion bootstrap')
ingest_state = {
    'pipeline_name': 'consumer_master', 'domain': 'banking', 'subdomain': 'Consumer',
    'source_type': 'Oracle', 'catalog': 'cert_dcs_catalog', 'schema': 'bankcore_dna',
    'columns': """customer_id    STRING   NOT NULL
first_name     STRING
last_name      STRING
email          STRING
phone          STRING
ssn            STRING
date_of_birth  DATE
created_at     TIMESTAMP
updated_at     TIMESTAMP"""
}
ingest_cls = classify_columns(parse_columns(ingest_state['columns']))
ingest_sum = classify_summary(ingest_cls)
ingest_exp = build_expectations(ingest_cls)
ingest_cfg = output_configs_dir('ingestion', ingest_state['pipeline_name'])

test('parses 9 columns',              lambda: eq(len(ingest_cls), 9))
test('detects ≥3 PII',                lambda: ok(ingest_sum['pii'] >= 3))
test('detects PK = customer_id',      lambda: ok('pk' in find_tags_in(ingest_cls, 'customer_id')))
test('configs dir resolves correctly',lambda: eq(ingest_cfg, 'output/ingestion/consumer_master/configs/'))
test('PK expectations generated',     lambda: ok(any(e['column']=='customer_id' and e['rule']=='not_null' and e['severity']=='CRITICAL' for e in ingest_exp) and any(e['column']=='customer_id' and e['rule']=='unique' for e in ingest_exp)))
test('email regex expectation',       lambda: ok(any(e['column']=='email' and e['rule']=='regex' for e in ingest_exp)))
test('manifest file path',            lambda: eq(ingest_cfg + 'manifest.json', 'output/ingestion/consumer_master/configs/manifest.json'))
test('spec path correct',             lambda: eq(spec_path('ingestion', ingest_state['pipeline_name']), 'specs/ingestion/consumer_master/spec.md'))


suite('E2E · consumer_master_prep data-prep bootstrap')
dp_state = {
    'pipeline_name': 'consumer_master_prep', 'subdomain': 'Consumer',
    'catalog': 'cert_dcs_catalog', 'schema': 'bankcore_dna',
    'source_mode': 'table', 't_extract_in': 'consumer_master',
    'columns': """customer_id     STRING   NOT NULL
first_name      STRING
last_name       STRING
email           STRING
phone           STRING
address_line_1  STRING
address_line_2  STRING
city            STRING
state           STRING
zip             STRING
country         STRING
ssn             STRING
date_of_birth   DATE
account_balance DECIMAL
account_status  STRING
is_active       BOOLEAN
created_at      TIMESTAMP
updated_at      TIMESTAMP"""
}
dp_cls = classify_columns(parse_columns(dp_state['columns']))
dp_sum = classify_summary(dp_cls)
dp_addr = detect_address_map(dp_cls)
dp_tx = build_transforms(dp_cls)
dp_cfg = output_configs_dir('dataprep', dp_state['pipeline_name'])
dp_rep = output_reports_dir('dataprep', dp_state['pipeline_name'])

test('parses 18 columns',             lambda: eq(len(dp_cls), 18))
test('detects 6 address columns',     lambda: eq(dp_sum['address'], 6))
def t_dp_addr():
    eq(dp_addr['line_1'], 'address_line_1')
    eq(dp_addr['line_2'], 'address_line_2')
    eq(dp_addr['city'], 'city')
    eq(dp_addr['state'], 'state')
    eq(dp_addr['postal_code'], 'zip')
    eq(dp_addr['country'], 'country')
test('address map fully resolved',    t_dp_addr)
test('detects ≥4 PII columns',        lambda: ok(dp_sum['pii'] >= 4, f'pii was {dp_sum["pii"]}'))
test('configs/ subdir path',          lambda: eq(dp_cfg, 'output/dataprep/consumer_master_prep/configs/'))
test('reports/ subdir path',          lambda: eq(dp_rep, 'output/dataprep/consumer_master_prep/reports/'))
test('extraction config path',        lambda: eq(dp_cfg + 'extraction.json', 'output/dataprep/consumer_master_prep/configs/extraction.json'))
test('conversion config path',        lambda: eq(dp_cfg + 'conversion.json', 'output/dataprep/consumer_master_prep/configs/conversion.json'))
test('manifest path',                 lambda: eq(dp_cfg + 'manifest.json', 'output/dataprep/consumer_master_prep/configs/manifest.json'))
test('SSN sha2_256 masked',           lambda: ok(any(t['op']=='mask' and 'ssn' in t['columns'] and t['args'].get('method')=='sha2_256' for t in dp_tx)))
test('DOB truncate_date masked',      lambda: ok(any(t['op']=='mask' and 'date_of_birth' in t['columns'] and t['args'].get('method')=='truncate_date' for t in dp_tx)))
test('email lowered',                 lambda: ok(any(t['op']=='lower' and 'email' in t['columns'] for t in dp_tx)))
test('phone regex_replaced',          lambda: ok(any(t['op']=='regex_replace' and 'phone' in t['columns'] for t in dp_tx)))
test('null PK rows dropped',          lambda: ok(any(t['op']=='drop_rows' and 'customer_id' in t['columns'] for t in dp_tx)))
test('domain = banking',              lambda: eq(detect_domain(dp_cls), 'banking'))


suite('E2E · header_query source mode (EDA → DataPrep bridge)')
header_sql = """SELECT
  c.customer_id,
  c.first_name,
  c.last_name,
  LOWER(c.email) AS email,
  c.phone,
  a.address_line_1, a.city, a.state, a.zip, a.country,
  c.created_at, c.updated_at
FROM main.bronze.customers c
LEFT JOIN main.bronze.addresses a ON c.customer_id = a.customer_id AND a.is_primary = true"""
hq_cls = classify_columns(parse_columns_from_query(header_sql))
test('parses 12 columns from SQL',    lambda: eq(len(hq_cls), 12))
test('email alias picked',            lambda: ok(any(c['name']=='email' for c in hq_cls)))
def t_hq_addr():
    addr = detect_address_map(hq_cls)
    eq(addr['line_1'], 'address_line_1'); eq(addr['country'], 'country')
test('address columns flow through',  t_hq_addr)
test('PK detected from SQL columns',  lambda: ok('pk' in find_tags_in(hq_cls, 'customer_id')))


suite('E2E · ingestion without columns → profiler skipped')
empty_cols = parse_columns('')
test('no columns parsed',             lambda: eq(len(empty_cols), 0))
test('profiler would be disabled',    lambda: ok(len(empty_cols) == 0))

# ══════════════════════════════════════════════════════════════════════════
# SUMMARY
# ══════════════════════════════════════════════════════════════════════════

print(f'\n{C.B}━━ Summary ━━{C.X}')
print(f'  Suites:  {suite_count}')
print(f'  Passed:  {C.G}{passed}{C.X}')
print(f'  Failed:  {C.R if failed else C.D}{failed}{C.X}')

if failures:
    print(f'\n{C.B}Failures:{C.X}')
    for s, t, e in failures:
        first_line = e.split("\n")[0]
        print(f'  {C.R}✗{C.X} {s} › {t}\n    {C.D}{first_line}{C.X}')
    sys.exit(1)
else:
    print(f'\n  {C.G}{C.B}All tests passed ✓{C.X}\n')
    sys.exit(0)
