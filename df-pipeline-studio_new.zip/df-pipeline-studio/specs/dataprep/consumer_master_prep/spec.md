# data_prep Pipeline Spec — `consumer_master_prep`

## Pipeline metadata
```
pipeline_name:  consumer_master_prep
catalog:        cert_dcs_catalog
schema:         bankcore_dna
subdomain:      Consumer
source_mode:    input_table
```

## Source — Input Table
`cert_dcs_catalog.bankcore_dna.consumer_master_prep_bronze` is the input to Stage 1 (Data Extraction).

## Source columns (drive all six stages)
```
customer_id    STRING   NOT NULL
first_name     STRING
last_name      STRING
email          STRING
phone          STRING
address_line_1 STRING
city           STRING
state          STRING
zip            STRING
country        STRING
kyc_status     STRING
date_of_birth  DATE
ssn            STRING
created_at     TIMESTAMP
updated_at     TIMESTAMP
```

## Pipeline table chain

| # | Stage | Input | Output |
|---|-------|-------|--------|
| 1 | Data Extraction | `consumer_master_prep_bronze` | `consumer_master_prep_extracted` |
| 2 | Data Extraction Profiler | `consumer_master_prep_extracted` | `consumer_master_prep_extracted_profile` |
| 3 | Data Preparation | `consumer_master_prep_extracted` | `consumer_master_prep_prepped` |
| 4 | Address Standardization | `consumer_master_prep_prepped` | `consumer_master_prep_addr_std` |
| 5 | Address Std Profiler | `consumer_master_prep_addr_std` | `consumer_master_prep_addr_std_profile` |
| 6 | Data Conversion | `consumer_master_prep_addr_std` | `consumer_master_prep_master` |

## Stage 1 — Data Extraction
Extract from `cert_dcs_catalog.bankcore_dna.consumer_master_prep_bronze` → `cert_dcs_catalog.bankcore_dna.consumer_master_prep_extracted`.
Use the source-column list above for the extraction schema.

## Stage 2 — Data Extraction Profiler
Profile `cert_dcs_catalog.bankcore_dna.consumer_master_prep_extracted` → `cert_dcs_catalog.bankcore_dna.consumer_master_prep_extracted_profile`.
Auto-named with `_profile` suffix.

## Stage 3 — Data Preparation
Transform `cert_dcs_catalog.bankcore_dna.consumer_master_prep_extracted` → `cert_dcs_catalog.bankcore_dna.consumer_master_prep_prepped`.
Standard transforms: trim names, lower email, cast timestamps, drop null PK,
mask sensitive fields, dedupe by PK.

## Stage 4 — Address Standardization
Standardize address columns from `cert_dcs_catalog.bankcore_dna.consumer_master_prep_prepped` → `cert_dcs_catalog.bankcore_dna.consumer_master_prep_addr_std`.
Reference data: USPS for US, country dictionary for INT. Threshold 0.85.

## Stage 5 — Address Standardization Profiler
Profile `cert_dcs_catalog.bankcore_dna.consumer_master_prep_addr_std` → `cert_dcs_catalog.bankcore_dna.consumer_master_prep_addr_std_profile`.
Auto-named with `_profile` suffix. Compare pre vs post address columns.

## Stage 6 — Data Conversion
Write `cert_dcs_catalog.bankcore_dna.consumer_master_prep_addr_std` → `cert_dcs_catalog.bankcore_dna.consumer_master_prep_master`.
Final Delta target, MERGE on the primary key.
